空域知微 · 无人机射频感知识别与双站测向系统
代码交付版本：2026-11-04

复现入口：reproduce/README.md。相同芯片新硬件的接口移植清单：reproduce/HARDWARE.md。
启动文件与部署步骤：reproduce/BOARD.md；本轮实际结果见包根 reproduction_results/。
本工程基准实现采用 Zynq XC7Z045 + AD9361；采用相同 XC7Z045 芯片的新硬件可按清单适配
DDR、MIO、引脚/电平、时钟复位、RF、AXI/DMA、中断、设备树及启动组件，并在目标硬件验收。
本轮不接板，离线构建与回放的通过范围不等于重新完成空口及测向精度验收。

系统以两套 Zynq XC7Z045 + AD9361 平台为接收节点，围绕“检测采集—特征识别—身份解析—测向定位”
形成完整处理链。FPGA 完成接收基带、双 RX 同步采样和数据搬运，板端 Linux 完成信源处理与单站测向，
PC 地面站负责双站调度、观测关联、几何交汇和可视化。

工程工作包括板级接口与时序适配、OFDM/DSSS 接收链集成、双通道 IQ 采集、RID 消息解析、
信源特征处理、LTF 相位测向、参考管理及地面站联调。源码按硬件、驱动、算法、服务与界面组织。

一、FPGA 工程

A 站：zynq7045_ad9361_rid_aoa/dma_project/dma_project.xpr
功能：OFDM 接收、双 RX IQ 采集与测向数据通路。

B 站：zynq7045_ad9361_rid_aoa/dsss_receiver/build/integrated_r2/dsss_b.xpr
功能：在相同板级平台上集成 OFDM 与 DSSS 接收，提供帧接入和双 RX IQ。

开发工具：Vivado 2022.2；器件：xc7z045fbg676-1。
两套工程共用 ow/board/ip_repo 与 ow/adi-hdl/library，提交和使用时保留完整目录结构。
.bd、.xdc、.xci、component.xml、.coe/.mem 分别保存连接、约束、IP 参数和初始化数据。
各站保留最终工程设置，综合和实现报告见交付包 final_fpga_results/。

二、板级适配与驱动

zynq7045_ad9361_rid_aoa/openwifi/：板级 PS 设置、接口约定、时钟约束、IP 打包及工程维护工具。
zynq7045_ad9361_rid_aoa/ow/：工程使用的接收 IP、硬件接口、驱动、设备树和射频初始化代码。
zynq7045_ad9361_rid_aoa/dsss_receiver/：DSSS 接收 RTL、帧缓存、AXI 寄存器接口及工程集成脚本。
kernel_build/：Linux 配置、模块符号表、AD9361 接口补丁、radiotap 修正及 A/B 设备树。

板端服务使用 /root/openwifi_rx1 与 /root/doa_stage 部署路径，服务定义位于 linux_doa/systemd/。
内核源代码以 tar.xz 归档保存，配套工具链、版本和构建步骤见 kernel_build/README.txt。

三、接收、识别与测向

rid_receiver/：帧接入、抓包解析、RID/GB46750 消息解析、信源特征与监测服务。
zynq7045_ad9361_rid_aoa/linux_doa/：目标 IQ 采集、LTF 匹配、跨 RX 相位估计、参考修正及单站 DOA。
target_capture_service.py 提供目标采集和板端测向结果，recognition_runtime.py 提供识别处理服务。
两站角度经目标、帧标识、频率、会话和时效检查后进入几何交汇。

四、PC 地面站

入口：rid_receiver/ground_station/serve.py；Windows 启动脚本：start.bat。
运行示例：python -B rid_receiver/ground_station/serve.py
访问地址：http://127.0.0.1:18770/#/home
Python 依赖见根目录 requirements.txt，既有运行环境为 Python 3.8 + NumPy。

地面站包含态势地图、信源检测、单站角度、双站交汇、设备布站和记录管理界面。
当前站点配置、默认参考及当前选用参考随包保存；更换现场或射频会话后按程序要求核验。
历史回放支持用户导入记录，随包 records 保留两份观测记录、信源捕获与关机对照材料。

五、FPGA 仿真示例

入口：zynq7045_ad9361_rid_aoa/dsss_receiver/sim/run_example.ps1
可通过 -VivadoBin 指定 Vivado 2022.2 的 bin 路径。
内容：完整 DSSS 接收链、134 字节帧体逐字节核对、错误 FCS、缓存保护和 ACK 检查。
输入为合成 IQ；通过摘要位于 final_fpga_results/simulation_result.txt。

六、构建和维护

openwifi/package.tcl：IP 打包。
openwifi/board_ps_settings.tcl、board_profile.json、hardware_contract.json：板级设置及接口约定。
dsss_receiver/scripts/create_integration.tcl、build_integrated.tcl：B 工程集成与综合/实现。
打开随附 XPR 即可查看当前工程；源码准备脚本使用 Git 工作树时，按 sources.lock.json 恢复指定版本。
部分 LUT 生成工具使用 Python 2，当前应用运行链路使用 Python 3。

各模块的版本记录、作者信息和许可文件随源码保存，具体见对应目录。
