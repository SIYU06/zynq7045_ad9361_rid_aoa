板端 Linux 构建输入

目标内核：5.15.0-175919-g427c94e8faa5-openwifi-rx1
源码提交：427c94e8faa57cb224bd40f1a0c8fe25168be2e5
架构：ARM；验证工具链：Ubuntu 22.04、arm-linux-gnueabi-gcc 11.4.0、Make 4.3。

third_party/linux-427c94e8faa5-source.tar.xz 保存指定提交的构建源码。
归档保留 Kconfig 所需 samples 及 Documentation/Kconfig；普通文档、图片、CI 和 tools/testing 不随包。
kernel.config 为目标配置；Module.symvers 为既有部署内核的模块符号版本表。
AD9361 导出和 radiotap 修正分别保存在两个标准补丁中。
device_tree/station_A_system.dts 对应随包实际 A 站参考 DTB 的全部节点属性；
station_B_dsss_overlay.dts 在相同底座增加 DSSS 外设，地址 0x83c60000。

从 source_code 目录，在 Linux/WSL 中执行：
bash reproduce/build_kernel.sh "$PWD" /var/tmp/airspace_kernel_01 /mnt/f/airspace_kernel_report_01

脚本要求新的工作目录，解压、打补丁、恢复配置、准备内核，构建 7 个外部模块及
cfg80211、mac80211、xilinx_dma 共 10 个模块，并检查全部 vermagic。
完整内核镜像使用：
bash reproduce/build_kernel_image.sh /var/tmp/airspace_kernel_01/linux-427c94e8faa57cb224bd40f1a0c8fe25168be2e5 /mnt/f/airspace_image_01
需要 u-boot-tools/mkimage。详细环境、输出及验收标准见 ../reproduce/README.md。

外部驱动源码位于 zynq7045_ad9361_rid_aoa/ow/linux/driver。
随包 Module.symvers SHA256：
7d6a185628ac55b8ba442c5d5be39e9416d2a0d5d7d1deefbe3f2ee0bd8d7377
该值与 linux_doa/side_ch_packet_build.json 中的接口记录一致。
更换内核配置或符号版本后，必须使用相应符号表重建驱动，不能仅改版本字符串冒充 ABI 兼容。

本轮为离线构建验证，没有更新板卡。实际构建范围及证据见交付包 reproduction_results。