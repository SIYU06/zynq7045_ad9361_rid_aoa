# 手动复现指南

本指南从解压提交包开始。先阅读 [相同芯片新硬件的接口移植清单](HARDWARE.md)。
**本轮你可以不接板，先独立完成以下离线验收。**

## 1. 环境与目录

将 ZIP 解压到较短的英文路径，例如 `F:\airspace`，然后进入其中的 `source_code`。
Vivado 的部分 Windows 子工具存在路径长度限制，不建议把工程放进多层中文目录。
第一次构建应使用新的解压目录，不复制开发机的 `.runs`、`.gen` 或缓存。

已使用的环境：Windows、Vivado 2022.2、CPython 3.8.10、NumPy 1.22.1；
Linux 构建使用 Ubuntu 22.04、GNU Make 4.3、`arm-linux-gnueabi-gcc` 11.4.0。

完整 FPGA 构建需要 XC7Z045 器件支持和工程使用的 IP 授权。Viterbi Decoder 9.1 在本机检查中显示
`Purchased`；授权文件属于本机工具环境，不包含在提交包中。DSSS 示例仿真使用随包 RTL。

若使用新的 Python 环境，在 PowerShell 中执行：

```powershell
Set-Location F:\airspace\source_code
& D:\Python38-32\python.exe -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r .\reproduce\requirements-offline.txt
```

其中 Python 和 Vivado 路径可替换为你的实际安装路径。依赖安装完成后，以下快速验收不需要互联网或板卡。

## 2. 一轮快速离线验收

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\reproduce\run_reproduction.ps1 `
  -Mode quick -Rounds 1 `
  -PythonExe F:\airspace\source_code\.venv\Scripts\python.exe `
  -VivadoBin E:\thenewruanjian\vivado\Vivado\2022.2\bin `
  -OutputRoot F:\airspace_check_01
```

已存在 `OutputRoot` 时脚本会退出，避免覆盖前一轮证据；再次复现时换成 `airspace_check_02`。
如果只想先验算法和网页，可加 `-SkipSimulation`；该模式不代表 FPGA 仿真已通过。

正常结果：

| 步骤 | 应看到的结果 | 证据文件 |
|---|---|---|
| 保存数据与算法对比 | `OFFLINE PASS 34 / 34` | `round_1/algorithms/offline_verification.json` |
| 地面站启动与资源检查 | `WEB PASS 46 HTTP checks` | `round_1/web/web_verification.json` |
| FPGA 示例 | 两行 `PASS`，帧体 134 字节相同 | `round_1/fpga_simulation/result.txt` |
| 本轮汇总 | `REPRO_PASS quick round 1` | `round_1/summary.json` |

算法对比包含两站保存的实收 IQ 相位与质量指标、保存的 DSSS/RID 帧解析、已知相位控制输入、
错误输入拒绝及双站解析几何。真实数据回放和受控输入在 JSON 的 `kind` 字段中分开标明。
合成输入用于功能检查；它不代表已验证真实场景测向精度。

## 3. 手动查看地面站效果

```powershell
& .\.venv\Scripts\python.exe -X utf8 -B .\rid_receiver\ground_station\serve.py --port 18770
```

打开 `http://127.0.0.1:18770/#/home`，按以下顺序检查：

1. 不接板时，真实接入应显示等待连接，不应产生新目标或新角度。
2. 在首页点击“回放35帧真实双站测向记录”，确认进入历史模式、显示记录名称与时间。
3. 在“测向工作台”选择 A/B 单站，检查角度及质量字段；切换双站视图检查局部几何。
4. 在“记录与诊断”点击播放、暂停和拖动进度条，确认显示随记录变化。
5. 回到真实接入模式，历史记录不能继续冒充当前实测。

历史回放应保留“历史”“临时标定”或“未校准”等原有标记。地图瓦片是可选联网资源，
离线时可选择“离线网格”，局部坐标与算法验证不依赖外部底图。
HTTP 自动检查不等于浏览器按钮已点击验收；界面操作由以上步骤单独确认。

## 4. FPGA 从源文件构建

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\reproduce\run_reproduction.ps1 `
  -Mode fpga -Station both -FpgaPhase bitstream `
  -VivadoBin E:\thenewruanjian\vivado\Vivado\2022.2\bin `
  -OutputRoot F:\airspace_fpga_01
```

可将 `-FpgaPhase` 改为 `validate`、`synth` 或 `impl`，分别停在工程/IP 生成、综合、布局布线阶段。
两站按顺序构建，以降低内存占用。首次构建需要较长时间，以控制台进度和日志为准。

脚本检查版本和 IP 状态，生成 BD/IP，执行综合与实现，输出资源、DRC、时序和 CDC 报告。
实现运行从干净配置创建，避免依赖开发目录的历史运行元数据。
只有时序与 DRC 门控通过，才输出 `system_top.bit` 和 `hardware.xsa`。

检查各站目录中的 `build.log`、`synth_utilization.rpt`、`impl_utilization.rpt`、`impl_timing.rpt`、
`impl_drc.rpt`、`check_timing.rpt` 和 `timing_gate.txt`。不能仅以 Vivado 打开工程成功为验收通过。
参考报告在交付包 `final_fpga_results`，新构建数值与对比结论在复现记录中单独保存。

## 5. Linux 内核准备与驱动交叉编译

在安装 ARM 交叉编译器、make、gcc、flex、bison、bc、OpenSSL 开发库、ELF 开发库及 kmod 的
Ubuntu 22.04 / WSL 环境中执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\reproduce\run_reproduction.ps1 `
  -Mode kernel -WslDistro Ubuntu-22.04 -OutputRoot F:\airspace_kernel_01
```

脚本在 WSL `/var/tmp` 的新目录解压源码、应用两个补丁、恢复配置、准备内核并编译 7 个外部模块及
`cfg80211`、`mac80211`、`xilinx_dma`，共 10 个模块，
核对各模块 `vermagic`。日志和模块副本回存到 `OutputRoot`。
内核目标版本应为 `5.15.0-175919-g427c94e8faa5-openwifi-rx1`。

继续生成完整 ARM 内核镜像时，在 WSL 中使用上一步控制台打印的工作目录：

```bash
bash reproduce/build_kernel_image.sh \
  /var/tmp/airspace_reproduction_时间戳/linux-427c94e8faa57cb224bd40f1a0c8fe25168be2e5 \
  /mnt/f/airspace_kernel_image_01
```

还需安装 `u-boot-tools`（提供 `mkimage`）。输出包含 `uImage`、`System.map` 和符号表；
可用 `verify_kernel_image.py --image <uImage路径> --out <校验输出目录>` 检查 CRC 与内核版本。
镜像结构通过不代表已在板卡启动。随包 `board_support/boot/common/uImage` 为同源码/配置的匿名重建镜像，
构建脚本使用通用构建账号及主机名；该镜像的 CRC、版本和导出符号校验见
`reproduction_results/kernel_image_anonymous`，本轮没有对其重新进行上电启动验收。

若要独立检查 C 接口与参考解码器，在 WSL 中执行：

```bash
bash reproduce/verify_c.sh "$PWD" /var/tmp/airspace_c_check_01
```

应看到 DOA 数值检查 `PASS`、参考 C 解码字段一致，以及 ARM ELF 交叉编译完成。

## 6. 启动包、设备树与板端文件

见 [启动与部署文件说明](BOARD.md)：包含 Bootgen 打包、A/B 设备树构建、
运行文件覆盖包生成，以及采用相同 XC7Z045 芯片的新硬件完成接口适配后的验收顺序。
这些工具的生成动作可以离线执行，不会向板卡刷写文件。

如需进一步检查历史记录格式及前端计算，在安装 Node.js 的环境执行：

```powershell
node .\reproduce\verify_frontend.mjs F:\airspace_frontend_01
```

该检查覆盖 JavaScript 语法、两份历史观测记录、坐标换算、过期/异帧门控和前后模糊保留，
不等于浏览器按钮点击验收。

## 7. 换到实机时的验收顺序

本轮只做离线复现。移植到采用相同 XC7Z045 芯片的新硬件时，先按 [接口移植清单](HARDWARE.md)
适配器件封装、DDR/MIO、引脚/电平、时钟复位、RF、AXI/DMA、中断、设备树及启动组件，
核对内核版本与模块 ABI，再加载目标硬件的工程及运行文件。
先检查 Linux、网口与 RF，再检查帧接收、双 RX IQ 和参考状态，最后检查角度与交汇。
应使用当前频率、增益、天线间距和实测布站建立/核验参考，不能直接把历史相位偏置当作新硬件的标定。

复现截图或记录应标注硬件型号、日期、软件版本、频率/增益、阵元与站间距、信源和参考状态。
这些实机项目在本轮不接板的条件下不记为通过。
