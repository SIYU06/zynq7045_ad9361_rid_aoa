"""Compare final implementation metrics against the packaged A/B references."""
import argparse
import hashlib
import json
import re
from pathlib import Path


def metrics(directory, timing_name, check_name):
    utilization=(directory/'impl_utilization.rpt').read_text()
    resources={}
    for key,label in [('LUT','Slice LUTs'),('FF','Slice Registers'),('BRAM','Block RAM Tile'),('DSP','DSPs')]:
        match=re.search(r'^\| '+re.escape(label)+r'\s*\|\s*([\d.]+)',utilization,re.M)
        assert match,label
        resources[key]=float(match[1])
    timing=(directory/timing_name).read_text()
    lines=timing.splitlines()
    index=next(i for i,line in enumerate(lines) if line.strip().startswith('WNS(ns)'))
    values=lines[index+2].split()
    assert len(values)==12
    timing_metrics=dict(WNS_ns=float(values[0]),TNS_ns=float(values[1]),setupFailing=int(values[2]),
                        WHS_ns=float(values[4]),THS_ns=float(values[5]),holdFailing=int(values[6]),
                        WPWS_ns=float(values[8]),TPWS_ns=float(values[9]),pulseFailing=int(values[10]))
    drc=(directory/'impl_drc.rpt').read_text()
    counts=dict(Error=0,Warning=0,Advisory=0)
    for severity,count in re.findall(r'^\|[^|]+\|\s*(Error|Warning|Advisory)\s*\|[^|]+\|\s*(\d+)\s*\|',drc,re.M):
        counts[severity]+=int(count)
    check=(directory/check_name).read_text()
    constraints={name:int(count) for name,count in re.findall(r'^\d+\. checking (\w+) \((\d+)\)',check,re.M)}
    return dict(resources=resources,timing=timing_metrics,drc=counts,constraintChecks=constraints)


parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--rebuilt-root',type=Path,required=True)
parser.add_argument('--reference-root',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
results=[]
for station,folder,timing,check in [('A','A_OFDM_20261027','impl_timing_summary.rpt','impl_check_timing.rpt'),
                                  ('B','B_OFDM_DSSS_20261102','impl_timing.rpt','check_timing.rpt')]:
    reference=metrics(args.reference_root/folder,timing,check)
    directory=args.rebuilt_root/station
    rebuilt=metrics(directory,'impl_timing.rpt','check_timing.rpt')
    assert rebuilt['resources']==reference['resources'],station+' resource mismatch'
    assert rebuilt['drc']['Error']==0
    assert all(rebuilt['timing'][name]>=0 for name in ['WNS_ns','WHS_ns','WPWS_ns'])
    assert all(rebuilt['timing'][name]==0 for name in ['TNS_ns','THS_ns','TPWS_ns','setupFailing','holdFailing','pulseFailing'])
    assert all(rebuilt['constraintChecks'][name]==0 for name in ['no_clock','unconstrained_internal_endpoints','loops'])
    route=(directory/'route_status.rpt').read_text()
    assert int(re.search(r'nets with routing errors[^:]+:\s*(\d+)',route)[1])==0
    bus_skew=(directory/'bus_skew.rpt').read_text()
    assert '(VIOLATED)' not in bus_skew
    assert (directory/'system_top.bit').stat().st_size>1000000
    assert (directory/'hardware.xsa').stat().st_size>10000
    results.append(dict(station=station,passed=True,reference=reference,rebuilt=rebuilt,
                        resourcesMatch=True,busSkewViolations=0,routeErrors=0,
                        outputs={name:dict(bytes=(directory/name).stat().st_size,sha256=hashlib.sha256((directory/name).read_bytes()).hexdigest())
                                 for name in ['system_top.bit','hardware.xsa']}))
proof=dict(passed=True,stations=results,scope='Rebuilt implementation versus reference; external RF/GPIO IO delay coverage and on-board RF behavior require separate validation.')
(args.out/'fpga_comparison.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
lines=['# FPGA 重建与参考对比','','单位：资源为个数（BRAM 为 Tile），时序为 ns。资源与时序来自完整布局布线报告。','',
       '| 站点/指标 | 参考 | 本轮重建 |','|---|---:|---:|']
for result in results:
    for group in ['resources','timing']:
        for name,value in result['reference'][group].items():
            if group=='resources' or name in ['WNS_ns','WHS_ns','WPWS_ns']:
                lines.append('| {} {} | {} | {} |'.format(result['station'],name,value,result['rebuilt'][group][name]))
    lines.append('| {} DRC Error / Warning / Advisory | {} | {} |'.format(result['station'],
                 ' / '.join(str(v) for v in result['reference']['drc'].values()),
                 ' / '.join(str(v) for v in result['rebuilt']['drc'].values())))
lines+=['','两站资源均与参考一致；建立、保持、脉宽检查无失败端点，布线错误及 DRC Error 为 0。',
        '总线偏斜报告无 VIOLATED。各站约束检查及未覆盖的板外接口见 JSON 和原始报告。',
        'RF/GPIO 等部分端口缺少输入/输出延迟约束；内部时序通过不等于板外接口已经完成时序签核。',
        'DRC Warning/Advisory 和 CDC 报告原样保留，本轮没有通过降低检查等级或新增 false path 消除它们。',
        '时钟约束包括 100/200 MHz PS 时钟、160 MHz RF 接口和 40/80 MHz 分频；没有据此宣称系统 Fmax。',
        'bitstream 文件头含生成信息，比较以功能输入、资源、约束与实现指标为准，不要求文件哈希与历史镜像相同。','']
(args.out/'FPGA_COMPARISON.md').write_text('\n'.join(lines),encoding='utf-8')
print('FPGA_COMPARISON PASS A/B resources, setup/hold/pulse timing, route, bus skew and DRC error checks')
