#!/usr/bin/env bash
set -euo pipefail
source_root=$1
work=$2
report_dir=${3:-}
expected=5.15.0-175919-g427c94e8faa5-openwifi-rx1
commit=427c94e8faa57cb224bd40f1a0c8fe25168be2e5
if [ -e "$work" ]; then printf '%s\n' 'Work directory exists; use a clean directory.' >&2; exit 2; fi
mkdir -p "$work"
if [ -n "$report_dir" ]; then mkdir -p "$report_dir"; exec > >(tee "$work/build.log" "$report_dir/build.log") 2>&1
else exec > >(tee "$work/build.log") 2>&1; fi
date -u +%FT%TZ
arm-linux-gnueabi-gcc --version | head -n 1
make --version | head -n 1
tar -xJf "$source_root/third_party/linux-427c94e8faa5-source.tar.xz" -C "$work"
kernel="$work/linux-$commit"
patch -d "$kernel" -p1 < "$source_root/kernel_build/ad9361_openwifi_exports.patch"
patch -d "$kernel" -p1 < "$source_root/kernel_build/mac80211_radiotap_cursor.patch"
cp "$source_root/kernel_build/kernel.config" "$kernel/.config"
make -C "$kernel" -j2 ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- olddefconfig
make -C "$kernel" -j2 ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- modules_prepare
cp "$source_root/kernel_build/Module.symvers" "$kernel/Module.symvers"
release=$(make -s -C "$kernel" ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- kernelrelease)
[ "$release" = "$expected" ] || { printf 'Kernel release mismatch: %s\n' "$release"; exit 1; }
cp -a "$source_root/zynq7045_ad9361_rid_aoa/ow/linux" "$work/linux_drivers"
driver="$work/linux_drivers/driver"
make -C "$kernel" -j2 ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- M="$driver" modules
make -C "$kernel" -j2 ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- M="$driver/side_ch" modules
for module_source in net/wireless net/mac80211 drivers/dma/xilinx; do
    make -C "$kernel" -j2 ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- M="$kernel/$module_source" modules
done
{
    find "$driver" -type f -name '*.ko' -print
    for module_source in net/wireless net/mac80211 drivers/dma/xilinx; do find "$kernel/$module_source" -maxdepth 1 -type f -name '*.ko' -print; done
} | sort > "$work/modules.txt"
while IFS= read -r module; do
    actual=$(modinfo -F vermagic "$module")
    printf 'MODULE %s VERMAGIC %s\n' "$module" "$actual"
    case "$actual" in "$expected "*) ;; *) exit 1 ;; esac
done < "$work/modules.txt"
if [ -n "$report_dir" ]; then
    cp "$work/modules.txt" "$report_dir/modules.txt"
    mkdir -p "$report_dir/modules"
    while IFS= read -r module; do cp "$module" "$report_dir/modules/"; done < "$work/modules.txt"
fi
printf 'REPRO_PASS kernel_and_drivers %s\n' "$release"
date -u +%FT%TZ
