#!/usr/bin/env bash
# Run after build_kernel.sh; uses the prepared kernel tree printed by that script.
set -euo pipefail
kernel=$1
output=$2
if [ -e "$output" ]; then printf '%s\n' 'Choose a new output directory.' >&2; exit 2; fi
mkdir -p "$output"
exec > >(tee "$output/build.log") 2>&1
release=$(make -s -C "$kernel" ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- kernelrelease)
[ "$release" = 5.15.0-175919-g427c94e8faa5-openwifi-rx1 ]
command -v mkimage
KBUILD_BUILD_USER=builder KBUILD_BUILD_HOST=fpga-build \
make -C "$kernel" -j2 ARCH=arm CROSS_COMPILE=arm-linux-gnueabi- UIMAGE_LOADADDR=0x8000 uImage
cp "$kernel/arch/arm/boot/uImage" "$output/uImage"
cp "$kernel/System.map" "$output/System.map"
cp "$kernel/Module.symvers" "$output/Module.symvers"
printf 'REPRO_PASS kernel_image %s\n' "$release"
