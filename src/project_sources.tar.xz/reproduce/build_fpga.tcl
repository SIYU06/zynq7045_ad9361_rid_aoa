# Build the supplied project in its own extracted tree. Never read an original worktree.
if {[llength $argv] != 4} {error "Use: <source_code directory> <A|B> <validate|synth|impl|bitstream> <output directory>"}
set source_root [file normalize [lindex $argv 0]]
set station [lindex $argv 1]
set phase [lindex $argv 2]
set output [file normalize [lindex $argv 3]]
if {$station ni {A B} || $phase ni {validate synth impl bitstream}} {error "Invalid station or phase"}
if {[version -short] ne "2022.2"} {error "Vivado 2022.2 is required"}
set root [file join $source_root zynq7045_ad9361_rid_aoa]
if {$station eq "A"} {
    set project [file join $root dma_project dma_project.xpr]
    set synth_run synth_txiq_cdc_1708
    set impl_run repro_impl_A
} else {
    set project [file join $root dsss_receiver build integrated_r2 dsss_b.xpr]
    set synth_run synth_1
    set impl_run repro_impl_B
}
file mkdir $output
set_param general.maxThreads 4
open_project $project
config_ip_cache -disable_cache
update_ip_catalog
set locked [get_ips -quiet -filter {IS_LOCKED == 1}]
if {[llength $locked]} {error "Locked IPs: $locked"}
set bd [get_files -quiet -filter {FILE_TYPE == "Block Designs"}]
if {[llength $bd] != 1} {error "Expected one block design"}
open_bd_design $bd
validate_bd_design
save_bd_design
generate_target all $bd
update_compile_order -fileset sources_1
report_ip_status -file [file join $output ip_status.rpt]
set fd [open [file join $output inputs.txt] w]
puts $fd "station=$station\nproject=$project\npart=[get_property PART [current_project]]\nvivado=[version -short]"
foreach name [get_files -compile_order sources -used_in synthesis] {
    if {![file exists $name]} {error "Missing synthesis source: $name"}
    puts $fd $name
}
close $fd
if {$phase eq "validate"} {puts "REPRO_PASS $station validate"; close_project; exit 0}

set_property AUTO_INCREMENTAL_CHECKPOINT 0 [get_runs $synth_run]
set_property incremental_checkpoint {} [get_runs $synth_run]
if {![string match *Complete* [get_property STATUS [get_runs $synth_run]]]} {
    launch_runs $synth_run -jobs 2
    wait_on_run $synth_run
}
set status [get_property STATUS [get_runs $synth_run]]
if {![string match *Complete* $status]} {error "Synthesis failed: $status"}
open_run $synth_run
report_utilization -file [file join $output synth_utilization.rpt]
report_drc -file [file join $output synth_drc.rpt]
close_design
if {$phase eq "synth"} {puts "REPRO_PASS $station synth"; close_project; exit 0}

if {![llength [get_runs -quiet $impl_run]]} {
    create_run $impl_run -parent_run $synth_run -flow {Vivado Implementation 2022} -strategy {Vivado Implementation Defaults} -constrset constrs_1
}
if {![string match *Complete* [get_property STATUS [get_runs $impl_run]]]} {
    launch_runs $impl_run -to_step route_design -jobs 2
    wait_on_run $impl_run
}
set status [get_property STATUS [get_runs $impl_run]]
if {![string match *Complete* $status]} {error "Implementation failed: $status"}
open_run $impl_run
report_utilization -file [file join $output impl_utilization.rpt]
report_drc -file [file join $output impl_drc.rpt]
report_timing_summary -report_unconstrained -file [file join $output impl_timing.rpt]
report_bus_skew -file [file join $output bus_skew.rpt]
report_route_status -file [file join $output route_status.rpt]
check_timing -verbose -file [file join $output check_timing.rpt]
report_cdc -details -file [file join $output cdc.rpt]
set setup_paths [get_timing_paths -quiet -delay_type max -max_paths 1]
set hold_paths [get_timing_paths -quiet -delay_type min -max_paths 1]
if {![llength $setup_paths] || ![llength $hold_paths]} {error "No constrained timing paths"}
set wns [get_property SLACK $setup_paths]
set whs [get_property SLACK $hold_paths]
set errors [get_drc_violations -quiet -filter {SEVERITY == Error}]
set fd [open [file join $output timing_gate.txt] w]
puts $fd "WNS_NS=$wns\nWHS_NS=$whs\nDRC_ERRORS=[llength $errors]"
close $fd
if {$wns < 0 || $whs < 0 || [llength $errors]} {error "Timing or DRC gate failed; inspect reports"}
if {$phase eq "bitstream"} {
    write_bitstream -force [file join $output system_top.bit]
    write_hw_platform -fixed -force -file [file join $output hardware.xsa]
}
puts "REPRO_PASS $station $phase"
close_project
exit 0
