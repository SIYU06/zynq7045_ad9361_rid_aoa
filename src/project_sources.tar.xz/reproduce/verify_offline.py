"""Reproduce captured-signal outputs and independent controlled cases without RF hardware."""
import argparse
import base64
import copy
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import time
import zlib

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[1]
DATA=Path(__file__).resolve().parent/'fixtures'
sys.path[:0]=[str(ROOT/'rid_receiver'),str(ROOT/'rid_receiver/ground_station'),str(ROOT/'zynq7045_ad9361_rid_aoa/linux_doa')]
sys.dont_write_bytecode=True
import numpy as np
from ofdm_preamble import analyze_ofdm_ltf,LTS
from source_doa import analyze_window
from board_doa import default_context,compute_observation,implementation_hash
from rid_features import recognize_rid
from gb46750 import decode_cn
from doa_geometry import intersect_candidates

checks=[]
def record(name,expected,actual,passed,kind):
    checks.append(dict(name=name,kind=kind,expected=expected,actual=actual,passed=bool(passed)))
def close(a,b,tol=1e-8):return type(a) in (int,float) and abs(a-b)<=tol

for reference in json.loads((DATA/'iq_reference.json').read_text(encoding='utf-8')):
    raw=(DATA/reference['file']).read_bytes()
    digest=hashlib.sha256(raw).hexdigest()
    assert digest==reference['sha256']
    actual=analyze_ofdm_ltf(raw,max_start_sample=1408)
    board=reference['expected'];prefix=reference['station']
    record(prefix+'_captured_phase_deg',board['phaseDeg'],actual['phase_unit_bins_deg'],close(actual['phase_unit_bins_deg'],board['phaseDeg']),'actual_air_capture_replay')
    q=actual['signal_quality'];old=board['signalQuality']
    record(prefix+'_captured_snr_proxy_db',old['snrProxyDb'],q['snrProxyDb'],all(close(a,b) for a,b in zip(q['snrProxyDb'],old['snrProxyDb'])),'actual_air_capture_replay')
    record(prefix+'_captured_quality_gate',old['accepted'],q['accepted'],q['accepted']==old['accepted'],'actual_air_capture_replay')
    record(prefix+'_captured_concentration',old['subcarrierConcentration'],q['subcarrierConcentration'],close(q['subcarrierConcentration'],old['subcarrierConcentration']),'actual_air_capture_replay')

reference=json.loads((DATA/'rid_reference.json').read_text(encoding='utf-8'))
frame=(DATA/reference['frameFile']).read_bytes()
assert hashlib.sha256(frame).hexdigest()==reference['frameSHA256']
recognition=recognize_rid(frame,fcs_valid=True)
messages=decode_cn(bytes.fromhex(reference['payloadHex']))
basic=next(x for x in messages if x['type']==0)
location=next(x for x in messages if x['type']==1)
system=next(x for x in messages if x['type']==4)
expected=reference['expected']
record('captured_RID_identity',expected['sn'],basic['uas_id'],basic['uas_id']==expected['sn'],'actual_air_capture_replay')
record('captured_RID_registration',expected['registration'],basic['registration'],basic['registration']==expected['registration'],'actual_air_capture_replay')
for key,actual in [('latitude',location['latitude']),('longitude',location['longitude']),('altitude',location['altitude_geo']),
                   ('groundSpeed',location['speed_horizontal']),('operatorLatitude',system['operator_latitude']),('operatorLongitude',system['operator_longitude'])]:
    record('captured_RID_'+key,expected[key],actual,close(actual,expected[key]),'actual_air_capture_replay')
record('captured_RID_transport','confirmed',recognition['status'],recognition['status']=='confirmed' and basic['uas_id'] in recognition['identities'],'actual_air_capture_replay')
record('bad_FCS_does_not_become_RID','none',recognize_rid(frame,fcs_valid=False)['status'],recognize_rid(frame,fcs_valid=False)['status']=='none','negative_case')

def controlled_iq(phase):
    first=np.zeros(4096,dtype=complex);first[96:224]=np.tile(LTS/max(abs(LTS))*6000,2)
    second=first*np.exp(1j*np.radians(phase))*.7
    values=np.stack((first.real,first.imag,second.real,second.imag),axis=1)
    raw=struct.pack('<Q',1053)+(np.rint(values/16)*16).astype('<i2').tobytes()
    frame=bytes.fromhex('80000000ffffffffffff0211223344550211223344550000')+bytes(12)+b'\x00\x04test'
    crc=zlib.crc32(frame)&0xffffffff
    trailer=bytes([crc&255,(crc>>8)&255,(crc>>16)&255,0x80])
    packet=struct.pack('<BBHIQBBHH',0,0,22,15,1000,16,12,2437,0xa0)+frame+trailer
    row=dict(index=1,sourceMac='02:11:22:33:44:55',frequencyMhz=2437,tsf=1053,sessionId='controlled_case',
             sha256=hashlib.sha256(raw).hexdigest(),freshnessVerified=True,monotonic=1,
             referenceCandidates=[dict(packetB64=base64.b64encode(packet).decode(),frameKey=hashlib.sha256(frame).hexdigest())])
    metadata=dict(rf_hz=2437000000,spacing_m=.06,iq_sample_rate_hz=20000000,pre_trigger_samples=1536,
                  kernel='5.15.0-175919-g427c94e8faa5-openwifi-rx1',
                  fixed_gain_profile=dict(active_mode='manual',active_gains=['0 dB','0 dB'],session_id='controlled_case'))
    return raw,row,metadata

for phase in [-40,0,25]:
    raw,row,metadata=controlled_iq(phase)
    result=analyze_window(raw,row,metadata,.06)
    theoretical=math.degrees(math.asin(math.radians(phase)*299792458/(2*math.pi*2437000000*.06)))
    record('controlled_phase_'+str(phase),phase,result['phaseDeg'],abs(result['phaseDeg']-phase)<.1,'controlled_waveform')
    record('controlled_diagnostic_angle_'+str(phase),theoretical,result['relativeAngle'],abs(result['relativeAngle']-theoretical)<.1,'controlled_waveform')
    obs=compute_observation(raw,row,metadata,default_context('A'))
    record('uncalibrated_production_gate_'+str(phase),False,obs['productionAccepted'],obs['productionAccepted'] is False,'negative_case')
    bad=dict(row,sha256='0'*64)
    try:analyze_window(raw,bad,metadata,.06);rejected=False
    except ValueError:rejected=True
    record('tampered_IQ_rejected_'+str(phase),True,rejected,rejected,'negative_case')
zero=analyze_ofdm_ltf(struct.pack('<Q',1)+bytes(4096*8))
record('zero_signal_no_LTF',False,zero['found'],zero['found'] is False,'negative_case')

angle=math.degrees(math.atan2(1.4,3))
a=dict(id='A',xM=1.4,yM=0,headingDeg=0,relativeAngle=-angle,targetId='controlled',frameKey='frame1',fresh=True,timestamp=1000)
b=dict(id='B',xM=-1.4,yM=0,headingDeg=0,relativeAngle=angle,targetId='controlled',frameKey='frame1',fresh=True,timestamp=1000)
points,error=intersect_candidates(a,b)
record('two_element_front_back_ambiguity',2,len(points),len(points)==2 and all(x['ambiguous'] for x in points),'analytic_geometry')
record('known_geometry_target_m',dict(xM=0,yM=3),points,any(abs(x['xM'])<1e-9 and abs(x['yM']-3)<1e-9 for x in points),'analytic_geometry')
foreign,_=intersect_candidates(a,dict(b,frameKey='another'))
record('different_frames_do_not_intersect',0,len(foreign),not foreign,'negative_case')

args.out.mkdir(parents=True,exist_ok=True)
summary=dict(passed=all(x['passed'] for x in checks),checks=checks,implementationHash=implementation_hash(),
             python=sys.version,numpy=np.__version__,scope='Offline saved-data replay, independent controlled cases, and analytic geometry; no live RF or absolute angle-accuracy claim.')
(args.out/'offline_verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print('OFFLINE', 'PASS' if summary['passed'] else 'FAIL',sum(x['passed'] for x in checks),'/',len(checks))
for row in checks:
    if not row['passed']:print('FAIL',row['name'],row['expected'],row['actual'])
raise SystemExit(0 if summary['passed'] else 1)
