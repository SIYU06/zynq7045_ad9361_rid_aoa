// Offline JavaScript and recording checks. Does not automate a browser.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../rid_receiver/ground_station');
const out=process.argv[2];
assert.ok(out,'Usage: node reproduce/verify_frontend.mjs <new output directory>');
assert.ok(!fs.existsSync(out),'Choose a new output directory');
const checked=[];
function walk(directory){for(const entry of fs.readdirSync(directory,{withFileTypes:true})){
  const filename=path.join(directory,entry.name);
  if(entry.isDirectory())walk(filename);
  else if(entry.name.endsWith('.js')){
    const result=spawnSync(process.execPath,['--check','--input-type=module'],{input:fs.readFileSync(filename),encoding:'utf8'});
    assert.equal(result.status,0,filename+'\n'+result.stderr);checked.push(path.relative(root,filename));
  }
}}
walk(root);
const source=fs.readFileSync(path.join(root,'workspace-core.js'));
const core=await import('data:text/javascript;base64,'+source.toString('base64'));
const recordings=[];
for(const filename of ['dual_center_20261102.json','nonrid_video_20261102.json']){
  const original=JSON.parse(fs.readFileSync(path.join(root,'records',filename),'utf8'));
  const loaded=core.validateRecording(original);
  assert.equal(loaded.samples.length,original.samples.length);
  assert.ok(loaded.samples.every(s=>s.data.replay===true&&s.data.demo===false));
  assert.ok(loaded.samples.every((s,i)=>!i||s.data.timestamp>=loaded.samples[i-1].data.timestamp));
  recordings.push({file:filename,samples:loaded.samples.length,markedHistorical:true});
}
assert.throws(()=>core.validateRecording({schema:'airspace.observations',version:1,samples:[]}));
const anchor={latitude:30,longitude:120};
const [latitude,longitude]=core.geographic(anchor,31.25,-14.5);
const xy=core.local(anchor,latitude,longitude);
assert.ok(Math.abs(xy[0]-31.25)<1e-6&&Math.abs(xy[1]+14.5)<1e-6);
const clock=1700000000000;
const feed={timestamp:clock,targetId:'test',stations:[0,1].map(()=>({timestamp:clock,relativeAngle:20,frameKey:'same'}))};
assert.equal(core.pairReady(feed,'external',clock,true),true);
feed.stations[1].frameKey='other';assert.equal(core.pairReady(feed,'external',clock,true),false);
feed.stations[1].frameKey='same';feed.stations[1].timestamp-=16000;assert.equal(core.pairReady(feed,'external',clock,true),false);
assert.equal(core.pairReady(feed,'external',clock,false),false);
assert.equal(core.bearingsForStation({bearing:20,relativeAngle:20,headingDeg:0},'full').length,2);
fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(path.join(out,'frontend_verification.json'),JSON.stringify({passed:true,node:process.version,syntaxChecked:checked,recordings,additionalChecks:['empty record rejected','coordinate roundtrip','frame mismatch rejected','stale pair rejected','disconnected pair rejected','front/back ambiguity retained'],scope:'JavaScript execution and saved recording integrity; no browser interaction.'},null,2));
console.log(`FRONTEND PASS ${checked.length} JavaScript files, 2 historical recordings and gating checks`);
