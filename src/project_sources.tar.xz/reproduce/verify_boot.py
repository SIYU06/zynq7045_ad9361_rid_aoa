"""Verify a reconstructed Zynq BOOT image against boot components and FPGA payload."""
import argparse,hashlib,json,struct
from pathlib import Path

def partitions(path):
    image=path.read_bytes()
    if struct.unpack_from('<I',image,0x20)[0]!=0xaa995566:raise ValueError('Bad Zynq boot header')
    table=struct.unpack_from('<I',image,0x9c)[0];result=[]
    for index in range(3):
        words=struct.unpack_from('<16I',image,table+64*index)
        if sum(words)&0xffffffff!=0xffffffff:raise ValueError('Partition header checksum')
        offset,length=words[5]*4,words[0]*4
        if not 0<length<=len(image)-offset:raise ValueError('Partition bounds')
        data=image[offset:offset+length]
        result.append(dict(index=index,attributes=words[6],load=words[3],execute=words[4],data=data,bytes=length,sha256=hashlib.sha256(data).hexdigest()))
    return result

def bit_payload(path):
    bit=path.read_bytes();cursor=2+int.from_bytes(bit[:2],'big')
    if int.from_bytes(bit[cursor:cursor+2],'big')!=1:raise ValueError('Bad BIT header')
    cursor+=2
    while True:
        tag=bit[cursor:cursor+1];cursor+=1;width=4 if tag==b'e' else 2
        length=int.from_bytes(bit[cursor:cursor+width],'big');cursor+=width
        if tag==b'e':
            body=bit[cursor:cursor+length]
            if len(body)!=length or cursor+length!=len(bit):raise ValueError('BIT payload length')
            return body
        if tag not in (b'a',b'b',b'c',b'd'):raise ValueError('Unknown BIT header tag')
        cursor+=length

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--image',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--bitstream',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    old=partitions(a.reference);new=partitions(a.image)
    for before,after in zip(old,new):
        assert (before['attributes'],before['load'],before['execute'])==(after['attributes'],after['load'],after['execute'])
    for index in (0,2):assert old[index]['data']==new[index]['data'],'Boot component changed'
    body=bit_payload(a.bitstream);swapped=b''.join(body[i:i+4][::-1] for i in range(0,len(body),4))
    actual=new[1]['data'];word_swapped=actual[:len(body)]==swapped
    assert actual[:len(body)] in (body,swapped),'FPGA payload mismatch'
    padding=actual[len(body):];nop=b'\x00\x00\x00\x20' if word_swapped else b'\x20\x00\x00\x00'
    assert len(padding)%4==0 and padding==nop*(len(padding)//4),'Bad FPGA padding'
    a.out.mkdir(parents=True,exist_ok=True)
    report=dict(passed=True,bootHeaderAndPartitionChecksums=True,fsblMatchesReference=True,uBootMatchesReference=True,
                fpgaMatchesRequestedBitstream=True,wordSwapped=word_swapped,partitions=[{k:v for k,v in x.items() if k!='data'} for x in new],
                scope='Offline boot-image packaging validation, not an on-board boot test.')
    (a.out/'boot_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('BOOT PASS headers, components, addresses and exact FPGA payload')
if __name__=='__main__':main()
