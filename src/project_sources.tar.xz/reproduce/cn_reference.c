/* Test harness for the unmodified Apache-2.0 OpenDroneID CN reference. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "opendroneidcn.h"
int main(int argc, char **argv) {
    if(argc != 2 || strlen(argv[1]) % 2 || strlen(argv[1]) > 510) return 2;
    unsigned char data[255]; size_t n = strlen(argv[1])/2;
    for(size_t i=0;i<n;i++) { unsigned v; if(sscanf(argv[1]+2*i,"%2x",&v)!=1) return 3; data[i]=(unsigned char)v; }
    DroneRIDData_t decoded; unsigned char version;
    int status=CN46750_RID_Decode(data,n,&decoded,&version);
    if(status != RID_OK) { printf("{\"status\":%d}\n",status); return 0; }
    printf("{\"status\":%d,\"sn\":\"%s\",\"registration\":\"%s\",\"longitude\":%.7f,\"latitude\":%.7f,\"operatorLongitude\":%.7f,\"operatorLatitude\":%.7f,\"altitude\":%.3f,\"groundSpeed\":%.3f,\"timestampMs\":%llu}\n",status,decoded.sn,decoded.uin,decoded.drone_lon,decoded.drone_lat,decoded.gcs_lon,decoded.gcs_lat,decoded.drone_alt,decoded.ground_speed,(unsigned long long)decoded.timestamp_ms);
    return 0;
}
