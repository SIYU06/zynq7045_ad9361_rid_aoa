"""Prepare paired-station file overlays; never writes a board or changes local services."""
import argparse,hashlib,io,json,re,secrets,tarfile
from pathlib import Path,PurePosixPath

ROOT=Path(__file__).resolve().parents[1]
SUPPORT=ROOT.parent/'board_support'
RELEASE='5.15.0-175919-g427c94e8faa5-openwifi-rx1'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--modules',type=Path,help='Optional newly rebuilt modules directory; ABI checked before packaging.')
args=parser.parse_args();args.out=args.out.resolve()
if args.out.exists():raise SystemExit('Choose a new output directory.')
args.out.mkdir(parents=True)
manifest=json.loads((SUPPORT/'manifest.json').read_text())
archive=SUPPORT/'runtime_base.tar.xz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['files']['runtime_base.tar.xz']['sha256']
base={}
with tarfile.open(archive,'r:xz') as stream:
    for member in stream:
        path=PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        if member.isfile():base[path.as_posix()]=(stream.extractfile(member).read(),member.mode)

def kernel_release(data):
    match=re.search(rb'vermagic=([^\x00]+)\x00',data)
    if not match:raise ValueError('Module has no vermagic')
    return match.group(1).decode().split()[0]

side=(SUPPORT/'reference_side_ch.packet.ko').read_bytes()
assert kernel_release(side)==RELEASE
if args.modules:
    required={'sdr','openofdm_rx','openofdm_tx','rx_intf','tx_intf','xpu','side_ch'}
    assert required.issubset({p.stem for p in args.modules.glob('*.ko')})
    for path in args.modules.glob('*.ko'):
        data=path.read_bytes();assert kernel_release(data)==RELEASE,path.name
        if path.stem=='side_ch':side=data
        elif path.stem in required:base['root/openwifi_rx1/'+path.name]=(data,0o644)
        else:
            relative={'cfg80211':'net/wireless/cfg80211.ko','mac80211':'net/mac80211/mac80211.ko','xilinx_dma':'drivers/dma/xilinx/xilinx_dma.ko'}
            if path.stem in relative:base['lib/modules/'+RELEASE+'/kernel/'+relative[path.stem]]=(data,0o644)
base['root/doa_stage/side_ch.packet.ko']=(side,0o644)
side_hash=hashlib.sha256(side).hexdigest()
for path in (ROOT/'rid_receiver').glob('*.py'):
    base['root/openwifi_rx1/rid_service/'+path.name]=(path.read_bytes(),0o644)
for path in (ROOT/'zynq7045_ad9361_rid_aoa/linux_doa').glob('*.py'):
    base['root/doa_stage/'+path.name]=(path.read_bytes(),0o644)
base['root/doa_stage/ofdm_lts_reference.txt']=((ROOT/'zynq7045_ad9361_rid_aoa/linux_doa/ofdm_lts_reference.txt').read_bytes(),0o644)
for name in ['start_openwifi_rid.sh','start_monitor_role.sh']:
    base['root/openwifi_rx1/'+name]=((ROOT/'rid_receiver'/name).read_bytes().replace(b'\r\n',b'\n'),0o755)
systemd=ROOT/'zynq7045_ad9361_rid_aoa/linux_doa/systemd'
runtime=(systemd/'runtime.py').read_text()
runtime,count=re.subn(r"SIDE_HASH='[0-9a-f]{64}'","SIDE_HASH='"+side_hash+"'",runtime)
assert count==1
base['root/doa_stage/systemd/runtime.py']=(runtime.encode(),0o644)
pair_key=secrets.token_hex(32)
results=[]
for station in ['A','B']:
    files=dict(base)
    files['root/doa_stage/systemd/station.json']=(json.dumps(dict(station=station)).encode()+b'\n',0o600)
    files['root/doa_stage/recognition_config.json']=(json.dumps(dict(station=station,pairKey=pair_key)).encode()+b'\n',0o600)
    files['root/openwifi_rx1/rid_service/receiver_role.json']=(json.dumps(dict(enabled=station=='B')).encode()+b'\n',0o600)
    if station=='B':files['root/openwifi_rx1/rid_service/dsss_channel']=(b'6\n',0o644)
    for name in ['airspace-rf.service','airspace-monitor.service','airspace-iq.service','airspace.target']:
        files['etc/systemd/system/'+name]=((systemd/name).read_bytes().replace(b'\r\n',b'\n'),0o644)
    unit=(systemd/'airspace-recognition.service.in').read_text().replace('@STATION@',station)
    files['etc/systemd/system/airspace-recognition.service']=(unit.encode(),0o644)
    proof=dict(station=station,requiredHostname=dict(A='analog',B='airspace-station-b')[station],kernel=RELEASE,sideModuleSHA256=side_hash,
               files={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),mode=mode) for name,(data,mode) in sorted(files.items())},
               moduleOrigin='rebuilt_modules' if args.modules else 'reference_modules',scope='Prepared and integrity-checked offline. Not installed or boot-tested in this session.')
    payload=json.dumps(proof,indent=2).encode()
    output=args.out/('station_'+station+'_overlay.tar.xz')
    with tarfile.open(output,'w:xz',preset=3) as stream:
        for name,(data,mode) in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=mode;stream.addfile(info,io.BytesIO(data))
        info=tarfile.TarInfo('AIRSPACE_MANIFEST.json');info.size=len(payload);info.mode=0o600;stream.addfile(info,io.BytesIO(payload))
    with tarfile.open(output,'r:xz') as stream:
        for name,(data,_) in files.items():assert stream.extractfile(name).read()==data
    (args.out/('station_'+station+'_manifest.json')).write_text(json.dumps(proof,indent=2),encoding='utf-8')
    results.append(dict(station=station,archive=output.name,files=len(files),archiveBytes=output.stat().st_size,sha256=hashlib.sha256(output.read_bytes()).hexdigest()))
(args.out/'overlay_verification.json').write_text(json.dumps(dict(passed=True,stations=results,scope='Offline package integrity and module ABI; no board writes.'),indent=2),encoding='utf-8')
print('BOARD_OVERLAY PASS A/B contents, hashes and module ABI; no board was modified.')
