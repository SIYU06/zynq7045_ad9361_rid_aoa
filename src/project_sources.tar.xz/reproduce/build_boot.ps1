param(
    [Parameter(Mandatory=$true)][ValidateSet('A','B')][string]$Station,
    [Parameter(Mandatory=$true)][string]$Bitstream,
    [Parameter(Mandatory=$true)][string]$OutputRoot,
    [string]$PythonExe = 'D:\Python38-32\python.exe',
    [string]$VivadoBin = $(if ($env:XILINX_VIVADO) { Join-Path $env:XILINX_VIVADO 'bin' } else { 'E:\thenewruanjian\vivado\Vivado\2022.2\bin' })
)
$ErrorActionPreference='Stop'
$sourceRoot=Split-Path -Parent $PSScriptRoot
$packageRoot=Split-Path -Parent $sourceRoot
$support=Join-Path $packageRoot 'board_support'
$Bitstream=(Resolve-Path -LiteralPath $Bitstream).Path
$OutputRoot=[IO.Path]::GetFullPath($OutputRoot)
if (Test-Path -LiteralPath $OutputRoot) { throw 'Choose a new OutputRoot.' }
New-Item -ItemType Directory -Path $OutputRoot | Out-Null
$fsbl=(Join-Path $support 'components\fsbl.elf').Replace('\','/')
$uboot=(Join-Path $support 'components\u-boot.elf').Replace('\','/')
$bit=$Bitstream.Replace('\','/')
$bif=Join-Path $OutputRoot 'boot.bif'
$text="the_ROM_image:`n{`n [bootloader] `"$fsbl`"`n `"$bit`"`n `"$uboot`"`n}`n"
[IO.File]::WriteAllText($bif,$text,(New-Object Text.UTF8Encoding($false)))
$image=Join-Path $OutputRoot 'BOOT.BIN'
& (Join-Path $VivadoBin 'bootgen.bat') -arch zynq -image $bif -o $image -w on
if ($LASTEXITCODE -ne 0) { throw 'Bootgen failed.' }
& $PythonExe -X utf8 -B (Join-Path $PSScriptRoot 'verify_boot.py') --image $image --reference (Join-Path $support ('boot\'+$Station+'\BOOT.BIN')) --bitstream $Bitstream --out $OutputRoot
if ($LASTEXITCODE -ne 0) { throw 'BOOT verification failed.' }
