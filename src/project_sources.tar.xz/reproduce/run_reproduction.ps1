param(
    [ValidateSet('quick','fpga','kernel')][string]$Mode = 'quick',
    [ValidateSet('A','B','both')][string]$Station = 'both',
    [ValidateSet('validate','synth','impl','bitstream')][string]$FpgaPhase = 'bitstream',
    [ValidateRange(1,10)][int]$Rounds = 1,
    [string]$PythonExe = '',
    [string]$VivadoBin = $(if ($env:XILINX_VIVADO) { Join-Path $env:XILINX_VIVADO 'bin' } else { 'E:\thenewruanjian\vivado\Vivado\2022.2\bin' }),
    [string]$OutputRoot = '',
    [string]$WslDistro = 'Ubuntu-22.04',
    [switch]$SkipSimulation
)
$ErrorActionPreference = 'Stop'
$sourceRoot = Split-Path -Parent $PSScriptRoot
if (-not $OutputRoot) { $OutputRoot = Join-Path $sourceRoot ('generated_build\reproduction_' + (Get-Date -Format 'yyyyMMdd_HHmmss')) }
$OutputRoot = [IO.Path]::GetFullPath($OutputRoot)
if (Test-Path -LiteralPath $OutputRoot) { throw 'OutputRoot already exists. Choose a new directory to keep each run independent.' }
New-Item -ItemType Directory -Path $OutputRoot | Out-Null
if (-not $PythonExe) {
    $candidates = @('D:\Python38-32\python.exe')
    $candidates += @(Get-Command python.exe -All -ErrorAction SilentlyContinue | Where-Object Source -NotLike '*\WindowsApps\*' | Select-Object -ExpandProperty Source)
    $PythonExe = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
}
function Invoke-PythonCheck([string]$Script, [string]$Directory) {
    & $PythonExe -X utf8 -B $Script --out $Directory
    if ($LASTEXITCODE -ne 0) { throw "Verification failed: $Script" }
}
if ($Mode -eq 'quick') {
    if (-not $PythonExe) { throw 'Specify -PythonExe with Python 3.8 and NumPy installed.' }
    & $PythonExe -X utf8 -B -c 'import sys,numpy; print(sys.version); print(numpy.__version__)'
    if ($LASTEXITCODE -ne 0) { throw 'Python or NumPy is unavailable.' }
    for ($round = 1; $round -le $Rounds; $round++) {
        $roundRoot = Join-Path $OutputRoot ('round_' + $round)
        New-Item -ItemType Directory -Path $roundRoot | Out-Null
        Invoke-PythonCheck (Join-Path $PSScriptRoot 'verify_offline.py') (Join-Path $roundRoot 'algorithms')
        Invoke-PythonCheck (Join-Path $PSScriptRoot 'verify_web.py') (Join-Path $roundRoot 'web')
        if (-not $SkipSimulation) {
            $simulation = Join-Path $sourceRoot 'zynq7045_ad9361_rid_aoa\dsss_receiver\sim\run_example.ps1'
            & $simulation -VivadoBin $VivadoBin -WorkDirectory (Join-Path $roundRoot 'fpga_simulation')
        }
        [pscustomobject]@{Round=$round;Mode='quick';Status='PASS';Simulation=(-not $SkipSimulation);Utc=(Get-Date).ToUniversalTime().ToString('o')} |
            ConvertTo-Json | Set-Content -LiteralPath (Join-Path $roundRoot 'summary.json') -Encoding UTF8
        Write-Output "REPRO_PASS quick round $round"
    }
} elseif ($Mode -eq 'fpga') {
    $stations = if ($Station -eq 'both') { @('A','B') } else { @($Station) }
    foreach ($item in $stations) {
        $stationRoot = Join-Path $OutputRoot $item
        New-Item -ItemType Directory -Path $stationRoot | Out-Null
        Push-Location $stationRoot
        try {
            & (Join-Path $VivadoBin 'vivado.bat') -mode batch -nojournal -log (Join-Path $stationRoot 'build.log') -source (Join-Path $PSScriptRoot 'build_fpga.tcl') -tclargs $sourceRoot $item $FpgaPhase $stationRoot
            if ($LASTEXITCODE -ne 0) { throw "FPGA $item build failed; inspect $stationRoot" }
        } finally { Pop-Location }
    }
} else {
    $linuxSource = (& wsl.exe -d $WslDistro -- wslpath -a $sourceRoot).Trim()
    if ($LASTEXITCODE -ne 0) { throw 'WSL path conversion failed.' }
    $linuxWork = '/var/tmp/airspace_reproduction_' + (Get-Date -Format 'yyyyMMdd_HHmmss')
    $linuxReport = (& wsl.exe -d $WslDistro -- wslpath -a $OutputRoot).Trim()
    if ($LASTEXITCODE -ne 0) { throw 'WSL output-path conversion failed.' }
    & wsl.exe -d $WslDistro -- bash ($linuxSource + '/reproduce/build_kernel.sh') $linuxSource $linuxWork $linuxReport
    if ($LASTEXITCODE -ne 0) { throw 'Kernel/driver reproduction failed; inspect the WSL build log.' }
    Write-Output "Kernel/driver artifacts: $linuxWork"
}
Write-Output "Reproduction results: $OutputRoot"
