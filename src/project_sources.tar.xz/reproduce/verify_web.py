"""Start an isolated localhost ground station and verify its HTTP/static contract."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import time
from urllib.request import build_opener,ProxyHandler

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args();args.out=args.out.resolve();args.out.mkdir(parents=True,exist_ok=True)
ROOT=Path(__file__).resolve().parents[1]
web=ROOT/'rid_receiver/ground_station'
config=args.out/'doa_config.json'
config.write_text(json.dumps(dict(anchor=None,stations=[],directionMode='full',minCrossingDeg=1)),encoding='utf-8')
with socket.socket() as listener:
    listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
base='http://127.0.0.1:'+str(port)
environment=os.environ.copy();environment.pop('OPENWIFI_RID_URL',None);environment['PYTHONDONTWRITEBYTECODE']='1'
stdout=(args.out/'server.stdout.log').open('w',encoding='utf-8')
stderr=(args.out/'server.stderr.log').open('w',encoding='utf-8')
process=subprocess.Popen([sys.executable,'-B','-u',str(web/'serve.py'),'--port',str(port),'--doa-config',str(config)],
                         cwd=str(web),env=environment,stdout=stdout,stderr=stderr,
                         creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
opener=build_opener(ProxyHandler({}));checks=[]
try:
    deadline=time.monotonic()+20
    while True:
        if process.poll() is not None:raise RuntimeError('Ground station exited: '+str(process.returncode))
        try:
            with opener.open(base+'/api/health',timeout=2) as response:health=json.load(response)
            break
        except OSError:
            if time.monotonic()>deadline:raise
            time.sleep(.2)
    assert health['available'] is True
    for endpoint in ['/api/health','/api/doa','/api/signals','/api/pipeline','/api/resources','/api/receivers']:
        with opener.open(base+endpoint,timeout=5) as response:
            value=json.load(response);status=response.status
        checks.append(dict(path=endpoint,status=status))
        (args.out/(endpoint.strip('/').replace('/','_')+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
        if endpoint=='/api/receivers':assert not any(x.get('connected') for x in value.get('stations',[]))
    # Traverse the actual index, ES imports, dynamic CSS and local CSS resources.
    pending=[web/'index.html',web/'runtime-config.js'];seen=set()
    while pending:
        path=pending.pop().resolve()
        if path in seen:continue
        seen.add(path);relative=path.relative_to(web).as_posix()
        with opener.open(base+'/'+relative,timeout=5) as response:body=response.read();status=response.status
        assert body and status==200
        if relative!='runtime-config.js':assert hashlib.sha256(body).digest()==hashlib.sha256(path.read_bytes()).digest()
        checks.append(dict(path='/'+relative,status=status,bytes=len(body)))
        if path.suffix not in {'.html','.js','.css'}:continue
        text=path.read_text(encoding='utf-8')
        if path.suffix=='.html':refs=re.findall(r'(?:src|href)=["\']([^"\']+)["\']',text)
        elif path.suffix=='.js':
            refs=re.findall(r'(?:from\s*|import\s*|new URL\(\s*)["\'](\.[^"\']+)["\']',text)
        else:refs=re.findall(r'url\(\s*["\']?([^\)"\']+)',text)
        for ref in refs:
            ref=ref.split('?')[0].split('#')[0]
            if not ref or ref.startswith(('http:','https:','data:','/')):continue
            target=(path.parent/ref).resolve()
            if target.is_file():pending.append(target)
            elif relative=='vendor/leaflet.css' and ref.startswith('images/'):
                # The app uses its own divIcon/vector symbols; stock Leaflet markers are unused.
                continue
            else:raise FileNotFoundError(str(target))
    for name in ['dual_center_20261102.json','nonrid_video_20261102.json','wifi_power_off_20261102.json']:
        with opener.open(base+'/records/'+name,timeout=5) as response:value=json.load(response)
        assert isinstance(value,dict)
        checks.append(dict(path='/records/'+name,status=200))
    summary=dict(passed=True,checks=checks,local_url=base,scope='Isolated localhost startup, APIs, delivered static assets and historical-record files; no boards or live-radio claims.')
    (args.out/'web_verification.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print('WEB PASS',len(checks),'HTTP checks')
finally:
    if process.poll() is None:process.terminate()
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
    stdout.close();stderr.close()
