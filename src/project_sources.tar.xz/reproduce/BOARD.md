# 启动与部署文件说明

本工程基准实现使用 **Zynq XC7Z045 + AD9361**。先阅读 [相同芯片新硬件的接口移植清单](HARDWARE.md)。
下面的基准生成与校验命令可以离线执行；移植到采用相同 XC7Z045 芯片的新硬件后，
使用目标板适配后的启动组件、设备树和配置，按第 5 节完成实机验收。

## 1. 随包文件的作用

| 位置（相对交付包根目录） | 用途 |
|---|---|
| `board_support/boot/A/BOOT.BIN`、`boot/B/BOOT.BIN` | 两站既有部署版本的启动参考，包含 FSBL、PL 配置和 U-Boot |
| `board_support/components/` | 基准实现的 FSBL 与 U-Boot ELF；目标板更新 PS/DDR 等配置后，按新 XSA 重新生成相应启动组件 |
| `board_support/boot/common/uImage`、`uEnv.txt` | 同源码/配置的匿名重建内核，以及 SD 启动环境 |
| `board_support/boot/A/system.dtb`、`boot/B/system.dtb` | A 参考设备树和按相同底座生成的 B 设备树 |
| `board_support/runtime_base.tar.xz` | 匹配内核的基础驱动及板端运行文件，供生成脚本读取 |
| `board_support/manifest.json` | 版本、大小与 SHA256 |

包中包含内核源码、配置、补丁、设备树、业务源码与生成工具；FSBL/U-Boot 以该板已用 ELF 提供。
内核镜像已用通用构建账号重新生成，校验见 `reproduction_results/kernel_image_anonymous`。
内核版本、配置和导出符号接口与基准一致；本轮没有对该匿名重建镜像重新进行上电启动验收。
**不包含整张 SD 卡镜像或完整 Linux 根文件系统。** 板上运行仍需已有的匹配 ARM Linux 根文件系统，
包括 systemd、Python 3/NumPy、tcpdump、iw/ip、kmod 和 AD9361/IIO 环境。
独立接收器 Scapy 抓包入口另需 Scapy，快速离线验收无需它。
现有 `uEnv.txt` 使用 FAT 第一分区和 ext4 第二分区，`root=/dev/mmcblk0p2`；
默认无 ramdisk 时直接使用第二分区。不要把四个启动文件当成完整根文件系统。

## 2. 从新 bitstream 生成 BOOT

在 `source_code` 目录，完成 FPGA 构建后执行（替换成实际输出路径）：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\reproduce\build_boot.ps1 `
  -Station A -Bitstream F:\airspace_fpga_01\A\system_top.bit `
  -OutputRoot F:\airspace_boot_A_01
```

B 站将 `-Station` 改成 `B` 并选择 B 的 bitstream。
移植目标板后，在打包脚本中采用目标 FSBL/U-Boot 的路径，并以目标硬件确认的 BOOT 更新校验参考。
脚本生成 BIF 与 `BOOT.BIN`，检查头部及分区校验和、加载地址、FSBL/U-Boot 与参考一致，
并逐字节核对 FPGA 分区确实来自指定 bitstream。应看到 `BOOT PASS`。
Bootgen 可能提示 FSBL 与 PL 分区的地址范围重叠；PL 分区属性及地址单独与既有启动参考核对，
该离线校验不能替代实际上电启动。

## 3. 构建设备树

在 Linux/WSL 的 `source_code` 目录，安装 `device-tree-compiler` 后执行：

```bash
bash reproduce/build_device_tree.sh "$PWD" /mnt/f/airspace_dtb_01
```

得到 A DTB、B overlay 及合并后的 B DTB。用 Windows Python 校验全部节点属性：

```powershell
& D:\Python38-32\python.exe -X utf8 -B .\reproduce\verify_device_tree.py `
  --reference-a ..\board_support\boot\A\system.dtb `
  --rebuilt-a F:\airspace_dtb_01\station_A.dtb `
  --rebuilt-b F:\airspace_dtb_01\station_B.dtb `
  --out F:\airspace_dtb_check_01
```

应看到 `DEVICE_TREE PASS`。源码来自既有 DTB 的展开形式，dtc 会保留关于旧节点的地址单元、
图端点等告警；校验比较属性语义，不要求重新编译的文件字节顺序相同。
B 必须存在 `/amba/dsss_rx@83c60000`，寄存器范围为 `0x83c60000/0x10000`。

## 4. 生成 A/B 运行文件覆盖包

```powershell
& D:\Python38-32\python.exe -X utf8 -B .\reproduce\prepare_board_overlay.py `
  --out F:\airspace_overlay_01 --modules F:\airspace_kernel_01\modules
```

省略 `--modules` 时使用随包参考模块；指定时检查新模块内核版本并替换对应文件。
脚本组合当前业务源码和基础运行文件，生成 A/B 两份 `overlay.tar.xz`、逐文件清单及校验 JSON。
两站识别服务共享本次生成的配对密钥，各自角色分别写入；重新生成会产生新的配对密钥和归档哈希。
新 `side_ch` 模块的 SHA256 自动写入生成副本中的运行检查，不修改业务源码的参考值。
覆盖包生成与重读校验通过应看到 `BOARD_OVERLAY PASS`。

## 5. 移植到相同芯片新硬件后的安装与验收

本轮没有执行以下实机步骤。按接口清单完成目标 XC7Z045 硬件的 DDR、MIO、XDC、IO 电平、
时钟复位及 RF 接口适配，生成目标启动组件与设备树；备份目标介质及服务配置后，执行以下验收。

1. 在对应站 FAT 启动分区放入目标硬件生成的 `BOOT.BIN`、`system.dtb`、`uImage`、`uEnv.txt`。
   使用随包内核时可沿用其 `uImage`；DDR/MIO 等目标参数通过新 FSBL 和设备树配套更新。
2. 进入目标 Linux 根文件系统，确认 `uname -r` 与驱动 ABI 一致。
   基准 A 主机名为 `analog`，B 为 `airspace-station-b`；目标板可保留这些逻辑身份，
   或同步修改运行器和部署配置的身份检查。变更内核时，用目标符号表重编驱动并同步版本检查。
3. 停止旧接收/测向服务和同端口的手动进程后，在对应板以 root 将该站覆盖包解压到 `/`。
   运行 `depmod -a`、`systemctl daemon-reload`，确认加载模块路径和启动日志正确。
4. 使用 `systemctl enable --now airspace.target airspace-recognition.service` 启动当前服务。
   以 `systemctl status` 和 `journalctl -b -u airspace-rf -u airspace-monitor -u airspace-iq -u airspace-recognition`
   核对状态。B 的设备树和固定信道必须与 2437 MHz 配置匹配。
5. 分别访问板端 `18771/api/receiver/status` 和 `18788/api/iq/status`，先验证 RF、帧接收、双 RX IQ，
   再在地面站配置当前地址与识别配对信息，检查设备健康及真实接入。
6. 实测站间基线、阵元间距、朝向并重新建立/核验当次相位参考。
   保存配置里有历史布站说明，文字中的距离与坐标推算不一致，必须以现场测量重新填写。
   没有有效参考时应保留“参考失效/待校准”，不能用历史回放中的角度作为本次真值。
7. 记录当前软件版本、频率/增益、信源、几何及参考状态，保存实测输出，再与参考字段和明确真值比较。

完成这些步骤以后才能确认当前硬件上的启动、空口接收及测向效果。离线回放、BOOT 结构校验、
内核和 FPGA 构建各自提供对应层次的证据。
