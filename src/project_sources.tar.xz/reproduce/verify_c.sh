#!/usr/bin/env bash
set -euo pipefail
source_root=$1
output=$2
mkdir -p "$output"
doa="$source_root/zynq7045_ad9361_rid_aoa/linux_doa"
cn="$source_root/zynq7045_ad9361_rid_aoa/dsss_receiver/research/checkouts/opendroneid-core-c/libopendroneidcn"
gcc -O2 -std=c11 -Wall -Wextra -Werror -pedantic -I"$doa" "$source_root/reproduce/doa_reference.c" "$doa/doa.c" -lm -o "$output/doa_reference"
"$output/doa_reference" | tee "$output/doa_result.txt"
gcc -O2 -std=c11 -I"$cn" "$source_root/reproduce/cn_reference.c" "$cn/opendroneidcn.c" -lm -o "$output/cn_reference"
python3 - "$source_root/reproduce/fixtures/rid_reference.json" "$output/cn_reference" "$output/cn_result.json" <<'PY'
import json,subprocess,sys
from pathlib import Path
reference=json.loads(Path(sys.argv[1]).read_text())
actual=json.loads(subprocess.check_output([sys.argv[2],reference['payloadHex']],text=True))
expected=reference['expected']
for key,want in expected.items():
    got=actual[key]
    assert abs(got-want)<1e-7 if isinstance(want,(int,float)) else got==want,(key,got,want)
Path(sys.argv[3]).write_text(json.dumps(dict(passed=True,expected=expected,actual=actual),indent=2))
print('REFERENCE_C PASS: all saved RID fields match the reference decoder')
PY
arm-linux-gnueabi-gcc -O2 -std=c11 -I"$doa" "$doa/linux_doa.c" "$doa/doa.c" -lm -o "$output/linux_doa_arm"
file "$output/linux_doa_arm" | tee "$output/arm_elf.txt"
printf '%s\n' 'REPRO_PASS C_reference_and_ARM_compile'
