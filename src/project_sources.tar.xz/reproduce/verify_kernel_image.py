"""Validate the U-Boot image header, payload CRC and embedded Linux release."""
import argparse
import gzip
import hashlib
import json
import struct
import zlib
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--image',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
data=args.image.read_bytes()
magic,header_crc,timestamp,size,load,entry,payload_crc,os_id,arch,kind,compression=struct.unpack_from('>7I4B',data)
assert magic==0x27051956 and len(data)==64+size
header=bytearray(data[:64]);header[4:8]=b'\0'*4
assert zlib.crc32(header)&0xffffffff==header_crc
payload=data[64:]
assert zlib.crc32(payload)&0xffffffff==payload_crc
assert os_id==5 and arch==2 and kind==2
# ARM zImage stores a compressed kernel behind its decompressor, not at byte 0.
assert struct.unpack_from('<I',payload,0x24)[0]==0x016f2818
start=payload.index(b'\x1f\x8b\x08')
decoded=zlib.decompress(payload[start:],wbits=31)
release=b'5.15.0-175919-g427c94e8faa5-openwifi-rx1'
assert b'Linux version '+release+b' ' in decoded
result=dict(passed=True,release=release.decode(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
            headerCRC=True,payloadCRC=True,armZImage=True,loadAddress=hex(load),entryAddress=hex(entry),
            scope='Offline image structure and embedded version; no board boot test.')
args.out.mkdir(parents=True,exist_ok=True)
(args.out/'kernel_image_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('KERNEL_IMAGE PASS header, payload CRC, ARM zImage and embedded release')
