"""Compare rebuilt flattened device trees with the packaged hardware ABI."""
import argparse
import hashlib
import json
import struct
from pathlib import Path


def nodes(path):
    data = path.read_bytes()
    magic, total, offset, strings = struct.unpack_from('>4I', data)
    assert magic == 0xd00dfeed and total == len(data)
    stack, result = [], {}
    while True:
        token = struct.unpack_from('>I', data, offset)[0]
        offset += 4
        if token == 1:
            end = data.index(b'\0', offset)
            stack.append(data[offset:end].decode())
            offset = (end + 4) & ~3
            result['/'.join(stack) or '/'] = {}
        elif token == 2:
            stack.pop()
        elif token == 3:
            size, name_offset = struct.unpack_from('>2I', data, offset)
            offset += 8
            end = data.index(b'\0', strings + name_offset)
            name = data[strings + name_offset:end].decode()
            result['/'.join(stack) or '/'][name] = data[offset:offset + size].hex()
            offset = (offset + size + 3) & ~3
        elif token == 4:
            continue
        elif token == 9:
            assert not stack
            return result
        else:
            raise ValueError('Invalid FDT token')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-a', type=Path, required=True)
    parser.add_argument('--rebuilt-a', type=Path, required=True)
    parser.add_argument('--rebuilt-b', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    reference, a, b = [nodes(p) for p in [args.reference_a, args.rebuilt_a, args.rebuilt_b]]
    assert a == reference, 'A device-tree properties differ from the reference'
    peripheral = '/amba/dsss_rx@83c60000'
    assert set(b) == set(a) | {peripheral}
    assert all(b[name] == properties for name, properties in a.items())
    assert b[peripheral]['compatible'] == b'airspace,dsss-rx-1mbps-v1\0'.hex()
    assert b[peripheral]['reg'] == struct.pack('>2I', 0x83c60000, 0x10000).hex()
    assert b[peripheral]['status'] == b'okay\0'.hex()
    proof = dict(passed=True, referenceNodes=len(a), stationBAddedPeripheral=peripheral,
                 scope='Offline FDT structure and all node properties; no board boot test.',
                 files={p.name:dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                        for p in [args.reference_a, args.rebuilt_a, args.rebuilt_b]})
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out/'device_tree_verification.json').write_text(json.dumps(proof, indent=2), encoding='utf-8')
    print('DEVICE_TREE PASS reference A properties, B peripheral and register ABI')
