#!/usr/bin/env bash
set -euo pipefail
source_root=$1
output=$2
dtc_tool=${3:-dtc}
overlay_tool=${4:-fdtoverlay}
mkdir -p "$output"
"$dtc_tool" -I dts -O dtb -o "$output/station_A.dtb" "$source_root/kernel_build/device_tree/station_A_system.dts"
"$dtc_tool" -@ -I dts -O dtb -o "$output/station_B_dsss.dtbo" "$source_root/kernel_build/device_tree/station_B_dsss_overlay.dts"
"$overlay_tool" -i "$output/station_A.dtb" -o "$output/station_B.dtb" "$output/station_B_dsss.dtbo"
printf '%s\n' 'REPRO_PASS device_tree_A_and_B'
