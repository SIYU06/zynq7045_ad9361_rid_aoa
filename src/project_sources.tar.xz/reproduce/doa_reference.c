#include "doa.h"

#include <math.h>
#include <stdint.h>
#include <stdio.h>

#define PI 3.14159265358979323846
#define C_M_S 299792458.0
#define COUNT 4096u

static void generate(doa_iq_sample_t *samples, double angle_deg, double bias_deg,
                     double rf_hz, double spacing_m)
{
    const double wavelength = C_M_S / rf_hz;
    const double phase = 2.0 * PI * spacing_m * sin(angle_deg * PI / 180.0) /
                         wavelength + bias_deg * PI / 180.0;
    size_t i;
    for (i = 0u; i < COUNT; ++i) {
        const double x = 2.0 * PI * 37.0 * (double)i / (double)COUNT;
        samples[i].rx1_i = (int16_t)lrint(12000.0 * cos(x));
        samples[i].rx1_q = (int16_t)lrint(12000.0 * sin(x));
        samples[i].rx2_i = (int16_t)lrint(9000.0 * cos(x + phase));
        samples[i].rx2_q = (int16_t)lrint(9000.0 * sin(x + phase));
    }
}

int main(void)
{
    doa_iq_sample_t calibration[COUNT];
    doa_iq_sample_t target[COUNT];
    doa_config_t config = {2437000000.0, 0.05, 0.90};
    doa_result_t result;
    double bias;
    double coherence;
    generate(calibration, 0.0, 23.0, config.rf_frequency_hz, config.antenna_spacing_m);
    generate(target, 30.0, 23.0, config.rf_frequency_hz, config.antenna_spacing_m);
    if (doa_calibrate_boresight(calibration, COUNT, &bias, &coherence) != 0 ||
        doa_estimate_block(&config, target, COUNT, bias, &result) != 0 ||
        (result.flags & DOA_FLAG_VALID) == 0u ||
        fabs(result.bearing_deg - 30.0) > 0.02 || coherence < 0.999) {
        fprintf(stderr, "FAIL bias=%.6f coherence=%.6f bearing=%.6f flags=0x%x\n",
                bias * 180.0 / PI, coherence, result.bearing_deg, result.flags);
        return 1;
    }
    printf("PASS bias_deg=%.6f coherence=%.6f bearing_deg=%.6f sigma_deg=%.6f\n",
           bias * 180.0 / PI, coherence, result.bearing_deg,
           result.bearing_sigma_deg);
    return 0;
}
