`define CLK_SPEED_100M
`define BETTER_SENSITIVITY
`define HAS_OLD_SOFT_BITS_METHOD 1
`define SAMPLE_FILE "../../../../../testing_inputs/simulated/ht_mcs7_gi1_aggr0_len14_pre100_post200_openwifi.txt"
 
 
 
 
`define an_xc7z045
