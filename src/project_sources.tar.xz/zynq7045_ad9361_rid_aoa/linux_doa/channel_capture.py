#!/usr/bin/env python3
"""Bounded board-side channel survey; never filters by MAC or requires RID.

survey: protocol-independent software snapshots, with explicit coverage gaps.
stream: FPGA free-running paired IQ, independent of protocol; FIFO/PS gaps measured.
ofdm: any valid OFDM PHY header, including non-RID and unknown senders.
ofdm-valid: any FCS-valid OFDM packet; supplemental association diagnostics.
energy: rising RSSI threshold, requires an explicitly measured hardware threshold.
This is a sampled survey, not gap-free IQ recording or automatic drone classification.
"""
import argparse
import hashlib
import json
import math
import os
import signal
import socket
import struct
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from single_station import analyze


class SideChannel:
    def __init__(self):
        self.sock = socket.socket(socket.AF_NETLINK, socket.SOCK_RAW, 2)
        self.sock.bind((os.getpid(), 0))
        self.sock.settimeout(2)
        self.seq = 0

    def request(self, action, reg=0, value=0):
        self.seq += 1
        self.sock.sendto(struct.pack('=IHHII4I', 32, 0, 0, self.seq,
                                    os.getpid(), action, 1, reg, value), (0, 0))
        reply = self.sock.recv(70000)
        nlen = struct.unpack_from('=I', reply)[0]
        if not 16 <= nlen <= len(reply):
            raise RuntimeError('malformed netlink response')
        return reply[16:nlen]

    def read(self, reg):
        data = self.request(2, reg)
        if len(data) != 4:
            raise RuntimeError('unexpected register response')
        return struct.unpack('=I', data)[0]

    def write(self, reg, value):
        self.request(1, reg, value)


@contextmanager
def capture_profile(ch, mode='survey', rssi_threshold=None):
    parameter = Path('/sys/module/side_ch/parameters/iq_software_trigger')
    if not parameter.exists():
        raise RuntimeError('matching side_ch.packet.ko is required')
    saved = {reg: ch.read(reg) for reg in (1, 3, 5, 7, 8, 9, 11, 12)}
    old_trigger = parameter.read_text().strip()
    if saved[3] != 0x11 or saved[12] != 4096:
        raise RuntimeError('expected paired IQ and 4096 samples')
    try:
        parameter.write_text('1' if mode == 'survey' else '0')
        ch.write(0, 0xffffffff)
        ch.write(0, 0)
        ch.write(1, 1)
        ch.write(3, 0x11)
        ch.write(5, 1 if mode == 'stream' else 0)
        ch.write(12, 4096)
        ch.write(11, {'ofdm': 768, 'ofdm-valid': 4094}.get(mode, 512))
        ch.write(8, {'survey': 0, 'stream': 0, 'ofdm': 4, 'ofdm-valid': 1, 'energy': 10}[mode])
        if mode == 'energy':
            if rssi_threshold is None or not 0 <= rssi_threshold <= 2047:
                raise ValueError('measured RSSI threshold required')
            ch.write(9, rssi_threshold)
        yield dict(registers_before=saved, manual_trigger_before=old_trigger,
                   registers_active={reg: ch.read(reg) for reg in (1, 3, 5, 7, 8, 9, 11, 12, 20, 21, 22)})
    finally:
        ch.write(0, 0xffffffff)
        for reg, value in saved.items():
            ch.write(reg, value)
        ch.write(0, 0)
        parameter.write_text(old_trigger)


def resolve_rx_gains(gain_db=None, rx1_gain_db=None, rx2_gain_db=None):
    if gain_db is not None and (rx1_gain_db is not None or rx2_gain_db is not None):
        raise ValueError('equal and independent RX gains are mutually exclusive')
    if gain_db is None and rx1_gain_db is None and rx2_gain_db is None:
        return None
    if gain_db is not None:
        pair = (gain_db, gain_db)
    elif rx1_gain_db is None or rx2_gain_db is None:
        raise ValueError('both independent RX gains must be specified')
    else:
        pair = (rx1_gain_db, rx2_gain_db)
    if any(isinstance(v, bool) or not math.isfinite(v) or not 0 <= v <= 60 for v in pair):
        raise ValueError('fixed diagnostic gains must be finite values in 0..60 dB')
    return tuple(float(v) for v in pair)


def rf_device():
    return next(d for d in Path('/sys/bus/iio/devices').glob('iio:device*')
                if (d / 'name').read_text().strip() == 'ad9361-phy')


def set_manual_rx_gains(rx1_gain_db, rx2_gain_db, device=None):
    """Change gains within an existing manual session; never retune RF/clocks."""
    pair = resolve_rx_gains(rx1_gain_db=rx1_gain_db, rx2_gain_db=rx2_gain_db)
    device = device if device is not None else rf_device()
    modes = [(device / ('in_voltage%d_gain_control_mode' % i)).read_text().strip() for i in (0, 1)]
    if modes != ['manual', 'manual']:
        raise ValueError('both RX channels must already be in manual mode')
    for i, value in enumerate(pair):
        (device / ('in_voltage%d_hardwaregain' % i)).write_text(str(value))
    active = [(device / ('in_voltage%d_hardwaregain' % i)).read_text().strip() for i in (0, 1)]
    if any(abs(float(value.split()[0])-expected) > .05 for value, expected in zip(active, pair)):
        raise RuntimeError('RX gain readback does not match requested pair: '+str(active))
    return active


@contextmanager
def fixed_gain_profile(gain_db=None, *, rx1_gain_db=None, rx2_gain_db=None):
    """Bounded diagnostic; restore both modes and any original fixed gains."""
    pair = resolve_rx_gains(gain_db, rx1_gain_db, rx2_gain_db)
    if pair is None:
        yield None
        return
    device = rf_device()
    saved = []
    for i in (0, 1):
        saved.append(dict(mode=(device / ('in_voltage%d_gain_control_mode' % i)).read_text().strip(),
                          gain=(device / ('in_voltage%d_hardwaregain' % i)).read_text().split()[0]))
    try:
        for i in (0, 1):
            (device / ('in_voltage%d_gain_control_mode' % i)).write_text('manual')
        active = set_manual_rx_gains(*pair, device=device)
        time.sleep(.1)
        yield dict(before=saved, active_mode='manual', active_gains=active,
                   requested_gains_db=list(pair), session_id=uuid.uuid4().hex)
    finally:
        failures = []
        for i, value in enumerate(saved):
            try:
                if value['mode'] == 'manual':
                    (device / ('in_voltage%d_hardwaregain' % i)).write_text(value['gain'])
                (device / ('in_voltage%d_gain_control_mode' % i)).write_text(value['mode'])
            except Exception as exc:
                failures.append('RX%d: %s' % (i+1, exc))
        if failures:
            raise RuntimeError('RX restoration incomplete: '+'; '.join(failures))


def stop_capture(signum, frame):
    raise KeyboardInterrupt('capture stopped by signal %d' % signum)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', required=True)
    p.add_argument('--mode', choices=['survey', 'stream', 'ofdm', 'ofdm-valid', 'energy'], default='stream')
    p.add_argument('--count', type=int, default=20)
    p.add_argument('--seconds', type=float, default=20)
    p.add_argument('--rssi-threshold', type=int)
    p.add_argument('--rf-hz', type=float, default=2437000000)
    p.add_argument('--spacing-m', type=float, default=.060)
    p.add_argument('--sample-rate', type=float, default=20000000)
    p.add_argument('--phase-bias-deg', type=float)
    p.add_argument('--capture-only', action='store_true',
                   help='defer CPU-intensive analysis to PC; retain all raw windows')
    p.add_argument('--fixed-gain-db', type=float,
                   help='temporary equal manual RX gains, 0..60 dB; restored on exit')
    p.add_argument('--rx1-gain-db', type=float, help='temporary independent RX1 gain; specify both RX gains')
    p.add_argument('--rx2-gain-db', type=float, help='temporary independent RX2 gain; specify both RX gains')
    args = p.parse_args()
    try:
        pair = resolve_rx_gains(args.fixed_gain_db, args.rx1_gain_db, args.rx2_gain_db)
    except ValueError as exc:
        p.error(str(exc))
    signal.signal(signal.SIGTERM, stop_capture)
    if args.mode == 'energy' and (args.rssi_threshold is None or not 0 <= args.rssi_threshold <= 2047):
        p.error('energy mode requires measured --rssi-threshold (raw hardware units 0..2047)')
    if not 1 <= args.count <= 500 or not 0 < args.seconds <= 300:
        p.error('bounded experiment required: count 1..500, seconds 0..300')
    parameter = Path('/sys/module/side_ch/parameters/iq_software_trigger')
    if not parameter.exists():
        p.error('load matching side_ch.packet.ko before capture; do not load old modules')
    out = Path(args.out)
    out.mkdir()  # refuse overwriting previous experiments
    ch = SideChannel()
    metadata = dict(args=vars(args), kernel=os.uname().release,
                    source_filter='none',
                    rf_gain_configuration='temporary_manual_then_restore' if pair is not None else 'unchanged',
                    rf_readback_note='snapshot before capture; fixed_gain_profile contains active manual settings; AGC gains may vary',
                    coverage='finite snapshots with gaps; not continuous monitoring',
                    sample_rate_note='side_ch paired IQ assumed 20MSPS for current 40MSPS RF profile; verify after any PL/RF change')
    for device in Path('/sys/bus/iio/devices').glob('iio:device*'):
        if (device / 'name').read_text().strip() == 'ad9361-phy':
            names = ('out_altvoltage0_RX_LO_frequency', 'in_voltage_sampling_frequency',
                     'in_voltage0_gain_control_mode', 'in_voltage1_gain_control_mode',
                     'in_voltage0_hardwaregain', 'in_voltage1_hardwaregain')
            metadata['rf_readback'] = {name: (device / name).read_text().strip() for name in names}
            break
    if args.phase_bias_deg is not None and pair is None:
        modes = [metadata.get('rf_readback', {}).get('in_voltage%d_gain_control_mode' % i) for i in (0, 1)]
        if modes != ['manual', 'manual']:
            ch.sock.close()
            raise ValueError('calibrated bearing requires fixed RX gains matching calibration; omit phase bias for diagnostics')
    (out / 'metadata.json').write_text(json.dumps(metadata, indent=2))
    results, errors, captured = [], [], []
    started = time.monotonic()
    try:
        with fixed_gain_profile(args.fixed_gain_db, rx1_gain_db=args.rx1_gain_db,
                rx2_gain_db=args.rx2_gain_db) as gain_profile, capture_profile(ch, args.mode, args.rssi_threshold) as profile:
            metadata.update(profile)
            metadata['fixed_gain_profile'] = gain_profile
            (out / 'metadata.json').write_text(json.dumps(metadata, indent=2))
            while len(captured) < args.count and time.monotonic() - started < args.seconds:
                raw = ch.request(3)
                if len(raw) == 4:
                    code = struct.unpack('=i', raw)[0]
                    if code != -2:
                        errors.append(code)
                    time.sleep(.01)
                    continue
                if len(raw) != 32776:
                    raise RuntimeError('expected 32776 IQ bytes, got %d' % len(raw))
                index = len(captured) + 1
                name = 'window_%03d.raw' % index
                (out / name).write_bytes(raw)
                captured.append((index, out / name, time.monotonic()))
        capture_elapsed = time.monotonic() - started
        # Analysis is deliberately outside the acquisition loop. Pure Python
        # processing must not stall the small FPGA FIFO between every window.
        with (out / 'windows.jsonl').open('w') as log:
            for index, name, received in captured:
                raw = name.read_bytes()
                if args.capture_only:
                    result = dict(tsf=struct.unpack_from('<Q', raw)[0], samples=4096,
                        sha256=hashlib.sha256(raw).hexdigest(), observations=[],
                        whole_window={'coherence': None}, status='ANALYSIS_DEFERRED_TO_PC')
                else:
                    result = analyze(raw, args.rf_hz, args.spacing_m,
                                     args.sample_rate, args.phase_bias_deg)
                result.update(index=index, raw_path=str(name), mode=args.mode,
                              received_monotonic_s=received, source_filter='none')
                results.append(result)
                log.write(json.dumps(result, allow_nan=False) + '\n')
                log.flush()
                if not args.capture_only:
                    print(json.dumps(dict(index=index, tsf=result['tsf'],
                        whole_coherence=result['whole_window']['coherence'],
                        observations=result['observations'])), flush=True)
    finally:
        ch.sock.close()
    elapsed = time.monotonic() - started
    tsf_gaps = [b['tsf'] - a['tsf'] for a, b in zip(results, results[1:])]
    summary = dict(captured=len(results), elapsed_s=elapsed, capture_elapsed_s=capture_elapsed,
        analysis_elapsed_s=elapsed - capture_elapsed, errors=errors[:30],
        total_errors=len(errors), observations=sum(len(r['observations']) for r in results),
        bearing_outputs=sum(o['bearing_deg'] is not None for r in results for o in r['observations']),
        unique_tsf=len(set(r['tsf'] for r in results)),
        raw_observation_time_s=sum(r['samples'] for r in results) / args.sample_rate,
        nominal_iq_coverage_fraction=sum(r['samples'] for r in results) / args.sample_rate / capture_elapsed,
        tsf_step_us_min=min(tsf_gaps) if tsf_gaps else None,
        tsf_step_us_max=max(tsf_gaps) if tsf_gaps else None,
        tsf_step_us_median=sorted(tsf_gaps)[len(tsf_gaps)//2] if tsf_gaps else None,
        status=('analysis_deferred_to_pc' if args.capture_only else
                'calibration_required' if args.phase_bias_deg is None else 'needs_known_angle_validation'),
        source_filter='none', mode=args.mode)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2))
    print('SUMMARY ' + json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
