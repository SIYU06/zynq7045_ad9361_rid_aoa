"""Foreground systemd adapters; keep board-specific receiver code and roles."""
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import build_opener, ProxyHandler

STAGE=Path('/root/doa_stage')
BASE=Path('/root/openwifi_rx1')
RID=BASE/'rid_service'
KERNEL='5.15.0-175919-g427c94e8faa5-openwifi-rx1'
SIDE_HASH='1ae964db6169ebe2152158e0dd5486480ae622a7aee827ae0663f5e607987db6'

def identity():
    configured=json.loads((STAGE/'systemd/station.json').read_text())
    station=configured['station']
    expected={'A':'analog','B':'airspace-station-b'}[station]
    if socket.gethostname()!=expected or os.uname().release!=KERNEL:
        raise RuntimeError('Station identity or kernel mismatch')
    return station

def rf():
    identity()
    if (Path('/sys/module/side_ch')).exists():
        subprocess.run(['rmmod','side_ch'],check=True)
    subprocess.run(['sh',str(BASE/'start_openwifi_rid.sh')],check=True)

def latest_capture_writer(original_writer,managed_root):
    class LatestCapture(original_writer):
        def __init__(self,path,*args,**kwargs):
            path=Path(path)
            if path.parent!=managed_root:
                raise ValueError('Unexpected managed capture directory')
            for old in path.parent.glob('capture*.pcap'):
                if old!=path and old.is_file():old.unlink()
            super().__init__(path,*args,**kwargs)
    return LatestCapture

def monitor(station):
    sys.path.insert(0,str(RID))
    import monitor_service as module
    # Only the latest receiver generation is retained in volatile storage.
    # The existing PcapWriter keeps its 64 MiB cap and continues decoding at cap.
    module.PcapWriter=latest_capture_writer(module.PcapWriter,Path('/run/airspace-monitor'))
    original_run=module.Monitor.run
    def supervised_run(self):
        try:original_run(self)
        finally:self.stop.set()
    module.Monitor.run=supervised_run
    role=RID/'receiver_role.json'
    if not role.exists():role.write_text(json.dumps(dict(enabled=station=='B'))+'\n')
    (RID/'service.pid').write_text(str(os.getpid())+'\n')
    (RID/'last_run').write_text('/run/airspace-monitor\n')
    args=[str(RID/'monitor_service.py'),'--interface','sdr0','--listen','0.0.0.0',
          '--capture','/run/airspace-monitor/capture.pcap','--role-config',str(role)]
    if station=='B' and (RID/'dsss_channel').exists():
        channel=int((RID/'dsss_channel').read_text())
        node='/sys/firmware/devicetree/base/amba/dsss_rx@83c60000'
        if channel!=6 or not Path(node,'compatible').exists():
            raise RuntimeError('DSSS configuration must match the fixed 2437 MHz RF profile')
        args+=['--dsss-dt-node',node,'--dsss-channel',str(channel)]
    sys.argv=args
    module.main()

def iq(station):
    if hashlib.sha256((STAGE/'side_ch.packet.ko').read_bytes()).hexdigest()!=SIDE_HASH:
        raise RuntimeError('side_ch deployment hash mismatch')
    if not Path('/sys/module/side_ch').exists():
        subprocess.run(['insmod',str(STAGE/'side_ch.packet.ko'),'iq_len_init=4096',
                        'iq_dual_init=1','iq_software_trigger=0'],check=True)
    (STAGE/'target_capture_current.pid').write_text(str(os.getpid())+'\n')
    # Bind all local interfaces so reception does not depend on DHCP/link-local
    # address acquisition order. The existing control API rejects browser Origin.
    os.execv(sys.executable,[sys.executable,'-u',str(STAGE/'target_capture_service.py'),
        '--station',station,'--out','/run/airspace-iq/window-ring','--seconds','0',
        '--frequency-mhz','2437','--listen','0.0.0.0'])

def ready(kind):
    endpoint=('18788/api/iq/status' if kind=='iq' else '18771/api/receiver/status')
    opener=build_opener(ProxyHandler({}));deadline=time.monotonic()+18;error=None
    while time.monotonic()<deadline:
        try:
            with opener.open('http://127.0.0.1:'+endpoint,timeout=1) as response:value=json.load(response)
            if value.get('error'):raise RuntimeError(value['error'])
            if kind=='iq':
                if value.get('state') not in ('waiting_target','listening','capturing'):
                    raise RuntimeError('IQ not initialized')
                if value.get('metadata',{}).get('iq_sample_rate_hz')!=20000000:
                    raise RuntimeError('IQ clock profile unavailable')
            elif value.get('ready') is not True:raise RuntimeError('Receiver role not ready')
            print(json.dumps(value),flush=True);return
        except Exception as exc:error=exc;time.sleep(.25)
    raise RuntimeError('Startup readiness failed: '+str(error))

if __name__=='__main__':
    action=sys.argv[1]
    if action.startswith('ready-'):ready(action[6:])
    else:
        station=identity()
        {'rf':rf,'monitor':lambda:monitor(station),'iq':lambda:iq(station)}[action]()
