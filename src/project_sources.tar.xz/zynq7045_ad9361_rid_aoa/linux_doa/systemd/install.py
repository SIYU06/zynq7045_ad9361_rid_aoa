"""Install the explicitly requested persistent board services, with backups."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time
import uuid

PACKAGE=Path(__file__).resolve().parent
STAGE=Path('/root/doa_stage')
BASE=Path('/root/openwifi_rx1')
UNITS=('airspace-rf.service','airspace-monitor.service','airspace-iq.service','airspace.target')

def run(*args,**kwargs):return subprocess.run(args,check=True,**kwargs)

def stop_legacy():
    candidates=[(STAGE/'target_capture_current.pid',[str(STAGE/'target_capture_service.py'),str(STAGE/'gain_audit_service_20261103.py')]),
        (BASE/'rid_service/service.pid',[str(BASE/'rid_service/monitor_service.py')])]
    for path,owners in candidates:
        if not path.exists():continue
        text=path.read_text().strip()
        if not text.isdigit() or int(text)<2:raise RuntimeError('Invalid PID file: '+str(path))
        pid=int(text);proc=Path('/proc')/text
        if not (proc/'cmdline').exists():continue
        command=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if not command:continue
        if not any(owner in command for owner in owners):
            raise RuntimeError('PID reused or unexpected owner; refusing to signal: '+command)
        print('Stopping legacy PID',pid,command,flush=True)
        os.kill(pid,signal.SIGTERM);deadline=time.monotonic()+15
        while proc.exists() and time.monotonic()<deadline:
            try:
                if (proc/'stat').read_text().split(') ',1)[1].split()[0]=='Z':break
            except FileNotFoundError:break
            time.sleep(.1)
        else:
            if proc.exists():raise RuntimeError('Legacy process did not stop gracefully')

def main():
    station=sys.argv[1]
    if station not in ('A','B') or socket.gethostname()!=dict(A='analog',B='airspace-station-b')[station]:
        raise RuntimeError('Wrong station')
    if os.geteuid()!=0 or os.uname().release!='5.15.0-175919-g427c94e8faa5-openwifi-rx1':
        raise RuntimeError('Root and matching kernel required')
    manifest=json.loads((PACKAGE/'manifest.json').read_text())
    for name,expected in manifest['files'].items():
        if hashlib.sha256((PACKAGE/name).read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Package integrity: '+name)
    for dest in [STAGE/'target_capture_service.py',BASE/'start_openwifi_rid.sh']:
        expected=manifest['allowed_originals'][dest.name]
        if hashlib.sha256(dest.read_bytes()).hexdigest() not in expected:
            raise RuntimeError('Unexpected deployed original; inspect before replacement: '+str(dest))
    for unit in UNITS:
        if Path('/etc/systemd/system',unit).exists():
            raise RuntimeError('An installed unit already exists; inspect before reinstall: '+unit)
    backup=STAGE/('backup_autostart_20261103_'+uuid.uuid4().hex[:12]);backup.mkdir()
    destinations={BASE/'start_openwifi_rid.sh':PACKAGE/'start_openwifi_rid.sh',
                  STAGE/'target_capture_service.py':PACKAGE/'target_capture_service.py',
                  STAGE/'systemd/runtime.py':PACKAGE/'runtime.py',
                  STAGE/'systemd/station.json':None}
    destinations.update({Path('/etc/systemd/system')/u:PACKAGE/u for u in UNITS})
    receipt=dict(station=station,backup=str(backup),bootId=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                 originalFiles={},lightdmPersistentMaskBefore=Path('/etc/systemd/system/lightdm.service').is_symlink(),
                 lightdmRuntimeMaskBefore=Path('/run/systemd/system/lightdm.service').is_symlink())
    for dest in destinations:
        info=dict(existed=dest.exists() or dest.is_symlink())
        if dest.is_symlink():info['symlink']=os.readlink(dest)
        elif dest.exists():
            copied=backup/dest.relative_to('/');copied.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(dest,copied);info['backup']=str(copied)
        receipt['originalFiles'][str(dest)]=info
    (backup/'receipt.json').write_text(json.dumps(receipt,indent=2))
    print('BACKUP='+str(backup),flush=True)
    stop_legacy()
    for dest,source in destinations.items():
        dest.parent.mkdir(parents=True,exist_ok=True)
        if source is None:dest.write_text(json.dumps(dict(station=station))+'\n')
        else:shutil.copyfile(source,dest)
        dest.chmod(0o644)
    if station=='A':run('systemctl','mask','lightdm.service')
    run('systemctl','daemon-reload')
    run('systemd-analyze','verify',*[str(Path('/etc/systemd/system')/u) for u in UNITS])
    run('systemctl','enable','airspace.target')
    run('systemctl','start','airspace.target')
    receipt['installed']=True
    receipt['serviceConfiguration']=dict(iqSeconds=0,rfSampleRateHz=40000000,rxGainsDb=[0,0],frequencyMhz=2437)
    (backup/'receipt.json').write_text(json.dumps(receipt,indent=2))
    (STAGE/'systemd/install_receipt.json').write_text(json.dumps(receipt,indent=2))
    print('INSTALLED='+station,flush=True)
    run('systemctl','--no-pager','show',*UNITS,'-p','Id','-p','ActiveState','-p','SubState','-p','MainPID')

if __name__=='__main__':main()
