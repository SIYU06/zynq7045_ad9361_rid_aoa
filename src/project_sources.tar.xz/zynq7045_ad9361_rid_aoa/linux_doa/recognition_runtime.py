"""A Linux owns signal recognition/routing; PC retains scheduling and AoA fusion.

B exports signed, already-decoded monitor snapshots. The PC transports that
bundle unchanged to A; only A evaluates source evidence. No IQ register owner
or target-selection/lease loop is added by this service.
"""
import argparse
import copy
from collections import deque
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
from pathlib import Path
import re
import signal
import sys
import threading
import time
import uuid
from urllib.request import build_opener,ProxyHandler
sys.path.insert(0,'/root/openwifi_rx1/rid_service')
from mission_sources import classify_feed
from rid_view import map_snapshot

SCHEMA='airspace.board-recognition.v1'
MAX_BODY=4*1024*1024

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')
def signed(payload,key):return dict(payload=payload,signature=hmac.new(bytes.fromhex(key),canonical(payload),hashlib.sha256).hexdigest())
def verified(bundle,key):
    if not isinstance(bundle,dict) or set(bundle)!={'payload','signature'}:raise ValueError('Invalid relay envelope')
    p=bundle['payload'];expected=hmac.new(bytes.fromhex(key),canonical(p),hashlib.sha256).hexdigest()
    if not isinstance(bundle['signature'],str) or not hmac.compare_digest(bundle['signature'],expected):raise ValueError('Board relay signature mismatch')
    if p.get('producerStation')!='B' or not re.fullmatch('[0-9a-f]{32}',p.get('producerSession','')) or type(p.get('sequence')) is not int or p['sequence']<1:raise ValueError('Wrong relay source or sequence')
    return p

SOURCE_FIELDS=('mac','frequency_mhz','frames','ssid','first_monotonic','last_monotonic','phy_types','rid_recognition')
PACKET_FIELDS=('id','source_mac','destination_mac','frequency_mhz','fcs_valid','received_monotonic','frame_type','phy_type','protocol','length','retry','protected','frame_sha256','ht_mcs','rid_recognition')
DECODED_FIELDS=('ip_source','ip_destination','source_port','destination_port','video_hint')
def compact_feed(feed):
    packets=[]
    for original in feed.get('packets',[]):
        if original.get('fcs_valid') is not True:continue
        row={k:original[k] for k in PACKET_FIELDS if k in original}
        decoded=original.get('decoded',{});row['decoded']={k:decoded[k] for k in DECODED_FIELDS if k in decoded};packets.append(row)
    return dict(monotonic=feed['monotonic'],session_id=feed.get('session_id'),sources=[{k:s[k] for k in SOURCE_FIELDS if k in s} for s in feed.get('sources',[])],packets=packets)
def compact_state(state):
    return {k:state[k] for k in ('monotonic','session_id','mode','source','interface','status','frames','packets','errors','capture','targets') if k in state}

class ReplayGuard:
    def __init__(self):self.sessions=deque(maxlen=32);self.session=None;self.sequence=0
    def accept(self,p):
        session=p['producerSession'];sequence=p['sequence']
        if session!=self.session:
            if session in self.sessions:raise ValueError('Old producer session')
            self.sessions.append(session);self.session=session;self.sequence=0
        if sequence<=self.sequence:return False
        self.sequence=sequence;return True

class Recognition:
    def __init__(self,station,path):
        self.station=station;self.path=Path(path);self.config=json.loads(self.path.read_text())
        if self.config.get('station')!=station:raise ValueError('Recognition configuration station mismatch')
        self.key=self.config['pairKey']
        if not re.fullmatch('[0-9a-f]{64}',self.key):raise ValueError('Invalid board relay key')
        self.lock=threading.RLock();self.stop=threading.Event();self.session=uuid.uuid4().hex
        self.opener=build_opener(ProxyHandler({}));self.role={};self.monitor_state={};self.signal_feed={}
        self.sources=[];self.source_time=0;self.source_station=None;self.imported=None;self.guard=ReplayGuard()
        self.sequence=0;self.relay_bundle=None;self.errors={};self.counters={};self.last_monitor=0;self.events=deque(maxlen=100);self.last_classes={}
        self.latest_feed_hash=None;self.rid_state=None;self.rid_now=0;self.input_available=False;self.last_processed=None;self.packet_cache={};self.packet_session=None
    def count(self,key):self.counters[key]=self.counters.get(key,0)+1
    def request(self,url):
        with self.opener.open(url,timeout=2) as response:data=response.read(MAX_BODY+1)
        if len(data)>MAX_BODY:raise ValueError('Oversized local response')
        return json.loads(data)
    def import_bundle(self,bundle):
        if self.station!='A':raise ValueError('Recognition feed destination must be A')
        p=verified(bundle,self.key);feed=p.get('signalFeed',{});state=p.get('receiverState',{})
        if not isinstance(feed.get('sources'),list) or len(feed['sources'])>512 or not isinstance(feed.get('packets'),list) or len(feed['packets'])>1000 or not isinstance(state.get('targets'),list):raise ValueError('Invalid decoded feed')
        with self.lock:
            fresh=self.guard.accept(p)
            if fresh:
                self.imported=(copy.deepcopy(p),time.monotonic());self.latest_feed_hash=hashlib.sha256(canonical(bundle)).hexdigest();self.count('importedFeeds')
        return dict(accepted=True,new=fresh,digest=hashlib.sha256(canonical(bundle)).hexdigest())
    def tick(self):
        now=time.monotonic()
        if now-self.last_monitor>=1:
            role=self.request('http://127.0.0.1:18771/api/receiver/status')
            with self.lock:self.role=role
            if role.get('enabled') and role.get('ready'):
                feed=self.request('http://127.0.0.1:18771/api/signals');state=self.request('http://127.0.0.1:18771/api/state')
                with self.lock:self.signal_feed=compact_feed(feed);self.monitor_state=compact_state(state)
            else:
                with self.lock:self.signal_feed={};self.monitor_state={}
            self.last_monitor=now
        with self.lock:
            if self.station=='B':
                if self.role.get('enabled') and self.signal_feed:
                    if now-getattr(self,'bundle_time',0)>=1:
                        self.sequence+=1
                        self.relay_bundle=signed(dict(producerStation='B',producerSession=self.session,sequence=self.sequence,generatedMonotonic=now,signalFeed=self.signal_feed,receiverState=self.monitor_state),self.key);self.bundle_time=now;self.count('exportedFeeds')
                else:self.relay_bundle=None
                self.input_available=bool(self.relay_bundle)
            else:
                feed=state=None;feed_now=0;token=None
                if self.role.get('enabled') and self.signal_feed:
                    feed=self.signal_feed;state=copy.deepcopy(self.monitor_state);feed_now=now;self.source_station='A'
                    token=('A',feed.get('session_id'),feed['monotonic'])
                elif self.imported and now-self.imported[1]<5:
                    incoming,received=self.imported;feed=incoming['signalFeed'];state=copy.deepcopy(incoming['receiverState']);feed_now=incoming['generatedMonotonic']+now-received;self.source_station='B'
                    token=('B',incoming['producerSession'],incoming['sequence'])
                self.input_available=bool(feed)
                if feed and token!=self.last_processed:
                    state['monotonic']=feed_now
                    session=(self.source_station,feed.get('session_id'))
                    if session!=self.packet_session:self.packet_cache={};self.packet_session=session
                    for packet in feed.get('packets',[]):
                        if packet.get('fcs_valid') is True and 0<=feed_now-packet['received_monotonic']<10:
                            identity=(packet.get('id'),packet['received_monotonic'],packet.get('frame_sha256'));self.packet_cache[identity]=packet
                    current=sorted((p for p in self.packet_cache.values() if 0<=feed_now-p['received_monotonic']<10),key=lambda p:p['received_monotonic'])[-1200:]
                    self.packet_cache={(p.get('id'),p['received_monotonic'],p.get('frame_sha256')):p for p in current}
                    view=dict(feed,packets=current)
                    self.sources=classify_feed(view,state,self.source_station,feed_now)
                    self.source_time=now;self.count('classificationCycles');self.last_processed=token
                    self.rid_state=state;self.rid_now=feed_now
                    for source in self.sources:
                        kind=source['recognition']['kind']
                        if self.last_classes.get(source['key'])!=kind:
                            self.events.append(dict(monotonic=now,sourceKey=source['key'],kind=kind,label=source['recognition']['label']));self.last_classes[source['key']]=kind
                    if len(self.last_classes)>512:self.last_classes={s['key']:s['recognition']['kind'] for s in self.sources}
                elif not feed:
                    self.sources=[];self.rid_state=None;self.last_processed=None;self.count('waitingFeedCycles')
            self.errors.pop('runtime',None);self.count('cycles')
    def run(self):
        while not self.stop.is_set():
            try:self.tick()
            except Exception as exc:
                with self.lock:self.errors['runtime']=str(exc);self.input_available=False;self.relay_bundle=None
            self.stop.wait(.5)
    def snapshot(self):
        with self.lock:
            now=time.monotonic();rows=copy.deepcopy(self.sources)
            for s in rows:
                s['ageSeconds']+=max(0,now-self.source_time);s['fresh']=s['ageSeconds']<10
            rid=None;state=copy.deepcopy(self.rid_state)
            if state and self.input_available:
                state['monotonic']=self.rid_now+max(0,now-self.source_time)
                rid=map_snapshot(state,0);rid['relativeTimestamps']=True
                for t in rid['targets']:t.update(receiver=self.source_station,receiverStations=[self.source_station])
            return dict(schema=SCHEMA,station=self.station,sessionId=self.session,generatedMonotonic=now,processingLocation='board',recognitionStation='A',schedulerLocation='pc',
                state='error' if self.errors else 'classifying' if self.station=='A' and self.input_available else 'relaying' if self.station=='B' else 'waiting_feed',errors=dict(self.errors),
                inputAvailable=self.input_available,decoderRole=copy.deepcopy(self.role),sourceStation=self.source_station,sources=rows,rid=rid,events=list(self.events),counters=dict(self.counters),
                relayBundle=copy.deepcopy(self.relay_bundle),lastFeedDigest=self.latest_feed_hash)

def handler(service):
    class Handler(BaseHTTPRequestHandler):
        def send(self,value,status=200):
            body=json.dumps(value,ensure_ascii=False,allow_nan=False).encode('utf8');self.send_response(status)
            self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        def do_GET(self):
            if self.path=='/api/recognition/status':self.send(service.snapshot())
            else:self.send(dict(error='not found'),404)
        def do_POST(self):
            importing=self.path in ('/api/recognition/import?fcs=standard','/api/recognition/import?fcs=device')
            if self.path!='/api/recognition/feed' and not importing:self.send(dict(error='not found'),404);return
            if self.headers.get('Origin'):self.send(dict(error='server-to-server only'),403);return
            if importing:
                try:
                    size=int(self.headers.get('Content-Length','0'))
                    if service.station!='A' or not 0<size<=8*1024*1024:raise ValueError('Invalid capture import')
                    from capture_import import parse_capture
                    parsed=parse_capture(self.rfile.read(size),openwifi=self.path.endswith('device'))
                    from signal_recognition import classify_source
                    previews=[]
                    for source in parsed['sources']:
                        rows=[p for p in parsed['packets'] if p.get('fcs_valid') is True and p.get('source_mac')==source['mac'] and p.get('frequency_mhz')==source['frequency_mhz']]
                        previews.append(dict(mac=source['mac'],frequencyMhz=source['frequency_mhz'],historical=True,recognition=classify_source([source],rows)))
                    parsed.update(scoringLocation='board',scoringStation='A',scorePreview=previews)
                    self.send(parsed)
                except (ValueError,TypeError,KeyError,OSError,IndexError) as exc:self.send(dict(error=str(exc)),400)
                return
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=MAX_BODY:raise ValueError('Invalid request size')
                self.send(service.import_bundle(json.loads(self.rfile.read(size))))
            except (ValueError,TypeError,KeyError,OSError) as exc:self.send(dict(error=str(exc)),400)
        def log_message(self,*args):pass
    return Handler

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--station',choices=['A','B'],required=True);p.add_argument('--config',type=Path,required=True);p.add_argument('--port',type=int,default=18789);args=p.parse_args()
    import fcntl
    owner=Path('/tmp/airspace_recognition.lock').open('a');fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
    service=Recognition(args.station,args.config);server=ThreadingHTTPServer(('0.0.0.0',args.port),handler(service));server.timeout=.3
    signal.signal(signal.SIGTERM,lambda *_:service.stop.set());signal.signal(signal.SIGINT,lambda *_:service.stop.set())
    worker=threading.Thread(target=service.run,daemon=True);worker.start()
    try:
        while not service.stop.is_set():server.handle_request()
    finally:service.stop.set();worker.join(5);server.server_close()

if __name__=='__main__':main()
