#!/usr/bin/env python3
"""Burst-wise two-receiver phase interferometry, independent of MAC/RID.

No third-party packages. A coherent result is not proof of a drone or a
single propagation path. Calibration and array-hemisphere assumptions remain
explicit; diagnostic candidate angles are kept separate from bearings.
"""
import argparse
import hashlib
import json
import math
import statistics
import struct
from pathlib import Path

C = 299792458.0


def wrap(x):
    return (x + math.pi) % (2 * math.pi) - math.pi


def block_stats(samples):
    n = len(samples)
    means = [sum(s[k] for s in samples) / n for k in range(4)]
    p = [0.0, 0.0]
    z = 0j
    clipped = 0
    for s in samples:
        a = complex(s[0] - means[0], s[1] - means[1])
        b = complex(s[2] - means[2], s[3] - means[3])
        z += a.conjugate() * b
        p[0] += abs(a) ** 2
        p[1] += abs(b) ** 2
        # AD9361 12-bit samples are left-aligned in int16: positive ADC
        # full-scale is 2047 << 4 == 32752, not 32767. Count both rails.
        clipped += any(v >= 32752 or v <= -32768 for v in s)
    denominator = math.sqrt(p[0] * p[1])
    return dict(phase_rad=math.atan2(z.imag, z.real),
                coherence=min(1.0, abs(z) / denominator) if denominator else 0.0,
                rms=[math.sqrt(v / n) for v in p], clipped_fraction=clipped / n,
                cross=[z.real, z.imag], samples=n)


def circular_consensus(blocks, tolerance_deg=15):
    """Equal block votes prevent one high-power transient dominating the fit."""
    radius = math.radians(tolerance_deg)
    groups = [[b for b in blocks if abs(wrap(b['phase_rad'] - center['phase_rad'])) <= radius]
              for center in blocks]
    group = max(groups, key=len)
    z = sum(complex(math.cos(b['phase_rad']), math.sin(b['phase_rad'])) for b in group)
    phase = math.atan2(z.imag, z.real)
    spread = math.sqrt(sum(wrap(b['phase_rad'] - phase) ** 2 for b in group) / len(group))
    return phase, spread, group


def analyze(raw, rf_hz=2437000000.0, spacing_m=0.060, sample_rate=20000000.0,
            phase_bias_deg=None, block_size=64, min_coherence=0.7,
            min_blocks=3, consensus_fraction=0.8, noise_rms=None, phase_only=False):
    if (not math.isfinite(rf_hz) or rf_hz <= 0 or
            not math.isfinite(spacing_m) or not 0 < spacing_m <= (1 if phase_only else C / rf_hz / 2) or
            not math.isfinite(sample_rate) or sample_rate <= 0 or block_size < 8 or
            min_blocks < 2 or not 0 <= min_coherence <= 1 or
            not 0.5 < consensus_fraction <= 1 or
            (phase_only and phase_bias_deg is not None) or
            (phase_bias_deg is not None and not math.isfinite(phase_bias_deg)) or
            (noise_rms is not None and (not math.isfinite(noise_rms) or noise_rms <= 0))):
        raise ValueError('invalid geometry, quality threshold or sample rate')
    if len(raw) < 8 + block_size * min_blocks * 8 or (len(raw) - 8) % 8:
        raise ValueError('expected TSF plus whole paired int16 IQ samples')
    samples = list(struct.iter_unpack('<hhhh', raw[8:]))
    blocks = []
    for offset in range(0, len(samples) - block_size + 1, block_size):
        b = block_stats(samples[offset:offset + block_size])
        b['start_sample'] = offset
        blocks.append(b)
    energies = sorted(min(b['rms']) ** 2 for b in blocks)
    floor = energies[max(0, len(energies) // 10)]
    # A lower quantile is a usable background only when this window contains
    # substantial power contrast. Flat windows do NOT yield a claimed SNR.
    contrast = energies[-1] / max(floor, 1e-30)
    threshold = noise_rms ** 2 * 4 if noise_rms is not None else (floor * 4 if contrast >= 8 else 0)
    gating = 'supplied_noise_floor' if noise_rms else ('within_window_power_contrast' if threshold else 'coherence_only_no_noise_reference')
    runs, run = [], []
    for b in blocks:
        b['usable'] = (min(b['rms']) ** 2 > threshold and b['coherence'] >= min_coherence
                       and b['clipped_fraction'] <= 0.001)
        if b['usable']:
            run.append(b)
        elif run:
            runs.append(run)
            run = []
    if run:
        runs.append(run)
    observations = []
    scale = C / rf_hz / (2 * math.pi * spacing_m)
    for run in runs:
        if len(run) < min_blocks:
            continue
        phase, spread, accepted = circular_consensus(run)
        fraction = len(accepted) / len(run)
        corrected = wrap(phase - math.radians(phase_bias_deg or 0))
        direction_cosine = corrected * scale
        candidate = math.degrees(math.asin(direction_cosine)) if not phase_only and abs(direction_cosine) <= 1 else None
        status = 'QUALITY_ACCEPTED' if fraction >= consensus_fraction else 'MIXED_OR_UNSTABLE_PHASE'
        if status == 'QUALITY_ACCEPTED' and phase_bias_deg is None:
            status = 'UNCALIBRATED'
        elif status == 'QUALITY_ACCEPTED' and candidate is None:
            status = 'PHASE_OUT_OF_RANGE'
        bearing = candidate if status == 'QUALITY_ACCEPTED' else None
        # Within-burst dispersion only; NOT absolute accuracy or a confidence interval.
        angle_spread = (math.degrees(spread * scale / math.sqrt(1 - direction_cosine ** 2))
                        if not phase_only and abs(direction_cosine) < 1 else None)
        observations.append(dict(start_sample=run[0]['start_sample'],
            end_sample=run[-1]['start_sample'] + block_size,
            duration_us=len(run) * block_size / sample_rate * 1e6,
            phase_deg=math.degrees(phase), phase_spread_deg=math.degrees(spread),
            consensus_fraction=fraction, blocks=len(run), accepted_blocks=len(accepted),
            median_coherence=statistics.median(b['coherence'] for b in accepted),
            median_rx1_rms=statistics.median(b['rms'][0] for b in accepted),
            median_rx2_rms=statistics.median(b['rms'][1] for b in accepted),
            candidate_bearing_deg=candidate, bearing_deg=bearing,
            within_burst_angle_spread_deg=angle_spread, status=status,
            signal_identity='unknown', drone_classification='not_performed',
            ambiguity='front_back_and_unknown_elevation'))
    return dict(schema='single_station_doa_v1', tsf=struct.unpack_from('<Q', raw)[0],
        sha256=hashlib.sha256(raw).hexdigest(), samples=len(samples), rf_hz=rf_hz,
        spacing_m=spacing_m, iq_sample_rate_hz=sample_rate,
        phase_bias_deg=phase_bias_deg, calibrated=phase_bias_deg is not None,
        energy_gating=gating, noise_reference_rms=noise_rms,
        whole_window=block_stats(samples), observations=observations,
        status='OBSERVATIONS' if observations else 'NO_RELIABLE_COHERENT_BURST',
        dropped_tail_samples=len(samples) % block_size)


def calibrate(records, known_angle_deg, min_records=10):
    """Only feed captures of one physically identified known-angle source."""
    if not math.isfinite(known_angle_deg) or not -80 <= known_angle_deg <= 80:
        raise ValueError('calibration angle must be between -80 and 80 degrees')
    phases, geometry = [], None
    for record in records:
        key = (record['rf_hz'], record['spacing_m'])
        if geometry is not None and geometry != key:
            raise ValueError('mixed RF frequencies or antenna spacings')
        geometry = key
        candidates = [o for o in record['observations']
                      if o['consensus_fraction'] >= .8 and o['median_coherence'] >= .7]
        if len(candidates) != 1:
            continue
        spatial = 2 * math.pi * key[1] * key[0] / C * math.sin(math.radians(known_angle_deg))
        phases.append(dict(phase_rad=wrap(math.radians(candidates[0]['phase_deg']) - spatial)))
    if len(phases) < min_records:
        raise ValueError('insufficient isolated coherent calibration captures')
    bias, spread, accepted = circular_consensus(phases, tolerance_deg=10)
    if len(accepted) / len(phases) < .9 or math.degrees(spread) > 5:
        raise ValueError('calibration phase is not repeatable')
    return dict(phase_bias_deg=math.degrees(bias), phase_spread_deg=math.degrees(spread),
                records=len(phases), inliers=len(accepted), known_angle_deg=known_angle_deg,
                rf_hz=geometry[0], spacing_m=geometry[1],
                requires_matching_gain_cables_and_rf=True,
                source_identification='operator_must_confirm')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('raw', nargs='+')
    p.add_argument('--rf-hz', type=float, default=2437000000)
    p.add_argument('--spacing-m', type=float, default=.060)
    p.add_argument('--sample-rate', type=float, default=20000000)
    p.add_argument('--phase-bias-deg', type=float)
    p.add_argument('--noise-rms', type=float)
    args = p.parse_args()
    for name in args.raw:
        result = analyze(Path(name).read_bytes(), args.rf_hz, args.spacing_m,
                         args.sample_rate, args.phase_bias_deg, noise_rms=args.noise_rms)
        result['raw_path'] = name
        print(json.dumps(result, allow_nan=False))


if __name__ == '__main__':
    main()
