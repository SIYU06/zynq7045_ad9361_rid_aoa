#ifndef _DEFAULT_SOURCE
#define _DEFAULT_SOURCE
#endif

/*
 * Linux single-device DOA front end for the derived openwifi side_ch driver.
 * Live mode uses the driver's NETLINK_USERSOCK interface, so DMA ownership and
 * cache maintenance stay in the kernel DMA API. File mode is host-testable.
 */
#include "doa.h"

#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __linux__
#include <linux/netlink.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#endif

#define PI 3.14159265358979323846
#define C_M_S 299792458.0
#define MAX_DMA_BYTES (8192u * 8u)
#define ACTION_SIDE_INFO_GET 3u

typedef struct {
    const char *file;
    size_t samples_per_window;
    unsigned long windows;
    unsigned interval_ms;
    double rf_hz;
    double spacing_m;
    double phase_bias_rad;
    double min_coherence;
    int calibration;
    double calibration_angle_rad;
} options_t;

static void usage(const char *name)
{
    fprintf(stderr,
        "Usage: %s (--live | --file RAW) --samples N --rf-hz HZ --spacing-m M [options]\n"
        "Options:\n"
        "  --phase-bias-deg DEG       fixed RX2-RX1 channel bias (default 0)\n"
        "  --calibrate-angle-deg DEG  print bias from a source at known angle\n"
        "  --min-coherence X          validity threshold (default 0.20)\n"
        "  --windows N                windows to process; live N=0 is unlimited\n"
        "  --interval-ms N            delay between live requests (default 100)\n"
        "RAW is one or more windows: 8-byte LE TSF, then N LE int16 tuples\n"
        "I0,Q0,I1,Q1. Bearing sign is RX2 phase minus RX1 phase.\n", name);
}

static int parse_size(const char *text, size_t *value)
{
    char *end = NULL;
    unsigned long parsed;
    errno = 0;
    parsed = strtoul(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0' || parsed == 0u) {
        return -1;
    }
    *value = (size_t)parsed;
    return 0;
}

static int parse_ulong(const char *text, unsigned long *value)
{
    char *end = NULL;
    errno = 0;
    *value = strtoul(text, &end, 10);
    return (errno == 0 && end != text && *end == '\0') ? 0 : -1;
}

static int parse_double(const char *text, double *value)
{
    char *end = NULL;
    errno = 0;
    *value = strtod(text, &end);
    return (errno == 0 && end != text && *end == '\0' && isfinite(*value)) ? 0 : -1;
}

static int parse_options(int argc, char **argv, options_t *opt)
{
    int live = 0;
    int i;
    memset(opt, 0, sizeof(*opt));
    opt->windows = 1u;
    opt->interval_ms = 100u;
    opt->min_coherence = 0.20;

    for (i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--live") == 0) {
            live = 1;
        } else if (strcmp(argv[i], "--file") == 0 && ++i < argc) {
            opt->file = argv[i];
        } else if (strcmp(argv[i], "--samples") == 0 && ++i < argc) {
            if (parse_size(argv[i], &opt->samples_per_window) != 0) return -1;
        } else if (strcmp(argv[i], "--windows") == 0 && ++i < argc) {
            if (parse_ulong(argv[i], &opt->windows) != 0) return -1;
        } else if (strcmp(argv[i], "--interval-ms") == 0 && ++i < argc) {
            unsigned long value;
            if (parse_ulong(argv[i], &value) != 0 || value > 60000u) return -1;
            opt->interval_ms = (unsigned)value;
        } else if (strcmp(argv[i], "--rf-hz") == 0 && ++i < argc) {
            if (parse_double(argv[i], &opt->rf_hz) != 0) return -1;
        } else if (strcmp(argv[i], "--spacing-m") == 0 && ++i < argc) {
            if (parse_double(argv[i], &opt->spacing_m) != 0) return -1;
        } else if (strcmp(argv[i], "--phase-bias-deg") == 0 && ++i < argc) {
            double degrees;
            if (parse_double(argv[i], &degrees) != 0) return -1;
            opt->phase_bias_rad = degrees * PI / 180.0;
        } else if (strcmp(argv[i], "--calibrate-angle-deg") == 0 && ++i < argc) {
            double degrees;
            if (parse_double(argv[i], &degrees) != 0) return -1;
            opt->calibration = 1;
            opt->calibration_angle_rad = degrees * PI / 180.0;
        } else if (strcmp(argv[i], "--min-coherence") == 0 && ++i < argc) {
            if (parse_double(argv[i], &opt->min_coherence) != 0) return -1;
        } else {
            return -1;
        }
    }

    if ((live != 0) == (opt->file != NULL) || opt->samples_per_window == 0u ||
        opt->rf_hz <= 0.0 || opt->spacing_m <= 0.0 ||
        opt->min_coherence < 0.0 || opt->min_coherence > 1.0 ||
        opt->spacing_m > C_M_S / opt->rf_hz / 2.0) {
        return -1;
    }
    return 0;
}

static uint64_t read_le64(const uint8_t *p)
{
    uint64_t value = 0u;
    unsigned i;
    for (i = 0u; i < 8u; ++i) value |= (uint64_t)p[i] << (8u * i);
    return value;
}

static int16_t read_le_i16(const uint8_t *p)
{
    return (int16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8u));
}

static int16_t centered_i16(double value)
{
    if (value > 32767.0) return INT16_MAX;
    if (value < -32768.0) return INT16_MIN;
    return (int16_t)lrint(value);
}

static double wrap_pi(double phase)
{
    while (phase >= PI) phase -= 2.0 * PI;
    while (phase < -PI) phase += 2.0 * PI;
    return phase;
}

static int process_window(const uint8_t *raw, const options_t *opt,
                          unsigned long sequence)
{
    doa_iq_sample_t *samples;
    doa_config_t config;
    doa_result_t result;
    double mean[4] = {0.0, 0.0, 0.0, 0.0};
    double power1 = 0.0;
    double power2 = 0.0;
    double measured_phase;
    double coherence;
    size_t i;

    samples = (doa_iq_sample_t *)malloc(opt->samples_per_window * sizeof(*samples));
    if (samples == NULL) return -1;

    for (i = 0u; i < opt->samples_per_window; ++i) {
        const uint8_t *p = raw + 8u + i * 8u;
        mean[0] += read_le_i16(p + 0u);
        mean[1] += read_le_i16(p + 2u);
        mean[2] += read_le_i16(p + 4u);
        mean[3] += read_le_i16(p + 6u);
    }
    for (i = 0u; i < 4u; ++i) mean[i] /= (double)opt->samples_per_window;

    for (i = 0u; i < opt->samples_per_window; ++i) {
        const uint8_t *p = raw + 8u + i * 8u;
        const double a = (double)read_le_i16(p + 0u) - mean[0];
        const double b = (double)read_le_i16(p + 2u) - mean[1];
        const double c = (double)read_le_i16(p + 4u) - mean[2];
        const double d = (double)read_le_i16(p + 6u) - mean[3];
        samples[i].rx1_i = centered_i16(a);
        samples[i].rx1_q = centered_i16(b);
        samples[i].rx2_i = centered_i16(c);
        samples[i].rx2_q = centered_i16(d);
        power1 += a * a + b * b;
        power2 += c * c + d * d;
    }

    if (doa_calibrate_boresight(samples, opt->samples_per_window,
                                &measured_phase, &coherence) != 0) {
        free(samples);
        fprintf(stderr, "window=%lu error=zero_power_or_invalid_samples\n", sequence);
        return -1;
    }

    if (opt->calibration) {
        const double wavelength = C_M_S / opt->rf_hz;
        const double spatial = 2.0 * PI * opt->spacing_m *
                               sin(opt->calibration_angle_rad) / wavelength;
        const double bias = wrap_pi(measured_phase - spatial);
        printf("window=%lu tsf=%llu valid_samples=%lu amplitude_rx1=%.6f "
               "amplitude_rx2=%.6f measured_phase_deg=%.6f "
               "known_angle_deg=%.6f phase_bias_deg=%.6f coherence=%.6f mode=calibration\n",
               sequence, (unsigned long long)read_le64(raw),
               (unsigned long)opt->samples_per_window,
               sqrt(power1 / (double)opt->samples_per_window),
               sqrt(power2 / (double)opt->samples_per_window),
               measured_phase * 180.0 / PI,
               opt->calibration_angle_rad * 180.0 / PI,
               bias * 180.0 / PI, coherence);
        free(samples);
        return 0;
    }

    config.rf_frequency_hz = opt->rf_hz;
    config.antenna_spacing_m = opt->spacing_m;
    config.min_coherence = opt->min_coherence;
    memset(&result, 0, sizeof(result));
    result.bearing_deg = NAN;
    result.bearing_sigma_deg = NAN;
    result.snr_db = NAN;
    if (doa_estimate_block(&config, samples, opt->samples_per_window,
                           opt->phase_bias_rad, &result) != 0) {
        free(samples);
        fprintf(stderr, "window=%lu error=doa_estimation_failed\n", sequence);
        return -1;
    }

    printf("window=%lu tsf=%llu valid_samples=%lu amplitude_rx1=%.6f "
           "amplitude_rx2=%.6f phase_rx2_minus_rx1_deg=%.6f "
           "corrected_phase_deg=%.6f coherence=%.6f coherence_snr_proxy_db=%.3f "
           "bearing_deg=%.6f bearing_sigma_deg=%.6f flags=0x%02x\n",
           sequence, (unsigned long long)read_le64(raw),
           (unsigned long)opt->samples_per_window,
           sqrt(power1 / (double)opt->samples_per_window),
           sqrt(power2 / (double)opt->samples_per_window),
           result.total_phase_rad * 180.0 / PI,
           result.corrected_phase_rad * 180.0 / PI,
           result.coherence, result.snr_db, result.bearing_deg,
           result.bearing_sigma_deg, result.flags);
    free(samples);
    return 0;
}

static int process_payload(const uint8_t *raw, size_t length, const options_t *opt,
                           unsigned long *sequence)
{
    const size_t frame_bytes = 8u + opt->samples_per_window * 8u;
    size_t offset;
    if (length == 4u || length == 0u) return 1;
    if (length % frame_bytes != 0u) {
        fprintf(stderr, "payload_bytes=%lu expected_multiple=%lu error=format_mismatch\n",
                (unsigned long)length, (unsigned long)frame_bytes);
        return -1;
    }
    for (offset = 0u; offset < length; offset += frame_bytes) {
        if (process_window(raw + offset, opt, *sequence) != 0) return -1;
        ++*sequence;
        if (opt->windows != 0u && *sequence >= opt->windows) break;
    }
    return 0;
}

static int run_file(const options_t *opt)
{
    FILE *stream;
    uint8_t *raw;
    long length;
    unsigned long sequence = 0u;
    int status;
    stream = fopen(opt->file, "rb");
    if (stream == NULL) { perror(opt->file); return -1; }
    if (fseek(stream, 0, SEEK_END) != 0 || (length = ftell(stream)) < 0 ||
        fseek(stream, 0, SEEK_SET) != 0) {
        fclose(stream); return -1;
    }
    raw = (uint8_t *)malloc((size_t)length);
    if (raw == NULL || fread(raw, 1u, (size_t)length, stream) != (size_t)length) {
        free(raw); fclose(stream); return -1;
    }
    fclose(stream);
    status = process_payload(raw, (size_t)length, opt, &sequence);
    free(raw);
    return status < 0 ? -1 : 0;
}

#ifdef __linux__
static int run_live(const options_t *opt)
{
    const size_t allocation = NLMSG_SPACE(MAX_DMA_BYTES);
    struct sockaddr_nl local;
    struct sockaddr_nl kernel;
    struct nlmsghdr *nlh;
    struct iovec iov;
    struct msghdr message;
    struct timeval timeout;
    unsigned long sequence = 0u;
    int fd;

    fd = socket(PF_NETLINK, SOCK_RAW, NETLINK_USERSOCK);
    if (fd < 0) { perror("netlink socket"); return -1; }
    memset(&local, 0, sizeof(local));
    local.nl_family = AF_NETLINK;
    local.nl_pid = (uint32_t)getpid();
    if (bind(fd, (struct sockaddr *)&local, sizeof(local)) != 0) {
        perror("netlink bind"); close(fd); return -1;
    }
    timeout.tv_sec = 2;
    timeout.tv_usec = 0;
    (void)setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    memset(&kernel, 0, sizeof(kernel));
    kernel.nl_family = AF_NETLINK;
    nlh = (struct nlmsghdr *)calloc(1u, allocation);
    if (nlh == NULL) { close(fd); return -1; }

    while (opt->windows == 0u || sequence < opt->windows) {
        uint32_t *command;
        ssize_t received;
        int status;
        memset(nlh, 0, allocation);
        nlh->nlmsg_len = NLMSG_SPACE(4u * sizeof(uint32_t));
        nlh->nlmsg_pid = local.nl_pid;
        command = (uint32_t *)NLMSG_DATA(nlh);
        command[0] = ACTION_SIDE_INFO_GET;
        iov.iov_base = nlh;
        iov.iov_len = nlh->nlmsg_len;
        memset(&message, 0, sizeof(message));
        message.msg_name = &kernel;
        message.msg_namelen = sizeof(kernel);
        message.msg_iov = &iov;
        message.msg_iovlen = 1u;
        if (sendmsg(fd, &message, 0) < 0) { perror("netlink sendmsg"); break; }

        memset(nlh, 0, allocation);
        iov.iov_len = allocation;
        received = recvmsg(fd, &message, 0);
        if (received < 0) { perror("netlink recvmsg"); break; }
        if ((size_t)received < NLMSG_HDRLEN || nlh->nlmsg_len > (uint32_t)received ||
            nlh->nlmsg_len < NLMSG_HDRLEN) {
            fprintf(stderr, "error=invalid_netlink_reply\n"); break;
        }
        status = process_payload((const uint8_t *)NLMSG_DATA(nlh),
                                 nlh->nlmsg_len - NLMSG_HDRLEN, opt, &sequence);
        if (status < 0) break;
        if (opt->interval_ms != 0u) usleep(opt->interval_ms * 1000u);
    }
    free(nlh);
    close(fd);
    return (opt->windows == 0u || sequence >= opt->windows) ? 0 : -1;
}
#else
static int run_live(const options_t *opt)
{
    (void)opt;
    fprintf(stderr, "Live netlink mode is available only in the Linux build.\n");
    return -1;
}
#endif

int main(int argc, char **argv)
{
    options_t options;
    if (parse_options(argc, argv, &options) != 0) {
        usage(argv[0]);
        return 2;
    }
    return options.file != NULL ? (run_file(&options) == 0 ? 0 : 1)
                                : (run_live(&options) == 0 ? 0 : 1);
}
