#!/usr/bin/env python3
"""Temporary known-source capture for calibration, not the survey receiver.

The existing FPGA matches only source-MAC bytes 2..5. A captured IQ window
must still be verified against full-MAC/FCS-valid monitor frames on the PC.
All side_ch registers and RF gain modes are restored after this bounded run.
"""
import argparse
import hashlib
import json
import os
import signal
from pathlib import Path
import struct
import time
from channel_capture import SideChannel, capture_profile, fixed_gain_profile, resolve_rx_gains, stop_capture


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', required=True)
    p.add_argument('--mac', required=True)
    p.add_argument('--gain-db', type=float, help='equal fixed gains; default 20 dB if no gain arguments')
    p.add_argument('--rx1-gain-db', type=float)
    p.add_argument('--rx2-gain-db', type=float)
    p.add_argument('--count', type=int, default=20)
    p.add_argument('--seconds', type=float, default=30)
    p.add_argument('--spacing-m', type=float, default=.060)
    p.add_argument('--rf-hz', type=float, default=2437000000)
    args = p.parse_args()
    if args.gain_db is None and args.rx1_gain_db is None and args.rx2_gain_db is None:
        args.gain_db = 20
    try:
        resolve_rx_gains(args.gain_db, args.rx1_gain_db, args.rx2_gain_db)
    except ValueError as exc:
        p.error(str(exc))
    signal.signal(signal.SIGTERM, stop_capture)
    try:
        mac = bytes.fromhex(args.mac.replace(':', ''))
    except ValueError:
        p.error('invalid source MAC')
    if len(mac) != 6 or not 1 <= args.count <= 100 or not 0 < args.seconds <= 180:
        p.error('invalid MAC or capture bounds')
    out = Path(args.out)
    out.mkdir()
    ch = SideChannel()
    phy = next(d for d in Path('/sys/bus/iio/devices').glob('iio:device*')
               if (d / 'name').read_text().strip() == 'ad9361-phy')
    actual_rf = int((phy / 'out_altvoltage0_RX_LO_frequency').read_text())
    actual_sample_rate = int((phy / 'in_voltage_sampling_frequency').read_text())
    if abs(actual_rf - args.rf_hz) > 10 or actual_sample_rate != 40000000:
        ch.sock.close()
        raise RuntimeError('RF profile mismatch; this helper does not retune the receiver')
    if not 0 < args.spacing_m <= 299792458.0 / actual_rf / 2:
        ch.sock.close()
        raise ValueError('invalid antenna spacing')
    metadata = dict(args=vars(args), kernel=os.uname().release,
        purpose='known-source calibration only; not full-channel monitoring',
        source_match='partial MAC in FPGA, full MAC and FCS require monitor verification',
        expected_source_mac=args.mac.lower(), rf_hz=actual_rf, spacing_m=args.spacing_m,
        rf_sampling_frequency_hz=actual_sample_rate,
        iq_sample_rate_hz=20000000, iq_samples=4096,
        trigger='addr2 valid rising edge', pre_trigger_samples=1536,
        host_started_epoch=time.time(), clock_note='board wall clock unsynchronized; use hardware TSF')
    names = ('out_altvoltage0_RX_LO_frequency', 'out_altvoltage1_TX_LO_frequency',
             'in_voltage0_rf_port_select', 'in_voltage1_rf_port_select',
             'in_voltage_quadrature_tracking_en', 'in_voltage_bb_dc_offset_tracking_en',
             'in_voltage_rf_dc_offset_tracking_en')
    metadata['additional_rf_readback'] = {name: (phy / name).read_text().strip()
                                           for name in names if (phy / name).exists()}
    rows, errors = [], []
    started = time.monotonic()
    try:
        with fixed_gain_profile(args.gain_db, rx1_gain_db=args.rx1_gain_db,
                rx2_gain_db=args.rx2_gain_db) as gain, capture_profile(ch, 'ofdm') as profile:
            ch.write(7, int.from_bytes(mac[2:], 'big'))
            ch.write(1, 0x4001)
            ch.write(11, 1536)
            ch.write(8, 25)
            # Discard any FIFO entry generated while changing trigger/filter.
            ch.write(0, 0xffffffff)
            ch.write(0, 0)
            # Discard any FIFO entry generated while changing trigger/filter.
            ch.write(0, 0xffffffff)
            ch.write(0, 0)
            metadata.update(capture_profile=profile, fixed_gain_profile=gain,
                active_registers={r: ch.read(r) for r in (1, 3, 5, 7, 8, 11, 12)})
            (out / 'metadata.json').write_text(json.dumps(metadata, indent=2))
            while len(rows) < args.count and time.monotonic() - started < args.seconds:
                raw = ch.request(3)
                if len(raw) == 4:
                    code = struct.unpack('=i', raw)[0]
                    if code != -2:
                        errors.append(code)
                    time.sleep(.01)
                    continue
                if len(raw) != 32776:
                    raise RuntimeError('unexpected IQ payload bytes %d' % len(raw))
                name = 'window_%03d.raw' % (len(rows) + 1)
                (out / name).write_bytes(raw)
                row = dict(index=len(rows)+1, file=name, tsf=struct.unpack_from('<Q', raw)[0],
                           sha256=hashlib.sha256(raw).hexdigest(), monotonic_s=time.monotonic())
                rows.append(row)
                print(json.dumps(row), flush=True)
    finally:
        ch.sock.close()
    (out / 'windows.jsonl').write_text('\n'.join(json.dumps(r) for r in rows) + '\n')
    summary = dict(captured=len(rows), unique_tsf=len(set(r['tsf'] for r in rows)),
                   elapsed_s=time.monotonic()-started, errors=errors,
                   full_source_identity_verified=False, calibrated=False,
                   next_step='verify full MAC and hardware TSF against FCS-valid monitor packets')
    (out / 'summary.json').write_text(json.dumps(summary, indent=2))
    print('SUMMARY ' + json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
