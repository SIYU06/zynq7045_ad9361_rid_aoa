"""Audit saved stage ordering; raw register writes alone do not prove freshness.

Board PCAP epochs and tar mtimes share the board wall clock. They must not
be compared with PC wall time. This does not verify FPGA timing closure or
prove simultaneous sampling inside the RF chip.
"""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import struct
import tarfile
from reference_analysis import reference_packets, associate


def audit(capture, archive):
    meta = json.loads((capture / 'metadata.json').read_text())
    packets = reference_packets(capture / 'monitor.pcap',
        meta['expected_source_mac'], meta['expected_id'])
    with tarfile.open(archive) as tar:
        mtimes = {Path(m.name).name: m.mtime for m in tar.getmembers()
                  if m.isfile() and m.name.endswith('.ready')}
    result = dict(stages={}, transitions=[], duplicate_payloads=[],
        qualification='saved-data audit, not FPGA timing closure or RF simultaneity verification',
        wall_clock_note='PCAP epoch compared only to ready-file mtime from same board archive; tar time precision may be 1 second')
    seen = {}; all_rows = []; previous = None
    for stage in meta['plan']['stages']:
        folder = capture / stage['name']
        if not (folder / 'windows.jsonl').exists():
            continue
        rows = [json.loads(line) for line in (folder / 'windows.jsonl').read_text().splitlines() if line]
        detail = []
        ready_epoch = mtimes.get(stage.get('ready_file'))
        for row in rows:
            raw = (folder / row['file']).read_bytes()
            if len(raw) != 32776 or hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('raw length/hash mismatch: ' + str(folder / row['file']))
            tsf = struct.unpack_from('<Q', raw)[0]
            if tsf != row['tsf']:
                raise ValueError('raw TSF mismatch')
            link = associate(tsf, packets, 53)
            body_hash = hashlib.sha256(raw[8:]).hexdigest()
            if body_hash in seen:
                result['duplicate_payloads'].append(dict(previous=seen[body_hash],
                    current=[stage['name'], row['file']]))
            seen[body_hash] = [stage['name'], row['file']]
            packet_epoch = link['packet']['capture_epoch'] if link else None
            detail.append(dict(file=row['file'], tsf_us=tsf, read_monotonic_s=row['monotonic_s'],
                source_verified=link is not None, packet_epoch=packet_epoch,
                seconds_after_ready_file=packet_epoch-ready_epoch if packet_epoch is not None and ready_epoch is not None else None,
                iq_body_sha256=body_hash))
        intervals = [(b['tsf_us']-a['tsf_us'])/1e6 for a,b in zip(detail, detail[1:])]
        post_ready = [r['seconds_after_ready_file'] for r in detail if r['seconds_after_ready_file'] is not None]
        item = dict(windows=len(detail), source_verified=sum(r['source_verified'] for r in detail),
            strictly_increasing_tsf=all(i>0 for i in intervals), first=detail[0], last=detail[-1],
            median_tsf_interval_s=statistics.median(intervals) if intervals else None,
            ready_file_epoch=ready_epoch, min_seconds_after_ready_file=min(post_ready) if post_ready else None,
            max_seconds_after_ready_file=max(post_ready) if post_ready else None,
            rows=detail)
        result['stages'][stage['name']] = item
        if previous:
            prev_name, prev = previous
            tsf_gap = (detail[0]['tsf_us']-prev['tsf_us'])/1e6
            read_gap = detail[0]['read_monotonic_s']-prev['read_monotonic_s']
            result['transitions'].append(dict(previous=prev_name, current=stage['name'],
                tsf_gap_s=tsf_gap, cpu_read_gap_s=read_gap,
                cpu_gap_minus_tsf_gap_s=read_gap-tsf_gap))
        previous = stage['name'], detail[-1]
        all_rows.extend(detail)
    tsfs = [r['tsf_us'] for r in all_rows]
    result.update(windows=len(all_rows), unique_tsfs=len(set(tsfs)),
        identical_iq_body_replays=len(result['duplicate_payloads']))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.capture, args.archive)
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / 'audit.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(dict(windows=result['windows'], unique_tsfs=result['unique_tsfs'],
        identical_iq_body_replays=result['identical_iq_body_replays'],
        transitions=result['transitions'],
        stages={s:{k:v for k,v in r.items() if k!='rows'} for s,r in result['stages'].items()}), indent=2))


if __name__ == '__main__':
    main()
