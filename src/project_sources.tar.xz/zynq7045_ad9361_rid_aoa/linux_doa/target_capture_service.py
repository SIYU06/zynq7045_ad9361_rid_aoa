#!/usr/bin/env python3
"""Passive paired-IQ acquisition and board-local, source-conditioned DOA.

All-channel decoded monitoring stays independent. Addr2 filtering schedules IQ
work only. No angular reference is fitted. Raw IQ stays in a bounded local ring;
normal PC traffic carries compact board-computed observations.
"""
import argparse
import copy
import math
import base64
from collections import deque
import hashlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import signal
import socket
import struct
import sys
import threading
import time
import uuid
from urllib.parse import urlsplit,parse_qs
from channel_capture import SideChannel,capture_profile,fixed_gain_profile,rf_device,resolve_rx_gains
sys.path.insert(0,'/root/openwifi_rx1/rid_service')
from capture_io import monitor_frame
from wifi_channels import CHANNELS,channel_frequency,tune_channel
from capture_freshness import reference_tsf
from board_doa import (SCHEMA,ESTIMATOR,MAX_CONTEXT_BYTES,default_context,validate_context,
                       context_hash,compute_observation,implementation_hash)

class CaptureState:
    def __init__(self,station):
        self.lock=threading.Lock();self.stop=threading.Event();self.station=station
        self.session=uuid.uuid4().hex;self.task=None;self.frames=deque(maxlen=128)
        self.rows=deque(maxlen=32);self.raw={};self.index=0;self.counters={}
        self.results=deque(maxlen=32);self.direction_context=default_context(station)
        self.last_rejection=None;self.pending_tune=None;self.channel_error=None
        self.state='starting';self.error=None;self.metadata={};self.restored=False
    def count(self,key):
        with self.lock:self.counters[key]=self.counters.get(key,0)+1
    def set_target(self,value):
        if not isinstance(value,dict):raise ValueError('target must be an object')
        mac=value.get('mac','').lower();lease=float(value.get('leaseSeconds',12))
        frequency=float(value.get('frequencyMhz',0))
        if not re.fullmatch(r'(?:[0-9a-f]{2}:){5}[0-9a-f]{2}',mac) or int(mac[:2],16)&1 or mac in ('00:00:00:00:00:00','ff:ff:ff:ff:ff:ff'):
            raise ValueError('invalid unicast transmitter MAC')
        if not math.isfinite(frequency) or not 1<=lease<=30 or abs(frequency-self.metadata.get('rf_hz',0)/1e6)>.01:
            raise ValueError('lease outside 1..30 s or target is not on current RF channel')
        context=validate_context(value['directionContext'],self.station) if 'directionContext' in value else None
        with self.lock:
            if self.pending_tune or abs(frequency-self.metadata.get('rf_hz',0)/1e6)>.01:
                raise ValueError('RF is changing or target frequency is stale')
            if context is not None:self.direction_context=context
            digest=context_hash(self.direction_context)
            self.task=dict(mac=mac,frequencyMhz=frequency,expires=time.monotonic()+lease,contextHash=digest)
        return dict(accepted=True,mac=mac,leaseSeconds=lease,sessionId=self.session,contextHash=digest)
    def set_channel(self,value):
        if not isinstance(value,dict) or set(value)!={'channel'}:raise ValueError('Expected channel only')
        channel_frequency(value['channel'])
        job=dict(channel=value['channel'],done=threading.Event())
        with self.lock:
            if self.state in ('starting','stopped') or self.pending_tune:raise ValueError('RF owner is not ready or already tuning')
            if abs(self.metadata.get('rf_hz',0)-channel_frequency(value['channel'])*1000000)<100:
                return dict(accepted=True,channel=value['channel'],frequencyMhz=channel_frequency(value['channel']),sessionId=self.session)
            self.pending_tune=job;self.task=None
        if not job['done'].wait(8):raise ValueError('RF acknowledgement timed out; inspect actual channel')
        if job.get('error'):raise ValueError(job['error'])
        return job['result']

    def reset_frequency(self,rf):
        # Called only by the DMA owner with acquisition stopped.
        with self.lock:
            self.session=uuid.uuid4().hex;self.task=None
            self.frames.clear();self.rows.clear();self.raw.clear();self.results.clear()
            self.metadata=copy.deepcopy(self.metadata);self.metadata['rf_hz']=rf
            self.metadata['fixed_gain_profile']['session_id']=self.session
            self.last_rejection=None

    def snapshot(self,after=None,compact=False):
        with self.lock:
            value=dict(station=self.station,sessionId=self.session,state=self.state,error=self.error,
                task=dict(self.task) if self.task else None,metadata=copy.deepcopy(self.metadata),
                channelControl=dict(available=True,tuning=bool(self.pending_tune),error=self.channel_error,supportedChannels=sorted(CHANNELS)),
                counters=dict(self.counters),rfRestored=self.restored,generatedMonotonic=time.monotonic(),
                windows=[dict(row) for row in self.rows if after is not None and row['index']>after][-16:])
            if compact:
                value.pop('windows')
                value.update(schema=SCHEMA,processing=self.metadata.get('processing',{}),lastRejection=self.last_rejection,
                    observations=[dict(row) for row in self.results if after is not None and row['index']>after][-16:])
            return value

def receiver(state):
    with socket.socket(socket.AF_PACKET,socket.SOCK_RAW,socket.htons(3)) as sock:
        sock.bind(('sdr0',0));sock.settimeout(.25)
        while not state.stop.is_set():
            try:packet,address=sock.recvfrom(65536)
            except socket.timeout:continue
            if address[2]==4:continue
            try:
                with state.lock:task=dict(state.task) if state.task else None
                if not task or task['expires']<time.monotonic():continue
                # The general monitor still receives every frame. This extra
                # socket only needs the scheduled transmitter, before CRC work.
                tsf=reference_tsf(packet,bytes.fromhex(task['mac'].replace(':','')))
                if tsf is None:continue
                frame,meta=monitor_frame(packet,127,openwifi_fcs=True)
                if meta['fcs_valid'] is not True or len(frame)<24:continue
                fc=struct.unpack_from('<H',frame)[0]
                if ((fc>>2)&3) not in (0,2):continue
                row=dict(mac=':'.join('%02x'%b for b in frame[10:16]),tsf=tsf,
                    frameKey=hashlib.sha256(frame).hexdigest(),received=time.monotonic(),packetB64=base64.b64encode(packet).decode('ascii'))
                with state.lock:
                    if not state.pending_tune and state.task==task and abs(meta.get('frequency_mhz',0)-task['frequencyMhz'])<.01:state.frames.append(row)
            except (ValueError,IndexError,struct.error):state.count('monitorRejected')

def capture(state,out,seconds,expected_rf_hz=2437000000,rx_gain_db=0):
    ch=None;started=time.monotonic();before=None
    try:
        phy=rf_device();rf=int((phy/'out_altvoltage0_RX_LO_frequency').read_text())
        fs=int((phy/'in_voltage_sampling_frequency').read_text())
        if not any(abs(rf-channel_frequency(c)*1000000)<100 for c in CHANNELS) or fs!=40000000:
            raise RuntimeError('Expected supported passive HT20 RF / 40MHz profile; no retune attempted')
        ch=SideChannel()
        # The matching driver must have its initial paired-IQ dimensions set.
        with fixed_gain_profile(rx_gain_db) as gain,capture_profile(ch,'ofdm') as profile:
            before=gain['before']
            gain['session_id']=state.session
            state.metadata=dict(rf_hz=rf,iq_sample_rate_hz=20000000,spacing_m=.060,
                geometryStatus='software target only; physical geometry not confirmed',
                fixed_gain_profile=gain,capture_profile=profile,kernel=os.uname().release,
                phase_calibration=None,calibrationStatus='uncalibrated',
                pre_trigger_samples=1536,
                association='candidate full MAC/FCS/TSF interval; PC verifies LTF position against signal-latch timing',
                timing_profile=dict(signal_latch_after_ltf_us=19.0,tolerance_us=1.5,verified_reference_rate_mbps=6,
                    note='legacy SIGNAL latch; never apply to HT header latch'),
                timing_profiles=dict(ht20_sgi_mcs0_5_20261102=dict(signal_latch_after_ltf_us=30.5,tolerance_us=1.5,
                    verified_mcs=[0,1,2,3,4,5],kernel='5.15.0-175919-g427c94e8faa5-openwifi-rx1',
                    evidence='64 saved dual-RX windows across two actual non-RID video runs; no phase bias fitted')))
            state.metadata['processing']=dict(location='board',schema=SCHEMA,estimator=ESTIMATOR,
                implementationHash=implementation_hash(),rawTransport='diagnostic_request_only',angleReference='session_and_geometry_bound')
            state.metadata['association']='board verifies full MAC/FCS/LTF/TSF and computes single-station phase/reference/angle'
            (out/'metadata.json').write_text(json.dumps(state.metadata,indent=2))
            ch.write(11,1536);ch.write(8,25)
            thread=threading.Thread(target=receiver,args=(state,),daemon=True);thread.start()
            state.state='listening';active=None;boundary=0;last_tsf=-1;bodies=deque(maxlen=128)
            while not state.stop.is_set() and (seconds == 0 or time.monotonic()-started<seconds):
                with state.lock:job=state.pending_tune
                if job:
                    state.state='tuning';ch.write(0,0xffffffff);active=None
                    try:
                        tune_channel(job['channel'])
                        state.stop.wait(.25)
                        actual=int((phy/'out_altvoltage0_RX_LO_frequency').read_text())
                        if abs(actual-channel_frequency(job['channel'])*1000000)>100:raise ValueError('RF readback does not match requested channel')
                        rf=actual;state.reset_frequency(rf);state.channel_error=None
                        boundary=0;last_tsf=-1;bodies.clear()
                        job['result']=dict(accepted=True,channel=job['channel'],frequencyMhz=channel_frequency(job['channel']),sessionId=state.session)
                    except Exception as exc:
                        state.channel_error=str(exc);job['error']=str(exc)
                        rf=int((phy/'out_altvoltage0_RX_LO_frequency').read_text());state.reset_frequency(rf)
                    finally:
                        ch.write(0,0)
                        with state.lock:state.pending_tune=None
                        state.state='waiting_target';job['done'].set()
                    continue
                actual=int((phy/'out_altvoltage0_RX_LO_frequency').read_text())
                if abs(actual-rf)>100:
                    ch.write(0,0xffffffff);ch.write(0,0);rf=actual
                    state.reset_frequency(rf);active=None;boundary=0;last_tsf=-1;bodies.clear()
                    state.channel_error='External RF change; observations invalidated'
                with state.lock:task=dict(state.task) if state.task else None
                if not task or task['expires']<time.monotonic():
                    if active is not None:
                        ch.write(0,0xffffffff);ch.write(0,0);active=None
                    state.state='waiting_target';state.stop.wait(.1);continue
                if active!=task['mac']:
                    ch.write(0,0xffffffff)
                    ch.write(7,int(task['mac'].replace(':','')[4:],16));ch.write(1,0x4001)
                    with state.lock:boundary=max((f['tsf']+80 for f in state.frames),default=0)
                    ch.write(0,0);active=task['mac'];state.state='capturing'
                raw=ch.request(3)
                if len(raw)==4:
                    code=struct.unpack('=i',raw)[0]
                    if code!=-2:raise RuntimeError('DMA/netlink error %d'%code)
                    state.stop.wait(.01);continue
                if state.pending_tune or abs(int((phy/'out_altvoltage0_RX_LO_frequency').read_text())-rf)>100:continue
                if len(raw)!=32776:raise RuntimeError('Unexpected IQ payload')
                tsf=int.from_bytes(raw[:8],'little');body=hashlib.sha256(raw[8:]).hexdigest()
                if tsf<=boundary or tsf<=last_tsf or body in bodies:state.count('staleRejected');continue
                last_tsf=tsf;bodies.append(body)
                matches=[];deadline=time.monotonic()+.25
                while time.monotonic()<deadline:
                    with state.lock:
                        matches=[f for f in state.frames if f['mac']==active and 0<=tsf-f['tsf']<=80 and time.monotonic()-f['received']<2]
                    if matches:break
                    state.stop.wait(.01)
                # Same frame can appear twice on some monitor drivers: one TSF/hash is one observation.
                unique={(f['tsf'],f['frameKey']):f for f in matches}
                if not 1<=len(unique)<=4:state.count('associationRejected');continue
                reference=next(iter(unique.values()));now=time.monotonic()
                clipped=any(v>=32752 or v<=-32768 for sample in struct.iter_unpack('<hhhh',raw[8:]) for v in sample)
                if clipped:state.count('clippedRejected');continue
                with state.lock:
                    state.index+=1;index=state.index
                    row=dict(index=index,sourceMac=active,frequencyMhz=rf/1e6,tsf=tsf,frameKey=reference['frameKey'] if len(unique)==1 else None,
                        sessionId=state.session,sha256=hashlib.sha256(raw).hexdigest(),monotonic=now,
                        triggerDelayUs=tsf-reference['tsf'],associationVerified=False,freshnessVerified=True,
                        packetB64=reference['packetB64'],
                        referenceCandidates=[{k:f[k] for k in ('tsf','frameKey','packetB64')} for f in unique.values()],
                        rawPath='/api/iq/raw/'+str(index))
                    state.rows.append(row);state.raw[index]=raw
                    direction_context=state.direction_context
                    while len(state.raw)>32:del state.raw[min(state.raw)]
                result={key:row[key] for key in ('index','sourceMac','frequencyMhz','tsf','sessionId','sha256','monotonic')}
                result['contextHash']=context_hash(direction_context)
                analysis_started=time.monotonic()
                try:
                    observation=compute_observation(raw,row,state.metadata,direction_context)
                    result.update(observation=observation,associationVerified=True)
                    state.count('doaAccepted')
                except (ValueError,KeyError,IndexError) as exc:
                    result.update(rejection=str(exc),associationVerified=False)
                    state.count('doaRejected')
                    with state.lock:state.last_rejection=str(exc)
                result['processingMs']=(time.monotonic()-analysis_started)*1000
                with state.lock:state.results.append(result)
                # A fixed-size evidence ring preserves actual IQ without SD growth.
                raw_path=out/('window_%02d.raw'%(index%32));tmp=out/'window.tmp'
                tmp.write_bytes(raw);tmp.replace(raw_path)
                (out/'latest.json').write_text(json.dumps(row))
                state.count('candidateWindows')
                state.stop.wait(.01)
    except BaseException as exc:
        state.error=type(exc).__name__+': '+str(exc)
    finally:
        state.stop.set()
        if ch:ch.sock.close()
        try:
            phy=rf_device();modes=[(phy/('in_voltage%d_gain_control_mode'%i)).read_text().strip() for i in (0,1)]
            state.restored=bool(before and modes==[s['mode'] for s in before])
        except OSError:pass
        state.state='stopped'
        (out/'status.json').write_text(json.dumps(state.snapshot(),indent=2))

def handler(state):
    class Handler(BaseHTTPRequestHandler):
        def send(self,value,status=200,raw=False,telemetry=False):
            body=value if raw else json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
            if raw or telemetry:
                with state.lock:
                    name='raw' if raw else 'doa'
                    state.counters[name+'Responses']=state.counters.get(name+'Responses',0)+1
                    state.counters[name+'BytesServed']=state.counters.get(name+'BytesServed',0)+len(body)
            self.send_response(status);self.send_header('Content-Type','application/octet-stream' if raw else 'application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body)
        def do_GET(self):
            value=urlsplit(self.path)
            if value.path=='/api/iq/status':self.send(state.snapshot());return
            if value.path=='/api/doa/status':self.send(state.snapshot(compact=True));return
            if value.path in ('/api/iq/windows','/api/doa/observations'):
                try:after=int(parse_qs(value.query).get('after',['0'])[0])
                except ValueError:self.send(dict(error='invalid cursor'),400);return
                if after<0:self.send(dict(error='invalid cursor'),400);return
                compact=value.path=='/api/doa/observations'
                self.send(state.snapshot(after,compact=compact),telemetry=compact);return
            if re.fullmatch(r'/api/iq/raw/\d+',value.path):
                with state.lock:raw=state.raw.get(int(value.path.rsplit('/',1)[1]))
                self.send(raw,raw=True) if raw else self.send(dict(error='window expired'),404)
                return
            self.send(dict(error='not found'),404)
        def do_POST(self):
            if self.path not in ('/api/iq/target','/api/iq/channel'):self.send(dict(error='not found'),404);return
            # No browser cross-origin control of RF tasks.
            if self.headers.get('Origin'):self.send(dict(error='server-to-server only'),403);return
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=MAX_CONTEXT_BYTES+2048:raise ValueError('invalid size')
                value=json.loads(self.rfile.read(size))
                self.send(state.set_channel(value) if self.path=='/api/iq/channel' else state.set_target(value))
            except (ValueError,TypeError,KeyError) as exc:self.send(dict(error=str(exc)),400)
        def log_message(self,*args):pass
    return Handler

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--station',choices=['A','B'],required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--seconds',type=int,default=3600,
        help='10..3600 for a bounded run; 0 explicitly enables a supervised continuous service')
    p.add_argument('--frequency-mhz',type=int,default=2437,help='Startup profile hint; service retains an existing supported scan frequency on restart')
    p.add_argument('--port',type=int,default=18788)
    p.add_argument('--rx-gain-db',type=float,default=os.environ.get('AOA_RX_GAIN_DB','0'),
        help='Equal fixed manual RX gain, 0..60 dB; changing gain requires a matching reference')
    p.add_argument('--listen',default='0.0.0.0',help='Prefer the station point-to-point Ethernet address')
    args=p.parse_args()
    try:resolve_rx_gains(args.rx_gain_db)
    except ValueError as exc:p.error(str(exc))
    if args.seconds != 0 and not 10<=args.seconds<=3600:p.error('duration must be 0 (continuous) or 10..3600 seconds')
    if args.frequency_mhz not in {channel_frequency(c) for c in CHANNELS}:p.error('expected supported passive HT20 center frequency')
    # One owner of side-channel registers, including accidental duplicate launches.
    import fcntl
    owner=Path('/tmp/airspace_target_iq.lock').open('w');fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
    args.out.mkdir(parents=True,exist_ok=False);state=CaptureState(args.station)
    signal.signal(signal.SIGTERM,lambda *a:state.stop.set());signal.signal(signal.SIGINT,lambda *a:state.stop.set())
    server=ThreadingHTTPServer((args.listen,args.port),handler(state));server.timeout=.3
    worker=threading.Thread(target=capture,args=(state,args.out,args.seconds,args.frequency_mhz*1000000,args.rx_gain_db),daemon=True);worker.start()
    while worker.is_alive():server.handle_request()
    worker.join(3);server.server_close()

if __name__=='__main__':main()
