#!/bin/sh
# Run on the board after the matching openwifi runtime has initialized the RF.
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$here"
[ "$(id -u)" = 0 ] || { echo 'Run as root.' >&2; exit 1; }
[ -x ./linux_doa ] || { echo 'Missing executable: linux_doa' >&2; exit 1; }
[ -n "${DOA_ANTENNA_SPACING_M:-}" ] || {
    echo 'Set DOA_ANTENNA_SPACING_M to the measured phase-center spacing.' >&2
    exit 1
}
if ! grep -q '^side_ch ' /proc/modules; then
    [ -s ./side_ch.ko ] || { echo 'Missing matching side_ch.ko' >&2; exit 1; }
    insmod ./side_ch.ko iq_len_init=4096 iq_dual_init=1
fi
exec ./linux_doa --live --samples 4096 --windows "${DOA_WINDOWS:-0}" \
    --rf-hz "${DOA_RF_HZ:-2437000000}" \
    --spacing-m "$DOA_ANTENNA_SPACING_M" \
    --phase-bias-deg "${DOA_PHASE_BIAS_DEG:-0}" \
    --min-coherence "${DOA_MIN_COHERENCE:-0.20}" \
    --interval-ms "${DOA_INTERVAL_MS:-100}"
