/* Single-station subset reused from ../v3_two_station_doa/doa.c. */
#include "doa.h"

#include <math.h>

#define DOA_C_M_S 299792458.0
#define DOA_PI 3.14159265358979323846
#define DOA_SIGMA_SEGMENTS 8u

static double wrap_pi(double phase)
{
    while (phase >= DOA_PI) {
        phase -= 2.0 * DOA_PI;
    }
    while (phase < -DOA_PI) {
        phase += 2.0 * DOA_PI;
    }
    return phase;
}

static int measure_phase(const doa_iq_sample_t *samples,
                         size_t count,
                         double *phase_rad,
                         double *coherence)
{
    double cross_re = 0.0;
    double cross_im_for_rx2_minus_rx1 = 0.0;
    double power1 = 0.0;
    double power2 = 0.0;
    size_t i;

    if (samples == NULL || phase_rad == NULL || coherence == NULL || count == 0u) {
        return -1;
    }

    for (i = 0u; i < count; ++i) {
        const double a = (double)samples[i].rx1_i;
        const double b = (double)samples[i].rx1_q;
        const double c = (double)samples[i].rx2_i;
        const double d = (double)samples[i].rx2_q;

        cross_re += a * c + b * d;
        cross_im_for_rx2_minus_rx1 += a * d - b * c;
        power1 += a * a + b * b;
        power2 += c * c + d * d;
    }

    if (power1 == 0.0 || power2 == 0.0) {
        return -1;
    }

    *phase_rad = atan2(cross_im_for_rx2_minus_rx1, cross_re);
    *coherence = hypot(cross_re, cross_im_for_rx2_minus_rx1) /
                 sqrt(power1 * power2);
    return 0;
}

static int phase_to_bearing(const doa_config_t *config,
                            double phase_rad,
                            double *bearing_deg)
{
    const double wavelength_m = DOA_C_M_S / config->rf_frequency_hz;
    const double value = wavelength_m * phase_rad /
                         (2.0 * DOA_PI * config->antenna_spacing_m);

    if (value < -1.0 || value > 1.0) {
        return -1;
    }
    *bearing_deg = asin(value) * 180.0 / DOA_PI;
    return 0;
}

int doa_calibrate_boresight(const doa_iq_sample_t *samples,
                            size_t count,
                            double *phase_bias_rad,
                            double *coherence)
{
    return measure_phase(samples, count, phase_bias_rad, coherence);
}

int doa_estimate_block(const doa_config_t *config,
                       const doa_iq_sample_t *samples,
                       size_t count,
                       double phase_bias_rad,
                       doa_result_t *result)
{
    double segment_bearings[DOA_SIGMA_SEGMENTS];
    double segment_mean = 0.0;
    double segment_variance = 0.0;
    double wavelength_m;
    size_t segment_count;
    size_t s;

    if (config == NULL || samples == NULL || result == NULL ||
        config->rf_frequency_hz <= 0.0 || config->antenna_spacing_m <= 0.0 ||
        count < DOA_SIGMA_SEGMENTS) {
        return -1;
    }

    wavelength_m = DOA_C_M_S / config->rf_frequency_hz;
    if (config->antenna_spacing_m > wavelength_m / 2.0) {
        return -1;
    }

    if (measure_phase(samples, count, &result->total_phase_rad,
                      &result->coherence) != 0) {
        return -1;
    }

    result->corrected_phase_rad = wrap_pi(result->total_phase_rad - phase_bias_rad);
    result->flags = DOA_FLAG_ELEVATION_UNKNOWN;
    if (phase_to_bearing(config, result->corrected_phase_rad,
                         &result->bearing_deg) != 0) {
        result->flags |= DOA_FLAG_PHASE_OUT_OF_RANGE;
        return 0;
    }

    if (result->coherence < config->min_coherence) {
        result->flags |= DOA_FLAG_LOW_COHERENCE;
    } else {
        result->flags |= DOA_FLAG_VALID;
    }

    if (result->coherence >= 1.0) {
        result->snr_db = 100.0;
    } else if (result->coherence <= 0.0) {
        result->snr_db = -100.0;
    } else {
        result->snr_db = 10.0 * log10(result->coherence /
                                      (1.0 - result->coherence));
    }

    segment_count = count / DOA_SIGMA_SEGMENTS;
    for (s = 0u; s < DOA_SIGMA_SEGMENTS; ++s) {
        double phase;
        double ignored_coherence;
        if (measure_phase(samples + s * segment_count, segment_count,
                          &phase, &ignored_coherence) != 0 ||
            phase_to_bearing(config, wrap_pi(phase - phase_bias_rad),
                             &segment_bearings[s]) != 0) {
            return -1;
        }
        segment_mean += segment_bearings[s];
    }
    segment_mean /= (double)DOA_SIGMA_SEGMENTS;
    for (s = 0u; s < DOA_SIGMA_SEGMENTS; ++s) {
        const double error = segment_bearings[s] - segment_mean;
        segment_variance += error * error;
    }
    result->bearing_sigma_deg = sqrt(segment_variance /
                                     (double)(DOA_SIGMA_SEGMENTS - 1u));
    return 0;
}
