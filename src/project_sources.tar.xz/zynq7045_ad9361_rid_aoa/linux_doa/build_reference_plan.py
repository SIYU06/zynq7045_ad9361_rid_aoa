"""Generate a new board capture plan from the current measured geometry."""
import argparse
import json
import math
from pathlib import Path

def build(geometry,station,known_angle_deg,confirmation):
    if station not in geometry['station_positions']:raise ValueError('unknown station')
    if not math.isfinite(known_angle_deg) or abs(known_angle_deg)>80:raise ValueError('reference angle must be finite within +/-80 degrees')
    if not isinstance(confirmation,str) or len(confirmation.strip())<3:raise ValueError('actual reference placement confirmation is required')
    return dict(purpose='New reference for current physical geometry; no old phase offset reused',
        station_id=station,spacing_m=geometry['spacing_m'],reject_clipped_windows=True,
        operator_geometry=dict(baseline_m=geometry['baseline_m'],stations=geometry['station_positions'],
            reference_known_angle_deg=known_angle_deg,confirmation=confirmation),
        orientation_source='Actual station heading must be verified independently',
        reference_pcap_only=True,checkpoints=True,live_seconds=3600,
        stages=[dict(name='reference_current',gains=[0,0],count=40,seconds=90)])

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--geometry',type=Path,default=Path(__file__).with_name('current_geometry.json'))
    parser.add_argument('--station',choices=['A','B'],required=True)
    parser.add_argument('--known-angle-deg',type=float,required=True)
    parser.add_argument('--confirmation',required=True,help='Recorded physical reference placement, not a guessed zero')
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    plan=build(json.loads(args.geometry.read_text()),args.station,args.known_angle_deg,args.confirmation)
    with args.out.open('x',encoding='utf-8') as stream:json.dump(plan,stream,indent=2)
    print('Saved plan:',args.out,'spacing_m:',plan['spacing_m'],'baseline_m:',plan['operator_geometry']['baseline_m'])

if __name__=='__main__':main()
