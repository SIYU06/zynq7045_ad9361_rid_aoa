#ifndef LINUX_DOA_H
#define LINUX_DOA_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    int16_t rx1_i;
    int16_t rx1_q;
    int16_t rx2_i;
    int16_t rx2_q;
} doa_iq_sample_t;

typedef struct {
    double rf_frequency_hz;
    double antenna_spacing_m;
    double min_coherence;
} doa_config_t;

enum {
    DOA_FLAG_VALID = 1u << 0,
    DOA_FLAG_LOW_COHERENCE = 1u << 1,
    DOA_FLAG_PHASE_OUT_OF_RANGE = 1u << 2,
    DOA_FLAG_ELEVATION_UNKNOWN = 1u << 3
};

typedef struct {
    double total_phase_rad;
    double corrected_phase_rad;
    double bearing_deg;
    double bearing_sigma_deg;
    double coherence;
    double snr_db;
    uint32_t flags;
} doa_result_t;

int doa_calibrate_boresight(const doa_iq_sample_t *samples,
                            size_t count,
                            double *phase_bias_rad,
                            double *coherence);

int doa_estimate_block(const doa_config_t *config,
                       const doa_iq_sample_t *samples,
                       size_t count,
                       double phase_bias_rad,
                       doa_result_t *result);

#endif
