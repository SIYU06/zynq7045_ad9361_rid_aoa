#!/usr/bin/env python3
"""Verify calibration IQ against full-MAC, RID, FCS and hardware TSF.

Produces a provisional broadside reference, never a claim of angular accuracy.
The explicit trigger latency is specific to this FPGA/PHY/capture configuration.
"""
import argparse
import bisect
import json
import math
from pathlib import Path
import statistics
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'rid_receiver'))
from capture_io import read_capture, monitor_frame
from decoder import extract_frame, decode_payload
from single_station import analyze, calibrate, wrap, C


def analyze_reference_phase(raw,rf_hz,spacing_m,estimator='burst_phase_v1',ltf_max_start_sample=None):
    """Same phase extractor for calibration and live verified reference packets."""
    result=analyze(raw,rf_hz=rf_hz,spacing_m=spacing_m,phase_only=True)
    result['phase_estimator']=estimator
    if estimator=='burst_phase_v1': return result
    if estimator!='ofdm_ltf_unit_bins_v1': raise ValueError('unknown reference phase estimator')
    from ofdm_preamble import analyze_ofdm_ltf
    ltf=analyze_ofdm_ltf(raw,max_start_sample=ltf_max_start_sample)
    result['ltf']=ltf
    result['observations']=[]
    result['status']='NO_VERIFIED_REFERENCE_LTF'
    if result['whole_window']['clipped_fraction'] or not ltf['found']: return result
    result['status']='VERIFIED_REFERENCE_LTF'
    result['observations']=[dict(phase_deg=ltf['phase_unit_bins_deg'],status='UNCALIBRATED',
        phase_estimator=estimator,template_score=ltf['template_score'],repeat64=ltf['repeat64'],
        start_sample=ltf['start_sample'],bearing_deg=None,candidate_bearing_deg=None)]
    return result


def radiotap_tsf_us(packet):
    if len(packet) < 8 or packet[0] != 0:
        raise ValueError('invalid radiotap')
    length = struct.unpack_from('<H', packet, 2)[0]
    if not 8 <= length <= len(packet):
        raise ValueError('invalid radiotap length')
    cursor, first = 4, None
    while True:
        if cursor + 4 > length:
            raise ValueError('truncated radiotap bitmap')
        present = struct.unpack_from('<I', packet, cursor)[0]
        if first is None:
            first = present
        cursor += 4
        if not present & 0x80000000:
            break
    cursor = (cursor + 7) & ~7
    if not first & 1 or cursor + 8 > length:
        raise ValueError('missing radiotap TSFT')
    return struct.unpack_from('<Q', packet, cursor)[0]


def reference_packets(path, mac, uas_id):
    source = bytes.fromhex(mac.replace(':', ''))
    if len(source) != 6:
        raise ValueError('invalid MAC')
    result = []
    for index, (stamp, link, packet) in enumerate(read_capture(path), 1):
        if link != 127:
            continue
        frame, info = monitor_frame(packet, link, openwifi_fcs=True)
        if len(frame) < 24 or frame[10:16] != source or info['fcs_valid'] is not True:
            continue
        ids = [message.get('uas_id') for event in extract_frame(frame)
               for message in decode_payload(event['payload']) if message['type'] == 0]
        if uas_id not in ids:
            continue
        result.append(dict(tsf=radiotap_tsf_us(packet), pcap_packet_index=index,
            capture_epoch=stamp, mac=mac.lower(), uas_id=uas_id,
            frame_length=len(frame), metadata=info))
    return sorted(result, key=lambda r:r['tsf'])


def associate(iq_tsf, packets, expected_delay_us, tolerance_us=1):
    """Reject missing/ambiguous references, rather than guessing the nearest."""
    times = [r['tsf'] for r in packets]
    expected = iq_tsf - expected_delay_us
    left = bisect.bisect_left(times, expected - tolerance_us)
    right = bisect.bisect_right(times, expected + tolerance_us)
    if right - left != 1:
        return None
    packet = packets[left]
    return dict(packet=packet, trigger_delay_us=iq_tsf - packet['tsf'])


def require_matching_profile(metadata, calibration):
    original = calibration['capture_metadata']
    if (abs(metadata['rf_hz'] - original['rf_hz']) > 10 or
            abs(metadata['spacing_m'] - original['spacing_m']) > 1e-6 or
            metadata['iq_sample_rate_hz'] != original['iq_sample_rate_hz']):
        raise ValueError('calibration frequency, antenna spacing or IQ rate mismatch')
    active = metadata['fixed_gain_profile']
    expected = calibration['fixed_gain_profile']
    if (active.get('session_id') or expected.get('session_id')) and active.get('session_id') != expected.get('session_id'):
        raise ValueError('calibration RF session mismatch; revalidate after gain-mode reentry or restart')
    if active['active_mode'] != 'manual' or expected['active_mode'] != 'manual':
        raise ValueError('fixed manual gains required for this reference')
    gains = [float(v.split()[0]) for v in active['active_gains']]
    expected_gains = [float(v.split()[0]) for v in expected['active_gains']]
    if gains != expected_gains:
        raise ValueError('calibration RX gains mismatch')


def evaluate_rows(rows, calibration, known_angle_deg):
    checks = []
    for row in rows:
        phase = row['observations'][0]['phase_deg']
        corrected = wrap(math.radians(phase - calibration['phase_bias_deg']))
        value = corrected * C / (2 * math.pi * row['rf_hz'] * row['spacing_m'])
        angle = math.degrees(math.asin(value)) if abs(value) <= 1 else None
        checks.append(dict(tsf=row['tsf'], phase_deg=phase, diagnostic_bearing_deg=angle,
            error_from_reference_deg=angle-known_angle_deg if angle is not None else None))
    return checks


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--iq-dir', type=Path, required=True)
    p.add_argument('--pcap', type=Path, required=True)
    p.add_argument('--mac', required=True)
    p.add_argument('--uas-id', required=True)
    p.add_argument('--expected-trigger-delay-us', type=int, required=True)
    p.add_argument('--known-angle-deg', type=float, default=0)
    p.add_argument('--train-count', type=int, default=10)
    p.add_argument('--evaluate-calibration', type=Path,
                   help='evaluate a saved reference without refitting its phase bias')
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    if args.train_count < 10 or args.expected_trigger_delay_us < 0:
        p.error('at least 10 training windows and nonnegative trigger latency required')
    args.out.mkdir(exist_ok=False)
    metadata = json.loads((args.iq_dir / 'metadata.json').read_text())
    packets = reference_packets(args.pcap, args.mac, args.uas_id)
    rows = []
    for path in sorted(args.iq_dir.glob('window_*.raw')):
        row = analyze(path.read_bytes(), rf_hz=metadata['rf_hz'], spacing_m=metadata['spacing_m'])
        link = associate(row['tsf'], packets, args.expected_trigger_delay_us)
        row.update(raw_path=str(path), reference=link, reference_packet_verified=link is not None)
        rows.append(row)
    (args.out / 'windows.jsonl').write_text('\n'.join(json.dumps(r, allow_nan=False) for r in rows) + '\n')
    eligible = [r for r in rows if r['reference_packet_verified'] and len(r['observations']) == 1
                and r['observations'][0]['status'] == 'UNCALIBRATED']
    summary = dict(windows=len(rows), reference_verified=sum(r['reference_packet_verified'] for r in rows),
                   quality_eligible=len(eligible), trigger_delay_us=args.expected_trigger_delay_us,
                   accepted_for_production_bearing=False)
    if args.evaluate_calibration is not None:
        frozen = json.loads(args.evaluate_calibration.read_text())
        require_matching_profile(metadata, frozen)
        checks = evaluate_rows(eligible, frozen, args.known_angle_deg)
        errors = [abs(r['error_from_reference_deg']) for r in checks if r['error_from_reference_deg'] is not None]
        (args.out / 'frozen_reference_check.json').write_text(json.dumps(dict(
            calibration_file=str(args.evaluate_calibration), phase_bias_deg=frozen['phase_bias_deg'],
            phase_bias_refitted=False, expected_angle_deg=args.known_angle_deg, windows=checks), indent=2))
        summary.update(status='saved_reference_evaluated_without_refitting',
            phase_bias_deg=frozen['phase_bias_deg'], evaluated_windows=len(checks),
            reference_mae_deg=statistics.mean(errors) if errors else None,
            reference_max_abs_deg=max(errors) if errors else None)
    elif len(eligible) < args.train_count + 1:
        summary.update(status='insufficient_training_or_holdout', calibrated=False)
    else:
        train, holdout = eligible[:args.train_count], eligible[args.train_count:]
        try:
            cal = calibrate(train, args.known_angle_deg)
        except ValueError as exc:
            summary.update(status='unstable_calibration', error=str(exc), calibrated=False)
        else:
            checks = []
            for row in holdout:
                phase = row['observations'][0]['phase_deg']
                corrected = wrap(math.radians(phase - cal['phase_bias_deg']))
                cosine = corrected * C / (2 * math.pi * row['rf_hz'] * row['spacing_m'])
                bearing = math.degrees(math.asin(cosine)) if abs(cosine) <= 1 else None
                checks.append(dict(tsf=row['tsf'], diagnostic_bearing_deg=bearing,
                                   error_from_reference_deg=bearing - args.known_angle_deg if bearing is not None else None))
            errors = [abs(r['error_from_reference_deg']) for r in checks if r['error_from_reference_deg'] is not None]
            cal.update(status='provisional_known_angle_reference_only',
                source_identification='full_mac_rid_fcs_and_hardware_tsf_verified',
                reference_mac=args.mac, reference_id=args.uas_id,
                known_direction_source='operator-reported placement; geometry tolerance not measured',
                fixed_gain_profile=metadata['fixed_gain_profile'],
                capture_metadata=metadata, training_windows=[dict(tsf=r['tsf'], sha256=r['sha256']) for r in train],
                holdout=checks, holdout_reference_mae_deg=statistics.mean(errors) if errors else None,
                holdout_reference_max_abs_deg=max(errors) if errors else None,
                independent_nonzero_angles_validated=False, accepted_for_production_bearing=False)
            (args.out / 'provisional_calibration.json').write_text(json.dumps(cal, indent=2))
            summary.update(status='provisional_reference_computed', calibrated=True,
                phase_bias_deg=cal['phase_bias_deg'], training_windows=len(train),
                holdout_windows=len(holdout), holdout_reference_mae_deg=cal['holdout_reference_mae_deg'],
                holdout_reference_max_abs_deg=cal['holdout_reference_max_abs_deg'])
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
