"""PC-side dual-RX legacy-OFDM LTF diagnostics; never enables a bearing."""
import math
from pathlib import Path
import numpy as np

REFERENCE=Path(__file__).with_name('ofdm_lts_reference.txt')
_values=np.loadtxt(REFERENCE).ravel()
LTS=_values[::2]+1j*_values[1::2]


def analyze_ofdm_ltf(raw, min_template=.45, min_repeat=.85, max_start_sample=None):
    if len(raw)<8+128*8 or (len(raw)-8)%8:
        raise ValueError('expected TSF followed by paired int16 IQ')
    a=np.frombuffer(raw,dtype='<i2',offset=8).reshape(-1,4).astype(float)
    x=np.stack((a[:,0]+1j*a[:,1],a[:,2]+1j*a[:,3]))
    x-=x.mean(axis=1,keepdims=True)
    energy=np.stack([np.convolve(abs(v)**2,np.ones(64),'valid') for v in x])
    candidates=[]
    for name,t in (('normal',LTS),('conjugate',LTS.conj())):
        corr=np.stack([abs(np.correlate(v,t,'valid')) for v in x])
        scores=corr/np.sqrt(np.maximum(energy*np.sum(abs(t)**2),1e-30))
        joint=np.minimum(scores[:,:-64],scores[:,64:]).min(axis=0)
        if max_start_sample is not None:
            if not 0<=max_start_sample<len(joint):raise ValueError('invalid LTF search boundary')
            joint=joint[:max_start_sample+1]
        n=int(joint.argmax()); candidates.append((float(joint[n]),n,name))
    score,n,kind=max(candidates)
    segment=x[:,n:n+128]
    lag=np.sum(segment[:,:64].conj()*segment[:,64:],axis=1)
    powers=np.sum(abs(segment[:,:64])**2,axis=1)*np.sum(abs(segment[:,64:])**2,axis=1)
    repeat=abs(lag)/np.sqrt(np.maximum(powers,1e-30))
    result=dict(start_sample=n,template_orientation=kind,template_score=score,repeat64=repeat.tolist(),
        found=bool(score>=min_template and min(repeat)>=min_repeat),bearing_deg=None,
        status='NO_VERIFIED_LTF',iq_sample_rate_hz=20000000)
    if not result['found']: return result
    phase=float(np.angle(np.sum(segment[0].conj()*segment[1])))
    cfo=float(np.angle(np.sum(lag/np.maximum(abs(lag),1e-30)))/64)
    corrected=segment*np.exp(-1j*cfo*np.arange(128))
    first=np.fft.fft(corrected[:,:64],axis=1)
    second=np.fft.fft(corrected[:,64:],axis=1)
    f=(first+second)/2
    bins=np.r_[np.arange(-26,0),np.arange(1,27)]
    cross=f[0,bins%64].conj()*f[1,bins%64]
    unit=cross/np.maximum(abs(cross),1e-30)
    result.update(status='UNCALIBRATED_LTF',phase_ltf_deg=math.degrees(phase),
        phase_unit_bins_deg=math.degrees(float(np.angle(unit.sum()))),cfo_hz=cfo*20000000/(2*math.pi),
        unit_subcarrier_cross=[[float(v.real),float(v.imag)] for v in unit])
    # Equal known LTF symbols: (F1-F2)/2 estimates noise in their average.
    # This is a repeat-residual SNR proxy, not an RF noise figure or a LoS test.
    active=bins%64
    noise=np.mean(abs((first[:,active]-second[:,active])/2)**2,axis=1)
    power=abs(f[:,active])**2
    signal=np.maximum(np.mean(power,axis=1)-noise,0)
    snr=10*np.log10(np.maximum(signal,1e-20)/np.maximum(noise,1e-20))
    snr=np.clip(snr,-120,120)
    reliable=np.all(power >= noise[:,None]*(1+10**(.6)),axis=0)
    concentration=float(abs(unit.mean()))
    cross1=first[0,active].conj()*first[1,active]
    cross2=second[0,active].conj()*second[1,active]
    p1=np.angle(np.sum(cross1/np.maximum(abs(cross1),1e-30)))
    p2=np.angle(np.sum(cross2/np.maximum(abs(cross2),1e-30)))
    disagreement=abs(math.degrees(float(np.angle(np.exp(1j*(p2-p1))))))
    rms=np.sqrt(np.mean(abs(segment)**2,axis=1))
    peaks=np.max(abs(a),axis=0).reshape(2,2).max(axis=1)/32752
    reasons=[]
    if min(snr)<10:reasons.append('LTF重复残差信噪比低于10 dB')
    if int(reliable.sum())<40:reasons.append('双路可靠子载波不足40/52')
    if concentration<.85:reasons.append('子载波相位集中度低于0.85')
    if disagreement>10:reasons.append('两段LTF相位差异超过10°')
    # Gain advice uses whole-window headroom (including other transmitters).
    # Never change gain during a calibrated session automatically.
    advice=('reduce_gain_and_revalidate' if max(peaks)>.8 else
            'trial_increase_gain_and_revalidate' if min(snr)<10 and max(peaks)<.25 else
            'inspect_channel_or_interference' if reasons else 'hold_gain')
    result.update(signal_quality=dict(version='ltf_quality_v1',accepted=not reasons,reasons=reasons,
        snrProxyDb=snr.tolist(),snrMethod='CFO-corrected repeated-LTF spectral residual; averaged symbol',
        reliableSubcarriers=int(reliable.sum()),totalSubcarriers=52,
        subcarrierConcentration=concentration,repeatPhaseDifferenceDeg=disagreement,
        ltfRms=rms.tolist(),windowPeakFraction=peaks.tolist(),gainAdvice=advice,
        gainAdjustmentAutomatic=False,absoluteAccuracyVerified=False,
        thresholds=dict(minSnrProxyDb=10,minReliableSubcarriers=40,
            minSubcarrierConcentration=.85,maxRepeatPhaseDifferenceDeg=10)))
    return result
