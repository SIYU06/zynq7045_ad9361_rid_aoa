"""Strict stage freshness checks for bounded reference experiments."""
import hashlib
import struct
import time


def reference_tsf(packet, source_mac=bytes.fromhex('90e5b1ce2708')):
    """Parse TSFT and full addr2; caller must additionally check frame FCS."""
    if len(packet)<8 or packet[0]!=0: return None
    length=struct.unpack_from('<H',packet,2)[0]
    if not 8<=length<=len(packet) or len(packet)<length+24: return None
    if packet[length+10:length+16]!=source_mac: return None
    first=struct.unpack_from('<I',packet,4)[0]
    if not first&1: return None
    cursor=4
    while True:
        if cursor+4>length: return None
        present=struct.unpack_from('<I',packet,cursor)[0]; cursor+=4
        if not present&(1<<31): break
    cursor=(cursor+7)&~7
    return struct.unpack_from('<Q',packet,cursor)[0] if cursor+8<=length else None


def reset_for_fresh_stage(ch, latest_reference, record, expected_delay_us=53):
    """Hold/reset and read back empty, then establish a fresh TSF boundary.

    record is filled even if a check fails; caller persists it in finally.
    Resetting this side-channel does not retune RF or change gains.
    """
    deadline=time.monotonic()+5
    reference=None
    while time.monotonic()<deadline:
        reference=latest_reference()
        if reference and 0<=time.monotonic()-reference['received_monotonic_s']<=2.5: break
        time.sleep(.02)
    else:
        raise RuntimeError('no recent FCS-valid reference clock for stage boundary')
    record.update(reset_requested_monotonic_s=time.monotonic(),
        queued_words_before_reset=ch.read(20),reference_before_reset=reference,
        reset_hold_s=.1,expected_trigger_delay_us=expected_delay_us)
    ch.write(0,0xffffffff)
    try:
        time.sleep(.05); record['empty_counts']=[ch.read(20)]
        time.sleep(.05); record['empty_counts'].append(ch.read(20))
        reply=ch.request(3)
        record['empty_read_code']=struct.unpack('=i',reply)[0] if len(reply)==4 else None
        if record['empty_counts']!=[0,0] or record['empty_read_code']!=-2:
            raise RuntimeError('stage reset did not produce an empty FIFO')
        boundary=latest_reference()
        if not boundary or not 0<=time.monotonic()-boundary['received_monotonic_s']<=2.5:
            raise RuntimeError('reference clock stale at reset release')
        record.update(reference_at_release=boundary,
            minimum_iq_tsf_exclusive=boundary['tsf']+expected_delay_us,
            reset_verified_empty=True)
    finally:
        ch.write(0,0)
        record['reset_released_monotonic_s']=time.monotonic()


class WindowFreshnessGuard:
    """Reject old boundaries, backward/repeated TSF and identical IQ replay."""
    def __init__(self):
        self.last_tsf=None
        self.bodies=set()

    def check(self, raw, minimum_iq_tsf_exclusive):
        if len(raw)!=32776: raise RuntimeError('unexpected IQ bytes %d'%len(raw))
        tsf=struct.unpack_from('<Q',raw)[0]
        if tsf<=minimum_iq_tsf_exclusive:
            raise RuntimeError('IQ TSF is not newer than stage reset boundary')
        if self.last_tsf is not None and tsf<=self.last_tsf:
            raise RuntimeError('IQ TSF repeated or moved backwards')
        body_hash=hashlib.sha256(raw[8:]).hexdigest()
        if body_hash in self.bodies:
            raise RuntimeError('identical IQ body replay, even though header TSF may differ')
        self.last_tsf=tsf; self.bodies.add(body_hash)
        return dict(tsf=tsf,iq_body_sha256=body_hash,minimum_iq_tsf_exclusive=minimum_iq_tsf_exclusive,
            freshness_verified=True)
