"""Shared single-station phase-to-angle inversion; no cross-station fusion."""
import math
from single_station import C,wrap


def phase_bearing_candidates(phase,rf_hz,spacing_m):
    """All wrapped-phase solutions in the chosen front hemisphere, not 360 degrees."""
    if not all(math.isfinite(v) for v in (phase,rf_hz,spacing_m)) or rf_hz<=0 or not .001<=spacing_m<=1:
        raise ValueError('无效的频率或天线间距')
    period=C/(rf_hz*spacing_m)
    principal=wrap(phase)*period/(2*math.pi)
    first=math.ceil((-1-principal)/period-1e-12)
    last=math.floor((1-principal)/period+1e-12)
    return [math.degrees(math.asin(max(-1,min(1,principal+k*period)))) for k in range(first,last+1)]

