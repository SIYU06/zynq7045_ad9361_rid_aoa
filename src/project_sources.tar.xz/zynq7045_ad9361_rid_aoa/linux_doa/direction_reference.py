"""Receiver references, including explicit operator-authorized historical reuse."""
import hashlib
import json
import math
from pathlib import Path
import re

C = 299792458.0
STATUS = 'provisional_known_angle_reference_only'
PERSISTENT_POLICY = 'operator_fixed_outdoor_reference'


def persistent_reference(reference):
    return reference.get('reuse_policy') == PERSISTENT_POLICY and reference.get('operator_authorized_reuse') is True


def finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError('临时参考缺少有效字段：' + label)
    return float(value)


def load_reference(setup, root):
    name = setup.get('calibration')
    if not name:
        return None, None
    path = Path(root) / name
    if not path.exists():
        return None, None
    if path.stat().st_size > 1024 * 1024:
        raise ValueError('临时参考文件过大')
    value = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value, dict):
        raise ValueError('临时参考文件结构无效')
    digest = hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
    return value, digest


def validate_geometry(reference, setup):
    recorded = reference.get('station_geometry')
    if not isinstance(recorded, dict):
        raise ValueError('临时参考缺少站点几何')
    for name in ('antennaSpacingM', 'xM', 'yM', 'headingDeg'):
        if abs(finite(recorded.get(name), name)-finite(setup.get(name), name)) > 1e-6:
            raise ValueError('站点位置、朝向或天线间距已改变，需重新核对参考')


def validate_reference(reference, setup, row, metadata):
    if reference.get('status') != STATUS:
        raise ValueError('临时参考状态未通过')
    if reference.get('station_id') != setup['id']:
        raise ValueError('临时参考站点不匹配')
    if reference.get('phase_estimator') != 'ofdm_ltf_unit_bins_v1':
        raise ValueError('临时参考相位估计器不匹配')
    if reference.get('accepted_for_production_bearing') is not False:
        raise ValueError('临时参考必须明确保留非生产精度状态')
    bias = finite(reference.get('phase_bias_deg'), 'phase_bias_deg')
    sign = reference.get('bearing_sign')
    if isinstance(sign, bool) or sign not in (-1, 1):
        raise ValueError('临时参考方向符号无效')
    if abs(finite(reference.get('known_angle_deg'), 'known_angle_deg')) > 80:
        raise ValueError('临时参考已知角超出验证范围')
    mac = reference.get('reference_mac', '')
    if (not isinstance(mac, str) or not re.fullmatch(r'(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}', mac)
            or int(mac[:2], 16) & 1 or mac == '00:00:00:00:00:00'):
        raise ValueError('临时参考完整MAC无效')
    if not isinstance(reference.get('reference_id'), str) or not reference['reference_id'].strip():
        raise ValueError('临时参考身份缺失')
    capture = reference.get('capture_metadata', {})
    session = reference.get('capture_session_id')
    current_session = row.get('sessionId')
    persistent = persistent_reference(reference)
    if not isinstance(session, str) or not session or not isinstance(current_session,str) or not current_session:
        raise ValueError('参考或当前采集会话编号缺失')
    if not persistent and session != current_session:
        raise ValueError('采集会话已改变，临时参考不再适用')
    for name, tolerance in (('rf_hz', 10), ('spacing_m', 1e-6), ('iq_sample_rate_hz', 0)):
        if abs(finite(capture.get(name), name)-finite(metadata.get(name), name)) > tolerance:
            raise ValueError('临时参考频率、阵距或采样率不匹配')
    if metadata['rf_hz'] <= 0 or not .001 <= metadata['spacing_m'] <= 1 or metadata['iq_sample_rate_hz'] != 20000000:
        raise ValueError('临时参考射频或采样参数不在已验证范围')
    if abs(finite(metadata.get('spacing_m'), 'spacing_m')-finite(setup.get('antennaSpacingM'), 'antennaSpacingM')) > 1e-6:
        raise ValueError('当前IQ元数据与站点天线间距不匹配')
    original = reference.get('fixed_gain_profile')
    embedded = capture.get('fixed_gain_profile')
    current = metadata.get('fixed_gain_profile')
    for profile, expected_session in ((original,session),(embedded,session),(current,current_session)):
        if not isinstance(profile, dict) or profile.get('active_mode') != 'manual' or profile.get('session_id') != expected_session:
            raise ValueError('固定增益模式或射频会话不匹配')
        gains = profile.get('active_gains')
        if not isinstance(gains, list) or len(gains) != 2:
            raise ValueError('临时参考两路增益不完整')
    def gains(profile):
        try:
            result = [float(value.split()[0]) if isinstance(value, str) else float(value)
                      for value in profile['active_gains']]
        except (ValueError, TypeError, IndexError):
            raise ValueError('临时参考两路增益无效')
        if not all(math.isfinite(value) for value in result):
            raise ValueError('临时参考两路增益无效')
        return result
    if gains(original) != gains(embedded) or gains(original) != gains(current):
        raise ValueError('当前两路增益与临时参考不匹配')
    validate_geometry(reference, setup)
    return bias, sign


def apply_reference_data(observation, row, metadata, setup, reference, digest=None):
    """Apply only a matching receiver reference, retaining raw source-verified phase."""
    result = dict(observation, rawPhaseDeg=observation['phaseDeg'])
    if (observation.get('signalQuality') or {}).get('accepted') is False:
        return dict(result,relativeAngle=None,calibrationRequired=True,
            quality=observation['angleRejection'])
    try:
        if digest is None and reference is not None:
            digest = hashlib.sha256(json.dumps(reference, sort_keys=True).encode()).hexdigest()
        if reference is None or reference.get('status') == 'requires_reference':
            return result
        bias, sign = validate_reference(reference, setup, row, metadata)
        if observation.get('phaseEstimator') != reference['phase_estimator']:
            raise ValueError('当前窗口相位估计器与临时参考不匹配')
        phase = (math.radians(observation['phaseDeg']-bias)+math.pi) % (2*math.pi)-math.pi
        period = C/(metadata['rf_hz']*setup['antennaSpacingM'])
        principal = phase*period/(2*math.pi)
        first = math.ceil((-1-principal)/period-1e-12)
        last = math.floor((1-principal)/period+1e-12)
        candidates = [sign*math.degrees(math.asin(max(-1, min(1, principal+k*period)))) for k in range(first, last+1)]
        rejection = None if len(candidates) == 1 else '参考修正后相位超出阵列反演范围或存在多个角度解'
        result.update(relativeAngle=candidates[0] if len(candidates) == 1 else None,
            correctedPhaseDeg=math.degrees(phase), phaseBiasAppliedDeg=bias, bearingSign=sign,
            calibrationStatus='provisional_reference', calibrationRequired=False,
            referenceMatched=True, referenceHash=digest, referenceStationId=setup['id'],
            referenceSessionId=row['sessionId'], referenceKnownAngleDeg=reference['known_angle_deg'],
            referenceSourceMac=reference['reference_mac'], referenceId=reference['reference_id'],
            referenceRepeatabilityPassed=reference.get('repeatability_check_passed'),
            independentNonzeroAnglesValidated=reference.get('independent_nonzero_angles_validated') is True,
            productionAccepted=False, geometryVerified=False, angleRejection=rejection,
            quality=('临时参考／重复性未通过' if reference.get('repeatability_check_passed') is False else '临时已知参考／精度待独立验证') if rejection is None else '相位有效／'+rejection)
        if persistent_reference(reference):
            result.update(referencePolicy=PERSISTENT_POLICY,
                referenceCaptureSessionId=reference['capture_session_id'],
                referenceReusedAcrossSessions=reference['capture_session_id']!=row['sessionId'],
                referenceAssumedGeometry=reference.get('fixed_reference_geometry'),
                quality='沿用户外固定参考／精度未重新核验' if rejection is None else '沿用户外固定参考／'+rejection)
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as exc:
        result.update(relativeAngle=None, calibrationStatus='uncalibrated', calibrationRequired=True,
            referenceMatched=False, referenceError=str(exc), phaseBiasAppliedDeg=0,
            angleRejection='临时参考未应用：'+str(exc),
            quality='原始相位有效／临时参考不匹配', productionAccepted=False, geometryVerified=False)
    return result


def apply_reference(observation, row, metadata, setup, root):
    try:
        reference, digest = load_reference(setup, root)
    except (ValueError, KeyError, TypeError, OSError) as exc:
        return reject_reference(observation,str(exc))
    return apply_reference_data(observation,row,metadata,setup,reference,digest)


def reject_reference(observation,error):
    return dict(observation,rawPhaseDeg=observation["phaseDeg"],relativeAngle=None,calibrationStatus="uncalibrated",
        calibrationRequired=True,referenceMatched=False,referenceError=error,phaseBiasAppliedDeg=0,
        angleRejection="临时参考未应用："+error,quality="原始相位有效／临时参考不匹配",productionAccepted=False,geometryVerified=False)


def verify_observation_reference(observation, setup, root):
    """Reject queued/history observations after a reference or station edit."""
    reference, digest = load_reference(setup, root)
    if not reference or reference.get('status') != STATUS or digest != observation.get('referenceHash'):
        raise ValueError('临时参考已改变，等待当前会话重新计算角度')
    validate_geometry(reference, setup)
    persistent = persistent_reference(reference)
    if (reference.get('station_id') != setup['id'] or observation.get('referenceStationId') != setup['id']
            or (not persistent and reference.get('capture_session_id') != observation.get('sessionId'))
            or observation.get('referenceSessionId') != observation.get('sessionId')
            or observation.get('referenceMatched') is not True or observation.get('productionAccepted') is not False):
        raise ValueError('当前观测缺少匹配的临时参考依据')
    if persistent and (observation.get('referencePolicy') != PERSISTENT_POLICY
        or observation.get('referenceCaptureSessionId') != reference.get('capture_session_id')):
        raise ValueError('固定参考缺少历史来源依据')
