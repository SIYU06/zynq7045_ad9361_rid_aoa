"""Independently recheck saved reset records, raw hashes and reference PCAP."""
import hashlib
import json
import struct
from reference_analysis import reference_packets, associate


def verify_stage(capture, stage, packets=None, seen_tsfs=None, seen_bodies=None):
    folder=capture/stage
    meta=json.loads((folder/'metadata.json').read_text())
    timing=json.loads((folder/'freshness.json').read_text())
    if timing!=meta['stage_freshness']: raise ValueError('stage timing records disagree')
    if timing['empty_counts']!=[0,0] or timing['empty_read_code']!=-2 or not timing['reset_verified_empty']:
        raise ValueError('FIFO empty reset was not verified')
    minimum=timing['minimum_iq_tsf_exclusive']
    boundary=timing['reference_at_release']['tsf']
    if minimum!=boundary+53 or timing['expected_trigger_delay_us']!=53:
        raise ValueError('stage TSF boundary inconsistent')
    if timing['reset_released_monotonic_s']-timing['reset_requested_monotonic_s']<.1:
        raise ValueError('reset duration not recorded correctly')
    if packets is None:
        packets=reference_packets(capture/('monitor_'+stage+'.pcap'),meta['expected_source_mac'],meta['expected_id'])
    if associate(boundary+53,packets,53) is None:
        raise ValueError('reference boundary cannot be verified in PCAP')
    seen_tsfs=seen_tsfs if seen_tsfs is not None else set()
    seen_bodies=seen_bodies if seen_bodies is not None else set()
    previous=minimum; count=0; verified=0
    for name in ('discarded.jsonl','windows.jsonl'):
        for line in (folder/name).read_text().splitlines():
            if not line: continue
            row=json.loads(line)
            file=folder/row['file']
            if file.parent!=folder: raise ValueError('invalid saved filename')
            raw=file.read_bytes()
            if len(raw)!=32776 or hashlib.sha256(raw).hexdigest()!=row['sha256']:
                raise ValueError('raw length/hash mismatch')
            tsf=struct.unpack_from('<Q',raw)[0]
            body=hashlib.sha256(raw[8:]).hexdigest()
            if tsf<=previous or tsf in seen_tsfs or body in seen_bodies:
                raise ValueError('stale, reordered or repeated IQ')
            if row['tsf']!=tsf or row['iq_body_sha256']!=body or row['minimum_iq_tsf_exclusive']!=minimum:
                raise ValueError('saved freshness row does not match raw data')
            if row['monotonic_s']<=timing['reset_released_monotonic_s']:
                raise ValueError('IQ read predates reset release')
            previous=tsf; seen_tsfs.add(tsf); seen_bodies.add(body); count+=1
            verified+=associate(tsf,packets,53) is not None
    if verified!=count: raise ValueError('missing or ambiguous source association')
    return dict(stage=stage,reset_verified_empty=True,raw_windows_including_discards=count,
        reference_verified=verified,minimum_iq_tsf_exclusive=minimum,
        last_tsf=previous,independent_freshness_check_passed=True)
