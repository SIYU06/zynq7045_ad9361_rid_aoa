"""Shared source-conditioned LTF, full-frame association and single-site DOA.

Normal operation executes this module on each SDR; the PC wrapper is for offline audit.
"""
import base64
import hashlib
import math
from capture_io import monitor_frame
from reference_analysis import radiotap_tsf_us,analyze_reference_phase
from direction_math import phase_bearing_candidates


def analyze_window(raw,row,metadata,spacing,*,phase_analyzer=None,frame_decoder=None,tsf_reader=None,angle_solver=None):
    phase_analyzer=phase_analyzer or analyze_reference_phase
    frame_decoder=frame_decoder or monitor_frame
    tsf_reader=tsf_reader or radiotap_tsf_us
    angle_solver=angle_solver or phase_bearing_candidates
    if len(raw)!=32776 or hashlib.sha256(raw).hexdigest()!=row['sha256']:raise ValueError('IQ hash/size mismatch')
    tsf=int.from_bytes(raw[:8],'little')
    if tsf!=row['tsf'] or not row.get('freshnessVerified'):raise ValueError('IQ freshness mismatch')
    adaptive=row.get('referenceCandidates') is not None
    result=phase_analyzer(raw,metadata['rf_hz'],spacing,'ofdm_ltf_unit_bins_v1',
        ltf_max_start_sample=1408 if adaptive else None)
    if result['whole_window']['clipped_fraction'] or len(result['observations'])!=1:raise ValueError('LTF not unique, absent or ADC clipped')
    references=row.get('referenceCandidates')
    if references is None:references=[dict(packetB64=row['packetB64'],frameKey=row['frameKey'])]
    if not isinstance(references,list) or not 1<=len(references)<=4:raise ValueError('invalid reference candidates')
    # The IQ timestamp is captured at addr2-valid; the monitor timestamp is
    # captured at SIGNAL-valid (see side_ch_control.v/rx_intf_pl_to_m_axis.v).
    # LTF location in the pretrigger buffer links those clocks without assuming
    # every sender uses the reference module's 6 Mbps payload rate.
    preamble=result.get('ltf',{}).get('start_sample')
    if adaptive and (preamble is None or metadata.get('pre_trigger_samples')!=1536 or metadata.get('iq_sample_rate_hz')!=20000000):
        raise ValueError('LTF timing profile unavailable')
    tolerance=1.5 if adaptive else 1
    matches={}
    for reference in references:
        packet=base64.b64decode(reference['packetB64'],validate=True)
        frame,info=frame_decoder(packet,127,openwifi_fcs=True)
        mac=':'.join('%02x'%v for v in frame[10:16]);fingerprint=hashlib.sha256(frame).hexdigest()
        delay=tsf-tsf_reader(packet)
        if info['fcs_valid'] is not True or mac!=row['sourceMac'] or fingerprint!=reference['frameKey']:continue
        # HT header-valid occurs later in the receiver state machine than
        # legacy SIGNAL-valid. 30.5 us is verified on real A/B HT20 SGI
        # windows at MCS 0..5; unobserved modes remain rejected.
        ht=info.get('ht_mcs')
        if ht:
            if (not adaptive or ht['bandwidth_mhz']!=20 or ht['short_gi'] is not True or ht['index'] not in range(6)
                or metadata.get('kernel')!='5.15.0-175919-g427c94e8faa5-openwifi-rx1'):continue
            latch_offset=30.5;timing_profile='ht20_sgi_mcs0_5_20261102'
        else:latch_offset=19.0;timing_profile='legacy_signal_latch_v1'
        expected_delay=(1536-preamble)/20-latch_offset if adaptive else 53
        if not 0<=delay<=80 or abs(delay-expected_delay)>tolerance:continue
        frame_type=(frame[0]>>2)&3;subtype=frame[0]>>4
        # Repeated NULL frames can be bit-identical across many transmissions.
        # They are valid same-source phase samples, not unique cross-site events.
        pairing_eligible=(frame_type==2 and subtype in (0,8) and len(frame)>64) or (frame_type==0 and subtype in (5,8) and len(frame)>36)
        matches[(fingerprint,delay)]=(mac,fingerprint,delay,expected_delay,timing_profile,pairing_eligible)
    if len(matches)!=1:raise ValueError('full MAC/FCS/LTF/TSF reference not unique or not matched')
    mac,fingerprint,delay,expected_delay,timing_profile,pairing_eligible=next(iter(matches.values()))
    phase=result['observations'][0]['phase_deg']
    ltf=result.get('ltf',{})
    units=ltf.get('unit_subcarrier_cross',[])
    concentration=abs(sum(complex(*v) for v in units))/len(units) if units else None
    signal_quality=ltf.get('signal_quality')
    angles=angle_solver(math.radians(phase),metadata['rf_hz'],spacing)
    rejection=None if len(angles)==1 else '原始相位超出名义阵列反演范围或存在多个角度解；等待实际几何与标定'
    if signal_quality and not signal_quality['accepted']:
        rejection='目标LTF质量不足：'+'；'.join(signal_quality['reasons'])
        angles=[]
    return dict(relativeAngle=angles[0] if len(angles)==1 else None,phaseDeg=phase,phaseEstimator='ofdm_ltf_unit_bins_v1',angleRejection=rejection,
        coherence=result['whole_window']['coherence'],sourceMac=mac,frameKey=fingerprint,sessionId=row['sessionId'],
        tsf=tsf,freshnessVerified=True,sourceVerified=True,framePairingEligible=pairing_eligible,triggerDelayUs=delay,antennaSpacingM=spacing,
        preambleStartSample=preamble,timingResidualUs=delay-expected_delay,timingProfile=timing_profile,
        subcarrierConcentration=concentration,ltfTemplateScore=ltf.get('template_score'),ltfRepeat64=ltf.get('repeat64'),
        signalQuality=signal_quality,
        calibrationStatus='uncalibrated',calibrationRequired=True,phaseBiasAppliedDeg=0,
        productionAccepted=False,geometryVerified=False,
        quality='未校准诊断角／零相位偏置／实际几何待确认' if not rejection else '相位有效／角度不可反演：'+rejection)

