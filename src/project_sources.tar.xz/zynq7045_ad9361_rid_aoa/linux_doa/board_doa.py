"""Compact board DOA protocol and context binding, shared with the PC consumer."""
import copy
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
import re
from direction_reference import load_reference,apply_reference_data,reject_reference

SCHEMA='airspace.board-doa.v1'
ESTIMATOR='ofdm_ltf_unit_bins_v1'
MAX_CONTEXT_BYTES=128*1024

def context_hash(context):
    return hashlib.sha256(json.dumps(context,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def default_context(station):
    return dict(version=1,setup=dict(id=station,antennaSpacingM=.06,xM=None,yM=None,headingDeg=None),reference=None,referenceError=None)

def validate_context(context,station):
    if not isinstance(context,dict) or set(context)!={'version','setup','reference','referenceError'} or type(context['version']) is not int or context['version']!=1:
        raise ValueError('invalid direction context schema')
    value=json.loads(json.dumps(context,allow_nan=False))
    if len(json.dumps(value).encode())>MAX_CONTEXT_BYTES:raise ValueError('direction context too large')
    setup=value['setup']
    if not isinstance(setup,dict) or set(setup)!={'id','antennaSpacingM','xM','yM','headingDeg'} or setup['id']!=station:
        raise ValueError('direction context station mismatch')
    spacing=setup['antennaSpacingM']
    if type(spacing) not in (int,float) or not math.isfinite(spacing) or not .001<=spacing<=1:
        raise ValueError('invalid direction antenna spacing')
    for key in ('xM','yM','headingDeg'):
        v=setup[key]
        if v is not None and (type(v) not in (int,float) or not math.isfinite(v)):
            raise ValueError('invalid direction geometry')
    if value['reference'] is not None and not isinstance(value['reference'],dict):
        raise ValueError('direction reference must be an object or null')
    if value['referenceError'] is not None and not isinstance(value['referenceError'],str):
        raise ValueError('invalid reference error')
    return value

def context_from_setup(setup,root):
    context=default_context(setup['id'])
    context['setup']={key:setup.get(key) for key in ('id','antennaSpacingM','xM','yM','headingDeg')}
    try:
        context['reference'],digest=load_reference(setup,root)
        # Library captures require session verification. The original default
        # files retain the operator's explicit historical-reuse policy.
        if context['reference'] and re.fullmatch(r'aoa_profile_[0-9a-f]{32}_[AB]\.json',Path(setup.get('calibration','')).name):
            path=Path(root)/'runtime/aoa_reference_runtime.json'
            state=json.loads(path.read_text(encoding='utf8')) if path.exists() else {}
            saved=state.get('stations',{}).get(setup['id'],{})
            if saved.get('referenceHash')!=digest or saved.get('valid') is not True:
                context['referenceError']='基准需原位核验：'+str(saved.get('reason') or '当前射频会话尚未核验')
    except (ValueError,TypeError,KeyError,OSError) as exc:context['referenceError']=str(exc)
    return validate_context(context,setup['id'])

def verify_observation_context(observation,setup,root):
    if observation.get('processingLocation')=='board' and observation.get('directionContextHash')!=context_hash(context_from_setup(setup,root)):
        raise ValueError('站点几何或参考已改变，等待板端按新配置计算')

@lru_cache(maxsize=1)
def implementation_hash():
    root=Path(__file__).parent
    names=('source_doa.py','board_doa.py','direction_math.py','direction_reference.py',
           'ofdm_preamble.py','ofdm_lts_reference.txt','reference_analysis.py','single_station.py')
    return hashlib.sha256(b''.join(name.encode()+b'\0'+(root/name).read_bytes() for name in names)).hexdigest()

def compute_observation(raw,row,metadata,context):
    from source_doa import analyze_window
    observation=analyze_window(raw,row,metadata,context['setup']['antennaSpacingM'])
    if context.get('referenceError'):
        observation=reject_reference(observation,context['referenceError'])
    else:
        observation=apply_reference_data(observation,row,metadata,context['setup'],context.get('reference'))
    observation.update(processingLocation='board',directionContextHash=context_hash(context))
    return observation

def validate_observation(row,current,station,target,expected_context_hash):
    """Validate result bindings and ranges; never download IQ or recompute DOA."""
    if current.get('schema')!=SCHEMA or current.get('station')!=station or current.get('processing',{}).get('location')!='board':
        raise ValueError('板端DOA接口或站点版本不匹配，需先更新板端')
    if type(row.get('index')) is not int or row['index']<=0:raise ValueError('invalid board observation cursor')
    if row.get('contextHash')!=expected_context_hash:raise ValueError('等待当前配置的板端DOA结果')
    if row.get('rejection'):raise ValueError(row['rejection'])
    obs=copy.deepcopy(row.get('observation'))
    if not isinstance(obs,dict):raise ValueError('board observation absent')
    if (row.get('sessionId')!=current.get('sessionId') or obs.get('sessionId')!=row.get('sessionId')
        or row.get('sourceMac')!=target['mac'] or obs.get('sourceMac')!=target['mac']
        or type(row.get('frequencyMhz')) not in (int,float) or not math.isfinite(row['frequencyMhz']) or abs(row['frequencyMhz']-target['frequencyMhz'])>.01
        or obs.get('tsf')!=row.get('tsf') or type(row.get('tsf')) is not int or not 0<=row['tsf']<2**64):
        raise ValueError('board observation source/session/TSF mismatch')
    if not re.fullmatch('[0-9a-f]{64}',row.get('sha256','')) or not re.fullmatch('[0-9a-f]{64}',obs.get('frameKey','')):
        raise ValueError('invalid board IQ/frame digest')
    if (row.get('associationVerified') is not True or obs.get('sourceVerified') is not True
        or obs.get('freshnessVerified') is not True or obs.get('processingLocation')!='board'
        or obs.get('phaseEstimator')!=ESTIMATOR or obs.get('directionContextHash')!=expected_context_hash
        or obs.get('productionAccepted') is not False or obs.get('geometryVerified') is not False
        or obs.get('calibrationStatus') not in ('uncalibrated','provisional_reference')):
        raise ValueError('board DOA evidence or calibration flags invalid')
    for key,low,high in (('phaseDeg',-180,180),('coherence',0,1),('subcarrierConcentration',0,1),
                         ('ltfTemplateScore',.45,1.000001),('timingResidualUs',-1.5,1.5)):
        value=obs.get(key)
        if type(value) not in (int,float) or not math.isfinite(value) or not low<=value<=high:
            raise ValueError('invalid board DOA metric: '+key)
    repeat=obs.get('ltfRepeat64')
    if not isinstance(repeat,list) or len(repeat)!=2 or any(type(v) not in (int,float) or not math.isfinite(v) or not .85<=v<=1.000001 for v in repeat):
        raise ValueError('invalid board LTF repeat evidence')
    angle=obs.get('relativeAngle')
    quality=obs.get('signalQuality')
    if quality is not None:
        if (not isinstance(quality,dict) or quality.get('version')!='ltf_quality_v1'
            or type(quality.get('accepted')) is not bool):
            raise ValueError('invalid board LTF quality evidence')
        if quality['accepted'] is False and angle is not None:
            raise ValueError('quality-rejected LTF must not produce an angle')
    if angle is not None and (type(angle) not in (int,float) or not math.isfinite(angle) or abs(angle)>90):
        raise ValueError('invalid board angle')
    if type(obs.get('framePairingEligible')) is not bool:raise ValueError('board frame pairing eligibility absent')
    if obs.get('rawPhaseDeg')!=obs['phaseDeg']:raise ValueError('board raw phase binding invalid')
    return obs
