// SPDX-License-Identifier: GPL-2.0-or-later
// Passive DSSS packet mailbox. One committed packet + one in-flight packet.
// Bytes become visible only after PHY FCS verification and exact byte count.
// No changes to the parallel OFDM receiver, DMA, ACK or transmit path.
`timescale 1ns/1ps
module dsss_axi_rx (
 (* X_INTERFACE_PARAMETER = "ASSOCIATED_BUSIF s_axi, ASSOCIATED_RESET aresetn" *)
 input wire aclk,
 (* X_INTERFACE_PARAMETER = "POLARITY ACTIVE_LOW" *) input wire aresetn,
 input wire [31:0] iq_word, // Openwifi rx_intf sample0 = {I[15:0],Q[15:0]}
 input wire iq_strobe,
 input wire [63:0] tsf_us,
 input wire [15:0] s_axi_awaddr,
 input wire [2:0] s_axi_awprot,
 input wire s_axi_awvalid, output wire s_axi_awready,
 input wire [31:0] s_axi_wdata, input wire [3:0] s_axi_wstrb,
 input wire s_axi_wvalid, output wire s_axi_wready,
 output wire [1:0] s_axi_bresp, output reg s_axi_bvalid, input wire s_axi_bready,
 input wire [15:0] s_axi_araddr, input wire [2:0] s_axi_arprot,
 input wire s_axi_arvalid, output wire s_axi_arready,
 output reg [31:0] s_axi_rdata, output wire [1:0] s_axi_rresp,
 output reg s_axi_rvalid, input wire s_axi_rready
);
 reg enabled, pending, capturing, write_bank, pending_bank;
 reg [11:0] expected_length, pending_length;
 reg [12:0] byte_count;
 reg [63:0] header_time, pending_time;
 reg [31:0] sequence_number, pending_sequence, dropped, headers, good, bad;
 (* ram_style="block" *) reg [31:0] packet_ram [0:2047];
 reg [31:0] packet_word;
 reg ram_wait;
 wire [7:0] rx_byte;
 wire rx_valid, header_valid, frame_done, fcs_ok;
 wire [11:0] rx_length;
 wire rx_reset = !aresetn || !enabled;
 dsss_rx_portable core(.clock(aclk), .reset(rx_reset), .iq_i(iq_word[31:16]),
  .iq_q(iq_word[15:0]), .iq_valid(iq_strobe && enabled), .data(rx_byte),
  .data_valid(rx_valid), .frame_length(rx_length), .header_valid(header_valid),
  .frame_done(frame_done), .fcs_ok(fcs_ok));

 reg aw_saved, w_saved;
 reg [15:0] write_address;
 reg [31:0] write_data;
 reg [3:0] write_strobe;
 assign s_axi_awready = !aw_saved && !s_axi_bvalid;
 assign s_axi_wready = !w_saved && !s_axi_bvalid;
 assign s_axi_arready = !s_axi_rvalid && !ram_wait;
 assign s_axi_bresp = 2'b00;
 assign s_axi_rresp = 2'b00;
 wire write_fire = aw_saved && w_saved && !s_axi_bvalid;
 wire pop = write_fire && write_address == 16'h0030 && &write_strobe &&
            pending && write_data == pending_sequence;
 wire disable_rx = write_fire && write_address == 16'h0004 && write_strobe[0] && !write_data[0];
 wire ram_read_fire = s_axi_arvalid && s_axi_arready && s_axi_araddr[15:12]==4'h1 && pending;
 integer lane;
 // Dedicated synchronous BRAM ports: constant byte lanes and a registered
 // read word. Keep the AXI status mux out of the RAM read-register process.
 always @(posedge aclk) begin
  if(aresetn && enabled && rx_valid && capturing && byte_count < expected_length && byte_count < 4096)
   for(lane=0;lane<4;lane=lane+1)
    if(byte_count[1:0]==lane)
     packet_ram[{write_bank,byte_count[11:2]}][8*lane +: 8] <= rx_byte;
  if(ram_read_fire) packet_word<=packet_ram[{pending_bank,s_axi_araddr[11:2]}];
 end

 // Separate AW/W holding registers honor AXI-Lite channels in either order.
 always @(posedge aclk) begin
  if (!aresetn) begin
   aw_saved<=0; w_saved<=0; s_axi_bvalid<=0;
   write_address<=0; write_data<=0; write_strobe<=0;
  end else begin
   if (s_axi_awvalid && s_axi_awready) begin aw_saved<=1;write_address<=s_axi_awaddr;end
   if (s_axi_wvalid && s_axi_wready) begin w_saved<=1;write_data<=s_axi_wdata;write_strobe<=s_axi_wstrb;end
   if (s_axi_bvalid && s_axi_bready) s_axi_bvalid<=0;
   if (write_fire) begin aw_saved<=0;w_saved<=0;s_axi_bvalid<=1;end
  end
 end

 always @(posedge aclk) begin
  if (!aresetn) begin
   enabled<=0;pending<=0;capturing<=0;write_bank<=0;pending_bank<=0;
   expected_length<=0;pending_length<=0;byte_count<=0;header_time<=0;pending_time<=0;
   sequence_number<=0;pending_sequence<=0;dropped<=0;headers<=0;good<=0;bad<=0;
  end else begin
   if (write_fire && write_address==16'h0004 && write_strobe[0]) enabled<=write_data[0];
   if (pop) pending<=0;
   if (header_valid && enabled) begin
    headers<=headers+1;capturing<=1;byte_count<=0;expected_length<=rx_length;
    write_bank<=pending ? !pending_bank : 1'b0;header_time<=tsf_us;
   end
   if (rx_valid && capturing) begin
    if (byte_count < 4096) byte_count<=byte_count+1;
   end
   if (frame_done && capturing) begin
    capturing<=0;
    if (fcs_ok && byte_count==expected_length && expected_length!=0) begin
     good<=good+1;sequence_number<=sequence_number+1;
     if (!pending || pop) begin
      pending<=1;pending_bank<=write_bank;pending_length<=expected_length;
      pending_time<=header_time;pending_sequence<=sequence_number+1;
     end else dropped<=dropped+1;
    end else bad<=bad+1;
   end
   if (disable_rx || !enabled) begin pending<=0;capturing<=0;end
  end
 end

 // Synchronous RAM read; host must ACK the observed sequence after copying.
 always @(posedge aclk) begin
  if (!aresetn) begin s_axi_rvalid<=0;s_axi_rdata<=0;ram_wait<=0;end
  else begin
   if (s_axi_rvalid && s_axi_rready) s_axi_rvalid<=0;
   if(ram_wait) begin s_axi_rdata<=packet_word;s_axi_rvalid<=1;ram_wait<=0;end
   if (s_axi_arvalid && s_axi_arready) begin
    if(ram_read_fire) begin ram_wait<=1;s_axi_rvalid<=0;end
    else begin
    s_axi_rvalid<=1;
    case(s_axi_araddr)
     16'h0000:s_axi_rdata<=32'h44535331;
     16'h0004:s_axi_rdata<={31'b0,enabled};
     16'h0008:s_axi_rdata<={29'b0,enabled,capturing,pending};
     16'h000c:s_axi_rdata<={20'b0,pending_length};
     16'h0010:s_axi_rdata<=pending_sequence;
     16'h0014:s_axi_rdata<=pending_time[31:0];
     16'h0018:s_axi_rdata<=pending_time[63:32];
     16'h001c:s_axi_rdata<=dropped;
     16'h0020:s_axi_rdata<=headers;
     16'h0024:s_axi_rdata<=good;
     16'h0028:s_axi_rdata<=bad;
     16'h002c:s_axi_rdata<=32'h00010001; // ABI 1, 1Mbps long RX
     default:s_axi_rdata<=0;
    endcase
    end
   end
  end
 end
endmodule
