-- Passive 1 Mbps study receiver wrapper. Samples: 20 MS/s, signed 16-bit I/Q.
-- Data is provisional until frame_done AND fcs_ok. No TX, ACK or MAC injection.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library wlan;
use wlan.wlan_p.all;
use wlan.wlan_rx_p.all;

entity dsss_rx_portable is
 port(clock,reset: in std_logic;
      iq_i,iq_q: in std_logic_vector(15 downto 0);
      iq_valid: in std_logic;
      data: out std_logic_vector(7 downto 0);
      data_valid: out std_logic;
      frame_length: out std_logic_vector(11 downto 0);
      header_valid,frame_done,fcs_ok: out std_logic);
end;
architecture rtl of dsss_rx_portable is
 signal sample: wlan_sample_t;
 signal params: wlan_rx_params_t;
begin
 sample.i<=signed(iq_i);sample.q<=signed(iq_q);sample.valid<=iq_valid;
 frame_length<=std_logic_vector(to_unsigned(params.length,12));
 core: entity wlan.wlan_dsss_rx port map(clock=>clock,reset=>reset,sample=>sample,
   params=>params,params_valid=>header_valid,data=>data,data_valid=>data_valid,
   framer_done=>frame_done,crc_correct=>fcs_ok);
end;
