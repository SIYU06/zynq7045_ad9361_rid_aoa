`timescale 1ns/1ps
module dsss_axi_tb;
 reg clk=0;always #5 clk=~clk;
 reg rstn=0;reg [31:0] sample=0;reg sample_valid=0;reg [63:0] tsf=0;
 always @(posedge clk) if(rstn) tsf<=tsf+1;
 reg [15:0] awaddr=0, araddr=0;reg [31:0] wdata=0;
 reg [3:0] wstrb=0;reg awvalid=0,wvalid=0,arvalid=0,bready=0,rready=0;
 wire awready,wready,bvalid,arready,rvalid;wire [31:0] rdata;wire [1:0] bresp,rresp;
 dsss_axi_rx dut(.aclk(clk),.aresetn(rstn),.iq_word(sample),.iq_strobe(sample_valid),.tsf_us(tsf),
 .s_axi_awaddr(awaddr),.s_axi_awprot(3'b0),.s_axi_awvalid(awvalid),.s_axi_awready(awready),
 .s_axi_wdata(wdata),.s_axi_wstrb(wstrb),.s_axi_wvalid(wvalid),.s_axi_wready(wready),
 .s_axi_bresp(bresp),.s_axi_bvalid(bvalid),.s_axi_bready(bready),
 .s_axi_araddr(araddr),.s_axi_arprot(3'b0),.s_axi_arvalid(arvalid),.s_axi_arready(arready),
 .s_axi_rdata(rdata),.s_axi_rresp(rresp),.s_axi_rvalid(rvalid),.s_axi_rready(rready));

 task automatic write_reg(input [15:0] addr,input [31:0] value,input bit data_first);
  begin
   // Exercise independent AW/W order and a stalled B response.
   if(data_first) begin
    @(negedge clk);wdata=value;wstrb=15;wvalid=1;
    do @(posedge clk);while(!wready);@(negedge clk);wvalid=0;
    repeat(3) @(negedge clk);awaddr=addr;awvalid=1;
    do @(posedge clk);while(!awready);@(negedge clk);awvalid=0;
   end else begin
    @(negedge clk);awaddr=addr;awvalid=1;
    do @(posedge clk);while(!awready);@(negedge clk);awvalid=0;
    repeat(2) @(negedge clk);wdata=value;wstrb=15;wvalid=1;
    do @(posedge clk);while(!wready);@(negedge clk);wvalid=0;
   end
   wait(bvalid);repeat(3) @(negedge clk);
   if(!bvalid || bresp!=0) $fatal(1,"B response lost under backpressure");
   bready=1;@(negedge clk);bready=0;
  end
 endtask
 task automatic read_reg(input [15:0] addr,output [31:0] value);
  reg [31:0] held;
  begin
   @(negedge clk);araddr=addr;arvalid=1;
   do @(posedge clk);while(!arready);@(negedge clk);arvalid=0;
   wait(rvalid);held=rdata;repeat(3) @(negedge clk);
   if(!rvalid || held!==rdata || rresp!=0) $fatal(1,"R response unstable");
   value=rdata;rready=1;@(negedge clk);rready=0;
  end
 endtask
 task automatic waveform(input string filename);
  integer fd,rc,iv,qv,k;
  begin
   fd=$fopen(filename,"r");if(!fd) $fatal(1,"missing IQ vector");
   while(!$feof(fd)) begin
    rc=$fscanf(fd,"%d %d\n",iv,qv);
    if(rc==2) begin
     @(negedge clk);sample={iv[15:0],qv[15:0]};sample_valid=1;
     @(negedge clk);sample_valid=0;
     repeat(3) @(negedge clk);
    end
   end
   $fclose(fd);repeat(100) @(negedge clk);
  end
 endtask
 integer out,k;reg [31:0] val,len,seq;
 initial begin
  #100;@(negedge clk);rstn=1;
  read_reg(0,val);if(val!==32'h44535331) $fatal(1,"magic mismatch");
  write_reg(4,1,0);
  waveform("clean.txt");
  read_reg(8,val);if(val[0]!==1) $fatal(1,"no committed packet");
  read_reg(12,len);if(len!==134) $fatal(1,"wrong frame length %d",len);
  read_reg(16,seq);if(seq!==1) $fatal(1,"wrong initial sequence");
  waveform("bad_fcs.txt");
  read_reg(40,val);if(val!==1) $fatal(1,"bad FCS was not rejected");
  waveform("clean.txt");
  read_reg(28,val);if(val!==1) $fatal(1,"pending packet not protected/drop missing");
  write_reg(48,32'hffffffff,1);read_reg(8,val);
  if(val[0]!==1) $fatal(1,"stale ACK removed pending packet");
  out=$fopen("axi_payload.txt","w");
  for(k=0;k<134;k=k+4) begin read_reg(16'h1000+k,val);$fdisplay(out,"%08x",val);end
  $fclose(out);
  write_reg(48,seq,1);read_reg(8,val);if(val[0]!==0) $fatal(1,"ACK failed");
  waveform("clean.txt");read_reg(16,val);if(val!==3) $fatal(1,"cannot receive after ACK");
  write_reg(4,0,0);read_reg(8,val);if(val!==0) $fatal(1,"disable did not flush");
  $display("DSSS_AXI_COMPLETE");$finish;
 end
 initial begin #100000000; $fatal(1,"test timeout");end
endmodule
