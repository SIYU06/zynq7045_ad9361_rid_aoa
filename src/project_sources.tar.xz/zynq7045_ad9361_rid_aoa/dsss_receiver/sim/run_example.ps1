param(
    [string]$VivadoBin = $(if ($env:XILINX_VIVADO) { Join-Path $env:XILINX_VIVADO 'bin' } else { 'E:\thenewruanjian\vivado\Vivado\2022.2\bin' }),
    [string]$WorkDirectory = ''
)
$ErrorActionPreference = 'Stop'
$designRoot = Split-Path -Parent $PSScriptRoot
if (-not $WorkDirectory) { $WorkDirectory = Join-Path $designRoot 'build\submission_sim' }
New-Item -ItemType Directory -Path $WorkDirectory -Force | Out-Null
$units = @('wlan_p','wlan_rx_p','wlan_crc','wlan_dsss_plcp_crc','wlan_dsss_p_norm','wlan_dsss_despreader','wlan_dsss_peak_finder','wlan_dsss_rx_controller','wlan_dsss_demodulator','wlan_dsss_rx_framer','wlan_dsss_rx')
$rtlFiles = @($units | ForEach-Object { Join-Path $designRoot ('rtl\nuand\' + $_ + '.vhd') })
Push-Location $WorkDirectory
try {
    foreach ($name in @('clean','bad_fcs')) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('vectors\' + $name + '.txt')) -Destination ($name + '.txt') -Force
    }
    & (Join-Path $VivadoBin 'xvhdl.bat') --2008 --work wlan @rtlFiles *> compile_wlan.log
    if ($LASTEXITCODE -ne 0) { throw 'DSSS VHDL compilation failed; see compile_wlan.log' }
    & (Join-Path $VivadoBin 'xvhdl.bat') --2008 --work xil_defaultlib (Join-Path $designRoot 'rtl\dsss_rx_portable.vhd') *> compile_wrapper.log
    if ($LASTEXITCODE -ne 0) { throw 'Wrapper compilation failed; see compile_wrapper.log' }
    & (Join-Path $VivadoBin 'xvlog.bat') --sv --work xil_defaultlib (Join-Path $designRoot 'rtl\dsss_axi_rx.v') (Join-Path $PSScriptRoot 'dsss_axi_tb.sv') *> compile_axi.log
    if ($LASTEXITCODE -ne 0) { throw 'AXI compilation failed; see compile_axi.log' }
    & (Join-Path $VivadoBin 'xelab.bat') xil_defaultlib.dsss_axi_tb --snapshot submission_axi --debug typical *> elaborate.log
    if ($LASTEXITCODE -ne 0) { throw 'Elaboration failed; see elaborate.log' }
    & (Join-Path $VivadoBin 'xsim.bat') submission_axi -R -log simulation.log *> simulation.stdout.log
    $result = Get-Content -LiteralPath simulation.stdout.log -Raw
    if ($LASTEXITCODE -ne 0 -or $result -notmatch 'DSSS_AXI_COMPLETE' -or $result -match 'Fatal:|FATAL_ERROR|ERROR:') {
        throw 'Simulation failed; see simulation.stdout.log'
    }
    $expected = (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'expected_payload.hex') -Raw).Trim().ToLowerInvariant()
    $remaining = $expected.Length / 2
    $actual = -join @(foreach ($line in Get-Content -LiteralPath axi_payload.txt) {
        $word = $line.Trim().ToLowerInvariant()
        if ($word.Length -ne 8) { throw 'Malformed AXI payload word' }
        for ($i = 0; $i -lt 4 -and $remaining -gt 0; $i++) {
            $byte = $word.Substring(6 - 2 * $i, 2)
            if ($byte -notmatch '^[0-9a-f]{2}$') { throw 'Undefined byte inside valid frame payload' }
            $byte
            $remaining--
        }
    })
    if ($remaining -ne 0) { throw 'Truncated AXI frame payload' }
    if ($actual -cne $expected) { throw 'Decoded payload does not match expected frame byte for byte' }
    $receipt = @(
        'PASS: complete 1 Mbps long-preamble DSSS frame decoded; 134 payload bytes match exactly.',
        'PASS: bad FCS rejected; occupied mailbox protected; stale ACK rejected; valid ACK and disable verified.',
        'Input: synthetic IQ vectors, 20 MS/s; FPGA processing clock: 100 MHz.',
        'Scope: this is a simulation result, not an RF reception or angle accuracy measurement.'
    )
    $receipt | Set-Content -LiteralPath result.txt -Encoding UTF8
    $receipt
} finally {
    Pop-Location
}
