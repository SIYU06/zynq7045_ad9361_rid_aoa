# Source provenance

- `rtl/nuand/`: Nuand, LLC., copyright 2020; GPL-2.0-or-later under the individual file headers. Upstream [bladeRF-wiphy](https://github.com/Nuand/bladeRF-wiphy/tree/8623814cba0af680a59b2a23f5e47e424a6c37c7), commit `8623814cba0af680a59b2a23f5e47e424a6c37c7`. Full license is `rtl/nuand/COPYING`. `port_manifest.json` records original/modified SHA-256 and each modification. `scripts/prepare_port.py` reproduces the port from the pinned checkout.
- `scripts/decode_long.py` uses the same credited 20-tap Barker filter coefficients. GPL-2.0-or-later.
- `sim/generate_vectors.py`: mathematical TX generator, cross-checked against Teng-Hui Huang's [gr-wifi-dsss](https://github.com/hui811116/gr-wifi-dsss/tree/47c1003459cbadcd842efdb70195757a9fe86626), commit `47c1003459cbadcd842efdb70195757a9fe86626`; GPL-3.0-or-later is used for this generator. Full reference license is `research/checkouts/gr-wifi-dsss/LICENSE`. This is a test reference, not hardware installed on the board.
- The existing `openwifi` design retains its own source licenses. When distributing a combined derivative, preserve the notices and select a compatible later GPL version for the GPL-2.0-or-later sources.

- `rid_receiver/gb46750.py`: independently implemented field reader, checked against Jun Zhang's Apache-2.0 [OpenDroneID CN reference](https://github.com/opendroneid/opendroneid-core-c/tree/849c03adbe0cdd68997a462fafab397edcfe53f3/libopendroneidcn), commit `849c03adbe0cdd68997a462fafab397edcfe53f3`. The original C/H remain unmodified in the pinned checkout. `sim/check_cn_reference.c` and `scripts/verify_gb46750_reference.py` run a differential check of the actual received body.

Waveforms under `sim/` are synthetic. `research/air_scan_20261102/` and `research/full_frame_air_scan.json` are actual-air evidence. Copying a MAC frame from an old capture into a synthetic DSSS waveform is **not** evidence of receiving that transmitter over DSSS.
