"""Fetch sparse primary sources at immutable commits; do not execute their code."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
PROJECTS = [
    ('Nuand/bladeRF-wiphy', '8623814cba0af680a59b2a23f5e47e424a6c37c7', ['fpga/vhdl', 'fpga/common', 'matlab']),
    ('hui811116/gr-wifi-dsss', '47c1003459cbadcd842efdb70195757a9fe86626', ['lib', 'include', 'python', 'examples']),
    ('opendroneid/opendroneid-core-c', '849c03adbe0cdd68997a462fafab397edcfe53f3', ['libopendroneidcn']),
]
def git(*args):
    return subprocess.check_output(['git', '-c', 'http.version=HTTP/1.1'] + list(args), text=True, stderr=subprocess.STDOUT).strip()

inventory = []
for repository, commit, folders in PROJECTS:
    target = ROOT / 'checkouts' / repository.split('/')[-1]
    if not (target / '.git').exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        git('clone', '--filter=blob:none', '--sparse', 'https://github.com/' + repository + '.git', str(target))
        git('-C', str(target), 'sparse-checkout', 'set', *folders)
        git('-C', str(target), 'checkout', '--detach', commit)
    actual = git('-C', str(target), 'rev-parse', 'HEAD')
    if actual != commit:
        raise RuntimeError('Existing checkout differs; preserving it: ' + str(target))
    inventory.append(dict(repository='https://github.com/' + repository, commit=actual, sparse=folders))
(ROOT / 'source_inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
print('Verified %d pinned primary-source checkouts' % len(inventory))
