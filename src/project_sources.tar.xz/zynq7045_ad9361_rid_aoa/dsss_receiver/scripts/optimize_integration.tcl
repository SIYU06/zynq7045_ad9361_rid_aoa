set dsss_here [file normalize [file join [file dirname [info script]] ..]]
set dsss_out [file join $dsss_here build integrated_r2]
open_project [file join $dsss_out dsss_b.xpr]
open_bd_design [get_files -filter {FILE_TYPE == "Block Designs"}]
# This input is an internal BUFG40MHz output, not a package pin. Selecting
# No_buffer avoids an extra IBUF and a duplicate primary clock at the MMCM input.
set_property CONFIG.PRIM_SOURCE No_buffer [get_bd_cells clk_wiz_0]
update_compile_order -fileset sources_1
validate_bd_design
save_bd_design
generate_target all [get_files -filter {FILE_TYPE == "Block Designs"}]
update_compile_order -fileset sources_1
reset_run synth_1
foreach dsss_changed_run {system_dsss_rx_0_0_synth_1 system_clk_wiz_0_0_synth_1} {
 if {[llength [get_runs -quiet $dsss_changed_run]]} {reset_run $dsss_changed_run}
}
puts "DSSS_INTERNAL_CLOCK_AND_BRAM_UPDATE_READY"
close_project
