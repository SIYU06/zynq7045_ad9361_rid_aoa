# Repair only this generated study project. Do not alter original board inputs.
set dsss_here [file normalize [file join [file dirname [info script]] ..]]
set dsss_out [file join $dsss_here build integrated_r2]
set dsss_board [file join [file dirname $dsss_here] ow board src]
open_project [file join $dsss_out dsss_b.xpr]
foreach dsss_accidental {axi_ad9361.v up_xfer_status.v} {
 set dsss_file [get_files -quiet [file join $dsss_out board_inputs $dsss_accidental]]
 if {[llength $dsss_file]} {remove_files $dsss_file}
}
foreach dsss_xdc {board.xdc openwifi_timing.xdc} {
 set dsss_destination [file join $dsss_out board_inputs $dsss_xdc]
 if {![file exists $dsss_destination]} {file copy [file join $dsss_board $dsss_xdc] $dsss_destination}
 if {![llength [get_files -quiet $dsss_destination]]} {add_files -fileset constrs_1 -norecurse $dsss_destination}
}
update_compile_order -fileset sources_1
reset_run synth_1
puts "DSSS_BOARD_CONSTRAINTS_RESTORED"
close_project
