set dsss_here [file normalize [file join [file dirname [info script]] ..]]
set dsss_out [file join $dsss_here build integrated_r2]
set_param general.maxThreads 4
open_project [file join $dsss_out dsss_b.xpr]
config_ip_cache -disable_cache
foreach dsss_xdc {board.xdc openwifi_timing.xdc} {
 if {![llength [get_files -quiet [file join $dsss_out board_inputs $dsss_xdc]]]} {error "Required board constraint absent: $dsss_xdc"}
}
launch_runs synth_1 -jobs 2
wait_on_run synth_1
if {![string match *Complete* [get_property STATUS [get_runs synth_1]]]} {error "Integrated synthesis failed"}
open_run synth_1
report_utilization -hierarchical -file [file join $dsss_out synth_utilization.rpt]
report_drc -file [file join $dsss_out synth_drc.rpt]
close_design
launch_runs impl_1 -to_step route_design -jobs 2
wait_on_run impl_1
if {![string match *Complete* [get_property STATUS [get_runs impl_1]]]} {error "Integrated route failed"}
open_run impl_1
report_utilization -file [file join $dsss_out impl_utilization.rpt]
report_drc -file [file join $dsss_out impl_drc.rpt]
report_timing_summary -report_unconstrained -file [file join $dsss_out impl_timing.rpt]
check_timing -verbose -file [file join $dsss_out check_timing.rpt]
report_cdc -details -file [file join $dsss_out cdc.rpt]
set dsss_setup [get_timing_paths -delay_type max -max_paths 1]
set dsss_hold [get_timing_paths -delay_type min -max_paths 1]
if {![llength $dsss_setup] || ![llength $dsss_hold]} {error "No timing paths found"}
if {[get_property SLACK $dsss_setup] < 0 || [get_property SLACK $dsss_hold] < 0} {error "Timing failure; no bitstream generated"}
set dsss_errors [get_drc_violations -filter {SEVERITY == Error}]
if {[llength $dsss_errors]} {error "DRC errors; no bitstream generated: $dsss_errors"}
write_bitstream -force [file join $dsss_out system_top.bit]
write_hw_platform -fixed -force -file [file join $dsss_out dsss_b.xsa]
puts "DSSS_INTEGRATED_BUILD_COMPLETE"
close_project
