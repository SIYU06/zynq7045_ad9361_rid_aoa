# The checked bitstream was written to an explicit artifact path. Export the
# hardware-only XSA separately; include_bit requires the project-run bit path.
set dsss_here [file normalize [file join [file dirname [info script]] ..]]
set dsss_out [file join $dsss_here build integrated_r2]
open_project [file join $dsss_out dsss_b.xpr]
open_run impl_1
set dsss_setup [get_timing_paths -delay_type max -max_paths 1]
set dsss_hold [get_timing_paths -delay_type min -max_paths 1]
if {[get_property SLACK $dsss_setup]<0 || [get_property SLACK $dsss_hold]<0} {error "Timing failed"}
set dsss_checked_bit [file join $dsss_out system_top.bit]
if {![file exists $dsss_checked_bit]} {error "Checked bitstream missing"}
write_hw_platform -fixed -force -file [file join $dsss_out dsss_b.xsa]
puts "DSSS_INTEGRATED_BUILD_COMPLETE"
close_project
