"""Reproducible, attributed Nuand 1 Mbps RX port, outside the running design."""
import hashlib
import json
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
upstream=root/'research/checkouts/bladeRF-wiphy';source=upstream/'fpga/vhdl'
output=root/'rtl/nuand';output.mkdir(parents=True,exist_ok=True)
names=['wlan_p','wlan_rx_p','wlan_crc','wlan_dsss_plcp_crc','wlan_dsss_p_norm',
 'wlan_dsss_despreader','wlan_dsss_peak_finder','wlan_dsss_rx_controller',
 'wlan_dsss_demodulator','wlan_dsss_rx_framer','wlan_dsss_rx']
manifest=[]
for name in names:
 path=source/(name+'.vhd');original=path.read_bytes();text=original.decode('utf-8').replace('\r\n','\n');changes=[]
 def replace(old,new,why):
  global text
  if text.count(old)!=1:raise ValueError((name,'unexpected source',old,text.count(old)))
  text=text.replace(old,new);changes.append(why)
 if name=='wlan_dsss_rx':
  replace('    use wlan.nco_p.all ;\n','','Remove unused NCO package import; DSSS has no NCO instance')
  replace('library altera_mf ;\n    use altera_mf.altera_mf_components.all ;\n\nlibrary wlan_pll ;\n','',
          'Remove unused Intel/PLL library imports; no vendor primitive instantiated')
 if name=='wlan_dsss_p_norm':
  replace('            report integer\'image(x) & " LUT " & real\'image(i);\n','','Suppress constant-table elaboration logging only')
 if name=='wlan_rx_p':
  replace('        rv.num_padding_bits := 0 ;','        rv.num_padding_bits := 0 ;\n        rv.num_decoded_bits := 0 ;\n        rv.packet_valid := \'0\' ;','Initialize all parameter record fields')
 if name=='wlan_dsss_despreader':
  replace("        if( reset = '1' ) then\n        elsif", "        if( reset = '1' ) then\n            despread <= NULL_SAMPLE ;\n            accum <= (others => (i => (others => '0'), q => (others => '0'), valid => '0'));\n        elsif",'Deterministic warmup valid bits and accumulators')
 if name=='wlan_dsss_peak_finder':
  replace("        elsif( rising_edge( clock ) ) then\n            if( despread.valid = '1' ) then", "        elsif( rising_edge( clock ) ) then\n            c_pow_valid <= '0' ;\n            if( despread.valid = '1' ) then",'Honor input valid gaps instead of repeatedly counting stale power')
 if name=='wlan_dsss_rx_framer':
  replace('comb : process( clock )','comb : process(all)','Correct combinational sensitivity for simulation/synthesis equivalence')
  replace('if(future.consecutive_ones(demod_idx) = 27 )','if(current.consecutive_ones(demod_idx) = 27 )','Remove combinational self-feedback from acquisition counter test')
  replace("        rv.framer_done := '0' ;","        rv.framer_done := '0' ;\n        rv.crc_correct := '0' ;",'Initialize FCS acceptance low on reset')
  replace('sfd_attempt         :   natural range 0 to 120','sfd_attempt         :   natural range 0 to 130','Make SFD search timeout reachable')
  replace('future.sfd_attempt <= current.sfd_attempt + 1 ;','if current.sfd_attempt < 130 then future.sfd_attempt <= current.sfd_attempt + 1 ; end if;','Saturate timeout counter')
  for field in ('byte_count','pkt_len','payload_len'):
   old=next(line for line in text.splitlines() if field+' ' in line and 'range 0 to 1200' in line)
   replace(old,old.replace('1200','4095'),'Bound '+field+' to validated 12-bit frame size')
  replace('if( plcp_crc_endian = current.recv_reg(47 downto 32) ) then',
   'if( plcp_crc_endian = current.recv_reg(47 downto 32) and\n'
   '                    current.recv_reg(7 downto 0) = x"0A" and\n'
   '                    current.recv_reg(18 downto 16) = "000" and\n'
   '                    unsigned(current.recv_reg(31 downto 19)) >= 5 and\n'
   '                    unsigned(current.recv_reg(31 downto 19)) <= 4095 ) then',
   'Only accept 1 Mbps SIGNAL and bounded integral byte lengths; reject unsupported modes')
 if 'process( clock )' in text:
  text=text.replace('process( clock )','process( clock, reset )')
  changes.append('Include asynchronous reset in clocked process sensitivity lists')
 text='-- Zynq portable study port, 2026-11-02; upstream license retained. See port_manifest.json.\n'+text
 data=text.encode('utf-8');(output/path.name).write_bytes(data)
 manifest.append(dict(file=path.name,upstreamSHA256=hashlib.sha256(original).hexdigest(),portedSHA256=hashlib.sha256(data).hexdigest(),changes=changes))
shutil.copy2(upstream/'LICENSE',output/'COPYING')
value=dict(repository='https://github.com/Nuand/bladeRF-wiphy',commit='8623814cba0af680a59b2a23f5e47e424a6c37c7',
 license='GPL-2.0-or-later, retained from per-file headers',supported='1 Mbps long-preamble RX only; not deployed',files=manifest)
(root/'port_manifest.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print('Prepared',len(manifest),'attributed VHDL files')
