# Export the current known-good BD read-only; create an isolated additive design.
set here [file normalize [file join [file dirname [info script]] ..]]
set root [file dirname $here]
set out [file join $here build integrated_r2]
if {[file exists [file join $out dsss_b.xpr]]} {error "Isolated project already exists; inspect it instead of overwriting"}
file mkdir $out
open_project -read_only [file join $root dma_project dma_project.xpr]
set repos [get_property IP_REPO_PATHS [current_project]]
set bds [get_files -filter {FILE_TYPE == "Block Designs"}]
if {[llength $bds]!=1} {error "Expected exactly one active BD"}
open_bd_design [lindex $bds 0]
write_bd_tcl -force [file join $out baseline_bd.tcl]
close_project

create_project dsss_b $out -part xc7z045fbg676-1
set_property ip_repo_paths $repos [current_project]
set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]
update_ip_catalog
set names {wlan_p wlan_rx_p wlan_crc wlan_dsss_plcp_crc wlan_dsss_p_norm wlan_dsss_despreader wlan_dsss_peak_finder wlan_dsss_rx_controller wlan_dsss_demodulator wlan_dsss_rx_framer wlan_dsss_rx}
foreach name $names {read_vhdl -vhdl2008 -library wlan [file join $here rtl nuand ${name}.vhd]}
read_vhdl -vhdl2008 [file join $here rtl dsss_rx_portable.vhd]
read_verilog [file join $here rtl dsss_axi_rx.v]
cd $out
source [file join $out baseline_bd.tcl]
set_property CONFIG.PRIM_SOURCE No_buffer [get_bd_cells clk_wiz_0]
current_bd_instance /openwifi_ip
set cell [create_bd_cell -type module -reference dsss_axi_rx dsss_rx_0]
set master [get_bd_cells axi_interconnect_1]
set count [get_property CONFIG.NUM_MI $master]
if {$count!=8} {error "Baseline AXI master count changed: $count"}
set_property CONFIG.NUM_MI 9 $master
set interfaces [get_bd_intf_pins -of_objects $cell -filter {VLNV =~ "xilinx.com:interface:aximm*" && MODE == Slave}]
if {[llength $interfaces]!=1} {error "DSSS AXI interface inference failed: $interfaces"}
connect_bd_intf_net [get_bd_intf_pins axi_interconnect_1/M08_AXI] $interfaces
foreach pin {dsss_rx_0/aclk axi_interconnect_1/M08_ACLK} {
 connect_bd_net [get_bd_pins rx_intf_0/s00_axi_aclk] [get_bd_pins $pin]
}
foreach pin {dsss_rx_0/aresetn axi_interconnect_1/M08_ARESETN} {
 connect_bd_net [get_bd_pins rx_intf_0/s00_axi_aresetn] [get_bd_pins $pin]
}
connect_bd_net [get_bd_pins rx_intf_0/sample0] [get_bd_pins dsss_rx_0/iq_word]
connect_bd_net [get_bd_pins rx_intf_0/sample_strobe] [get_bd_pins dsss_rx_0/iq_strobe]
connect_bd_net [get_bd_pins xpu_0/tsf_runtime_val] [get_bd_pins dsss_rx_0/tsf_us]
current_bd_instance /
set segment [get_bd_addr_segs -of_objects $interfaces]
if {[llength $segment]!=1} {set segment [get_bd_addr_segs openwifi_ip/dsss_rx_0/*/*]}
if {[llength $segment]!=1} {error "Ambiguous DSSS register segment: $segment"}
assign_bd_address -offset 0x83C60000 -range 0x00010000 -target_address_space [get_bd_addr_spaces sys_ps7/Data] $segment -force
validate_bd_design
save_bd_design
set bd [get_files -filter {FILE_TYPE == "Block Designs"}]
generate_target all $bd
add_files -norecurse [make_wrapper -files $bd -top]
file mkdir [file join $out board_inputs]
file copy [file join $root ow board src system_top.v] [file join $out board_inputs system_top.v]
add_files -norecurse [file join $out board_inputs system_top.v]
foreach dsss_board_constraint {board.xdc openwifi_timing.xdc} {
 file copy [file join $root ow board src $dsss_board_constraint] [file join $out board_inputs $dsss_board_constraint]
 add_files -fileset constrs_1 -norecurse [file join $out board_inputs $dsss_board_constraint]
}
set_property top system_top [get_filesets sources_1]
set_property AUTO_INCREMENTAL_CHECKPOINT 0 [get_runs synth_1]
set_property incremental_checkpoint {} [get_runs synth_1]
update_compile_order -fileset sources_1
report_ip_status -file [file join $out ip_status.rpt]
write_bd_tcl -force [file join $out dsss_bd.tcl]
puts "DSSS_ISOLATED_PROJECT_READY"
close_project
