"""Bounded, read-only RX source audit. No Vivado, simulation or compilation."""
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

from export_hw_contract import audit_rx_path

ROOT = Path(__file__).resolve().parents[1]


def main():
    lock = json.loads((ROOT / 'openwifi/sources.lock.json').read_text(encoding='utf-8'))
    versions = {}
    for key, rel in [('openwifi_hw', 'upstream/openwifi-hw'), ('openwifi', 'upstream/openwifi'),
                     ('adi_hdl', 'upstream/openwifi-hw/adi-hdl'),
                     ('openofdm', 'upstream/openwifi-hw/ip/openofdm_rx')]:
        repo = ROOT / rel
        actual = subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(),
                                          '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
        if actual != lock[key]['commit']:
            raise ValueError('Locked commit mismatch: ' + rel)
        dirty = subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(),
                                         '-C', str(repo), 'diff', '--name-only', '--ignore-submodules=all'], text=True).strip()
        if dirty:
            raise ValueError('Upstream tracked files changed: ' + rel + ': ' + dirty)
        versions[key] = actual
    bd = ROOT / 'ow/board/src/system.bd'
    audit_rx_path(json.loads(bd.read_text(encoding='utf-8'))['design'])
    contract = json.loads((ROOT / 'openwifi/hardware_contract.json').read_text(encoding='utf-8'))
    if contract['bd_sha256'] != hashlib.sha256(bd.read_bytes()).hexdigest():
        raise ValueError('Stale hardware_contract.json; run export_hw_contract.py')
    packages = {}
    paths = [ROOT / 'ow/board/ip_repo' / n / 'component.xml' for n in
             ['openofdm_rx', 'openofdm_tx', 'rx_intf', 'tx_intf', 'xpu', 'side_ch']]
    paths += [ROOT / 'ow/adi-hdl/library' / n / 'component.xml' for n in
              ['axi_ad9361', 'util_pack/util_cpack2', 'util_pack/util_upack2',
               'util_wfifo', 'util_rfifo', 'util_tdd_sync', 'xilinx/util_clkdiv']]
    for path in paths:
        count = 0
        for item in ET.parse(path).getroot().iter():
            if item.tag.split('}')[-1] != 'file':
                continue
            for node in item:
                if node.tag.split('}')[-1] == 'name' and node.text:
                    if not (path.parent / node.text).is_file():
                        raise ValueError('Missing packaged file: ' + str(path.parent / node.text))
                    count += 1
        packages[path.parent.name] = count
    # Check the generated side-channel change remains reproducible from upstream.
    from prepare_linux import adapt_side_channel
    source = (ROOT / 'upstream/openwifi/driver/side_ch/side_ch.c').read_text(encoding='utf-8')
    staged = (ROOT / 'ow/linux/driver/side_ch/side_ch.c').read_text(encoding='utf-8')
    if adapt_side_channel(source) != staged:
        raise ValueError('Derived side_ch differs from reproducible board adaptation')
    manifest = json.loads((ROOT / 'ow/linux/sources_manifest.json').read_text(encoding='utf-8'))
    mismatches = [name for name, digest in manifest['files_sha256'].items()
                  if hashlib.sha256((ROOT / 'ow/linux' / name).read_bytes()).hexdigest() != digest]
    if mismatches:
        raise ValueError('Linux staging manifest mismatch: ' + ', '.join(mismatches))
    print(json.dumps({'status': 'PASS: source checks only; no Vivado or board acceptance',
                      'locked_versions': versions, 'packaged_file_counts': packages,
                      'bd_sha256': contract['bd_sha256'],
                      'rx_topology': contract['rx_path_static_audit'],
                      'linux_staging_manifest': 'all recorded files match',
                      'not_checked': ['Vivado BD validation', 'HDL/C compilation', 'CDC/timing closure',
                                      'Viterbi license', 'kernel ABI', 'RF tuning', 'Wi-Fi FCS', 'AOA calibration']},
                     indent=2))


if __name__ == '__main__':
    main()
