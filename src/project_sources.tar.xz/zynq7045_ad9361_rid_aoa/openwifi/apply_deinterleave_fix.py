"""Reproducible board-only latch fix. Never write the locked upstream checkout."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL_SHA256 = '44f228e94704b7feb5fcf4f8c8ed5cf7cb44aa2b70df0d2aaa940520e19681df'
MARKER = '    // Board fix: define unmapped soft-bit selections; infer no storage.\n    out_bits = 6\'b000000;\n'


def fixed_source(source):
    if source.count('always @* begin\n') != 1:
        raise ValueError('Unexpected deinterleave combinational structure')
    return source.replace('always @* begin\n', 'always @* begin\n' + MARKER, 1)


def main():
    upstream = ROOT / 'upstream/openwifi-hw/ip/openofdm_rx/verilog/deinterleave.v'
    original = upstream.read_text(encoding='utf-8')
    if hashlib.sha256(original.encode()).hexdigest() != ORIGINAL_SHA256:
        raise ValueError('Locked deinterleave source drift; review patch')
    fixed = fixed_source(original)
    targets = [ROOT / 'ow/ip/openofdm_rx/verilog/deinterleave.v',
               ROOT / 'ow/board/ip_repo/openofdm_rx/src/deinterleave.v']
    targets += sorted((ROOT / 'ow/board/src/ipshared').glob('*/src/deinterleave.v'))
    backup = ROOT / 'change_backups/deinterleave_20261025'
    result = []
    for path in targets:
        if not path.exists():
            continue
        current = path.read_text(encoding='utf-8')
        if current.rstrip() == fixed.rstrip():
            continue
        if current.rstrip() != original.rstrip():
            raise ValueError('Unexpected local modifications: ' + str(path))
        saved = backup / path.relative_to(ROOT)
        saved.parent.mkdir(parents=True, exist_ok=True)
        if not saved.exists():
            shutil.copy2(path, saved)
        with path.open('w', encoding='utf-8', newline='\n') as stream:
            stream.write(fixed)
        result.append(path.relative_to(ROOT).as_posix())
    print(json.dumps({'changed': result, 'upstream_unchanged': True}, indent=2))


if __name__ == '__main__':
    main()
