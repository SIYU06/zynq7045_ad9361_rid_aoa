"""Stage locked Linux sources and board changes; no compilation or board access."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'openwifi'
UP = ROOT / 'upstream/openwifi'
OUT = ROOT / 'ow/linux'


def adapt_side_channel(text):
    """Opt into the existing RTL's paired IQ mode; keep upstream defaults."""
    declaration = 'static int iq_len_init = 0; //if iq_len>0, iq capture enabled, csi disabled'
    write_iq = 'SIDE_CH_REG_IQ_CAPTURE_write(1);'
    if text.count(declaration) != 1 or text.count(write_iq) != 1:
        raise ValueError('Unexpected side_ch source; review dual IQ adaptation')
    text = text.replace(declaration, declaration + '\n'
                        'static bool iq_dual_init = false;\n'
                        'module_param(iq_dual_init, bool, 0);\n'
                        'MODULE_PARM_DESC(iq_dual_init, "Capture paired RX IQ instead of IQ plus status; requires iq_len_init>0");')
    # side_ch.v: reg3[0]=capture, reg3[4]=iq_capture_cfg[0].
    return text.replace(write_iq, 'SIDE_CH_REG_IQ_CAPTURE_write(iq_dual_init ? 0x11 : 1);')


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='\n') as stream:
        stream.write(value)


def main():
    lock = json.loads((HERE / 'sources.lock.json').read_text(encoding='utf-8'))
    actual = subprocess.check_output(['git', '-c', 'safe.directory=' + UP.as_posix(),
                                     '-C', str(UP), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != lock['openwifi']['commit']:
        raise SystemExit('Software revision differs from sources.lock.json')
    if OUT.exists():
        raise SystemExit('ow/linux already exists; retain it. Use a new reviewed staging directory before regenerating.')
    OUT.mkdir(parents=True)
    shutil.copytree(UP / 'driver', OUT / 'driver', ignore=shutil.ignore_patterns(
        '.git', '*.o', '*.ko', '*.cmd', '*.mod*', 'Module.symvers', 'modules.order'))
    source = OUT / 'driver/sdr.c'
    text = source.read_text(encoding='utf-8')
    needle = 'strstr(fpga_model, "ZC706") != NULL)'
    if text.count(needle) != 1:
        raise SystemExit('Unexpected board detection code; review manually')
    text = text.replace(needle, 'strstr(fpga_model, "ZC706") != NULL || strstr(fpga_model, "XC7Z045") != NULL)')
    write(source, text)
    side = OUT / 'driver/side_ch/side_ch.c'
    write(side, adapt_side_channel(side.read_text(encoding='utf-8')))
    runtime = OUT / 'runtime'
    runtime.mkdir()
    for name in ['wgd.sh', 'load_fpga_img.sh', 'openwifi_ad9361_fir_tx_0MHz_11n.ftr']:
        shutil.copy2(UP / 'user_space' / name, runtime / name)
    wgd = runtime / 'wgd.sh'
    text = wgd.read_text(encoding='utf-8')
    if text.count('./rf_init_11n.sh\n') != 1 or text.count('./agc_settings.sh 1 || exit 1') != 1:
        raise SystemExit('Unexpected loader; review RF/AGC initialization manually')
    text = text.replace('./rf_init_11n.sh\n', 'sh ./rf_init_11n.sh || exit 1\n')
    text = text.replace('./agc_settings.sh 1 || exit 1', '# Local board uses explicit MGC; no inherited AGC register writes.')
    write(wgd, text)
    for p in (HERE / 'linux').glob('*.sh'):
        write(runtime / p.name, p.read_text(encoding='utf-8'))
    for p in (HERE / 'linux').glob('*.dtsi'):
        write(OUT / 'dts' / p.name, p.read_text(encoding='utf-8'))
    for name in ['LICENSE', 'LICENSE.md', 'COPYING']:
        if (UP / name).is_file():
            shutil.copy2(UP / name, OUT / name)
    hashes = {p.relative_to(OUT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in OUT.rglob('*') if p.is_file()}
    write(OUT / 'sources_manifest.json', json.dumps({
        'openwifi_commit': actual, 'files_sha256': hashes,
        'kernel_abi': lock['linux'], 'status': 'source staging only; not a deployable release'
    }, indent=2) + '\n')
    print('Prepared', OUT, '(no compilation, FPGA load or board access)')


if __name__ == '__main__':
    main()
