"""Apply source-only board corrections and remove old tool logs, inside dma_project."""
import hashlib
import json
import re
import shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STAMP = datetime.now().strftime('%Y%m%d_%H%M%S')
BACKUP = ROOT / 'change_backups' / STAMP
CHANGES = []


def checked(path):
    path = path.resolve()
    path.relative_to(ROOT.resolve())
    if '.git' in path.relative_to(ROOT).parts:
        raise ValueError('Refusing Git metadata mutation')
    return path


def save(path, content):
    path = checked(path)
    data = content.encode('utf-8') if isinstance(content, str) else content
    if path.exists() and path.read_bytes() == data:
        return
    before = None
    if path.exists():
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        target = BACKUP / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    CHANGES.append({'path': path.relative_to(ROOT).as_posix(), 'before_sha256': before,
                    'after_sha256': hashlib.sha256(data).hexdigest()})


def main():
    # Canonical PS input lives inside the project; no dependency on sibling projects.
    canonical = ROOT / 'openwifi/board_ps_settings.tcl'
    if not canonical.exists():
        save(canonical, (ROOT / 'ow/board/ps_settings.tcl').read_bytes())
    prep = ROOT / 'openwifi/prepare.py'
    s = prep.read_text(encoding='utf-8')
    if 'import sys\n' not in s:
        s = s.replace('import subprocess\n', 'import subprocess\nimport sys\nfrom datetime import datetime\n')
    s = s.replace('        write_board()\n        print(\'Refreshed board inputs; existing packaged IP retained.\')',
                  "        write_board(refresh_adapters='--refresh-adapters' in sys.argv)\n        print('Existing board BD retained; only missing inputs prepared.')")
    s = s.replace('def write_board():', '''def copy_adapter(src, dst, refresh=False):
    if dst.exists():
        if not refresh or dst.read_bytes() == src.read_bytes():
            return
        backup = ROOT / 'change_backups' / ('adapter_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f')) / dst.relative_to(ROOT)
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst, backup)
    shutil.copy2(src, dst)


def write_board(refresh_adapters=False):''')
    s = s.replace("    (b / 'src/system.bd').write_text(json.dumps(d, indent=2))", "    if not (b / 'src/system.bd').exists():\n        (b / 'src/system.bd').write_text(json.dumps(d, indent=2))")
    for name in ['system_top.v', 'board.xdc']:
        s = s.replace("    shutil.copy2(HERE / '%s', b / 'src/%s')" % (name, name),
                      "    copy_adapter(HERE / '%s', b / 'src/%s', refresh_adapters)" % (name, name))
    s = s.replace("    shutil.copy2(UP / 'openwifi-hw/boards/zc706_fmcs2/src/system.xdc', b / 'src/openwifi_timing.xdc')",
                  "    copy_adapter(UP / 'openwifi-hw/boards/zc706_fmcs2/src/system.xdc', b / 'src/openwifi_timing.xdc', refresh_adapters)")
    start = s.find("    # PS board settings come from the user's RF project;")
    if start >= 0:
        end = s.index("    cfg = b / 'ip_config'", start)
        s = s[:start] + "    copy_adapter(HERE / 'board_ps_settings.tcl', b / 'ps_settings.tcl', refresh_adapters)\n" + s[end:]
    s = s.replace("        (cfg / (name + '_pre_def.v')).write_text('`define an_xc7z045\\n')",
                  "        target = cfg / (name + '_pre_def.v')\n        if not target.exists():\n            target.write_text('`define an_xc7z045\\n')")
    s = s.replace("    (backup / 'sha256.json').write_text(json.dumps(manifest, indent=2))",
                  "    if not (backup / 'sha256.json').exists():\n        (backup / 'sha256.json').write_text(json.dumps(manifest, indent=2))")
    save(prep, s)

    # Retarget only editable project inputs. Historical XSA/ELF/bit files are not relabeled.
    for sub in ['demo_vivado_v2_IQ', 'dma_project']:
        for p in (ROOT / sub).rglob('*'):
            if p.suffix not in ['.xpr', '.bd', '.xci']:
                continue
            if any(x.endswith(('.gen', '.cache', '.runs')) for x in p.parts):
                continue
            text = p.read_text(encoding='utf-8-sig')
            text = text.replace('xc7z045ffg676-2', 'xc7z045fbg676-1')
            if p.suffix in ['.bd', '.xci']:
                d = json.loads(text)
                if p.suffix == '.bd':
                    for c in d['design'].get('components', {}).values():
                        param = c.get('parameters', {})
                        if 'PCW_PACKAGE_NAME' in param:
                            param['PCW_PACKAGE_NAME']['value'] = 'fbg676'
                else:
                    params = d['ip_inst']['parameters']
                    project = params.get('project_parameters', {})
                    if 'PACKAGE' in project:
                        project['PACKAGE'][0]['value'] = 'fbg676'
                    if 'SPEEDGRADE' in project:
                        project['SPEEDGRADE'][0]['value'] = '-1'
                    if p.stem == 'ila_0':
                        for group in ['component_parameters', 'model_parameters']:
                            for key, value in [('C_DATA_DEPTH', '32768'), ('C_EN_STRG_QUAL', '1')]:
                                if key in params.get(group, {}):
                                    params[group][key][0]['value'] = value
                text = json.dumps(d, indent=2) + '\n'
            save(p, text)

    rfroot = ROOT / 'demo_vivado_v2_IQ/demo_v2/ofdm_80211n_2r2t_v1'
    top = rfroot / 'ofdm_80211n_2r2t_v1.srcs/sources_1/src/system_top.v'
    # Preserve the source encoding's existing comment bytes while editing ASCII tokens.
    t = top.read_bytes()
    t = re.sub(rb'(assign gpio_T[12]_PA_EN\s*=\s*)1;', rb'\g<1>0;', t)
    t = t.replace(b'reg         phy_rst;', b'wire        phy_rst;')
    t = re.sub(rb'    wire phy_rst_vio;\s*always @\(posedge data_clk_320m\) begin\s*phy_rst <= phy_rst_vio;\s*end',
               b'    assign phy_rst = ~mmcm_locked_out;', t)
    t = t.replace(b".dac_valid     (1'b1)", b".dac_valid     (1'b0)")
    t = t.replace(b".dds_en     (1'b1)", b".dds_en     (1'b0)")
    t = t.replace(b'.clk(data_clk_320m)', b'.clk(data_clk)')
    save(top, t)
    xdc = rfroot / 'ofdm_80211n_2r2t_v1.srcs/constrs_1/new/system.xdc'
    t = xdc.read_bytes().replace(b'C_CLK_INPUT_FREQ_HZ 300000000', b'C_CLK_INPUT_FREQ_HZ 200000000')
    t = t.replace(b'connect_debug_port dbg_hub/clk [get_nets data_clk_320m]',
                  b'connect_debug_port dbg_hub/clk [get_nets rx_diag_axi_clk]')
    save(xdc, t)

    app = ROOT / 'vitis_ws_IQ/vitis_ws/workspace_amd/ad9361_app_v2/src'
    p = app / 'helloworld.c'
    s = p.read_text(encoding='utf-8')
    s = s.replace('/* Manual RX gain: same 20 dB on both receivers. */',
                  '/* Explicit manual mode and configurable equal gain on both receivers. */\n'
                  '    ret = ad9361_set_rx_gain_control_mode(ad9361_phy, 0, RF_GAIN_MGC);\n'
                  '    if (ret < 0) { xil_printf("RX1 MGC setup failed: %d\\r\\n", (int)ret); return 1; }\n'
                  '    ret = ad9361_set_rx_gain_control_mode(ad9361_phy, 1, RF_GAIN_MGC);\n'
                  '    if (ret < 0) { xil_printf("RX2 MGC setup failed: %d\\r\\n", (int)ret); return 1; }')
    marker = '\txil_printf("REAL RF RX mode: internal BIST tone/PRBS/loopback disabled.\\r\\n");'
    if 'RX Analog Bandwidth' not in s:
        assert marker in s
        s = s.replace(marker, '''    {
        uint32_t bw = 0;
        uint8_t mode1 = 255, mode2 = 255;
        ret = ad9361_get_rx_rf_bandwidth(ad9361_phy, &bw);
        print_rate("RX Analog Bandwidth", bw, ret);
        int32_t r1 = ad9361_get_rx_gain_control_mode(ad9361_phy, 0, &mode1);
        int32_t r2 = ad9361_get_rx_gain_control_mode(ad9361_phy, 1, &mode2);
        xil_printf("RX gain modes: RX1=%u ret=%d RX2=%u ret=%d (MGC=0)\\r\\n",
                   (unsigned)mode1, (int)r1, (unsigned)mode2, (int)r2);
    }
''' + marker)
    save(p, s)
    p = app / 'ad9361_cfg_init.c'
    s = p.read_bytes()
    old = b'ad9361_trx_load_enable_fir(ad9361_phy, rx_fir_config, tx_fir_config);usleep(200);'
    if old in s:
        s = s.replace(old, b'ret = ad9361_trx_load_enable_fir(ad9361_phy, rx_fir_config, tx_fir_config);\n'
                      b'    if (ret < 0) { xil_printf("FIR load failed: %d\\r\\n", ret); return ret; }\n'
                      b'    usleep(200);')
    save(p, s)

    # Old logs only: never remove repositories, source, handoff artifacts or backups.
    removed = []
    for sub in ['dma_project', 'openwifi', 'demo_vivado_v2_IQ', 'vitis_ws_IQ', 'ow']:
        for p in (ROOT / sub).rglob('*'):
            if not p.is_file() or '.git' in p.parts:
                continue
            if p.suffix.lower() not in ['.log', '.jou', '.str']:
                continue
            p = checked(p)
            removed.append({'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size})
    BACKUP.mkdir(parents=True, exist_ok=True)
    manifest = {'root': str(ROOT), 'source_changes': CHANGES, 'old_logs_to_remove': removed}
    (BACKUP / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    for item in removed:
        checked(ROOT / item['path']).unlink()
    print(json.dumps({'changed_files': len(CHANGES), 'deleted_logs': len(removed),
                      'deleted_bytes': sum(x['bytes'] for x in removed), 'backup': str(BACKUP)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
