"""Export a source-BD snapshot and PL DTS fragment, without invoking Vivado.

The DTS targets retarget.tcl (23-bit DMA length), not old deployed bitstreams.
"""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'openwifi'


def require_net(scope, endpoints, interfaces=False):
    key, ports = ('interface_nets', 'interface_ports') if interfaces else ('nets', 'ports')
    matches = [n for n in scope[key].values() if set(endpoints) <= set(n[ports])]
    if len(matches) != 1:
        raise ValueError('Missing/ambiguous connection: ' + ' -> '.join(endpoints))


def audit_rx_path(d):
    h = d['components']['openwifi_ip']
    expected_params = [
        (d['components']['util_ad9361_adc_pack'], 'NUM_OF_CHANNELS', '4'),
        (d['components']['util_ad9361_adc_pack'], 'SAMPLE_DATA_WIDTH', '16'),
        (d['components']['clk_wiz_0'], 'PRIM_IN_FREQ', '40.000'),
        (d['components']['clk_wiz_0'], 'CLKOUT1_REQUESTED_OUT_FREQ', '100.000'),
        (d['components']['clk_wiz_0'], 'USE_LOCKED', 'true'),
        (h['components']['sys_rstgen1'], 'C_EXT_RESET_HIGH', '0'),
    ]
    for cell, key, expected in expected_params:
        if cell['parameters'].get(key, {}).get('value') != expected:
            raise ValueError('Unexpected RX parameter ' + key)
    for channel, lane in [('i0', 0), ('q0', 1), ('i1', 2), ('q1', 3)]:
        require_net(d, ['axi_ad9361/adc_data_' + channel,
                        'util_ad9361_adc_fifo/din_data_' + str(lane)])
        require_net(d, ['util_ad9361_adc_fifo/dout_data_' + str(lane),
                        'util_ad9361_adc_pack/fifo_wr_data_' + str(lane)])
    for a, b in [('util_ad9361_adc_pack/packed_fifo_wr_data', 'openwifi_ip/adc_data'),
                 ('util_ad9361_adc_pack/packed_fifo_wr_en', 'openwifi_ip/adc_valid'),
                 ('clk_wiz_0/locked', 'openwifi_ip/bb_clk_locked'),
                 ('clk_wiz_0/clk_out1', 'openwifi_ip/m_axi_mm2s_aclk'),
                 ('sys_concat_intc/dout', 'sys_ps7/IRQ_F2P')]:
        require_net(d, [a, b])
    for ends in [
        ['bb_clk_locked', 'sys_rstgen1/dcm_locked'],
        ['adc_data', 'rx_intf_0/adc_data'],
        ['adc_valid', 'rx_intf_0/adc_valid'],
        ['rx_intf_0/sample0', 'openofdm_rx_0/sample_in', 'side_ch_0/sample0_in'],
        ['rx_intf_0/sample1', 'side_ch_0/sample1_in'],
        ['rx_intf_0/sample_strobe', 'openofdm_rx_0/sample_in_strobe', 'side_ch_0/sample_in_strobe'],
        ['sys_rstgen1/peripheral_aresetn', 'axi_dma_0/axi_resetn', 'axi_dma_1/axi_resetn',
         'rx_intf_0/m00_axis_aresetn', 'openofdm_rx_0/s00_axi_aresetn'],
    ]:
        require_net(h, ends)
    for ends in [
        ['rx_intf_0/m00_axis', 'axi_dma_1/S_AXIS_S2MM'],
        ['side_ch_0/m00_axis', 'axi_dma_0/S_AXIS_S2MM'],
        ['axi_dma_0/M_AXIS_MM2S', 'tx_intf_0/s00_axis'],
        ['axi_dma_1/M_AXIS_MM2S', 'side_ch_0/s00_axis'],
    ]:
        require_net(h, ends, interfaces=True)
    for name in ['axi_dma_0', 'axi_dma_1']:
        params = h['components'][name]['parameters']
        if params.get('c_sg_length_width', {}).get('value') != '23':
            raise ValueError(name + ': expected source BD DMA length width 23')
    return h


def node_end(text, start):
    depth = 0
    opened = False
    for index in range(start, len(text)):
        if text[index] == '{':
            opened = True
            depth += 1
        elif text[index] == '}':
            depth -= 1
            if opened and depth == 0:
                return text.index(';', index) + 1
    raise ValueError('Incomplete reference DTS node')


def main():
    src = ROOT / 'ow/board/src/system.bd'
    d = json.loads(src.read_text(encoding='utf-8'))['design']
    h = audit_rx_path(d)
    segments = d['addressing']['/sys_ps7']['address_spaces']['Data']['segments']
    addresses = {k: {'offset': v['offset'], 'range': v['range'], 'target': v['address_block']}
                 for k, v in segments.items()}
    irq = []
    for name, net in h['nets'].items():
        for port in net['ports']:
            if not re.fullmatch(r'axi_dma_[01]/(?:mm2s|s2mm)_introut', port):
                continue
            external = [p for p in net['ports'] if '/' not in p]
            if len(external) != 1:
                raise ValueError('Ambiguous DMA interrupt connection')
            endpoint = 'openwifi_ip/' + external[0]
            roots = [n for n in d['nets'].values() if endpoint in n['ports']]
            inputs = [p for n in roots for p in n['ports'] if p.startswith('sys_concat_intc/In')]
            if len(inputs) != 1:
                raise ValueError('Missing concat interrupt mapping')
            bit = int(inputs[0].split('/In')[1])
            absolute = 61 + bit if bit < 8 else 84 + bit - 8
            irq.append({'source': port, 'f2p_bit': bit, 'gic_absolute': absolute,
                        'dts_spi': absolute - 32, 'trigger': 'level-high'})
    roles = {
        'axi_dma_0': {'mm2s': 'PS -> tx_intf', 's2mm': 'side_ch -> PS'},
        'axi_dma_1': {'mm2s': 'PS -> side_ch', 's2mm': 'rx_intf decoded frame -> PS'}
    }
    contract = {
        'status': 'static source snapshot; no implemented or deployed hardware claim',
        'bd_sha256': hashlib.sha256(src.read_bytes()).hexdigest(),
        'addresses': addresses, 'dma_roles': roles, 'dma_interrupts': irq,
        'sdr_interrupts': [
            {'index': 0, 'dts_spi': 29, 'source': 'GND (reserved)'},
            {'index': 1, 'dts_spi': 30, 'source': 'rx_intf_0/rx_pkt_intr'},
            {'index': 2, 'dts_spi': 33, 'source': 'unconnected (reserved)'},
            {'index': 3, 'dts_spi': 34, 'source': 'tx_intf_0/tx_itrpt'},
        ],
        'baseband_reset': 'clk_wiz_0/locked -> bb_clk_locked -> sys_rstgen1/dcm_locked; active-low PS reset',
        'rx_path_static_audit': 'passed: four IQ lanes, shared strobe, PHY, side_ch, DMA streams, lock/reset nets',
        'target_dma_length_width': 23,
        'target_length_note': 'retarget.tcl sets this explicitly; old source BD/IP defaults can still be 14',
        'unknown': ['post-implementation AXI ID adaptation', 'LVDS PN tuning',
                    'gpio_clksel polarity and startup value', 'Ethernet PHY address and RGMII delays']
    }
    ref = ROOT / 'upstream/openwifi/kernel_boot/boards/openwifi_32_ad9361.dtso'
    text = ref.read_text(encoding='utf-8')
    start = text.index('sdr: sdr {')
    end = text.index('cf-ad9361-lpc@79020000', start)
    body = text[start:end]
    a = body.index('axidmatest_1:')
    body = body[:a] + body[node_end(body, a):]
    body = body.replace('xlnx,sg-length-width = <0xe>;', 'xlnx,sg-length-width = <23>;')
    body = body.replace('"not_valid_anymore", "rx_pkt_intr", "tx_itrpt"',
                        '"reserved0", "rx_pkt_intr", "reserved2", "tx_itrpt"')
    # Reject source drift before exporting the fixed reference-derived bindings.
    for key, offset in [('SEG_axi_dma_0_Reg', '0x80400000'), ('SEG_axi_dma_1_Reg', '0x80410000'),
                        ('SEG_data_axi_ad9361', '0x79020000'),
                        ('SEG_tx_intf_0_reg0', '0x83c00000'), ('SEG_openofdm_tx_0_reg0', '0x83c10000'),
                        ('SEG_rx_intf_0_reg0', '0x83c20000'), ('SEG_openofdm_rx_0_reg0', '0x83c30000'),
                        ('SEG_xpu_0_reg0', '0x83c40000'), ('SEG_side_ch_0_reg0', '0x83c50000')]:
        if addresses[key]['offset'].lower() != offset:
            raise ValueError(key + ': address changed; regenerate bindings manually')
        if addresses[key]['range'] != '64K':
            raise ValueError(key + ': register range changed; review bindings')
    expected = {'axi_dma_0/mm2s_introut': 35, 'axi_dma_0/s2mm_introut': 36,
                'axi_dma_1/mm2s_introut': 31, 'axi_dma_1/s2mm_introut': 32}
    if {i['source']: i['dts_spi'] for i in irq} != expected:
        raise ValueError('DMA IRQ wiring changed; regenerate bindings manually')
    for source, external, bit in [('rx_intf_0/rx_pkt_intr', 'rx_pkt_intr', 1),
                                  ('tx_intf_0/tx_itrpt', 'tx_itrpt', 5)]:
        require_net(h, [source, external])
        require_net(d, ['openwifi_ip/' + external, 'sys_concat_intc/In' + str(bit)])
    out = HERE / 'linux/an_openwifi_pl.dtsi'
    header = ('/* Derived from the locked openwifi openwifi_32_ad9361.dtso.\n'
              ' * Source-only PL fragment for the updated retarget.tcl.\n'
              ' * Requires amba/intc/clkc and FCLK0=100MHz; remove duplicate nodes.\n'
              ' * AD9361 SPI and ADC/DDS nodes belong to the matching base DTS.\n'
              ' * DMA length is 23 bits: do not pair with an old 14-bit image.\n */\n')
    out.write_text(header + '&amba {\n' + body + '\n};\n', encoding='utf-8')
    (HERE / 'hardware_contract.json').write_text(json.dumps(contract, indent=2) + '\n', encoding='utf-8')
    print('Exported hardware_contract.json and linux/an_openwifi_pl.dtsi (static inputs only)')


if __name__ == '__main__':
    main()
