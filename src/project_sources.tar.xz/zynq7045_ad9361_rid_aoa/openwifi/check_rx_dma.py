"""Read-only source/BD/XCI contract check; does not run Vivado or touch hardware."""
import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    bd = ROOT / 'ow/board/src/system.bd'
    design = json.loads(bd.read_text(encoding='utf-8'))['design']
    ow = design['components']['openwifi_ip']
    checks = []

    def connected(section, a, b, interface=False):
        key = 'interface_ports' if interface else 'ports'
        nets = section['interface_nets' if interface else 'nets']
        found = [name for name, net in nets.items() if {a, b} <= set(net[key])]
        assert len(found) == 1, (a, b, found)
        checks.append(dict(from_port=a, to_port=b, net=found[0]))

    for a, b in [
        ('rx_intf_0/sample0', 'openofdm_rx_0/sample_in'),
        ('openofdm_rx_0/byte_out', 'rx_intf_0/byte_in'),
        ('openofdm_rx_0/byte_out_strobe', 'rx_intf_0/byte_in_strobe'),
        ('openofdm_rx_0/byte_count', 'rx_intf_0/byte_count'),
        ('openofdm_rx_0/pkt_len', 'rx_intf_0/pkt_len'),
        ('openofdm_rx_0/fcs_ok', 'rx_intf_0/fcs_ok'),
        ('openofdm_rx_0/fcs_out_strobe', 'rx_intf_0/fcs_in_strobe'),
        ('axi_dma_1/s2mm_introut', 'rx_intf_0/s2mm_intr'),
        ('rx_intf_0/m00_axis_aclk', 'axi_dma_1/m_axi_s2mm_aclk'),
        ('rx_intf_0/m00_axis_aresetn', 'axi_dma_1/axi_resetn')]:
        connected(ow, a, b)
    for a, b in [
        ('rx_intf_0/m00_axis', 'axi_dma_1/S_AXIS_S2MM'),
        ('axi_dma_1/M_AXI_S2MM', 'axi_interconnect_2/S01_AXI'),
        ('axi_dma_1/M_AXI_SG', 'axi_interconnect_2/S02_AXI'),
        ('axi_interconnect_2/M00_AXI', 'M00_AXI')]:
        connected(ow, a, b, True)
    connected(design, 'openwifi_ip/M00_AXI', 'sys_ps7/S_AXI_ACP', True)
    xcifile = ROOT / 'ow/board/src/ip/system_axi_dma_1_0/system_axi_dma_1_0.xci'
    # Vivado's XCI contains literal control characters in register descriptions.
    params = json.loads(xcifile.read_text(encoding='utf-8'), strict=False)['ip_inst']['parameters']['component_parameters']
    config = {k: params[k][0]['value'] for k in (
        'c_include_sg', 'c_sg_length_width', 'c_include_s2mm', 'c_addr_width',
        'c_s_axis_s2mm_tdata_width', 'c_m_axi_s2mm_data_width', 'c_include_s2mm_dre')}
    assert config == dict(c_include_sg='1', c_sg_length_width='23', c_include_s2mm='1',
                          c_addr_width='32', c_s_axis_s2mm_tdata_width='64',
                          c_m_axi_s2mm_data_width='64', c_include_s2mm_dre='1'), config
    spaces = design['addressing']['/openwifi_ip/axi_dma_1']['address_spaces']
    ddr = {}
    for space in ('Data_S2MM', 'Data_SG'):
        segments = spaces[space]['segments']
        segment = segments['SEG_sys_ps7_ACP_DDR_LOWOCM']
        assert segment['offset'] == '0x00000000' and segment['range'] == '1G'
        assert segment.get('is_excluded') != 'TRUE'
        ddr[space] = segment
    driver = ROOT / 'ow/linux/driver'
    hw = (driver / 'hw_def.h').read_text()
    header = (driver / 'sdr.h').read_text()
    maxlen = int(re.search(r'#define OPENWIFI_MAX_SIGNAL_LEN_TH\s+(\d+)', hw)[1])
    capacity = int(re.search(r'#define RX_BD_BUF_SIZE\s+\((\d+)\)', header)[1])
    transfer = 16 + ((maxlen + 7) // 8) * 8
    assert transfer <= capacity
    result = dict(status='PASS: static sources only', connections=checks, dma1=config,
                  ddr=ddr, max_phy_length=maxlen, max_axis_bytes=transfer,
                  driver_bd_capacity=capacity, private_header_bytes=16,
                  fcs='last PHY byte replaced by {fcs_ok, rx_pkt_sn[6:0]}; not intact FCS bytes',
                  bd_sha256=hashlib.sha256(bd.read_bytes()).hexdigest(),
                  xci_sha256=hashlib.sha256(xcifile.read_bytes()).hexdigest(),
                  unverified=['PHY decoding/CRC correctness', 'XPU admission policy',
                              'DMA engine/descriptor execution', 'ACP coherency/DDR contents',
                              'interrupt ordering and continuous reception'])
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('PASS: %d connections; DMA1 SG/64-bit/23-bit; %d <= %d bytes; ACP DDR mapped' %
          (len(checks), transfer, capacity))


if __name__ == '__main__':
    main()
