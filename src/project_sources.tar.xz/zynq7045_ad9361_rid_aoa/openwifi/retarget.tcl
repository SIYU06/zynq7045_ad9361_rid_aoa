# Applied to a local copy of the ZC706 openwifi BD, never to upstream sources.
source $::ow_stage/board/ps_settings.tcl
set_property -dict $board_ps_settings [get_bd_cells sys_ps7]
# Match an_openwifi_pl.dtsi. Keep SG and the original DMA roles; enlarge the
# length field so a 32768-byte IQ window does not exceed a 14-bit descriptor.
foreach dma {openwifi_ip/axi_dma_0 openwifi_ip/axi_dma_1} {
    set_property CONFIG.c_sg_length_width 23 [get_bd_cells $dma]
}
# SPI1 is disabled in the board PS configuration; remove stale external ports
# and orphan nets instead of retaining undriven reference-board connections.
foreach p [get_bd_ports -quiet spi1_*] {
    set old_nets [get_bd_nets -quiet -of_objects $p]
    delete_bd_objs $p
    foreach n $old_nets {
        if {[llength [get_bd_pins -quiet -of_objects $n]] == 0 &&
            [llength [get_bd_ports -quiet -of_objects $n]] == 0} {
            delete_bd_objs $n
        }
    }
}
# The reference graph has a legacy dummy HDMI/audio port group tied to ground.
# Those ports are not board pins and have no function on this hardware.
foreach p {hdmi_out_clk hdmi_hsync hdmi_vsync hdmi_data_e hdmi_data spdif} {
    delete_bd_objs [get_bd_ports -quiet $p]
}
# No FMC I2C devices on the custom board. Keep the unused AXI slot terminated
# by the original IIC core but remove physical I2C pins from the design.
delete_bd_objs [get_bd_intf_ports -quiet iic_main]
proc ow_tie {target value} {
    set pin [get_bd_pins $target]
    if {[llength [get_bd_nets -quiet -of_objects $pin]]} {return}
    set left [get_property LEFT $pin]
    set right [get_property RIGHT $pin]
    set width 1
    if {$left ne "" && $right ne ""} {set width [expr {abs($left-$right)+1}]}
    set name ow_tie_[string map {/ _} $target]
    if {![llength [get_bd_cells -quiet $name]]} {
        create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 $name
    }
    set_property -dict [list CONFIG.CONST_WIDTH $width CONFIG.CONST_VAL $value] [get_bd_cells $name]
    connect_bd_net [get_bd_pins $name/dout] $pin
}
foreach pin {openwifi_ip/dma_data openwifi_ip/dma_valid openwifi_ip/openofdm_rx_0/para_valid openwifi_ip/openofdm_rx_0/para_rx_sensitivity_th openwifi_ip/side_ch_0/openofdm_tx_iq1} {
    ow_tie $pin 0
}
ow_tie axi_iic_main/scl_i 1
ow_tie axi_iic_main/sda_i 1
set_property -dict [list CONFIG.PRIM_IN_FREQ 40.000 CONFIG.CLKOUT1_REQUESTED_OUT_FREQ 100.000] [get_bd_cells clk_wiz_0]
set_property CONFIG.FREQ_HZ 40000000 [get_bd_pins util_ad9361_divclk/clk_out]
# The baseband clock comes from this MMCM, not PS FCLK2. Hold the
# PHY/MAC, interconnect and DMA in reset until its clock is stable.
set_property CONFIG.USE_LOCKED true [get_bd_cells clk_wiz_0]
set_property CONFIG.C_EXT_RESET_HIGH 0 [get_bd_cells openwifi_ip/sys_rstgen1]
if {![llength [get_bd_pins -quiet openwifi_ip/bb_clk_locked]]} {
    set previous_instance [current_bd_instance .]
    current_bd_instance /openwifi_ip
    create_bd_pin -dir I bb_clk_locked
    current_bd_instance $previous_instance
}
foreach target {openwifi_ip/bb_clk_locked openwifi_ip/sys_rstgen1/dcm_locked} {
    set old [get_bd_nets -quiet -of_objects [get_bd_pins $target]]
    if {[llength $old]} {disconnect_bd_net $old [get_bd_pins $target]}
}
connect_bd_net [get_bd_pins clk_wiz_0/locked] [get_bd_pins openwifi_ip/bb_clk_locked]
connect_bd_net [get_bd_pins openwifi_ip/bb_clk_locked] [get_bd_pins openwifi_ip/sys_rstgen1/dcm_locked]
validate_bd_design
save_bd_design
