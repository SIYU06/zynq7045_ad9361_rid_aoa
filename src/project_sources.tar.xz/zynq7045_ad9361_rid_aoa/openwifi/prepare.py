"""Prepare locked, disposable Windows build sources. Upstream checkouts stay intact."""
import hashlib
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UP = ROOT / 'upstream'
STAGE = ROOT / 'ow'
HERE = Path(__file__).resolve().parent


def git(repo, *args):
    return subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(),
                                    '-C', str(repo), *args], text=True).strip()


def main():
    lock = json.loads((HERE / 'sources.lock.json').read_text())
    for key, rel in [('openwifi_hw', 'openwifi-hw'), ('openwifi', 'openwifi'),
                     ('adi_hdl', 'openwifi-hw/adi-hdl'),
                     ('openofdm', 'openwifi-hw/ip/openofdm_rx')]:
        actual = git(UP / rel, 'rev-parse', 'HEAD')
        if actual != lock[key]['commit']:
            raise SystemExit('Version mismatch for {}: {}'.format(key, actual))
    if STAGE.exists():
        write_board(refresh_adapters='--refresh-adapters' in sys.argv)
        from apply_deinterleave_fix import main as apply_deinterleave_fix
        apply_deinterleave_fix()
        from apply_rx_axis_fix import main as apply_rx_axis_fix
        apply_rx_axis_fix()
        from apply_tx_iq_cdc_fix import main as apply_tx_iq_cdc_fix
        apply_tx_iq_cdc_fix()
        print('Existing board BD retained; only missing inputs prepared.')
        return
    STAGE.mkdir()
    shutil.copytree(UP / 'openwifi-hw/ip', STAGE / 'ip',
                    ignore=shutil.ignore_patterns('.git', '*.png', '*.jpg', '*.pdf'))
    shutil.copytree(UP / 'openwifi-hw/adi-hdl/library', STAGE / 'adi-hdl/library')
    shutil.copytree(UP / 'openwifi-hw/adi-hdl/scripts', STAGE / 'adi-hdl/scripts')
    shutil.copytree(UP / 'openwifi-hw/adi-hdl/projects/scripts', STAGE / 'adi-hdl/projects/scripts')
    helper = STAGE / 'adi-hdl/library/scripts/adi_ip_xilinx.tcl'
    helper.write_text(helper.read_text().replace(
        'add_files -norecurse -scan_for_includes -fileset',
        'add_files -norecurse -fileset'))
    # ADI packaging resolves project version/environment through scripts/adi_env.tcl.
    for name in ['LICENSE', 'LICENSE_ADIBSD', 'LICENSE_GPL2']:
        p = UP / 'openwifi-hw/adi-hdl' / name
        if p.is_file():
            shutil.copy2(p, STAGE / 'adi-hdl' / name)
    for name in ['parse_board_name.tcl', 'openofdm_rx/parse_board_name.tcl']:
        p = STAGE / 'ip' / name
        s = p.read_text()
        # Keep Zynq-7000 large-FPGA defaults, add an explicit board identity.
        s = s.replace('if {$BOARD_NAME=="zed_fmcs2"}',
            'if {$BOARD_NAME=="an_xc7z045"} {\n'
            ' set ultra_scale_flag 0\n set part_string "xc7z045fbg676-1"\n'
            ' set board_part_string []\n set board_id_string []\n'
            ' set fpga_size_flag 1\n} elseif {$BOARD_NAME=="zed_fmcs2"}', 1)
        p.write_text(s)
    # Replace shell revision helpers only in generated sources; preserve real revisions.
    for p in (STAGE / 'ip').glob('*/*.tcl'):
        s = p.read_text()
        rev = lock['openofdm' if p.parent.name == 'openofdm_rx' else 'openwifi_hw']['commit'][:8]
        s = re.sub(r'set HASHCODE \[exec (?:bash )?[^\]\n]*get_git_rev\.sh\]',
                   'set HASHCODE ' + rev, s)
        p.write_text(s)
    write_board()
    from apply_deinterleave_fix import main as apply_deinterleave_fix
    apply_deinterleave_fix()
    from apply_rx_axis_fix import main as apply_rx_axis_fix
    apply_rx_axis_fix()
    from apply_tx_iq_cdc_fix import main as apply_tx_iq_cdc_fix
    apply_tx_iq_cdc_fix()


def copy_adapter(src, dst, refresh=False):
    if dst.exists():
        if not refresh or dst.read_bytes() == src.read_bytes():
            return
        backup = ROOT / 'change_backups' / ('adapter_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f')) / dst.relative_to(ROOT)
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst, backup)
    shutil.copy2(src, dst)


def write_board(refresh_adapters=False):
    b = STAGE / 'board'
    (b / 'src').mkdir(parents=True, exist_ok=True)
    ref = UP / 'openwifi-hw/boards/zc706_fmcs2/src/system.bd'
    d = json.loads(ref.read_text())
    d['design']['design_info']['device'] = 'xc7z045fbg676-1'
    if not (b / 'src/system.bd').exists():
        (b / 'src/system.bd').write_text(json.dumps(d, indent=2))
    copy_adapter(HERE / 'system_top.v', b / 'src/system_top.v', refresh_adapters)
    copy_adapter(HERE / 'board.xdc', b / 'src/board.xdc', refresh_adapters)
    copy_adapter(HERE / 'board_timing.xdc', b / 'src/openwifi_timing.xdc', refresh_adapters)
    copy_adapter(HERE / 'board_ps_settings.tcl', b / 'ps_settings.tcl', refresh_adapters)
    cfg = b / 'ip_config'
    cfg.mkdir(exist_ok=True)
    for name in ['xpu', 'tx_intf', 'rx_intf', 'openofdm_tx', 'openofdm_rx', 'side_ch']:
        target = cfg / (name + '_pre_def.v')
        if not target.exists():
            target.write_text('`define an_xc7z045\n')
    # Backup the editable project inputs once, before any Vivado project mutation.
    backup = ROOT / 'baseline_before_openwifi'
    backup.mkdir(exist_ok=True)
    paths = ['dma_project.xpr', 'dma_project.srcs/sources_1/bd/system/system.bd']
    manifest = {}
    for rel in paths:
        src = ROOT / 'dma_project' / rel
        target = backup / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copy2(src, target)
        manifest[rel] = hashlib.sha256(target.read_bytes()).hexdigest()
    if not (backup / 'sha256.json').exists():
        (backup / 'sha256.json').write_text(json.dumps(manifest, indent=2))
    print('Prepared locked sources at', STAGE)


if __name__ == '__main__':
    main()
