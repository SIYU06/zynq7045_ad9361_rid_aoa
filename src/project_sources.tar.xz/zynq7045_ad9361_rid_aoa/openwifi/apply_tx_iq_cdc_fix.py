"""Mark the existing TX IQ destination pipeline as a CDC synchronizer."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def fixed_source(source):
    old = (
        '    `DEBUG_PREFIX reg [(2*IQ_DATA_WIDTH-1) : 0] data_from_acc_stage1;\n'
        '    `DEBUG_PREFIX reg [(2*IQ_DATA_WIDTH-1) : 0] data_from_acc_stage2;'
    )
    new = (
        '    // Source data changes only on the synchronized read request; these two\n'
        '    // destination-clock stages form the existing multi-bit CDC capture chain.\n'
        '    (* ASYNC_REG = "TRUE" *) `DEBUG_PREFIX reg [(2*IQ_DATA_WIDTH-1) : 0] data_from_acc_stage1;\n'
        '    (* ASYNC_REG = "TRUE" *) `DEBUG_PREFIX reg [(2*IQ_DATA_WIDTH-1) : 0] data_from_acc_stage2;'
    )
    if source.count(old) != 1:
        raise ValueError('Unexpected dac_intf CDC structure; review the patch')
    return source.replace(old, new)


def main():
    upstream = ROOT / 'upstream/openwifi-hw/ip/tx_intf/src/dac_intf.v'
    original = upstream.read_text(encoding='utf-8')
    fixed = fixed_source(original)
    targets = [
        ROOT / 'ow/ip/tx_intf/src/dac_intf.v',
        ROOT / 'ow/board/ip_repo/tx_intf/src/dac_intf.v',
    ]
    targets += sorted((ROOT / 'ow/board/src/ipshared').glob('*/src/dac_intf.v'))
    changed = []
    for path in targets:
        if not path.exists():
            continue
        current = path.read_text(encoding='utf-8')
        if current.rstrip() == fixed.rstrip():
            continue
        if current.rstrip() != original.rstrip():
            raise ValueError('Unexpected local modifications: ' + str(path))
        backup = ROOT / 'change_backups/tx_iq_cdc_20261027' / path.relative_to(ROOT)
        backup.parent.mkdir(parents=True, exist_ok=True)
        if not backup.exists():
            shutil.copy2(path, backup)
        with path.open('w', encoding='utf-8', newline='\n') as stream:
            stream.write(fixed)
        changed.append(path.relative_to(ROOT).as_posix())
    print(json.dumps({
        'changed': changed,
        'upstream_sha256': hashlib.sha256(original.encode()).hexdigest(),
    }, indent=2))


if __name__ == '__main__':
    main()
