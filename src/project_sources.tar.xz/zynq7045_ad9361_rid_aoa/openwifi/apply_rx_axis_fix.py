"""Board-only AXIS TLAST fix; preserve the locked upstream checkout."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def fixed_source(source):
    old = 'assign M_AXIS_TLAST\t    = axis_tlast&&(!axis_tlast_delay);'
    new = ('// Board fix: packet metadata stays valid under DMA backpressure.\n'
           '\tassign M_AXIS_TLAST\t    = axis_tlast;')
    last_old = 'assign axis_tlast = ( (read_pointer == M_AXIS_NUM_DMA_SYMBOL) && tx_en ) && (endless_mode==0);'
    last_new = 'assign axis_tlast = (read_pointer == M_AXIS_NUM_DMA_SYMBOL) && axis_tvalid && (endless_mode==0);'
    if source.count(old) != 1 or source.count(last_old) != 1:
        raise ValueError('Unexpected RX AXIS structure; review the patch')
    # The unused legacy delay register is removed, not made part of the handshake.
    source = source.replace(old, new).replace(last_old, last_new)
    source = source.replace('    reg     axis_tlast_delay;\n', '')
    begin = source.index('\t// Delay the axis_tvalid and axis_tlast signal')
    end = source.index('\talways@(posedge M_AXIS_ACLK)', begin)
    return source[:begin] + source[end:]


def main():
    changed = []
    hashes = {}
    for name in ('rx_intf_m_axis.v', 'rx_intf.v'):
        upstream = ROOT / 'upstream/openwifi-hw/ip/rx_intf/src' / name
        original = upstream.read_text(encoding='utf-8')
        hashes[name] = hashlib.sha256(original.encode()).hexdigest()
        if name == 'rx_intf_m_axis.v':
            fixed = fixed_source(original)
        else:
            old = '.m_axis_tlast(m00_axis_tlast_inner),'
            assert original.count(old) == 1
            # The controller consumes a completed-packet event, not valid metadata.
            fixed = original.replace(old,
                '.m_axis_tlast(m00_axis_tlast_inner & m00_axis_tready),')
        targets = [ROOT / 'ow/ip/rx_intf/src' / name,
                   ROOT / 'ow/board/ip_repo/rx_intf/src' / name]
        targets += sorted((ROOT / 'ow/board/src/ipshared').glob('*/src/' + name))
        for path in targets:
            if not path.exists():
                continue
            current = path.read_text(encoding='utf-8')
            if current.rstrip() == fixed.rstrip():
                continue
            if current.rstrip() != original.rstrip():
                raise ValueError('Unexpected local modifications: ' + str(path))
            backup = ROOT / 'change_backups/rx_axis_20261026' / path.relative_to(ROOT)
            backup.parent.mkdir(parents=True, exist_ok=True)
            if not backup.exists():
                shutil.copy2(path, backup)
            with path.open('w', encoding='utf-8', newline='\n') as stream:
                stream.write(fixed)
            changed.append(path.relative_to(ROOT).as_posix())
    print(json.dumps(dict(changed=changed, upstream_sha256=hashes), indent=2))


if __name__ == '__main__':
    main()
