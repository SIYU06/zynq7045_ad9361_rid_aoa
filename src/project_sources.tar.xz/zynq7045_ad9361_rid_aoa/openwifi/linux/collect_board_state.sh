#!/bin/sh
# Read-only evidence collection. Redirect stdout to a file INSIDE the project
# after transfer. Does not load modules, tune the RF, or modify sysfs.
set -eu
echo '=== kernel ==='
uname -a
echo '=== model ==='
tr '\000' '\n' < /proc/device-tree/model
echo '=== kernel config ==='
if [ -r /proc/config.gz ]; then
    zcat /proc/config.gz | sha256sum
else
    echo 'UNKNOWN: /proc/config.gz unavailable; obtain the exact build .config'
fi
echo '=== kernel symbol versions ==='
sym=/lib/modules/$(uname -r)/build/Module.symvers
if [ -r "$sym" ]; then sha256sum "$sym"; else echo 'UNKNOWN: obtain Module.symvers from the exact kernel build'; fi
echo '=== loaded modules ==='
cat /proc/modules
echo '=== RF readback ==='
for dev in /sys/bus/iio/devices/iio:device*; do
    [ -f "$dev/in_voltage_rf_bandwidth" ] || continue
    echo "$dev"
    for attr in name in_voltage_sampling_frequency in_voltage_rf_bandwidth in_voltage0_gain_control_mode in_voltage1_gain_control_mode in_voltage0_hardwaregain in_voltage1_hardwaregain out_altvoltage0_RX_LO_frequency in_voltage_filter_fir_en; do
        if [ -r "$dev/$attr" ]; then printf '%s=' "$attr"; cat "$dev/$attr"; fi
    done
done
