#!/bin/sh
# Run from the generated runtime directory with matching locally built .ko files.
# Keeps FPGA/BOOT loading separate. No AP, association or active scan is started.
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$here"
[ "$(id -u)" = 0 ] || { echo 'Run as root on the board.' >&2; exit 1; }
model=$(tr -d '\000' < /proc/device-tree/model)
case "$model" in *XC7Z045*) ;; *) echo "Unexpected board model: $model" >&2; exit 1 ;; esac
if [ -e /sys/class/net/sdr0 ]; then ip link set sdr0 down; fi
for module in tx_intf rx_intf openofdm_tx openofdm_rx xpu sdr; do
    [ -s "$module.ko" ] || { echo "Missing $module.ko" >&2; exit 1; }
    magic=$(modinfo -F vermagic "./$module.ko")
    [ "${magic%% *}" = "$(uname -r)" ] || { echo "Kernel mismatch: $module" >&2; exit 1; }
done
# The generated local wgd skips direct-register AGC overrides and checks RF init.
OPENWIFI_RELOAD_FPGA=0 bash ./wgd.sh
ip link set sdr0 down
iw dev sdr0 set type monitor
ip link set sdr0 up
iw dev sdr0 set channel 6 HT20
# Driver channel tuning can change RF settings, so apply/record MGC afterwards.
sh ./configure_rx.sh "${OPENWIFI_RX_GAIN_DB:-46}"
iw dev sdr0 info
echo 'Monitor RX configured. side_ch is loaded separately after choosing its IQ mode.'
