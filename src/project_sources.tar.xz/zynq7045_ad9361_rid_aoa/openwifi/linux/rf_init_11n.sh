#!/bin/sh
# Local receive-first initialization. Run with capture and sdr interface stopped.
# Uses the FIR from the locked openwifi revision, not the teammate's wideband FIR.
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
dev=
for candidate in /sys/bus/iio/devices/iio:device*; do
    if [ -f "$candidate/in_voltage_rf_bandwidth" ] &&
       [ -f "$candidate/out_altvoltage0_RX_LO_frequency" ]; then
        [ -z "$dev" ] || { echo 'Multiple RF devices found.' >&2; exit 1; }
        dev=$candidate
    fi
done
[ -n "$dev" ] || { echo 'AD9361 not found.' >&2; exit 1; }
fir=$here/openwifi_ad9361_fir_tx_0MHz_11n.ftr
[ -s "$fir" ] || { echo "Missing locked FIR: $fir" >&2; exit 1; }
# Linux FIR upload programs the filter's clock chain; do not mix in the
# teammate's DEC2 clock chain. Fail immediately on any rejected attribute write.
printf '0\n' > "$dev/in_voltage_filter_fir_en"
printf '0\n' > "$dev/out_voltage_filter_fir_en"
cat "$fir" > "$dev/filter_fir_config"
printf '1\n' > "$dev/in_voltage_filter_fir_en"
printf '1\n' > "$dev/out_voltage_filter_fir_en"
# Values used by the matching upstream 11n initialization; not measured bandwidths.
printf '25215513\n' > "$dev/in_voltage_rf_bandwidth"
printf '25215414\n' > "$dev/out_voltage_rf_bandwidth"
printf '40000000\n' > "$dev/in_voltage_sampling_frequency"
printf '40000000\n' > "$dev/out_voltage_sampling_frequency"
printf '2437000000\n' > "$dev/out_altvoltage1_TX_LO_frequency"
printf '%s\n' -89.75 > "$dev/out_voltage0_hardwaregain"
printf '%s\n' -89.75 > "$dev/out_voltage1_hardwaregain"
sh "$here/configure_rx.sh" "${OPENWIFI_RX_GAIN_DB:-46}"
for attr in in_voltage_filter_fir_en out_voltage_filter_fir_en; do
    [ "$(cat "$dev/$attr")" = 1 ] || { echo "FIR enable failed: $attr" >&2; exit 1; }
done
