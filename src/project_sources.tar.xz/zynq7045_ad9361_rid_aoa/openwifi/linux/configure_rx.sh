#!/bin/sh
# Apply only AFTER matching FPGA, driver and FIR initialization. No FPGA loading.
set -eu
dev=
for candidate in /sys/bus/iio/devices/iio:device*; do
    if [ -f "$candidate/in_voltage_rf_bandwidth" ] &&
       [ -f "$candidate/out_altvoltage0_RX_LO_frequency" ]; then
        [ -z "$dev" ] || { echo 'Multiple AD9361 candidates; specify the intended board separately.' >&2; exit 1; }
        dev=$candidate
    fi
done
[ -n "$dev" ] || { echo 'AD9361 IIO device not found.' >&2; exit 1; }
# Do not change sampling clocks behind an already running FPGA capture.
fs=$(cat "$dev/in_voltage_sampling_frequency")
[ "$fs" = 40000000 ] || { echo "Expected initialized 40 MSPS; got $fs. Check FIR/clock initialization first." >&2; exit 1; }
gain=${1:-46}
case "$gain" in ''|*[!0-9]*) echo 'Gain must be an integer in 0..70 dB.' >&2; exit 1 ;; esac
[ "$gain" -le 70 ] || { echo 'Gain must be in 0..70 dB for this initial profile.' >&2; exit 1; }
printf '%s\n' 2437000000 > "$dev/out_altvoltage0_RX_LO_frequency"
printf '%s\n' manual > "$dev/in_voltage0_gain_control_mode"
printf '%s\n' manual > "$dev/in_voltage1_gain_control_mode"
printf '%s\n' "$gain" > "$dev/in_voltage0_hardwaregain"
printf '%s\n' "$gain" > "$dev/in_voltage1_hardwaregain"
for attr in out_altvoltage0_RX_LO_frequency in_voltage_sampling_frequency in_voltage_rf_bandwidth in_voltage0_gain_control_mode in_voltage1_gain_control_mode in_voltage0_hardwaregain in_voltage1_hardwaregain; do
    printf '%s: ' "$attr"
    cat "$dev/$attr"
done
