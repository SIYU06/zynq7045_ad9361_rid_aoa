# Prepare a separate project; never mutate the main XPR during validation.
set script_dir [file normalize [file dirname [info script]]]
set root [file normalize $script_dir/..]
set ::ow_stage [file normalize $root/ow]
set action [lindex $argv 0]
if {$action eq ""} {set action validate}
if {$action ni {validate synth impl}} {error "Use validate, synth or impl"}
if {[version -short] ne "2022.2"} {error "Use Vivado 2022.2"}
foreach name {openofdm_rx openofdm_tx rx_intf tx_intf xpu side_ch} {
    if {![file exists $::ow_stage/board/ip_repo/$name/component.xml]} {error "Package $name first"}
}
if {![file exists $root/baseline_before_openwifi/sha256.json]} {error "Run prepare.py first to back up project inputs"}
set project_dir $::ow_stage/project
if {[file exists $project_dir/dma_project_openwifi.xpr]} {
    error "Existing staging project retained: $project_dir. Open it to continue; no files overwritten."
}
create_project dma_project_openwifi $project_dir -part xc7z045fbg676-1
set_property ip_repo_paths [list $::ow_stage/adi-hdl/library $::ow_stage/board/ip_repo] [current_project]
update_ip_catalog -rebuild
set local_src $project_dir/board_src
file mkdir $local_src
foreach name {system.bd system_top.v board.xdc openwifi_timing.xdc} {
    file copy $::ow_stage/board/src/$name $local_src/$name
}
set local_bd $local_src/system.bd
add_files -norecurse $local_bd
open_bd_design $local_bd
source $script_dir/retarget.tcl
set bd_ips [get_ips -quiet]
set locked [get_ips -quiet -filter {IS_LOCKED == 1}]
if {[llength $locked]} {upgrade_ip $locked}
validate_bd_design
save_bd_design
generate_target all [get_files $local_bd]
set wrapper [make_wrapper -files [get_files $local_bd] -top]
add_files -norecurse $wrapper
add_files -norecurse $local_src/system_top.v
add_files -fileset constrs_1 [list $local_src/board.xdc $local_src/openwifi_timing.xdc]
set_property top system_top [get_filesets sources_1]
set_property top_auto_set 0 [get_filesets sources_1]
set_property AUTO_INCREMENTAL_CHECKPOINT 0 [get_runs synth_1]
set_property incremental_checkpoint {} [get_runs synth_1]
update_compile_order -fileset sources_1
set report_dir $project_dir/reports
file mkdir $report_dir
report_ip_status -file $report_dir/ip_status.rpt
write_bd_tcl -force $report_dir/system_generated.tcl
set fd [open $report_dir/address_map.txt w]
foreach seg [get_bd_addr_segs -hierarchical] {
    puts $fd "$seg OFFSET=[get_property -quiet OFFSET $seg] RANGE=[get_property -quiet RANGE $seg]"
}
close $fd
if {$action ne "validate"} {
    launch_runs synth_1 -jobs 4
    wait_on_run synth_1
    if {![string match *Complete* [get_property STATUS [get_runs synth_1]]]} {error "Synthesis failed"}
    open_run synth_1
    report_drc -file $report_dir/synth_drc.rpt
    close_design
}
if {$action eq "impl"} {
    launch_runs impl_1 -to_step route_design -jobs 4
    wait_on_run impl_1
    if {![string match *Complete* [get_property STATUS [get_runs impl_1]]]} {error "Implementation failed"}
    open_run impl_1
    report_timing_summary -file $report_dir/timing_summary.rpt
    report_drc -file $report_dir/impl_drc.rpt
    # Deliberately separate bitstream generation from timing/DRC review.
}
exit
