"""Strict GB 46750 V1.x payload reader, normalized to the existing RID feed.

Field order/scales checked against the OpenDroneID project's Apache-2.0
libopendroneidcn, revision 849c03adbe0cdd68997a462fafab397edcfe53f3.
https://github.com/opendroneid/opendroneid-core-c/tree/849c03adbe0cdd68997a462fafab397edcfe53f3/libopendroneidcn
This module does not authenticate a sender or assert the truth of its position.
"""
import struct


def decode_cn(data):
    if len(data) < 6 or data[0] != 255 or data[1] & 0xe0 != 0x20:
        raise ValueError('Invalid GB46750 header')
    flags = []; pos = 3
    while pos < len(data):
        flags.append(data[pos]); pos += 1
        if not flags[-1] & 1: break
        if len(flags) >= 3: raise ValueError('Unknown GB46750 flag extension')
    if len(flags) != 3 or flags[-1] & 1 or len(data) != pos + data[2]:
        raise ValueError('Invalid GB46750 declared length/flags')
    if any(f & mask != mask for f, mask in zip(flags, (0xde, 0xe4, 0xfe))):
        raise ValueError('Missing mandatory GB46750 field')
    sizes = (20, 8, 1, 1, 1, 8, 2, 8, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1, 1, 6, 1)
    fields = {}
    for index, size in enumerate(sizes):
        if flags[index // 7] & (0x80 >> (index % 7)):
            if pos + size > len(data): raise ValueError('Truncated GB46750 field')
            fields[index + 1] = data[pos:pos+size]; pos += size
    if pos != len(data): raise ValueError('Unconsumed GB46750 bytes')

    def ascii_field(index):
        raw = fields[index]
        if any(value and not 32 <= value <= 126 for value in raw):
            raise ValueError('Invalid GB46750 identity text')
        value = raw.rstrip(b'\0')
        if not value or b'\0' in value: raise ValueError('Invalid GB46750 identity padding')
        return value.decode('ascii')

    def integer(index): return int.from_bytes(fields[index], 'little')
    def nibble(index):
        value = integer(index)
        if value > 15: raise ValueError('Invalid GB46750 reserved bits')
        return value
    def altitude(index, offset=1000):
        value = integer(index) if index in fields else 0
        return value * .5 - offset if value else None
    def position(index):
        lon, lat = struct.unpack('<ii', fields[index])
        if lon == -1 or lat == -1: return None, None
        lon, lat = lon / 1e7, lat / 1e7
        if abs(lat) > 90 or abs(lon) > 180: raise ValueError('Invalid GB46750 coordinate range')
        return (None, None) if lon == lat == 0 else (lat, lon)

    sn, registration = ascii_field(1), ascii_field(2)
    lat, lon = position(8); operator_lat, operator_lon = position(6)
    coordinate_system = nibble(16)
    if coordinate_system not in (0, 1): raise ValueError('Unknown GB46750 coordinate system')
    # Preserve CGCS2000 values explicitly; avoid presenting them as WGS84.
    raw_position = dict(latitude=lat, longitude=lon, coordinateSystem=coordinate_system)
    if coordinate_system != 0: lat = lon = operator_lat = operator_lon = None
    track = integer(9)
    if track != 65535 and track > 3599: raise ValueError('Invalid GB46750 track angle')
    vertical = integer(12) if 12 in fields else 255
    timestamp = integer(20)
    common = dict(format='GB46750', version=data[1] & 31, raw=data.hex(),
                  timestamp_ms=timestamp, timestamp_accuracy=nibble(21), registration=registration,
                  coordinate_system=coordinate_system, authenticated=False)
    basic = dict(common, type=0, id_type=1, ua_type=0, uas_id=sn, drone_class=nibble(4))
    location = dict(common, type=1, status=nibble(15), latitude=lat, longitude=lon,
        direction=None if track == 65535 else track / 10,
        speed_horizontal=None if integer(10) == 65535 else integer(10) / 10,
        speed_vertical=None if vertical == 255 else (-1 if vertical & 128 else 1) * (vertical & 127) * .5,
        altitude_geo=altitude(13), altitude_baro=altitude(14), height=altitude(11, 9000),
        height_reference='takeoff', horizontal_accuracy=nibble(17), vertical_accuracy=nibble(18),
        speed_accuracy=nibble(19), broadcast_position=raw_position)
    system = dict(common, type=4, operator_location_type=nibble(5),
        operator_latitude=operator_lat, operator_longitude=operator_lon, operator_altitude_geo=altitude(7))
    return [basic, location, system]
