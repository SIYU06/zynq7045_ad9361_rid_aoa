"""Shared passive HT20 channels: current OpenWiFi driver and historical survey."""
import subprocess
CHANNELS_24=tuple(range(1,14))
CHANNELS_5=(36,38,40,42,44,46,48,52,56,60,64)
CHANNELS=set(CHANNELS_24+CHANNELS_5)

def channel_frequency(channel):
    if type(channel) is not int or channel not in CHANNELS:
        raise ValueError('unsupported passive HT20 channel')
    return 2407+5*channel if channel<=13 else 5000+5*channel

def tune_channel(channel,interface='sdr0'):
    channel_frequency(channel)
    subprocess.run(['iw','dev',interface,'set','channel',str(channel),'HT20'],
                   check=True,capture_output=True,timeout=3)
