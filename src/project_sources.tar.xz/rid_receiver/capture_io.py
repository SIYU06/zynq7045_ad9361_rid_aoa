"""802.11 monitor framing and PCAP I/O without third-party dependencies."""
import struct
import zlib


def monitor_frame(packet, linktype=127, openwifi_fcs=False):
    info = {'rssi': None, 'frequency_mhz': None, 'rate_mbps': None, 'fcs_valid': None}
    if linktype == 105:
        return packet, info
    if linktype != 127 or len(packet) < 8:
        raise ValueError('Expected raw 802.11 or radiotap capture')
    version, _, length = struct.unpack_from('<BBH', packet)
    if version or not 8 <= length <= len(packet):
        raise ValueError('Invalid radiotap header')
    cursor, present = 4, []
    while True:
        if cursor + 4 > length:
            raise ValueError('Truncated radiotap bitmap')
        bitmap = struct.unpack_from('<I', packet, cursor)[0]
        present.append(bitmap)
        cursor += 4
        if not bitmap & 0x80000000:
            break
    flags = 0
    layout=[(8,8),(1,1),(1,1),(2,4),(2,2),(1,1),(1,1),(2,2),(2,2),(2,2),
            (1,1),(1,1),(1,1),(1,1),(2,2),(2,2),(1,1),(1,1),(4,8),(1,3)]
    for field,(alignment,size) in enumerate(layout):
        if not present[0] & (1 << field):
            continue
        cursor = (cursor + alignment - 1) & ~(alignment - 1)
        if cursor + size > length:
            raise ValueError('Truncated radiotap field')
        value = packet[cursor:cursor + size]
        cursor += size
        if field == 1:
            flags = value[0]
        elif field == 2 and value[0] < 128:
            info['rate_mbps'] = value[0] * .5
        elif field == 3:
            info['frequency_mhz'] = struct.unpack_from('<H', value)[0]
        elif field == 5:
            info['rssi'] = struct.unpack('b', value)[0]
        elif field == 19:
            known,mcs_flags,index=value
            info['ht_mcs']=dict(known=known,flags=mcs_flags,index=index if known&2 else None,
                bandwidth_mhz=(20 if mcs_flags&3==0 else 40 if mcs_flags&3==1 else None) if known&1 else None,
                short_gi=bool(mcs_flags&4) if known&4 else None)
    frame = packet[length:]
    if flags & 0x40:
        info['fcs_valid'] = False
    if flags & 0x10:
        if len(frame) < 4:
            raise ValueError('Missing FCS')
        stored = struct.unpack('<I', frame[-4:])[0]
        metadata_byte = frame[-1]
        frame = frame[:-4]
        crc = zlib.crc32(frame) & 0xffffffff
        if openwifi_fcs:
            # rx_intf replaces the final FCS byte with {fcs_ok, 7-bit packet SN}.
            # Preserve raw capture; check hardware CRC32 plus the remaining CRC24.
            info['fcs_valid'] = (info['fcs_valid'] is not False and bool(metadata_byte & 0x80)
                                 and (crc & 0xffffff) == (stored & 0xffffff))
            info['fcs_method'] = 'openwifi_hw_crc32_plus_retained_crc24'
        else:
            info['fcs_valid'] = info['fcs_valid'] is not False and crc == stored
            info['fcs_method'] = 'software_crc32'
    return frame, info


def _options(data, endian):
    pos = 0
    while pos + 4 <= len(data):
        code, size = struct.unpack_from(endian + 'HH', data, pos)
        pos += 4
        if not code:
            break
        yield code, data[pos:pos + size]
        pos += (size + 3) & ~3


def read_capture(path):
    """Yield (capture epoch seconds, linktype, packet bytes), PCAP or PCAPNG."""
    with open(path, 'rb') as stream:
        magic = stream.read(4)
        formats = {b'\xd4\xc3\xb2\xa1': ('<', 1e-6), b'\xa1\xb2\xc3\xd4': ('>', 1e-6),
                   b'\x4d\x3c\xb2\xa1': ('<', 1e-9), b'\xa1\xb2\x3c\x4d': ('>', 1e-9)}
        if magic in formats:
            endian, unit = formats[magic]
            header = stream.read(20)
            if len(header) != 20:
                raise ValueError('Truncated PCAP header')
            linktype = struct.unpack_from(endian + 'I', header, 16)[0] & 0xffff
            while True:
                header = stream.read(16)
                if not header:
                    return
                sec, frac, size, original = struct.unpack(endian + 'IIII', header)
                if size > 16 * 1024 * 1024:
                    raise ValueError('Oversized packet')
                packet = stream.read(size)
                if len(packet) != size:
                    raise ValueError('Truncated PCAP packet')
                yield sec + frac * unit, linktype, packet
        elif magic == b'\x0a\x0d\x0d\x0a':
            stream.seek(0)
            endian, interfaces = '<', []
            while True:
                header = stream.read(8)
                if not header:
                    return
                if len(header) != 8:
                    raise ValueError('Truncated PCAPNG block')
                prefix = b''
                if header[:4] == b'\x0a\x0d\x0d\x0a':
                    prefix = stream.read(4)
                    endian = {b'\x4d\x3c\x2b\x1a': '<', b'\x1a\x2b\x3c\x4d': '>'}.get(prefix)
                    if not endian:
                        raise ValueError('Invalid PCAPNG byte order')
                    interfaces = []
                kind, size = struct.unpack(endian + 'II', header)
                if size < 12 or size % 4 or size > 16 * 1024 * 1024:
                    raise ValueError('Invalid PCAPNG block size')
                body = prefix + stream.read(size - 8 - len(prefix))
                if len(body) != size - 8 or struct.unpack(endian + 'I', body[-4:])[0] != size:
                    raise ValueError('Truncated PCAPNG block body')
                body = body[:-4]
                if kind == 1:
                    linktype = struct.unpack_from(endian + 'H', body)[0]
                    options = dict(_options(body[8:], endian))
                    resolution = options.get(9, b'\x06')[0]
                    unit = 2 ** -(resolution & 127) if resolution & 128 else 10 ** -resolution
                    offset = struct.unpack(endian + 'q', options.get(14, b'\0' * 8))[0]
                    interfaces.append((linktype, unit, offset))
                elif kind == 6:
                    interface, hi, lo, captured, original = struct.unpack_from(endian + 'IIIII', body)
                    linktype, unit, offset = interfaces[interface]
                    packet = body[20:20 + captured]
                    if len(packet) != captured:
                        raise ValueError('Truncated PCAPNG packet')
                    yield ((hi << 32) | lo) * unit + offset, linktype, packet
        else:
            raise ValueError('Unsupported capture file')


class PcapWriter:
    def __init__(self, path, limit_bytes=64 * 1024 * 1024):
        self.stream = open(path, 'wb')
        self.stream.write(struct.pack('<IHHIIII', 0xa1b2c3d4, 2, 4, 0, 0, 262144, 127))
        self.stream.flush()
        self.limit, self.size, self.full = limit_bytes, 24, False

    def write(self, timestamp, packet):
        if self.size + len(packet) + 16 > self.limit:
            self.full = True
            return
        sec = int(timestamp)
        self.stream.write(struct.pack('<IIII', sec, int((timestamp - sec) * 1e6), len(packet), len(packet)))
        self.stream.write(packet)
        self.stream.flush()
        self.size += len(packet) + 16

    def close(self):
        self.stream.close()
