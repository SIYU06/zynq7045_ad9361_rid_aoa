'use strict';
const $ = id => document.getElementById(id);
const names = {0:'基本身份',1:'位置',2:'认证数据（未验证）',3:'自我描述',4:'系统信息',5:'运营者身份'};
let selected = null, state = null, signature = '';
function el(tag, text, cls) { const e=document.createElement(tag); if(text!==undefined)e.textContent=text; if(cls)e.className=cls; return e; }
function fmt(n, digits=1) { return typeof n==='number' && Number.isFinite(n) ? n.toFixed(digits) : '—'; }
function latest(t,type) { return Object.values(t.messages).filter(m=>m.type===type && !m.warning).sort((a,b)=>b.received_at-a.received_at)[0] || {}; }
function age(ts) { return Math.max(0,Math.floor(state.now-ts)); }
function renderTargets() {
  const query=$('search').value.toLowerCase();
  const targets=state.targets.filter(t=>(t.mac+' '+Object.values(t.messages).map(m=>m.uas_id||'').join(' ')).toLowerCase().includes(query));
  $('targets').replaceChildren();
  for(const t of targets) {
    const button=el('button',undefined,'target'+(selected===t.mac?' selected':''));
    button.type='button'; button.setAttribute('aria-pressed',String(selected===t.mac));
    button.append(el('strong',latest(t,0).uas_id||'尚未收到基本身份'));
    button.append(el('small',t.mac+' · '+t.transport));
    button.append(el('small',(age(t.last_seen)<=15?'● 活跃':'○ 已过期')+' · '+age(t.last_seen)+' 秒前 · '+t.packets+' 包',age(t.last_seen)<=15?'dot':'stale'));
    button.onclick=()=>{selected=t.mac;signature='';renderTargets();renderDetail();};
    $('targets').append(button);
  }
  if(!targets.length) $('targets').append(el('p',state.targets.length?'没有匹配的目标':'尚未接收到 RID 广播','empty'));
}
function renderDetail() {
  const t=state.targets.find(t=>t.mac===selected);
  if(!t){$('detail').className='empty';$('detail').textContent='等待接收 RID 数据';$('freshness').textContent='尚未选择';return;}
  $('freshness').textContent=age(t.last_seen)+' 秒前收到 / '+(age(t.last_seen)<=15?'活跃':'已过期');
  const sig=JSON.stringify(t);
  if(signature===sig)return;
  signature=sig;
  const basic=latest(t,0),loc=latest(t,1),sys=latest(t,4),op=latest(t,5);
  const root=$('detail');
  const opened=new Set(Array.from(root.querySelectorAll('details[open]')).map(d=>d.dataset.key));
  root.className='detail-content';root.replaceChildren();
  const title=el('div',undefined,'identity');title.append(el('h3',basic.uas_id||'未知身份发射源'),el('p',t.mac+' · '+t.transport+' · '+(t.rssi==null?'信号强度未知':t.rssi+' dBm')));root.append(title);
  const fields=el('div',undefined,'fields');
  const list=[['纬度',fmt(loc.latitude,7),'°'],['经度',fmt(loc.longitude,7),'°'],['几何高度',fmt(loc.altitude_geo),'m（WGS84 椭球）'],['相对高度',fmt(loc.height),'m / '+(loc.height_reference==='ground'?'地面':'起飞点')],['水平速度',fmt(loc.speed_horizontal),'m/s'],['垂直速度',fmt(loc.speed_vertical),'m/s'],['航向',fmt(loc.direction),'° 真北'],['飞行状态',({0:'未声明',1:'地面',2:'空中',3:'紧急',4:'RID 故障'})[loc.status]||'—','广播声明'],['位置更新时间',loc.received_at?age(loc.received_at)+' 秒前':'—','位置字段可能早于最近广播'],['运营者纬度',fmt(sys.operator_latitude,7),'°'],['运营者经度',fmt(sys.operator_longitude,7),'°'],['运营者 ID',op.operator_id||'—','未认证']];
  for(const [label,value,unit]of list){const f=el('div',undefined,'field');f.append(el('span',label),el('b',value),el('small',unit));fields.append(f);}root.append(fields);
  for(const [key,m]of Object.entries(t.messages)){const d=el('details');d.dataset.key=key;d.open=opened.has(key);d.append(el('summary',(names[m.type]||'未知消息')+' · '+key+' · '+new Date(m.received_at*1000).toLocaleTimeString()),el('pre',JSON.stringify(m,null,2)));root.append(d);}
}
function render() {
  const demo=state.mode==='demo';$('mode').textContent=demo?'模拟演示':state.mode==='live'?'真实接收':'抓包回放';$('mode').className='badge'+(demo?' demo':'');
  $('notice').textContent=state.status;$('notice').className='notice'+(demo?' demo':state.status.includes('失败')?' error':'');
  $('active').textContent=state.targets.filter(t=>age(t.last_seen)<=15).length;
  for(const key of ['packets','frames','errors'])$(''+key).textContent=state[key].toLocaleString();
  $('total').textContent=state.targets.length+' 个';
  if(!state.targets.some(t=>t.mac===selected)){selected=state.targets[0]?.mac||null;signature='';}
  renderTargets();renderDetail();$('events').replaceChildren();
  for(const e of state.events.slice(0,30)){const row=el('tr');for(const val of [new Date(e.received_at*1000).toLocaleTimeString(),e.mac,e.transport,e.counter??'—',e.messages.map(m=>names[m.type]||m.type).join(' / ')])row.append(el('td',String(val)));$('events').append(row);}
}
async function poll(){try{const response=await fetch('/api/state',{signal:AbortSignal.timeout(4000)});if(!response.ok)throw Error(response.status);state=await response.json();render();}catch(e){$('notice').textContent='本地接收程序连接中断，请检查终端是否仍在运行。页面保留上次数据，当前活跃状态已失效。';$('notice').className='notice error';$('mode').textContent='已断开';$('active').textContent='—';}finally{setTimeout(poll,1000);}}
$('search').addEventListener('input',()=>{if(state)renderTargets();});poll();
