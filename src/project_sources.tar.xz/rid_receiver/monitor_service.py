"""Passive Linux monitor capture and read-only Ethernet RID feed; PCAP replay on PC."""
import argparse
import json
import socket
import signal
import subprocess
import threading
import time
import struct
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from capture_io import PcapWriter, monitor_frame, read_capture
from receiver import Store
from signal_inspector import SignalStore
from resource_monitor import ResourceMonitor
from dsss_mailbox import DSSSIngest


class Monitor:
    def __init__(self, args):
        self.args, self.stop = args, threading.Event()
        self.log = args.log.open('a', encoding='utf-8') if args.log else None
        self.store = Store('replay' if args.pcap else 'live', self.log)
        self.session = str(time.time_ns())
        self.stats = dict(raw_packets=0, bad_fcs=0, malformed=0, pcap_limit_reached=False)
        self.writer = None
        self.signals=SignalStore()
        self.resources=ResourceMonitor()
        self.condition=threading.Condition(threading.RLock())
        self.enabled=True if args.pcap else not getattr(args,'standby',False)
        self.role_path=None if args.pcap else getattr(args,'role_config',None)
        if self.role_path and self.role_path.exists():
            value=json.loads(self.role_path.read_text())
            if type(value.get('enabled')) is not bool:raise ValueError('Invalid persisted receiver role')
            self.enabled=value['enabled']
        self.generation=0;self.active_generation=-1;self.capture_active=False;self.role_error=None
        self.current_capture=args.capture
        channel=getattr(args,'dsss_channel',None)
        self.dsss=DSSSIngest(self,getattr(args,'dsss_dt_node',None),2407+5*channel if channel else None)

    def ingest_dsss(self,timestamp,frame,metadata):
        """Internal hardware-mailbox input; no remote frame injection endpoint."""
        with self.condition:
            if not self.enabled or self.args.pcap:return
            if metadata.get('fcs_valid') is not True or metadata.get('phy_type')!='dsss_long_1m':
                raise ValueError('DSSS requires a committed hardware-verified frame')
            self.stats['raw_packets']+=1
            self.stats['dsss_packets']=self.stats.get('dsss_packets',0)+1
            if self.writer:
                # FCS stripped by hardware. Preserve that fact in PCAP: no
                # fabricated checksum trailer and no OpenWiFi status trailer.
                packet=struct.pack('<BBHIBBHH',0,0,14,0x0e,0,2,int(metadata['frequency_mhz']),0xa0)+frame
                self.writer.write(timestamp,packet)
                self.stats['pcap_limit_reached']=self.writer.full
            try:
                self.signals.frame(timestamp,frame,metadata)
                self.store.frame(frame,capture_time=timestamp,**metadata)
            except (ValueError,IndexError):self.stats['malformed']+=1

    def role_snapshot(self):
        with self.condition:
            active=self.capture_active and self.active_generation==self.generation
            return dict(enabled=self.enabled,captureActive=active,
                ready=(active if self.enabled else not self.capture_active and not self.dsss.snapshot().get('captureActive',False)) and not self.role_error,
                role='capture_decode' if self.enabled else 'direction_only',generation=self.generation,
                sessionId=self.session,error=self.role_error)

    def set_enabled(self,enabled,timeout=2):
        if type(enabled) is not bool:raise ValueError('enabled must be boolean')
        if self.args.pcap:raise ValueError('Replay cannot control hardware reception')
        with self.condition:
            if self.role_path:
                self.role_path.parent.mkdir(parents=True,exist_ok=True)
                temporary=self.role_path.with_suffix('.tmp')
                temporary.write_text(json.dumps(dict(enabled=enabled))+'\n')
                temporary.replace(self.role_path)
            if enabled!=self.enabled:
                self.enabled=enabled;self.generation+=1;self.role_error=None
                self.session=str(time.time_ns())
                self.store=Store('live',self.log);self.signals=SignalStore()
                self.stats=dict(raw_packets=0,bad_fcs=0,malformed=0,pcap_limit_reached=False)
            self.condition.notify_all()
            deadline=time.monotonic()+timeout
            while not self.role_snapshot()['ready'] and not self.role_error and time.monotonic()<deadline:
                self.condition.wait(min(.1,max(0,deadline-time.monotonic())))
            return self.role_snapshot()

    def packet(self, timestamp, linktype, packet):
        with self.condition:
            if not self.enabled:return
            self._packet(timestamp,linktype,packet)

    def _packet(self,timestamp,linktype,packet):
        self.stats['raw_packets'] += 1
        if self.writer:
            self.writer.write(timestamp, packet)
            self.stats['pcap_limit_reached'] = self.writer.full
        try:
            frame, metadata = monitor_frame(packet, linktype, openwifi_fcs=not self.args.pcap or getattr(self.args, 'openwifi_fcs', False))
            self.signals.frame(timestamp,frame,metadata)
            if metadata['fcs_valid'] is False:
                self.stats['bad_fcs'] += 1
                return
            self.store.frame(frame, capture_time=timestamp, **metadata)
        except (ValueError, IndexError):
            self.stats['malformed'] += 1

    def run(self):
        try:
            if self.args.pcap:
                self.store.status = '正在回放参考抓包，非实时空口'
                for timestamp, linktype, packet in read_capture(self.args.pcap):
                    if self.stop.is_set():
                        break
                    self.packet(timestamp, linktype, packet)
                self.store.status = '回放结束，保留参考数据'
                return
            check = subprocess.run(['iw', 'dev', self.args.interface, 'info'], capture_output=True, text=True, check=True)
            if 'type monitor' not in check.stdout:
                raise RuntimeError('Interface is not in monitor mode')
            while not self.stop.is_set():
                with self.condition:
                    if not self.enabled:
                        self.store.status='仅测向待命／完整信源解码已关闭'
                        self.condition.wait(.25);continue
                    generation=self.generation
                try:
                    with socket.socket(socket.AF_PACKET,socket.SOCK_RAW,socket.htons(3)) as capture:
                        capture.bind((self.args.interface,0));capture.settimeout(.2)
                        with self.condition:
                            if not self.enabled or generation!=self.generation:continue
                            if self.args.capture:
                                self.current_capture=self.args.capture if generation==0 else self.args.capture.with_name(self.args.capture.stem+'.role-'+self.session+self.args.capture.suffix)
                                self.writer=PcapWriter(self.current_capture)
                            self.capture_active=True;self.active_generation=generation;self.role_error=None
                            self.store.status='monitor被动接收中';self.condition.notify_all()
                        while not self.stop.is_set():
                            with self.condition:
                                if not self.enabled or generation!=self.generation:break
                            try:packet,address=capture.recvfrom(262144)
                            except socket.timeout:continue
                            if address[2]==4:continue
                            with self.condition:
                                if self.enabled and generation==self.generation:self.packet(time.time(),127,packet)
                finally:
                    with self.condition:
                        if self.writer:self.writer.close();self.writer=None
                        self.capture_active=False;self.condition.notify_all()
        except Exception as exc:
            self.store.status = '接收失败：' + str(exc)
            with self.condition:self.role_error=str(exc);self.condition.notify_all()
            print(self.store.status, flush=True)
        finally:
            if self.writer:
                self.writer.close()

    def snapshot(self):
        with self.condition:
            value = self.store.snapshot()
            value.update(session_id=self.session, source='pcap_replay' if self.args.pcap else 'fpga_ofdm_dsss' if self.dsss.snapshot()['available'] else 'openwifi_ofdm',
                     interface=self.args.interface, capture=dict(self.stats),
                     capture_path=str(self.current_capture) if self.current_capture else None,receiverRole=self.role_snapshot(),
                     phyCapabilities=dict(ofdm=True,dsss=self.dsss.snapshot()))
        return value


def handler(monitor):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path=='/api/receiver/status':
                self.reply(monitor.role_snapshot());return
            if self.path=='/api/resources':
                body=json.dumps(monitor.resources.snapshot(),ensure_ascii=False).encode('utf-8')
                self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8')
                self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)))
                self.end_headers();self.wfile.write(body);return
            if self.path in ('/api/state','/api/signals'):
                with monitor.condition:
                    value=monitor.snapshot() if self.path=='/api/state' else dict(monitor.signals.snapshot(),session_id=monitor.session,mode='replay' if monitor.args.pcap else 'live' if monitor.enabled else 'standby',receiverRole=monitor.role_snapshot(),phyCapabilities=dict(ofdm=True,dsss=monitor.dsss.snapshot()))
                body = json.dumps(value, ensure_ascii=False).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(body)
            elif self.path == '/capture.pcap':
                with monitor.condition:
                    path=monitor.current_capture
                    if not path or not path.exists():self.send_error(404);return
                    stream=path.open('rb')
                    remaining=monitor.writer.size if monitor.writer else path.stat().st_size
                with stream:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.tcpdump.pcap')
                    self.send_header('Content-Length', str(remaining))
                    self.end_headers()
                    while remaining:
                        chunk = stream.read(min(65536, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
            else:
                self.send_error(404)

        def log_message(self, *_):
            pass

        def reply(self,value,status=200):
            body=json.dumps(value,ensure_ascii=False).encode('utf-8')
            self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)))
            self.end_headers();self.wfile.write(body)

        def do_POST(self):
            if self.path!='/api/receiver/control':self.send_error(404);return
            if self.headers.get('Origin'):self.send_error(403);return
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=256:raise ValueError('Invalid control size')
                value=json.loads(self.rfile.read(size))
                if not isinstance(value,dict) or set(value)!={'enabled'}:raise ValueError('Expected enabled only')
                result=monitor.set_enabled(value['enabled'])
                self.reply(result,200 if result['ready'] else 503)
            except (ValueError,TypeError,OSError) as exc:self.reply(dict(error=str(exc)),400)
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--interface', default='sdr0')
    parser.add_argument('--pcap', type=Path)
    parser.add_argument('--openwifi-fcs', action='store_true', help='PCAP contains OpenWiFi rx_intf FCS/status trailer')
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--log', type=Path)
    parser.add_argument('--listen', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=18771)
    parser.add_argument('--standby',action='store_true',help='Serve resources/control without all-frame decode')
    parser.add_argument('--role-config',type=Path,default=Path(__file__).with_name('receiver_role.json'),help='Persist receiver role across service restarts')
    parser.add_argument('--dsss-dt-node',type=Path,help='Matching loaded FPGA and DT required; absent disables DSSS MMIO')
    parser.add_argument('--dsss-channel',type=int,choices=range(1,14),help='Initial DSSS channel; live ingest follows verified 2.4 GHz RF readback')
    args = parser.parse_args()
    if bool(args.dsss_dt_node)!=bool(args.dsss_channel) or args.pcap and args.dsss_dt_node:
        parser.error('DSSS requires both matching DT node and a fixed channel, in live mode')
    for path in (args.capture, args.log):
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)
    monitor = Monitor(args)
    server = ThreadingHTTPServer((args.listen, args.port), handler(monitor))
    server.timeout=.3
    signal.signal(signal.SIGTERM,lambda *_:monitor.stop.set())
    thread = threading.Thread(target=monitor.run, daemon=True)
    thread.start()
    dsss_thread=threading.Thread(target=monitor.dsss.run,daemon=True)
    dsss_thread.start()
    print('RID feed: http://%s:%d/api/state' % (args.listen, args.port), flush=True)
    try:
        while not monitor.stop.is_set():server.handle_request()
    except KeyboardInterrupt:
        pass
    finally:
        monitor.stop.set()
        thread.join(timeout=3)
        dsss_thread.join(timeout=3)
        server.server_close()
        if monitor.log:
            monitor.log.close()


if __name__ == '__main__':
    main()
