"""Local RID receiver for monitor capture and PCAP import."""
import argparse
import copy
import json
import platform
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from decoder import decode_payload, extract_frame

ROOT = Path(__file__).resolve().parent


class Store:
    def __init__(self, mode, log=None):
        self.lock = threading.Lock()
        self.mode, self.log = mode, log
        self.targets = {}
        self.events = deque(maxlen=200)
        self.frames = self.packets = self.errors = 0
        self.status = 'starting'

    def accept(self, event):
        messages = decode_payload(event['payload'])
        now = time.time()
        monotonic = time.monotonic()
        record = {k: v for k, v in event.items() if k != 'payload'}
        record.update(received_at=now, mode=self.mode, payload_hex=event['payload'].hex(), messages=messages)
        with self.lock:
            if event['mac'] not in self.targets and len(self.targets) >= 1000:
                oldest = min(self.targets, key=lambda k: self.targets[k]['last_seen'])
                del self.targets[oldest]
            target = self.targets.setdefault(event['mac'], dict(mac=event['mac'], first_seen=now, packets=0, messages={}))
            target.update(last_seen=now, last_seen_monotonic=monotonic, transport=event['transport'],
                          rssi=event.get('rssi'), counter=event.get('counter'))
            for key in ('frequency_mhz', 'rate_mbps', 'fcs_valid', 'fcs_method', 'capture_time'):
                if key in event:
                    target[key] = event[key]
            target['packets'] += 1
            for message in messages:
                kind = message['type']
                suffix = message.get('id_type') if kind == 0 else message.get('page') if kind == 2 else None
                key = str(kind) if suffix is None else f'{kind}:{suffix}'
                target['messages'][key] = dict(message, received_at=now, received_monotonic=monotonic)
            self.packets += 1
            self.events.appendleft(record)
            if self.log:
                self.log.write(json.dumps(record, ensure_ascii=False) + '\n')
                self.log.flush()

    def frame(self, frame, rssi=None, **metadata):
        with self.lock:
            self.frames += 1
        for event in extract_frame(frame):
            try:
                self.accept(dict(event, rssi=rssi, **metadata))
            except ValueError:
                with self.lock:
                    self.errors += 1

    def snapshot(self):
        with self.lock:
            return copy.deepcopy(dict(mode=self.mode, status=self.status, now=time.time(), monotonic=time.monotonic(),
                                      frames=self.frames, packets=self.packets, errors=self.errors,
                                      targets=list(self.targets.values()), events=list(self.events)))



def capture(stop, store, interface):
    try:
        from scapy.all import Dot11, RadioTap, conf, sniff
        if interface not in conf.ifaces:
            raise RuntimeError(f'找不到网卡接口 {interface}；请先运行 iw dev')
        # Refuse Ethernet/managed interfaces instead of silently claiming to capture RID.
        import subprocess
        result = subprocess.run(['iw', 'dev', interface, 'info'], capture_output=True, text=True, check=True)
        if 'type monitor' not in result.stdout:
            raise RuntimeError('接口不是 monitor 模式，请按 README 配置后重试')
        store.status = f'正在监听 {interface}；只接收当前信道'

        def packet(p):
            if p.haslayer(Dot11):
                if p.haslayer(RadioTap) and getattr(p[RadioTap], 'Flags', 0) is not None:
                    if int(p[RadioTap].Flags or 0) & 0x40:  # bad FCS
                        return
                store.frame(bytes(p[Dot11]), getattr(p, 'dBm_AntSignal', None))

        while not stop.is_set():
            sniff(iface=interface, prn=packet, store=False, timeout=1)
    except Exception as exc:
        store.status = f'接收失败：{exc}'
        print(store.status, flush=True)


def replay(stop, store, path):
    try:
        from scapy.all import Dot11, PcapReader
        store.status = '正在回放抓包文件'
        with PcapReader(str(path)) as packets:
            for p in packets:
                if stop.is_set():
                    return
                if p.haslayer(Dot11):
                    store.frame(bytes(p[Dot11]), getattr(p, 'dBm_AntSignal', None))
        store.status = '回放结束；页面保留结果（时间为本次导入时间）'
    except Exception as exc:
        store.status = f'回放失败：{exc}'


def handler_for(store):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            route = urlparse(self.path).path
            extra = {}
            if route in ('/api/state', '/api/export'):
                body = json.dumps(store.snapshot(), ensure_ascii=False).encode()
                kind = 'application/json; charset=utf-8'
                if route == '/api/export':
                    extra['Content-Disposition'] = 'attachment; filename="rid-export.json"'
            elif route in ('/', '/index.html', '/app.js', '/style.css'):
                file = 'index.html' if route == '/' else route[1:]
                body = (ROOT / 'web' / file).read_bytes()
                kind = {'html': 'text/html', 'js': 'text/javascript', 'css': 'text/css'}[file.rsplit('.', 1)[1]] + '; charset=utf-8'
            else:
                self.send_error(404)
                return
            self.send_response(200)
            for k, v in dict(extra, **{'Content-Type': kind, 'Content-Length': str(len(body)), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *_):
            pass
    return Handler


def main():
    parser = argparse.ArgumentParser(description='Independent local Wi-Fi RID receiver')
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--interface', help='Linux monitor interface, e.g. wlp0s20f3')
    modes.add_argument('--pcap', type=Path, help='replay a pcap/pcapng file (requires scapy)')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--log', type=Path, help='append every decoded RID packet as JSONL; use a disk path')
    args = parser.parse_args()
    if args.interface and platform.system() != 'Linux':
        parser.error('Live capture requires Linux and a monitor-mode Wi-Fi interface')
    if args.pcap and not args.pcap.is_file():
        parser.error('pcap file does not exist')
    log = None
    if args.log:
        args.log.parent.mkdir(parents=True, exist_ok=True)
        log = args.log.open('a', encoding='utf-8')
    mode = 'replay' if args.pcap else 'live'
    store, stop = Store(mode, log), threading.Event()
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), handler_for(store))
        worker = threading.Thread(target=replay if args.pcap else capture,
                                  args=(stop, store, args.pcap or args.interface), daemon=True)
        worker.start()
        print(f'RID {mode}: http://127.0.0.1:{args.port}  (Ctrl+C to stop)', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            stop.set()
            server.server_close()
            worker.join(timeout=3)
    finally:
        if log:
            log.close()


if __name__ == '__main__':
    main()
