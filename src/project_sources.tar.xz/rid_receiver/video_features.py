"""Visible media-transport structure only; not drone attribution or decryption."""
import struct

def jpeg_header_hint(data):
    """SOI plus a bounded, complete SOF segment; never claim image decoding."""
    if not data.startswith(b'\xff\xd8'):return None
    cursor=2
    while cursor+4<=len(data) and data[cursor]==255:
        marker=data[cursor+1];length=struct.unpack_from('!H',data,cursor+2)[0]
        if length<2 or cursor+2+length>len(data):return None
        if marker in (0xc0,0xc1,0xc2) and length>=8:
            height,width=struct.unpack_from('!HH',data,cursor+5)
            return dict(codec='JPEG (SOI/SOF header)',width=width,height=height) if 0<height<=8192 and 0<width<=8192 else None
        cursor+=2+length
    return None

def lab_fragment_hint(payload,source_port,destination_port,role,source_ip=None,destination_ip=None):
    """Empirical layout from the 2026-11-02 drone-power-off experiment.

    This is a repeatable protocol pattern, not a MAC allowlist or model ID.
    A current on/off comparison is still required for drone attribution.
    """
    # The receiver negotiates a different UDP destination port on reconnect.
    # Keep the measured sender port and fragment structure; never pin its MAC
    # or a single run's ephemeral receiver port.
    if source_port!=50050 or not isinstance(destination_port,int) or not 1024<=destination_port<=65535 or role!='AP-direction' or len(payload)<64:return None
    if payload[5:8]!=bytes(3) or payload[8:12]!=b'\x65\0\0\0' or payload[12:40]!=bytes(28):return None
    if not 1<=payload[3]<=127 or payload[2]>=payload[3]:return None
    result=dict(transport='Lab UDP fragments',codec='unconfirmed',profile='lab_fragment_20261102',
        stream='%s:%s>%s:%s'%(source_ip,source_port,destination_ip,destination_port),
        sequence=struct.unpack_from('<H',payload)[0],fragmentIndex=payload[2],fragmentCountHint=payload[3])
    image=jpeg_header_hint(payload[40:]) if payload[2]==0 else None
    if image:result.update(image)
    return result

def udp_video_hint(payload):
    if len(payload)>=376 and len(payload)%188==0 and all(payload[i]==0x47 for i in range(0,len(payload),188)):
        return dict(transport='MPEG-TS/UDP',codec='MPEG-TS',stream=None,sequence=None)
    if len(payload)<13 or payload[0]>>6!=2:return None
    count=payload[0]&15;offset=12+4*count
    if len(payload)<offset:return None
    if payload[0]&0x10:
        if len(payload)<offset+4:return None
        offset+=4+4*struct.unpack_from('!H',payload,offset+2)[0]
    end=len(payload)
    if payload[0]&0x20:
        padding=payload[-1]
        if not padding or padding>end-offset:return None
        end-=padding
    if offset>=end:return None
    kind=payload[1]&127;nal=payload[offset]&31
    if kind==26:codec='JPEG'
    elif 96<=kind<=127 and not payload[offset]&0x80 and nal in (1,5,7,8,24,28):codec='H264-like (dynamic payload; SDP unverified)'
    elif kind in (31,32,33,34):codec='static video payload %d'%kind
    else:return None
    return dict(transport='RTP',codec=codec,stream=struct.unpack_from('!I',payload,8)[0],sequence=struct.unpack_from('!H',payload,2)[0])
