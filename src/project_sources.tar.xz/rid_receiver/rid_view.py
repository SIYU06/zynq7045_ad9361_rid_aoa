"""Board-local formatting of already decoded RID messages for display."""
def map_snapshot(snapshot, pc_received_ms):
    sampled = snapshot['monotonic']
    replay = snapshot['mode'] == 'replay'
    targets = []
    for target in snapshot.get('targets', []):
        messages = list(target.get('messages', {}).values())
        basics = [m for m in messages if m['type'] == 0 and m.get('uas_id')]
        basic = max(basics, key=lambda m: m['received_monotonic'], default={})
        location = next((m for m in messages if m['type'] == 1), {})
        system = next((m for m in messages if m['type'] == 4), {})
        age = max(0, sampled - target['last_seen_monotonic'])
        location_age = sampled - location.get('received_monotonic', -1e20)
        # Do not let fresh identity-only packets extend the life of old positions.
        fresh_location = replay or location_age <= 15
        source = '参考PCAP回放' if replay else '空口接收 / ' + snapshot.get('interface', 'sdr0')
        if fresh_location:
            position = {name: location.get(key) for name, key in
                        [('latitude', 'latitude'), ('longitude', 'longitude'), ('altitude', 'altitude_geo'),
                         ('speed', 'speed_horizontal'), ('heading', 'direction')]}
        else:
            position = dict.fromkeys(('latitude', 'longitude', 'altitude', 'speed', 'heading'))
        if not location:
            position_status = '等待Location消息'
        elif not fresh_location:
            position_status = '位置消息已过期'
        elif position['latitude'] is None or position['longitude'] is None:
            position_status = 'Location未提供有效当前位置'
        else:
            position_status = 'RID广播当前位置'
        system_fresh = replay or sampled - system.get('received_monotonic', -1e20) <= 15
        reference = dict(type=system.get('operator_location_type'),
                         latitude=system.get('operator_latitude'), longitude=system.get('operator_longitude')) if system_fresh else None
        targets.append(dict(position, id=basic.get('uas_id') or target['mac'],
                            type={1: '固定翼', 2: '多旋翼/直升机'}.get(basic.get('ua_type'), '类型未知'),
                            status={1: '地面', 2: '空中', 3: '紧急', 4: 'RID故障'}.get(location.get('status'), '状态未知'),
                            source=source, demo=False, replay=replay, timestamp=pc_received_ms - age * 1000,
                            timestampBasis='PC接收时间减板端单调时钟数据年龄',
                            sourceMac=target['mac'], rssi=target.get('rssi'), packets=target['packets'],
                            positionStatus=position_status, referencePosition=reference,
                            frequencyMhz=target.get('frequency_mhz'), rateMbps=target.get('rate_mbps'),
                            fcsValid=target.get('fcs_valid'), fcsMethod=target.get('fcs_method'), captureTime=target.get('capture_time'),
                            positionTimestamp=pc_received_ms - location_age * 1000 if location else None,
                            observationId='%s:%s:%s:%s' % (snapshot['session_id'], target['mac'], target['last_seen_monotonic'], fresh_location)))
    return dict(targets=targets, mode=snapshot['mode'], source=snapshot.get('source'),
                status=snapshot['status'], frames=snapshot['frames'], packets=snapshot['packets'],
                errors=snapshot['errors'], capture=snapshot.get('capture', {}), sessionId=snapshot['session_id'])

