"""Read-only Linux CPU/memory resource counters. No fabricated utilization."""
from pathlib import Path
import threading
import time

def cpu_counters(text):
    values=[int(v) for v in text.splitlines()[0].split()[1:9]]
    return sum(values),values[3]+(values[4] if len(values)>4 else 0)

def memory_usage(text):
    fields={line.split(':',1)[0]:int(line.split()[1]) for line in text.splitlines() if len(line.split())>=2}
    total,available=fields.get('MemTotal'),fields.get('MemAvailable')
    if not total or available is None:return dict(percent=None)
    return dict(percent=100*(total-available)/total,totalBytes=total*1024,availableBytes=available*1024)

class ResourceMonitor:
    def __init__(self,proc=Path('/proc')):
        self.proc=proc;self.lock=threading.Lock();self.previous=None;self.cached=None;self.sampled=0
    def snapshot(self):
        with self.lock:
            now=time.monotonic()
            if self.cached and now-self.sampled<1:return dict(self.cached)
            try:
                total,idle=cpu_counters((self.proc/'stat').read_text())
                percent=None;interval=None
                if self.previous:
                    previous_total,previous_idle,previous_time=self.previous
                    delta=total-previous_total;interval=now-previous_time
                    if delta>0:percent=max(0,min(100,100*(delta-(idle-previous_idle))/delta))
                self.previous=(total,idle,now)
                value=dict(available=True,cpuPercent=percent,sampleIntervalSeconds=interval,
                    memory=memory_usage((self.proc/'meminfo').read_text()),
                    loadAverage=[float(v) for v in (self.proc/'loadavg').read_text().split()[:3]],
                    uptimeSeconds=float((self.proc/'uptime').read_text().split()[0]),
                    monotonic=now,source='Linux /proc; aggregate CPU busy incl iowait',cpuCount=sum(line.startswith('cpu') and len(line)>3 and line[3].isdigit() for line in (self.proc/'stat').read_text().splitlines()))
                value['source']='Linux /proc; aggregate CPU busy, idle and iowait excluded'
            except (OSError,ValueError,IndexError) as exc:value=dict(available=False,error=str(exc),monotonic=now)
            self.sampled=now;self.cached=value
            return dict(value)
