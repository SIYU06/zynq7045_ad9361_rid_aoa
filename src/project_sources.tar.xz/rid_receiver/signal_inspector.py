"""Bounded passive 802.11 frame inspection; unknown/protected payloads stay unknown."""
from collections import deque
import copy
import threading
import time
import struct
import hashlib
from wifi_candidates import CandidateStore,parse_wifi_frame,mac
from decoder import extract_frame,decode_payload
from rid_features import recognize_rid
from video_features import udp_video_hint,lab_fragment_hint

MANAGEMENT={0:'Association Request',1:'Association Response',4:'Probe Request',5:'Probe Response',8:'Beacon',10:'Disassociation',11:'Authentication',12:'Deauthentication',13:'Action'}
CONTROL={8:'Block Ack Request',9:'Block Ack',10:'PS-Poll',11:'RTS',12:'CTS',13:'ACK',14:'CF-End',15:'CF-End+ACK'}

def inspect_frame(frame,metadata):
    if len(frame)<2:raise ValueError('short frame')
    fc=struct.unpack_from('<H',frame)[0];kind=(fc>>2)&3;subtype=(fc>>4)&15
    row=dict(length=len(frame),frame_type=kind,subtype=subtype,
             frame_name=MANAGEMENT.get(subtype,'Management') if kind==0 else CONTROL.get(subtype,'Control') if kind==1 else 'QoS Data' if subtype&8 else 'Data',
             protocol='802.11',source_mac=None,destination_mac=None,bssid=None,ssid=None,
             sequence=None,retry=bool(fc&0x800),protected=bool(fc&0x4000),
             frequency_mhz=metadata.get('frequency_mhz'),rssi=metadata.get('rssi'),rate_mbps=metadata.get('rate_mbps'),ht_mcs=metadata.get('ht_mcs'),
             fcs_valid=metadata.get('fcs_valid'),fcs_method=metadata.get('fcs_method'),
             phy_type=metadata.get('phy_type','ofdm' if metadata.get('ht_mcs') or (metadata.get('rate_mbps') or 0)>=6 else 'unknown'),
             doa_association=metadata.get('doaAssociation'),decoded={},
             frame_hex=frame[:256].hex(),hex_truncated=len(frame)>256,frame_sha256=hashlib.sha256(frame).hexdigest())
    if metadata.get('fcs_valid') is not True:
        row['protocol']='FCS错误' if metadata.get('fcs_valid') is False else '校验未知';return row
    parsed=parse_wifi_frame(frame)
    if len(frame)>=10:row['destination_mac']=mac(frame[4:10])
    if parsed:
        row.update(source_mac=parsed['transmitter'],bssid=parsed['bssid'],ssid=parsed['ssid'])
        row['decoded'].update(role=parsed['role'],ht_advertised=parsed['ht_advertised'],vht_advertised=parsed['vht_advertised'],advertised_channel=parsed['advertised_channel'])
    if kind in (0,2) and len(frame)>=24:row['sequence']=struct.unpack_from('<H',frame,22)[0]>>4
    if row['protected']:row['protocol']='802.11 Protected';return row
    if kind==2 and not subtype&4:
        offset=24+(6 if fc&0x300==0x300 else 0)
        if subtype&8:
            if len(frame)<offset+2:return row
            if frame[offset]&0x80:row['protocol']='802.11 A-MSDU';return row
            offset+=2
            if fc&0x8000:offset+=4
        payload=frame[offset:]
        if len(payload)>=8 and payload[:6]==bytes.fromhex('aaaa03000000'):
            ether=struct.unpack_from('!H',payload,6)[0];row['decoded']['ethertype']='0x%04x'%ether
            if ether==0x0800:
                ip=payload[8:]
                if len(ip)>=20 and ip[0]>>4==4:
                    ihl=(ip[0]&15)*4
                    if ihl>=20 and len(ip)>=ihl:
                        row['protocol']='IPv4';d=row['decoded'];d.update(ip_source='.'.join(map(str,ip[12:16])),ip_destination='.'.join(map(str,ip[16:20])),ip_protocol=ip[9])
                        if ip[9] in (6,17) and not struct.unpack_from('!H',ip,6)[0]&0x1fff and len(ip)>=ihl+(8 if ip[9]==17 else 20):
                            row['protocol']='UDP' if ip[9]==17 else 'TCP';d['source_port'],d['destination_port']=struct.unpack_from('!HH',ip,ihl)
                            if ip[9]==17:
                                udp_length=struct.unpack_from('!H',ip,ihl+4)[0]
                                ip_length=struct.unpack_from('!H',ip,2)[0]
                                if 8<udp_length<=len(ip)-ihl and ihl+udp_length<=ip_length and not struct.unpack_from('!H',ip,6)[0]&0x3fff:
                                    hint=udp_video_hint(ip[ihl+8:ihl+udp_length])
                                    if not hint:hint=lab_fragment_hint(ip[ihl+8:ihl+udp_length],d['source_port'],d['destination_port'],d.get('role'),d.get('ip_source'),d.get('ip_destination'))
                                    if hint:d['video_hint']=hint
            elif ether==0x0806:row['protocol']='ARP'
            elif ether==0x86dd:row['protocol']='IPv6'
    recognition=recognize_rid(frame,metadata.get('fcs_valid'))
    if recognition['status']!='none':
        row['rid_recognition']=recognition
        if recognition['status']=='confirmed':row['protocol']='RID';row['decoded']['rid_messages']=recognition['messages']
    return row

class SignalStore:
    def __init__(self,packet_limit=400):
        self.lock=threading.Lock();self.packets=deque(maxlen=packet_limit);self.sources=CandidateStore(evict_oldest=True);self.total=0;self.malformed=0;self.bad_fcs=0;self.rid_sources={}
    def frame(self,timestamp,frame,metadata):
        with self.lock:
            self.total+=1
            if metadata.get('fcs_valid') is False:self.bad_fcs+=1
            try:
                row=inspect_frame(frame,metadata);row.update(id=self.total,capture_time=timestamp,received_monotonic=time.monotonic());self.packets.append(row)
                self.sources.frame(frame,metadata)
                if row.get('rid_recognition') and row.get('source_mac'):
                    key=(row['frequency_mhz'],row['source_mac'])
                    if key not in self.rid_sources and len(self.rid_sources)>=256:
                        del self.rid_sources[min(self.rid_sources,key=lambda k:self.rid_sources[k]['last_monotonic'])]
                    if key in self.sources.rows:
                        self.rid_sources[key]=dict(row['rid_recognition'],last_monotonic=row['received_monotonic'])
            except (ValueError,IndexError,struct.error):self.malformed+=1
    def snapshot(self):
        with self.lock:
            sources=self.sources.snapshot()
            for source in sources:
                rid=self.rid_sources.get((source['frequency_mhz'],source['mac']))
                if rid:source['rid_recognition']=copy.deepcopy(rid)
            return dict(monotonic=time.monotonic(),packets=copy.deepcopy(list(self.packets)),sources=sources,
                        total=self.total,bad_fcs=self.bad_fcs,malformed=self.malformed,packet_limit=self.packets.maxlen,source_overflow=self.sources.overflow)
