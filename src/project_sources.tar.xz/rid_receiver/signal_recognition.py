"""Evidence-based signal recognition, shared with board-local mission processing."""
import math
import re

def source_key(mac,frequency):return '%s@%s'%(mac.lower(),round(float(frequency),3))

def positioning_route(recognition):
    """Fresh RID coordinates bypass IQ; lack of identity alone proves nothing."""
    if recognition['kind']=='rid' and recognition.get('identities'):
        for message in recognition.get('messages',[]):
            lat,lon=message.get('latitude'),message.get('longitude')
            if message.get('type')==1 and all(type(v) in (int,float) and math.isfinite(v) for v in (lat,lon)) and abs(lat)<=90 and abs(lon)<=180:
                return dict(method='rid',label='RID广播位置直显',position=dict(latitude=lat,longitude=lon),reason='已解析RID身份与有效经纬度，无需AOA排队')
    if recognition.get('eligible'):
        return dict(method='aoa',label='AOA测向',position=None,reason='RID位置缺失，等待同源IQ' if recognition['kind']=='rid' else '疑似无人机信源，无RID位置；归属待核验')
    return dict(method='observe',label='继续识别',position=None,reason='尚无足够无人机识别依据；无RID不等于黑飞')

def signal_features(sources,packets):
    types={p.get('phy_type') for p in packets}
    types.update(name for source in sources for name in source.get('phy_types',{}))
    phy=[]
    if any(t and t.startswith('dsss') for t in types):phy.append('DSSS')
    if any(t and ('ofdm' in t or t.startswith('ht')) for t in types) or any(p.get('ht_mcs') is not None for p in packets):phy.append('OFDM')
    protocols=['802.11']
    if any(p.get('ht_mcs') is not None for p in packets):protocols.append('802.11n / HT')
    return dict(phy=phy or ['PHY待确认'],protocols=protocols,payloadProtocols=sorted({p['protocol'] for p in packets if p.get('protocol')}))

def classify_source(sources,packets):
    """Sources are per-station counters; packets are recent FCS-valid rows."""
    evidence=[];ids=set();messages={};transports=set();candidate=False;rid=False
    for source in sources:
        recognition=source.get('rid_recognition',{})
        rid_age=source.get('age_seconds',0)+max(0,source.get('last_monotonic',0)-recognition.get('last_monotonic',0))
        if recognition.get('status') not in ('candidate','confirmed') or rid_age>15:continue
        candidate=True;transports.add(recognition.get('transport','未知'))
        evidence.extend(recognition.get('evidence',[]))
        if recognition.get('status')=='confirmed':
            rid=True;ids.update(recognition.get('identities',[]))
            for m in recognition.get('messages',[]):messages[(m['type'],m.get('id_type'),m.get('page'))]=m
    # Packet evidence also works for imported/older board feed schemas.
    for packet in packets:
        recognition=packet.get('rid_recognition',{})
        if recognition.get('status')=='confirmed':
            rid=True;candidate=True;ids.update(recognition.get('identities',[]));transports.add(recognition.get('transport','未知'))
            evidence.extend(recognition.get('evidence',[]))
            for m in recognition.get('messages',[]):messages[(m['type'],m.get('id_type'),m.get('page'))]=m
    if rid:
        return dict(kind='rid',label='RID广播',evidenceScore=100,scoreMeaning='协议结构匹配；不是身份真实性概率',
            eligible=True,evidence=list(dict.fromkeys(evidence)),identities=sorted(ids),messages=list(messages.values())[-18:],
            transports=sorted(transports),identityStatus='已解析广播身份／未认证' if ids else 'RID消息有效／等待Basic ID',authenticated=False)
    if candidate:
        return dict(kind='rid_candidate',label='RID格式候选',evidenceScore=30,eligible=False,evidence=list(dict.fromkeys(evidence))+['载荷未通过当前结构校验'],identities=[],messages=[],identityStatus='待协议适配',authenticated=False)
    ssids={s.get('ssid') or '' for s in sources}
    matched_ssids=sorted(s for s in ssids if re.search(r'(drone|fpv|quadcopter|uav|tello|ufo)',s,re.I))
    ssid_hint=bool(matched_ssids)
    # Use one receiver and count each captured frame hash once.
    by_station={}
    for packet in packets:
        if packet.get('fcs_valid') is not False:by_station.setdefault(packet.get('station'),[]).append(packet)
    rows=max(by_station.values(),key=len,default=[]);data=[];seen=set();duplicates=0
    for p in rows:
        if p.get('frame_type')!=2 or p.get('retry'):continue
        digest=p.get('frame_sha256')
        if digest and digest in seen:duplicates+=1;continue
        if digest:seen.add(digest)
        data.append(p)
    large=[p for p in data if p.get('length',0)>=700]
    span=(max((p.get('observed_at',0) for p in data),default=0)-min((p.get('observed_at',0) for p in data),default=0))/1000
    udp=[p for p in data if p.get('protocol')=='UDP' and not p.get('protected')]
    def unicast(value):
        return isinstance(value,str) and bool(re.fullmatch(r'(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}',value)) and not int(value[:2],16)&1 and value.lower()!='00:00:00:00:00:00'
    destinations={p.get('destination_mac') for p in large if unicast(p.get('destination_mac'))}
    unknown_receivers=sum(not unicast(p.get('destination_mac')) for p in large)
    streams={}
    for p in data:
        decoded=p.get('decoded',{});hint=decoded.get('video_hint')
        if not hint or p.get('protected') or p.get('protocol') not in (None,'UDP'):continue
        flow=(decoded.get('ip_source'),decoded.get('source_port'),decoded.get('ip_destination'),decoded.get('destination_port'),hint.get('transport'),hint.get('stream'))
        streams.setdefault(flow,[]).append(hint)
    rtp_runs=0;rtp_steps=0;ts_runs=0;lab_runs=0;lab_packets=0;lab_sequences=0
    for flow,hints in streams.items():
        transport=flow[-2]
        if transport=='MPEG-TS/UDP' and len(hints)>=3:ts_runs+=1
        if transport=='RTP':
            sequences=[h.get('sequence') for h in hints if type(h.get('sequence')) is int]
            steps=sum(0<(b-a)%65536<=20 for a,b in zip(sequences,sequences[1:]))
            rtp_steps=max(rtp_steps,steps)
            if steps>=2:rtp_runs+=1
        if transport=='Lab UDP fragments':
            sequences={h.get('sequence') for h in hints if type(h.get('sequence')) is int}
            lab_packets=max(lab_packets,len(hints));lab_sequences=max(lab_sequences,len(sequences))
            if len(hints)>=4 and len(sequences)>=2:lab_runs+=1
    verified_media=rtp_runs>0 or ts_runs>0;lab_profile=lab_runs>0
    breakdown=[]
    def rule(identifier,label,points,hit,observed,available=True):
        breakdown.append(dict(id=identifier,label=label,maxPoints=points,matched=bool(hit),points=points if hit else 0,observed=observed,observable=bool(available)))
    rule('ssid_keyword','SSID关键词',30,ssid_hint,'命中：'+', '.join(matched_ssids) if matched_ssids else '未命中关键词',bool(any(ssids)))
    rule('large_frames','持续大数据帧',20,len(large)>=20 and span>=1,'非重传大帧%d；数据帧跨度%.2f秒'%(len(large),span),bool(data))
    rule('udp_frames','明文UDP数据帧',15,len(udp)>=10,'已解析UDP %d帧'%len(udp),bool(udp))
    rule('receiver_focus','集中接收端',10,len(large)>=20 and unknown_receivers==0 and 1<=len(destinations)<=2,'大帧%d；单播接收端%d；未知/组播地址%d'%(len(large),len(destinations),unknown_receivers),bool(large) and unknown_receivers==0)
    rule('media_structure','连续RTP / MPEG-TS结构',55,verified_media,'RTP连续流%d（最大有效序号转移%d）；TS流%d'%(rtp_runs,rtp_steps,ts_runs),bool(udp) or bool(streams))
    rule('lab_fragments','历史私有UDP分片布局',55,lab_profile,'匹配流%d；最多%d包 / %d个序号'%(lab_runs,lab_packets,lab_sequences),bool(udp) or bool(streams))
    score=sum(item['points'] for item in breakdown)
    if ssid_hint:evidence.append('SSID含飞行器相关词，仅弱证据')
    if breakdown[1]['matched']:evidence.append('短时窗内持续大数据帧，视频/下载均可能')
    if breakdown[2]['matched']:evidence.append('多帧UDP流，未证明为视频或无人机')
    if breakdown[3]['matched']:evidence.append('大帧集中发送至少数已知单播接收端')
    if verified_media:evidence.append('同一UDP流连续RTP视频型载荷或MPEG-TS结构；无人机归属待核验')
    if lab_profile:evidence.append('重复匹配历史断电对照中的私有UDP分片布局；本轮来源仍需开关机复核')
    video=score>=50
    if ssid_hint and not video:evidence.append('仅SSID线索，尚无足够图传载荷证据；可测向，来源待核验')
    eligible=video or ssid_hint
    return dict(kind='video_candidate' if video else 'ssid_candidate' if ssid_hint else 'wifi',label='Wi-Fi图传候选／无人机待核验' if video else 'SSID线索候选／来源待核验' if ssid_hint else '普通/未知Wi-Fi',
        evidenceScore=min(score,75),rawEvidenceScore=score,maxEvidenceScore=75,scoreMeaning='启发式证据分，上限75；不是无人机概率',scoringVersion='candidate_rules_v2',scoreBreakdown=breakdown,
        measurements=dict(nonRetryDataFrames=len(data),largeFrames=len(large),dataSpanSeconds=span,udpFrames=len(udp),receiverCount=len(destinations),discardedDuplicateFrames=duplicates,protectedFrames=sum(bool(p.get('protected')) for p in data)),
        eligible=eligible,evidence=evidence or ['尚无RID或足够图传特征；继续观测'],identities=[],messages=[],identityStatus='已检查：未发现RID身份广播' if eligible else '无RID身份',identitySkipped=eligible,profiles=['lab_fragment_20261102'] if lab_profile else [],authenticated=False)
