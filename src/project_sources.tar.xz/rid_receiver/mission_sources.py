"""Board-owned source classification and RID/AOA routing, without IQ calculation."""
import math
from signal_recognition import source_key,classify_source,positioning_route,signal_features

def classify_feed(feed,rid_state,station,now):
    groups={}
    for source in feed.get('sources',[]):
        if source.get('frequency_mhz') and source.get('mac'):
            groups.setdefault(source_key(source['mac'],source['frequency_mhz']),[]).append(source)
    by_source={}
    for p in feed.get('packets',[]):
        if p.get('fcs_valid') is True and 0<=now-p['received_monotonic']<10:
            by_source.setdefault((p.get('source_mac'),p.get('frequency_mhz')),[]).append(dict(p,station=station,observed_at=p['received_monotonic']*1000))
    rows=[]
    for key,sources in groups.items():
        source=sources[0]
        packets=by_source.get((source['mac'],source['frequency_mhz']),[])
        aged=[dict(s,age_seconds=max(0,now-s['last_monotonic'])) for s in sources]
        recognition=classify_source(aged,packets);age=min(s['age_seconds'] for s in aged)
        positioning=positioning_route(recognition)
        for target in rid_state.get('targets',[]):
            if target.get('mac')!=source['mac'] or target.get('frequency_mhz')!=source['frequency_mhz']:continue
            locations=[m for m in target.get('messages',{}).values() if m.get('type')==1 and 0<=rid_state['monotonic']-m.get('received_monotonic',-1e20)<15]
            if not locations:continue
            m=locations[-1];lat,lon=m.get('latitude'),m.get('longitude')
            if all(type(v) in (int,float) and math.isfinite(v) for v in (lat,lon)) and abs(lat)<=90 and abs(lon)<=180:
                positioning=dict(method='rid',label='RID广播位置直显',position=dict(latitude=lat,longitude=lon),reason='板端已解析新鲜RID位置，无需AOA排队')
        dsss=all(p.get('phy_type')=='dsss_long_1m' for p in packets) if packets else {k for s in sources for k in s.get('phy_types',{})}=={'dsss_long_1m'}
        item=dict(key=key,mac=source['mac'],frequencyMhz=source['frequency_mhz'],ssid=next((s.get('ssid') for s in sources if s.get('ssid')),None),
                  doaSupported=not dsss,positioning=positioning,features=signal_features(sources,packets),receiverStations=[station] if age<10 else [],fresh=age<10,ageSeconds=age,
                  frames=sum(s.get('frames',0) for s in sources),recognition=recognition,recognitionLocation='board',recognitionStation='A',schedulerLocation='pc',
                  stages=dict(capture='observed' if age<10 else 'stale',features=recognition['kind'],identity='parsed' if recognition['identities'] else 'pending' if recognition['kind']=='rid' else 'skipped_no_rid' if recognition.get('identitySkipped') else 'not_applicable',
                              direction='rid_position' if positioning['method']=='rid' else 'unsupported_phy' if dsss and recognition['eligible'] else 'queued' if recognition['eligible'] and age<10 else 'not_eligible'))
        if age>=10:
            item['recognition']=dict(recognition,scoreBreakdown=[],measurements={})
        rows.append(item)
    return sorted(rows,key=lambda s:(s['fresh'],s['recognition']['eligible'],s['recognition']['kind']=='rid',-s['ageSeconds']),reverse=True)[:256]
