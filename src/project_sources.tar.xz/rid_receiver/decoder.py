"""Small, independent OpenDroneID decoder (protocol versions 0..2).

Wire format references: https://github.com/opendroneid/opendroneid-core-c
No authentication verification is performed. Unknown messages retain raw bytes.
"""
import struct


def text(data):
    return data.split(b'\0', 1)[0].decode('utf-8', errors='replace')


def u16(data, pos):
    return struct.unpack_from('<H', data, pos)[0]


def altitude(data, pos):
    n = u16(data, pos)
    return n * .5 - 1000 if n else None


def coords(data, pos):
    lat, lon = struct.unpack_from('<ii', data, pos)
    lat, lon = lat / 1e7, lon / 1e7
    if (lat == 0 and lon == 0) or abs(lat) > 90 or abs(lon) > 180:
        return None, None
    return lat, lon


def decode_message(m):
    if len(m) != 25:
        raise ValueError('RID message must have 25 bytes')
    kind, version = m[0] >> 4, m[0] & 15
    r = dict(type=kind, version=version, raw=m.hex())
    if version > 2:
        r['warning'] = 'Unsupported protocol version; raw bytes only'
        return r
    if kind == 0:
        id_type = m[1] >> 4
        r.update(id_type=id_type, ua_type=m[1] & 15,
                 uas_id=text(m[2:22]) if id_type in (1, 2) else m[2:22].hex())
    elif kind == 1:
        direction = m[2] + (180 if m[1] & 2 else 0)
        hs = m[3] * .75 + 63.75 if m[1] & 1 else m[3] * .25
        vs = struct.unpack_from('b', m, 4)[0] * .5
        lat, lon = coords(m, 5)
        r.update(status=m[1] >> 4, direction=direction if direction < 360 else None,
                 speed_horizontal=None if hs == 255 else hs,
                 speed_vertical=vs if -62 <= vs <= 62 else None,
                 latitude=lat, longitude=lon, altitude_baro=altitude(m, 13),
                 altitude_geo=altitude(m, 15), height=altitude(m, 17),
                 height_reference='ground' if m[1] & 4 else 'takeoff',
                 horizontal_accuracy=m[19] & 15, vertical_accuracy=m[19] >> 4,
                 speed_accuracy=m[20] & 15, baro_accuracy=m[20] >> 4,
                 timestamp=None if u16(m, 21) == 65535 else u16(m, 21) / 10,
                 timestamp_accuracy=(m[23] & 15) / 10)
    elif kind == 2:
        page = m[1] & 15
        r.update(auth_type=m[1] >> 4, page=page,
                 auth_data=m[8:].hex() if page == 0 else m[2:].hex(), verified=False)
        if page == 0:
            r.update(last_page=m[2], auth_length=m[3], timestamp=struct.unpack_from('<I', m, 4)[0])
    elif kind == 3:
        r.update(description_type=m[1], description=text(m[2:25]))
    elif kind == 4:
        lat, lon = coords(m, 2)
        r.update(operator_location_type=m[1] & 3, classification_type=(m[1] >> 2) & 7,
                 operator_latitude=lat, operator_longitude=lon,
                 area_count=u16(m, 10), area_radius=m[12] * 10,
                 area_ceiling=altitude(m, 13), area_floor=altitude(m, 15),
                 category_eu=m[17] >> 4, class_eu=m[17] & 15,
                 operator_altitude_geo=altitude(m, 18),
                 timestamp=struct.unpack_from('<I', m, 20)[0] if version >= 2 else None)
    elif kind == 5:
        r.update(operator_id_type=m[1], operator_id=text(m[2:22]))
    return r


def decode_payload(data):
    if not data:
        raise ValueError('Empty RID payload')
    if len(data) >= 2 and data[0] == 255 and data[1] & 0xe0 == 0x20:
        from gb46750 import decode_cn
        return decode_cn(data)
    if data[0] >> 4 != 15:
        return [decode_message(data)]
    if len(data) < 3 or data[1] != 25 or not 1 <= data[2] <= 9:
        raise ValueError('Invalid message pack header')
    if len(data) != 3 + data[2] * 25:
        raise ValueError('Truncated or oversized message pack')
    if data[0] & 15 > 2:
        raise ValueError('Unsupported message pack version')
    return [decode_message(data[i:i+25]) for i in range(3, len(data), 25)]


def extract_frame(frame):
    """Accept a raw 802.11 frame without radiotap/FCS. Return RID events only."""
    if len(frame) < 24:
        return []
    fc = u16(frame, 0)
    if fc & 0x000c or fc & 0x4000:
        return []
    mac = ':'.join(f'{b:02x}' for b in frame[10:16])
    results = []
    if fc & 0x00f0 == 0x80:
        pos = 36
        while pos + 2 <= len(frame):
            tag, size = frame[pos:pos+2]
            pos += 2
            if pos + size > len(frame):
                break
            value = frame[pos:pos+size]
            pos += size
            if tag == 221 and value[:4] == bytes.fromhex('fa0bbc0d') and len(value) >= 6:
                results.append(dict(mac=mac, transport='Wi-Fi Beacon', counter=value[4], payload=value[5:]))
    elif fc & 0x00f0 == 0xd0 and frame[24:30] == bytes.fromhex('0409506f9a13'):
        pos = 30
        while pos + 3 <= len(frame):
            tag, size = frame[pos], u16(frame, pos + 1)
            pos += 3
            if pos + size > len(frame):
                break
            value = frame[pos:pos+size]
            pos += size
            # Fixed service descriptor profile used by OpenDroneID; reject optional layouts.
            if (tag == 3 and len(value) >= 11 and value[:6] == bytes.fromhex('8869199d9209')
                    and value[8] == 0x10 and value[9] == len(value) - 10):
                results.append(dict(mac=mac, transport='Wi-Fi NAN', counter=value[10], payload=value[11:]))
    return results
