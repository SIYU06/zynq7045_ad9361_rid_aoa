"""RID transport recognition, structural validation and evidence, not authentication.

Profiles: OpenDroneID Wi-Fi Beacon and NAN fixed descriptor. BLE/GB-specific
transports require their own tested adapters; never infer RID from an SSID.
"""
import struct
from decoder import extract_frame, decode_payload

TYPE_NAMES = {0:'Basic ID',1:'Location/Vector',2:'Authentication',3:'Self ID',4:'System',5:'Operator ID'}

def recognize_rid(frame, fcs_valid=True):
    empty=dict(status='none',transport=None,messages=[],identities=[],evidence=[],authenticated=False)
    if fcs_valid is not True or len(frame)<24:
        return empty
    fc=struct.unpack_from('<H',frame)[0]
    if fc&0x400c:
        return empty
    hint=None
    if fc&0xf0==0x80:
        pos=36
        while pos+2<=len(frame):
            tag,size=frame[pos:pos+2];pos+=2
            if pos+size>len(frame):
                break
            value=frame[pos:pos+size];pos+=size
            if tag==221 and value[:4]==bytes.fromhex('fa0bbc0d'):
                hint='Wi-Fi Beacon'
    elif fc&0xf0==0xd0 and frame[24:30]==bytes.fromhex('0409506f9a13'):
        # NAN alone is not RID; demand the Remote ID service hash as well.
        pos=30
        while pos+3<=len(frame):
            tag=frame[pos];size=struct.unpack_from('<H',frame,pos+1)[0];pos+=3
            if pos+size>len(frame):break
            value=frame[pos:pos+size];pos+=size
            if tag==3 and value[:6]==bytes.fromhex('8869199d9209'):hint='Wi-Fi NAN'
    if not hint:return empty
    result=dict(empty,status='candidate',transport=hint,evidence=['FCS有效','RID专用传输标识匹配'])
    try:
        events=extract_frame(frame)
        if not events:raise ValueError('传输布局尚未支持或长度不完整')
        messages=[m for event in events for m in decode_payload(event['payload'])]
        if not messages or any(m['type'] not in TYPE_NAMES or m.get('format')!='GB46750' and m['version']>2 for m in messages):
            raise ValueError('未知消息类型或版本，仅保留RID候选')
        for message in messages:
            if message['type']==0:
                if (message['id_type'] not in (1,2,3,4) or not message['uas_id'] or
                    message.get('format')!='GB46750' and not any(bytes.fromhex(message['raw'])[2:22])):
                    raise ValueError('Basic ID类型或内容无效')
                if message['id_type'] in (1,2) and any(ord(c)<32 or ord(c)>126 for c in message['uas_id']):
                    raise ValueError('Basic ID文本编码不符合当前解析器约束')
            message['type_name']=TYPE_NAMES[message['type']]
        result.update(status='confirmed',messages=messages,
            identities=sorted({m['uas_id'] for m in messages if m['type']==0}),
            evidence=result['evidence']+['GB46750字段/长度结构有效' if messages[0].get('format')=='GB46750' else '25字节消息/消息包结构有效','支持的消息类型与版本'])
    except (ValueError,KeyError,IndexError,struct.error) as exc:
        result['reason']=str(exc)
    return result
