"""Passive bounded channel survey controlled by the PC; no MAC/RID allowlist."""
import argparse
import json
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
from urllib.parse import unquote
sys.path.insert(0,'/root/openwifi_rx1/rid_service')
from capture_io import PcapWriter,monitor_frame
from wifi_candidates import CandidateStore

from wifi_channels import CHANNELS,tune_channel


def validate_plan(plan):
    if not isinstance(plan,dict) or not re.fullmatch('[a-z0-9_]{1,64}',plan.get('name','')): raise ValueError('invalid run name')
    channels=plan.get('channels')
    dwell=plan.get('dwell_s',2)
    if not isinstance(channels,list) or not channels or len(channels)>24 or len(set(channels))!=len(channels): raise ValueError('invalid channels')
    if any(isinstance(c,bool) or not isinstance(c,int) or c not in CHANNELS for c in channels): raise ValueError('unsupported passive channel')
    if isinstance(dwell,bool) or not isinstance(dwell,(int,float)) or not .5<=dwell<=20 or len(channels)*(dwell+.2)>65: raise ValueError('bounded dwell required')
    return channels,float(dwell)


class Survey:
    def __init__(self,args):
        self.args=args;self.lock=threading.Lock();self.stop=threading.Event();self.worker=None;self.runs=0
        self.state=dict(state='ready',station=args.station,source='real_openwifi_passive_monitor',source_filter='none',last_run=None)
        self.phy=next(p for p in Path('/sys/bus/iio/devices').glob('iio:device*') if (p/'name').read_text().strip()=='ad9361-phy')

    def publish(self,**values):
        with self.lock: self.state.update(monotonic_s=time.monotonic(),**values)

    def snapshot(self):
        with self.lock: return dict(self.state)

    def begin(self,plan):
        validate_plan(plan)
        with self.lock:
            if self.worker and self.worker.is_alive(): raise ValueError('survey already running')
            if self.runs>=12: raise ValueError('bounded session run limit reached')
            folder=self.args.out/plan['name']
            folder.mkdir()
            self.runs+=1
            self.state.update(state='starting',last_run=plan['name'])
            self.worker=threading.Thread(target=self.run,args=(plan,folder),daemon=True);self.worker.start()

    def tune(self,channel):
        tune_channel(channel,self.args.interface)

    def run(self,plan,folder):
        channels,dwell=validate_plan(plan); stages=[];errors=[];restored=False
        (folder/'plan.json').write_text(json.dumps(plan,indent=2))
        try:
            with socket.socket(socket.AF_PACKET,socket.SOCK_RAW,socket.htons(3)) as capture:
                capture.bind((self.args.interface,0));capture.settimeout(.05)
                for channel in channels:
                    if self.stop.is_set(): break
                    self.publish(state='tuning',channel=channel)
                    self.tune(channel);time.sleep(.1)
                    # Discard packets queued while retuning, without a persistent filter.
                    drain=time.monotonic()+.1
                    while time.monotonic()<drain:
                        try: capture.recv(65536)
                        except socket.timeout: break
                    stage_dir=folder/('ch_%03d'%channel);stage_dir.mkdir()
                    writer=PcapWriter(stage_dir/'valid_frames.pcap',limit_bytes=2*1024*1024)
                    store=CandidateStore();counts=dict(raw_packets=0,valid_fcs=0,bad_fcs=0,malformed=0)
                    begun=time.monotonic();rssi=[];next_rssi=begun
                    self.publish(state='capturing',channel=channel)
                    try:
                        while time.monotonic()-begun<dwell and not self.stop.is_set():
                            now=time.monotonic()
                            if now>=next_rssi:
                                rssi.append([(self.phy/('in_voltage%d_rssi'%i)).read_text().strip() for i in (0,1)])
                                next_rssi=now+.2
                            try: packet,address=capture.recvfrom(65536)
                            except socket.timeout: continue
                            if address[2]==4: continue
                            counts['raw_packets']+=1
                            try:
                                frame,metadata=monitor_frame(packet,127,openwifi_fcs=True)
                                if metadata['fcs_valid'] is not True:
                                    counts['bad_fcs']+=1;continue
                                counts['valid_fcs']+=1
                                writer.write(time.time(),packet)
                                store.frame(frame,metadata,now)
                            except (ValueError,IndexError): counts['malformed']+=1
                    finally: writer.close()
                    stage=dict(channel=channel,rf_hz=(self.phy/'out_altvoltage0_RX_LO_frequency').read_text().strip(),
                        dwell_actual_s=time.monotonic()-begun,counts=counts,candidates=store.snapshot(),
                        candidate_overflow=store.overflow,pcap_limit_reached=writer.full,
                        rx_rssi_raw=rssi,source_filter='none')
                    (stage_dir/'summary.json').write_text(json.dumps(stage,indent=2))
                    stages.append(stage)
                    self.publish(state='capturing',completed_channels=len(stages),last_channel_summary=stage)
        except Exception as exc: errors.append(type(exc).__name__+': '+str(exc))
        finally:
            try: self.tune(6);restored=True
            except Exception as exc: errors.append('restore: '+str(exc))
            result=dict(station=self.args.station,plan=plan,stages=stages,errors=errors,
                restored_channel6=restored,source='real_openwifi_passive_monitor',source_filter='none',
                scope='WiFi transmitter candidates; attribution requires controlled experiment; no calibrated DOA')
            (folder/'summary.json').write_text(json.dumps(result,indent=2))
            self.publish(state='complete' if not errors else 'failed',result=result)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--station',choices=['A','B'],required=True)
    parser.add_argument('--listen',required=True)
    parser.add_argument('--interface',default='sdr0')
    parser.add_argument('--port',type=int,default=18795)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    survey=Survey(args)
    class Handler(BaseHTTPRequestHandler):
        def sendjson(self,value,code=200):
            data=json.dumps(value).encode();self.send_response(code);self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        def do_GET(self):
            if self.path=='/api/state': self.sendjson(survey.snapshot());return
            if self.path.startswith('/runs/'):
                path=(args.out/unquote(self.path[6:])).resolve()
                if args.out.resolve() not in path.parents or not path.is_file() or path.suffix not in ('.json','.pcap'):
                    self.send_error(404);return
                self.send_response(200);self.send_header('Content-Length',str(path.stat().st_size));self.end_headers()
                with path.open('rb') as stream: shutil.copyfileobj(stream,self.wfile)
                return
            self.send_error(404)
        def do_POST(self):
            if self.path!='/api/run': self.send_error(404);return
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=8192: raise ValueError('invalid request size')
                survey.begin(json.loads(self.rfile.read(size)));self.sendjson({'accepted':True},202)
            except (ValueError,FileExistsError,TypeError) as exc: self.sendjson({'error':str(exc)},400)
        def log_message(self,*args): pass
    server=ThreadingHTTPServer((args.listen,args.port),Handler)
    def stop(*_):
        survey.stop.set();threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,stop)
    try: server.serve_forever()
    finally:
        survey.stop.set()
        if survey.worker: survey.worker.join(10)
        server.server_close()

if __name__=='__main__': main()
