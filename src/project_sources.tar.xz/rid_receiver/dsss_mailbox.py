"""Optional passive FPGA DSSS mailbox. Never probe an undeclared AXI address.

The matching device-tree node is required before /dev/mem is opened. This input
does not authorize or synthesize any AoA: its timestamp is the PLCP header latch.
"""
import ctypes
import mmap
import os
from pathlib import Path
import struct
import threading
import time

BASE = 0x83c60000
MAGIC = 0x44535331
COMPATIBLE = b'airspace,dsss-rx-1mbps-v1'


class MemoryBus:
    def __init__(self, node):
        node = Path(node)
        if COMPATIBLE not in (node / 'compatible').read_bytes().split(b'\0'):
            raise ValueError('Matching DSSS device-tree node absent; AXI was not accessed')
        if (node / 'reg').read_bytes() != struct.pack('>II', BASE, 0x10000):
            raise ValueError('DSSS device-tree address/size mismatch')
        if (node / 'status').exists() and (node / 'status').read_bytes().rstrip(b'\0') not in (b'okay', b'ok'):
            raise ValueError('DSSS peripheral is disabled in device tree')
        import fcntl
        self.lock = open('/tmp/airspace_dsss_rx.lock', 'a')
        self.fd = None
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.fd = os.open('/dev/mem', os.O_RDWR | os.O_SYNC)
            self.memory = mmap.mmap(self.fd, 0x2000, offset=BASE)
        except Exception:
            if self.fd is not None:os.close(self.fd)
            self.lock.close()
            raise

    def read32(self, offset):
        return ctypes.c_uint32.from_buffer(self.memory, offset).value

    def write32(self, offset, value):
        ctypes.c_uint32.from_buffer(self.memory, offset).value = value

    def close(self):
        self.memory.close()
        os.close(self.fd)
        self.lock.close()


class Mailbox:
    def __init__(self, bus):
        self.bus = bus
        if bus.read32(0) != MAGIC or bus.read32(0x2c) != 0x00010001:
            raise ValueError('DSSS mailbox ABI mismatch')

    def enable(self, enabled):
        self.bus.write32(4, int(bool(enabled)))

    def take(self):
        if not self.bus.read32(8) & 1:
            return None
        sequence = self.bus.read32(0x10)
        length = self.bus.read32(0xc)
        if not 1 <= length <= 4091:
            raise ValueError('Invalid hardware frame length')
        timestamp = self.bus.read32(0x14) | self.bus.read32(0x18) << 32
        frame = b''.join(struct.pack('<I', self.bus.read32(0x1000 + offset))
                         for offset in range(0, length, 4))[:length]
        if self.bus.read32(0x10) != sequence or not self.bus.read32(8) & 1:
            raise RuntimeError('Mailbox ownership changed during copy')
        self.bus.write32(0x30, sequence)
        return dict(frame=frame, sequence=sequence, header_tsf_us=timestamp)

    def counters(self):
        return dict(headers=self.bus.read32(0x20), fcsAccepted=self.bus.read32(0x24),
                    fcsRejected=self.bus.read32(0x28), hostDrops=self.bus.read32(0x1c))


class DSSSIngest:
    def __init__(self, monitor, node, frequency_mhz):
        self.monitor, self.node, self.frequency = monitor, node, frequency_mhz
        self.state = dict(available=False, state='not_configured' if not node else 'starting',
                          supportedRatesMbps=[1], preamble='long', deployed=False)
        self.lock = threading.Lock()

    def snapshot(self):
        with self.lock:
            return dict(self.state)

    def update(self, **value):
        with self.lock:
            self.state.update(value)

    def run(self):
        if not self.node:
            return
        bus = mailbox = None
        try:
            device = next(device for device in Path('/sys/bus/iio/devices').glob('iio:device*')
                          if (device / 'name').read_text().strip() == 'ad9361-phy')
            if int((device / 'in_voltage_sampling_frequency').read_text()) != 40000000:
                raise ValueError('Initialize the40MS/s RF profile before opening DSSS AXI')
            frequency_path = device / 'out_altvoltage0_RX_LO_frequency'
            bus = MemoryBus(self.node)
            mailbox = Mailbox(bus)
            enabled = False
            mailbox.enable(False)
            tick = 0;last_rf=None;stable_since=0
            while not self.monitor.stop.is_set():
                actual_rf=int(frequency_path.read_text());center=round(actual_rf/1000000)
                if actual_rf!=last_rf:
                    mailbox.enable(False);enabled=False
                    mailbox.take()
                    last_rf=actual_rf;stable_since=time.monotonic()
                    self.update(captureActive=False,state='tuning')
                rf_ok=abs(actual_rf-center*1000000)<100 and center in range(2412,2473,5)
                self.frequency=center if rf_ok else None
                with self.monitor.condition:
                    wanted = self.monitor.enabled and rf_ok and time.monotonic()-stable_since>=.2
                    if wanted != enabled:
                        mailbox.enable(wanted)
                        enabled = wanted
                        self.update(captureActive=enabled)
                    packet = mailbox.take() if enabled else None
                    if packet and int(frequency_path.read_text()) != actual_rf:
                        mailbox.enable(False)
                        enabled = False
                        packet = None
                        self.update(captureActive=False, state='channel_mismatch')
                    if packet:
                        metadata = dict(phy_type='dsss_long_1m', frequency_mhz=self.frequency,
                                        rate_mbps=1.0, rssi=None, fcs_valid=True,
                                        fcs_method='dsss_fpga_crc32_verified',
                                        header_tsf_us=packet['header_tsf_us'],
                                        doaAssociation='unsupported_pending_Barker_phase_path')
                        self.monitor.ingest_dsss(time.time(), packet['frame'], metadata)
                if time.monotonic() - tick > 1:
                    self.update(available=True, deployed=True, state='receiving' if enabled else 'standby' if rf_ok else 'unsupported_frequency',
                                frequencyMhz=self.frequency, counters=mailbox.counters(),
                                timestampMeaning='PLCP header latch; not an OFDM LTF timestamp')
                    tick = time.monotonic()
                self.monitor.stop.wait(.002 if not packet else .0001)
        except Exception as exc:
            self.update(available=False, state='error', error=str(exc))
        finally:
            if bus:
                try:
                    if mailbox is not None:mailbox.enable(False)
                finally:
                    bus.close()
                    self.update(captureActive=False)
