"""Bounded board-side PCAP/PCAPNG import for the ground-station UI."""
from pathlib import Path
import tempfile
from capture_io import read_capture,monitor_frame
from signal_inspector import SignalStore

def parse_capture(data,openwifi=False):
    if not data or len(data)>8*1024*1024:raise ValueError('抓包文件需为1字节至8 MiB')
    store=SignalStore();count=0
    with tempfile.TemporaryDirectory(prefix='airspace_pcap_') as folder:
        path=Path(folder)/'capture.pcap';path.write_bytes(data)
        for timestamp,link,packet in read_capture(path):
            count+=1
            if count>50000:raise ValueError('文件超过50000帧，请截取后导入')
            try:
                frame,meta=monitor_frame(packet,link,openwifi_fcs=openwifi);store.frame(timestamp,frame,meta)
            except (ValueError,IndexError):continue
    value=store.snapshot()
    for packet in value['packets']:packet.update(station='文件',session_id='archive',historical=True,observed_at=packet['capture_time']*1000)
    for source in value['sources']:source.update(station='文件',historical=True)
    value.update(schema='airspace.signals',version=1,mode='archive',connected=False,stations=[],label='导入抓包 · 历史',file_frames=count)
    return value

