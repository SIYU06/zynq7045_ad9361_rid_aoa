#!/bin/sh
set -eu
station=$1
case "$station" in A|B);;*)exit 2;;esac
service=/root/openwifi_rx1/rid_service
if [ -f "$service/service.pid" ];then
 old=$(cat "$service/service.pid")
 if [ -r "/proc/$old/cmdline" ];then
  if ! tr '\000' ' ' <"/proc/$old/cmdline" | grep -F -q "$service/monitor_service.py";then echo 'Unexpected PID owner';exit 1;fi
  kill "$old"
  for attempt in 1 2 3 4 5 6 7 8 9 10;do if ! kill -0 "$old" 2>/dev/null;then break;fi;sleep .2;done
  if kill -0 "$old" 2>/dev/null;then echo 'Old monitor still running';exit 1;fi
 fi
fi
if [ ! -f "$service/receiver_role.json" ];then
 if [ "$station" = B ];then echo '{"enabled":true}' >"$service/receiver_role.json";else echo '{"enabled":false}' >"$service/receiver_role.json";fi
fi
set --
if [ "$station" = B ] && [ -f "$service/dsss_channel" ];then
 channel=$(cat "$service/dsss_channel")
 case "$channel" in [1-9]|1[0-3]);;*)echo 'Invalid DSSS receive channel';exit 1;;esac
 node=/sys/firmware/devicetree/base/amba/dsss_rx@83c60000
 test -f "$node/compatible"
 iw dev sdr0 set channel "$channel" HT20
 set -- --dsss-dt-node "$node" --dsss-channel "$channel"
fi
suffix=$(cat /proc/sys/kernel/random/uuid)
run=/root/openwifi_rx1/experiments/${station}_receiver_role_$suffix
mkdir "$run"
nohup python3 -u "$service/monitor_service.py" --interface sdr0 --listen 0.0.0.0 --capture "$run/capture.pcap" --log "$run/rid.jsonl" --role-config "$service/receiver_role.json" "$@" >"$run/service.log" 2>&1 </dev/null &
echo $! >"$service/service.pid"
echo "$run" >"$service/last_run"
sleep 1
kill -0 "$(cat "$service/service.pid")"
python3 - <<'PY'
import json,urllib.request
print(json.dumps(json.load(urllib.request.urlopen('http://127.0.0.1:18771/api/receiver/status',timeout=3))))
PY
