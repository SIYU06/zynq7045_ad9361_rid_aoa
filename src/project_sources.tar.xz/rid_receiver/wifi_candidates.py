"""Bounded generic 802.11 transmitter metadata; no RID or drone assumption."""
from collections import Counter
import math
import struct
import time


def mac(raw):
    return ':'.join('%02x'%v for v in raw)


def parse_wifi_frame(frame):
    if len(frame)<2: raise ValueError('short frame control')
    fc=struct.unpack_from('<H',frame)[0]
    if fc&3: raise ValueError('unsupported 802.11 version')
    kind=(fc>>2)&3; subtype=(fc>>4)&15
    # Short ACK/CTS frames have no transmitter address; never invent addr2.
    if kind==1 and subtype not in (8,9,10,11,14,15): return None
    if kind not in (0,1,2): return None
    if len(frame)<(16 if kind==1 else 24): raise ValueError('short transmitter header')
    ta=frame[10:16]
    if ta==bytes(6) or ta==b'\xff'*6 or ta[0]&1: return None
    to_ds=bool(fc&0x100);from_ds=bool(fc&0x200)
    result=dict(transmitter=mac(ta),receiver=mac(frame[4:10]),frame_type=kind,subtype=subtype,
        protected=bool(fc&0x4000),to_ds=to_ds,from_ds=from_ds,
        role='control-transmitter' if kind==1 else 'AP-direction' if kind==2 and from_ds and not to_ds else
             'STA-direction' if kind==2 and to_ds and not from_ds else 'unspecified',
        bytes=len(frame),ssid=None,advertised_channel=None,bssid=None,
        ht_advertised=False,vht_advertised=False)
    if kind==2:
        if to_ds and from_ds:
            if len(frame)<30: raise ValueError('short four-address header')
        else:
            result['bssid']=mac(frame[4:10] if to_ds else frame[10:16] if from_ds else frame[16:22])
    elif kind==0 and subtype in (8,5):
        if len(frame)<36: raise ValueError('short beacon/probe response')
        result['role']='AP-beacon';result['bssid']=mac(frame[16:22])
        offset=36
        while offset<len(frame):
            if offset+2>len(frame): raise ValueError('truncated IE header')
            tag,size=frame[offset:offset+2];offset+=2
            if offset+size>len(frame): raise ValueError('truncated IE body')
            value=frame[offset:offset+size];offset+=size
            if tag==0 and size<=32: result['ssid']=value.decode('utf-8','replace')
            elif (tag==3 and size==1) or (tag==61 and size==22): result['advertised_channel']=value[0]
            elif tag==45 and size==26: result['ht_advertised']=True
            elif (tag==191 and size==12) or (tag==192 and size==5): result['vht_advertised']=True
    return result


class CandidateStore:
    def __init__(self,limit=256,evict_oldest=False):
        self.limit=limit;self.rows={};self.overflow=0;self.evict_oldest=evict_oldest

    def frame(self,frame,metadata,now=None):
        if metadata.get('fcs_valid') is not True: return
        parsed=parse_wifi_frame(frame)
        if parsed is None: return
        key=(metadata.get('frequency_mhz'),parsed['transmitter'])
        now=time.monotonic() if now is None else now
        row=self.rows.get(key)
        if row is None:
            if len(self.rows)>=self.limit:
                self.overflow+=1
                if not self.evict_oldest:return
                del self.rows[min(self.rows,key=lambda k:self.rows[k]['last_monotonic'])]
            row=dict(mac=parsed['transmitter'],frequency_mhz=key[0],frames=0,bytes=0,data_frames=0,
                data_bytes=0,control_frames=0,protected_frames=0,beacons=0,ssid=None,bssid=None,advertised_channel=None,
                ht_advertised=False,vht_advertised=False,roles=Counter(),rates_mbps=Counter(),phy_types=Counter(),
                first_monotonic=now,last_monotonic=now,rssi_sum=0.,rssi_count=0,
                classification='WiFi transmitter candidate; drone/video attribution unconfirmed')
            self.rows[key]=row
        row['frames']+=1;row['bytes']+=len(frame);row['last_monotonic']=now
        row['data_frames']+=parsed['frame_type']==2
        row['data_bytes']+=len(frame) if parsed['frame_type']==2 else 0
        row['control_frames']+=parsed['frame_type']==1
        row['protected_frames']+=parsed['protected'];row['beacons']+=parsed['frame_type']==0 and parsed['subtype']==8
        for name in ('ssid','bssid','advertised_channel'):
            if parsed[name] is not None: row[name]=parsed[name]
        row['ht_advertised']|=parsed['ht_advertised'];row['vht_advertised']|=parsed['vht_advertised']
        row['roles'][parsed['role']]+=1
        rate=metadata.get('rate_mbps')
        row['phy_types'][metadata.get('phy_type','ofdm' if metadata.get('ht_mcs') or (rate or 0)>=6 else 'unknown')]+=1
        if rate is not None: row['rates_mbps'][str(rate)]+=1
        rssi=metadata.get('rssi')
        if isinstance(rssi,(int,float)) and math.isfinite(rssi): row['rssi_sum']+=rssi;row['rssi_count']+=1

    def snapshot(self):
        rows=[]
        for original in self.rows.values():
            row=dict(original)
            total=row.pop('rssi_sum');count=row.pop('rssi_count')
            row['mean_driver_rssi']=total/count if count else None
            row['roles']=dict(row['roles']);row['rates_mbps']=dict(row['rates_mbps']);row['phy_types']=dict(row['phy_types'])
            rows.append(row)
        return sorted(rows,key=lambda row:row['data_bytes'],reverse=True)
