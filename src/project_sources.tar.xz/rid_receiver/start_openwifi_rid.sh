#!/bin/sh
# Run on the board; passive initialization with the proven RF-before-sdr order.
set -eu
base=/root/openwifi_rx1
service_dir=$base/rid_service
release=5.15.0-175919-g427c94e8faa5-openwifi-rx1
test "$(uname -r)" = "$release" || { echo 'Kernel mismatch'; exit 1; }
cd "$base"
if [ -f "$service_dir/service.pid" ] && kill -0 "$(cat "$service_dir/service.pid")" 2>/dev/null; then
    pid=$(cat "$service_dir/service.pid")
    if tr '\000' ' ' < "/proc/$pid/cmdline" | grep -q "$service_dir/monitor_service.py"; then
        kill "$pid"
        sleep 1
    fi
fi
for module in tx_intf rx_intf openofdm_tx openofdm_rx xpu sdr; do
    test "$(modinfo -F vermagic ./$module.ko | cut -d ' ' -f 1)" = "$release"
done
modprobe xilinx_dma
modprobe mac80211
# Exclude both the driver's temporary name and the final monitor name.
if ! grep -qxF 'denyinterfaces sdr0 wlan0' /etc/dhcpcd.conf; then
    test -e "$service_dir/dhcpcd.conf.before_rid" || cp -a /etc/dhcpcd.conf "$service_dir/dhcpcd.conf.before_rid"
    if grep -qxF 'denyinterfaces sdr0' /etc/dhcpcd.conf; then
        sed -i 's/^denyinterfaces sdr0$/denyinterfaces sdr0 wlan0/' /etc/dhcpcd.conf
    else
        printf '\n# OpenWiFi passive monitor\ndenyinterfaces sdr0 wlan0\n' >> /etc/dhcpcd.conf
    fi
    systemctl restart dhcpcd
fi
systemctl stop wpa_supplicant 2>/dev/null || true
wpa_cli -i sdr0 terminate >/dev/null 2>&1 || true
wpa_cli -i wlan0 terminate >/dev/null 2>&1 || true
if [ -e /sys/class/net/sdr0 ]; then ip link set sdr0 down; fi
if [ -e /sys/class/net/wlan0 ]; then ip link set wlan0 down; fi
if [ -d /sys/module/sdr ]; then rmmod sdr; fi
sh ./rf_init_11n.sh
for module in tx_intf rx_intf openofdm_tx openofdm_rx xpu sdr; do
    if [ ! -d "/sys/module/$module" ]; then insmod "./$module.ko"; fi
done
if [ ! -e /sys/class/net/sdr0 ]; then
    for address in /sys/class/net/*/address; do
        case "$(cat "$address")" in
            66:55:44:33:22:*)
                name=${address%/address}; name=${name##*/}
                ip link set "$name" down
                ip link set "$name" name sdr0
                break
                ;;
        esac
    done
fi
test -e /sys/class/net/sdr0
ip link set sdr0 down
iw dev sdr0 set type monitor
ip link set sdr0 up
iw dev sdr0 set channel 6 HT20
sh ./configure_rx.sh "${OPENWIFI_RX_GAIN_DB:-46}"
mode=${OPENWIFI_RX_GAIN_MODE:-fast_attack}
case "$mode" in manual|fast_attack|slow_attack|hybrid) ;; *) echo 'Invalid RX gain mode'; exit 1 ;; esac
for rf in /sys/bus/iio/devices/iio:device*; do
    if [ -f "$rf/in_voltage_rf_bandwidth" ]; then
        printf '%s\n' "$mode" > "$rf/in_voltage0_gain_control_mode"
        printf '%s\n' "$mode" > "$rf/in_voltage1_gain_control_mode"
    fi
done
if [ "${OPENWIFI_INIT_ONLY:-0}" = 1 ]; then
    echo 'RF/monitor interface initialized; foreground services are managed separately.'
    iw dev sdr0 info
    exit 0
fi
run=${OPENWIFI_RUN_DIRECTORY:-$base/experiments/a_$(date +%Y%m%d_%H%M%S)}
# Never reopen a previous capture after a board clock reset or repeated launch.
mkdir -p "$(dirname "$run")"
mkdir "$run"
nohup python3 -u "$service_dir/monitor_service.py" --interface sdr0 --listen 0.0.0.0 \
    --capture "$run/capture.pcap" --log "$run/rid.jsonl" > "$run/service.log" 2>&1 &
echo $! > "$service_dir/service.pid"
echo "$run" > "$service_dir/last_run"
sleep 1
kill -0 "$(cat "$service_dir/service.pid")"
echo "RID service PID: $(cat "$service_dir/service.pid"); data: $run"
echo 'Board clock may be inaccurate; the PC bridge uses monotonic data age.'
iw dev sdr0 info
