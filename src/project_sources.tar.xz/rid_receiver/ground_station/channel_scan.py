"""Persistent passive scan coordination; each board's IQ owner performs its retune."""
import copy
import json
from pathlib import Path
import sys
import threading
import time
from urllib.request import build_opener,ProxyHandler,Request
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from wifi_channels import CHANNELS,CHANNELS_24,CHANNELS_5,channel_frequency

MODES=('combined','2.4','5','fixed')

def validate_config(value):
    if not isinstance(value,dict) or set(value)!={'mode','channel','dwellSeconds'}:raise ValueError('Expected mode, channel and dwellSeconds')
    if not isinstance(value['mode'],str) or value['mode'] not in MODES:raise ValueError('Unknown scan mode')
    channel_frequency(value['channel'])
    dwell=value['dwellSeconds']
    if type(dwell) not in (int,float) or not 2<=dwell<=10:raise ValueError('Dwell must be 2..10 seconds')
    return dict(mode=value['mode'],channel=value['channel'],dwellSeconds=float(dwell))

def scan_plan(mode,channel=6):
    if mode=='fixed':return [channel]
    if mode=='2.4':return [6]+[c for c in CHANNELS_24 if c!=6]
    if mode=='5':return list(CHANNELS_5)
    # Alternate bands; revisit channel 6 after four other frequencies.
    low=[c for c in CHANNELS_24 if c!=6];high=list(CHANNELS_5);plan=[6]
    for i in range(max(len(low),len(high))):
        for values in (high,low):
            if i<len(values):
                if len(plan)%5==0:plan.append(6)
                plan.append(values[i])
    return plan

class ChannelScanner:
    def __init__(self,urls,path,selection=None):
        self.urls=urls;self.path=Path(path);self.selection=selection
        self.lock=threading.RLock();self.operation=threading.Lock()
        self.opener=build_opener(ProxyHandler({}));self.current=None;self.index=0;self.due=0
        self.state='waiting';self.error=None;self.boards={};self.visited={};self.cycles=0;self.revision=0
        self.config=validate_config(json.loads(self.path.read_text(encoding='utf8')) if self.path.exists() else dict(mode='fixed',channel=6,dwellSeconds=3))
    def configure(self,value):
        config=validate_config(value)
        if not self.operation.acquire(False):raise ValueError('Channel switch in progress; retry shortly')
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True);tmp=self.path.with_suffix('.tmp')
            tmp.write_text(json.dumps(config,indent=2)+'\n',encoding='utf8');tmp.replace(self.path)
            with self.lock:
                self.config=config;self.index=0;self.current=None;self.due=0;self.state='waiting';self.revision+=1;self.error=None;self.visited={};self.cycles=0
        finally:self.operation.release()
        return self.snapshot()
    def request(self,station,channel):
        request=Request(self.urls[station]+'/api/iq/channel',data=json.dumps(dict(channel=channel)).encode(),headers={'Content-Type':'application/json'})
        with self.opener.open(request,timeout=10) as response:value=json.loads(response.read(16384))
        if value.get('accepted') is not True or value.get('channel')!=channel or value.get('frequencyMhz')!=channel_frequency(channel):raise ValueError('Board did not acknowledge RF readback')
        return value
    def tick(self):
        if time.monotonic()<self.due or not self.operation.acquire(False):return False
        try:
            if not self.urls:return False
            selected=self.selection.snapshot() if self.selection else None
            primary=selected.get('selectedStation') if selected else next(iter(self.urls))
            if selected and not selected.get('confirmed'):
                with self.lock:self.state='waiting_receiver';self.error='等待接收站分工确认';self.due=time.monotonic()+1
                return False
            with self.lock:
                plan=scan_plan(self.config['mode'],self.config['channel'])
                channel=plan[self.index%len(plan)];self.state='tuning';self.error=None
            previous=copy.deepcopy(self.boards);old_channel=self.current
            results={};errors={}
            # Full decoder first; other station may be offline without stopping detection.
            for station in [primary]+[s for s in self.urls if s!=primary]:
                try:results[station]=self.request(station,channel)
                except Exception as exc:errors[station]=str(exc)
            with self.lock:
                self.boards={s:dict(**results[s],error=None) if s in results else dict(error=errors.get(s)) for s in self.urls}
                if primary not in results:
                    self.state='error';self.current=None;self.error='检测站切频未确认：'+errors.get(primary,'未配置');self.due=time.monotonic()+5
                    return True
                self.current=channel;self.state='receiving';self.error=None
                self.visited[channel]=dict(timestamp=time.time()*1000,stations=sorted(results))
                self.index+=1
                if self.config['mode']!='fixed' and self.index%len(plan)==0:self.cycles+=1
                self.due=time.monotonic()+(self.config['dwellSeconds'] if self.config['mode']!='fixed' else 5)
            return old_channel!=channel or any(previous.get(s,{}).get('sessionId')!=v.get('sessionId') for s,v in results.items())
        finally:self.operation.release()
    def snapshot(self):
        with self.lock:
            return dict(**self.config,state=self.state,currentChannel=self.current,
                frequencyMhz=channel_frequency(self.current) if self.current else None,
                channels=sorted(set(scan_plan(self.config['mode'],self.config['channel']))),supportedChannels=sorted(CHANNELS),
                bands=['2.4 GHz','5 GHz'],simultaneous=False,bandwidthMhz=20,
                completedCycles=self.cycles,visited=copy.deepcopy(self.visited),stations=copy.deepcopy(self.boards),
                revision=self.revision,error=self.error,partialErrors={s:v['error'] for s,v in self.boards.items() if v.get('error')})
