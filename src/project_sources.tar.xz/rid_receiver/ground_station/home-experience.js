// Procedural point-cloud artwork, independent of all hardware observations.
export function setupHome(){
 const page=document.querySelector('[data-page="home"]'),heading=page.querySelector('h1'),stage=page.querySelector('.system-diagram');
 heading.innerHTML='<span class="hero-line">空域知微</span>';
 heading.setAttribute('aria-label','空域知微');
 page.querySelector('.lead').textContent='无人机侦测定位系统';
 page.querySelector('.kicker').textContent='让信号可见，让空域可知';
 stage.innerHTML='<canvas id="home-field" tabindex="0" aria-label="拖动或使用方向键旋转点云，上拖切换俯视；非实测数据"></canvas><div class="field-reticle"><i></i><i></i><i></i><i></i></div>';
 const actions=document.createElement('div');actions.className='hero-actions';actions.append(page.querySelector('.home-heading .primary'),page.querySelector('.home-heading .text-link'));page.querySelector('.lead').after(actions);
 const note=page.querySelector('.home-note'),description=document.getElementById('home-description'),geometry=document.getElementById('home-geometry');
 const more=document.createElement('details');more.className='home-system-info';more.innerHTML='<summary>运行信息</summary>';more.append(description,geometry);note.append(more);
 const band=document.createElement('section');band.className='home-workflow-caption';band.setAttribute('aria-label','系统构建：四级处理流程');band.innerHTML='<span class="workflow-prefix">系统构建：</span><ol class="workflow-line"><li><span>检测采集</span><i class="workflow-connector" aria-hidden="true"></i></li><li><span>特征识别</span><i class="workflow-connector" aria-hidden="true"></i></li><li><span>身份解析</span><i class="workflow-connector" aria-hidden="true"></i></li><li><span>测向定位</span></li></ol>';page.querySelector('.home-heading').append(band);
 const canvas=document.getElementById('home-field');if(!canvas.getContext)return {activate(){}};
 let ctx;try{ctx=canvas.getContext('2d');}catch{return {activate(){}};}if(!ctx)return {activate(){}};
 const reduced=globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches??false;
 let active=false,raf=0,width=600,height=480,last=0;
 const initialView={yaw:.4,pitch:.92};
 let yaw=initialView.yaw,pitch=initialView.pitch,drag=null,seed=6071;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const cloud=[];
 function point(x,y,z,kind=0){cloud.push({x:x+(random()-.5)*.018,y:y+(random()-.5)*.012,z:z+(random()-.5)*.018,kind,light:.45+random()*.55});}
 function line(a,b,count,kind=0){for(let i=0;i<count;i++){const f=i/(count-1);point(...a.map((v,k)=>v+(b[k]-v)*f),kind);}}
 function block(x,z,w,d,h){
  for(let i=0;i<460;i++){const u=random(),v=random(),side=i%5;
   if(side===0)point(x+u*w,h,z+v*d);
   else if(side===1)point(x+u*w,v*h,z);
   else if(side===2)point(x+u*w,v*h,z+d);
   else point(x+(side===3?0:w),v*h,z+u*d);
  }
  for(const dx of [0,w])for(const dz of [0,d])line([x+dx,0,z+dz],[x+dx,h,z+dz],32,1);
  for(const dz of [0,d])line([x,h,z+dz],[x+w,h,z+dz],30,1);
  for(const dx of [0,w])line([x+dx,h,z],[x+dx,h,z+d],25,1);
 }
 function structure(x,z,w,d,h){
  const lean=(random()-.5)*.18,phase=random()*6.28;
  // Broken facade patches with gaps, scattered edges and uneven roof fragments.
  // No solid perimeter or exact corner lines: the city stays a background texture.
  for(let i=0;i<860;i++){
   const side=i%4,u=random(),v=random();
   if(Math.sin(u*8+v*9+phase)+Math.cos(v*13-side)>.85||random()<.13)continue;
   const taper=1-v*.14,warp=Math.sin(v*11+side+phase)*.045+(random()-.5)*.07;
   let px=side<2?(u-.5)*w*taper:(side===2?-.5:.5)*w*taper;
   let pz=side<2?(side===0?-.5:.5)*d*taper:(u-.5)*d*taper;
   px+=lean*v+warp;pz+=Math.sin(v*7+phase)*.05;
   point(x+w/2+px,v*h*(.9+.08*Math.sin(u*5+phase)),z+d/2+pz);
   if(i%11===0)point(x+w/2+px+(random()-.5)*.3,v*h,z+d/2+pz+(random()-.5)*.3,4);
  }
  for(let i=0;i<95;i++){
   const u=random(),v=random();if(u+v>1.3||random()<.2)continue;
   point(x+u*w+lean,h*(.82+random()*.12),z+v*d,4);
  }
 }
 for(let i=0;i<950;i++)point((random()-.5)*5.9,.005,(random()-.5)*3.9,2);
 structure(-2.25,-1.35,.8,.75,1.08);structure(-1.25,-1.55,.62,.8,1.85);
 structure(.95,-1.45,1.05,.7,1.28);structure(2.12,-.5,.48,.68,.72);
 structure(-2.12,.7,.6,.7,.38);structure(.65,.75,.9,.55,.28);
 // Small quadrotor silhouette above the open centre of the scene.
 const aircraftStart=cloud.length;
 block(-.17,-.15,.34,.3,.16);
 const flightY=1.45;
 for(const p of cloud.slice(aircraftStart))p.y+=flightY;
 for(const x of [-.38,.38])for(const z of [-.31,.31]){
  line([0,flightY+.08,0],[x,flightY+.08,z],35,3);
  for(let i=0;i<90;i++){const a=i/90*Math.PI*2;point(x+Math.cos(a)*.17,flightY+.09,z+Math.sin(a)*.17,3);}
 }
 for(const x of [-.95,.95]){
  block(x-.07,.45,.14,.14,.17);
  for(const dx of [-.045,.045])line([x+dx,.17,.52],[x+dx,.48,.52],22,3);
 }
 const palette=['#25c6d3','#2ce0c6','#65e7ab','#bee98c','#f4d98a','#ffe9bd'];
 let camera={scale:100,cx:300,cy:300};
 const extent=cloud.concat([[-3,0,-2],[3,0,-2],[-3,0,2],[3,0,2]].map(([x,y,z])=>({x,y,z})));
 function fitCamera(){
  let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
  const c=Math.cos(yaw),s=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
  for(const p of extent){const x=p.x*c+p.z*s,z=p.z*c-p.x*s,y=p.y*cp-z*sp,k=10/(10-z*cp-p.y*sp),sx=x*k,sy=-y*k;minX=Math.min(minX,sx);maxX=Math.max(maxX,sx);minY=Math.min(minY,sy);maxY=Math.max(maxY,sy);}
  const left=width*(width<900?.04:.42),right=width*(width<900?.97:.99),top=height*.13,bottom=height*.86,scale=Math.min((right-left)/(maxX-minX),(bottom-top)/(maxY-minY));
  camera={scale,cx:(left+right)/2-(minX+maxX)/2*scale,cy:(top+bottom)/2-(minY+maxY)/2*scale};
 }
 function resize(){const box=stage.getBoundingClientRect();width=Math.max(300,box.width);height=Math.max(300,box.height);const ratio=Math.min(globalThis.devicePixelRatio||1,2);canvas.width=width*ratio;canvas.height=height*ratio;canvas.style.width=width+'px';canvas.style.height=height+'px';ctx.setTransform(ratio,0,0,ratio,0,0);
  fitCamera();
  if(reduced||!active)draw(performance.now());}
 function draw(now){
  ctx.clearRect(0,0,width,height);ctx.shadowBlur=0;ctx.lineWidth=1;
  const t=reduced?2:now*.001,c=Math.cos(yaw),s=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
  const {scale,cx,cy}=camera;
  function project(x,y,z){const rx=x*c+z*s,rz=z*c-x*s,ry=y*cp-rz*sp,depth=rz*cp+y*sp,k=10/(10-depth);return {x:cx+rx*scale*k,y:cy-ry*scale*k,k,depth};}
  function path(vertices,color,lineWidth=1){ctx.strokeStyle=color;ctx.lineWidth=lineWidth;ctx.beginPath();vertices.forEach((v,i)=>{const p=project(...v);if(i)ctx.lineTo(p.x,p.y);else ctx.moveTo(p.x,p.y);});ctx.stroke();}
  for(let x=-3;x<=3.01;x+=.25)path([[x,-.025,-2],[x,-.025,2]],`rgba(57,151,171,${Math.abs(x%1)<.01?.23:.1})`);
  for(let z=-2;z<=2.01;z+=.25)path([[-3,-.025,z],[3,-.025,z]],`rgba(57,151,171,${Math.abs(z%1)<.01?.23:.1})`);
  const scanX=(t*.55%6)-3;
  const visible=cloud.map(p=>({...project(p.x,p.y,p.z),p})).sort((a,b)=>a.depth-b.depth);
  for(const {x,y,k,p} of visible){
   if(x<0||x>width||y<0||y>height)continue;
   const hit=Math.max(0,1-Math.abs(p.x-scanX)/.22),dim=p.kind===4?.29:.65;
   ctx.globalAlpha=Math.min(1,p.light*dim+hit*.48);
   ctx.fillStyle=hit>.45?'#d6fff2':p.kind===3?'#a9f6ed':palette[Math.min(5,Math.max(0,Math.floor(p.y/2*6)))];
   ctx.beginPath();ctx.arc(x,y,Math.max(.55,(p.kind===1?1.2:.85)*k),0,Math.PI*2);ctx.fill();
  }
  ctx.globalAlpha=1;
  for(const [i,x] of [-.95,.95].entries()){
   const p=project(x,.15,.52);ctx.fillStyle=i?'#e0b57e':'#84ddd9';ctx.font='500 14px "Source Han Sans SC", sans-serif';ctx.fillText?.(i?'B':'A',p.x-4,p.y+20);
   path([[x,.48,.52],[0,flightY,0]],i?'rgba(225,184,121,.3)':'rgba(114,231,211,.3)',.8);
  }
 }
 function loop(now){if(!active||document.hidden)return;if(now-last>32){last=now;draw(now);}raf=requestAnimationFrame(loop);}
 function release(){drag=null;canvas.classList.remove('is-dragging');}
 function changeView(nextYaw,nextPitch){yaw=nextYaw;pitch=Math.min(1.48,Math.max(.3,nextPitch));fitCamera();if(reduced||!active)draw(performance.now());}
 canvas.addEventListener('pointerdown',event=>{if(event.button!=null&&event.button!==0)return;drag={x:event.clientX,y:event.clientY,yaw,pitch};canvas.setPointerCapture?.(event.pointerId);canvas.classList.add('is-dragging');});
 canvas.addEventListener('pointermove',event=>{if(drag)changeView(drag.yaw+(event.clientX-drag.x)*.004,drag.pitch-(event.clientY-drag.y)*.004);});
 canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);canvas.addEventListener('lostpointercapture',release);
 canvas.addEventListener('keydown',event=>{const step=.09;if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Home'].includes(event.key))return;event.preventDefault();if(event.key==='Home')changeView(initialView.yaw,initialView.pitch);else changeView(yaw+(event.key==='ArrowRight'?step:event.key==='ArrowLeft'?-step:0),pitch+(event.key==='ArrowUp'?step:event.key==='ArrowDown'?-step:0));});
 new ResizeObserver(resize).observe(stage);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){release();globalThis.cancelAnimationFrame?.(raf);}else if(active&&!reduced)raf=requestAnimationFrame(loop);});
 return {activate(value){if(active===value)return;active=value;globalThis.cancelAnimationFrame?.(raf);if(active){resize();if(!reduced)raf=requestAnimationFrame(loop);}else release();}};
}
