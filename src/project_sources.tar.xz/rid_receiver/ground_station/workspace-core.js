export const R=6378137;
export const finite=v=>typeof v==='number'&&Number.isFinite(v);
export function fieldNumber(text,nullable=false){if(String(text).trim()===''){if(nullable)return null;throw new Error('请填写完整数值');}const v=Number(text);if(!finite(v))throw new Error('请输入有效数字');return v;}
export const normalized=v=>((v%360)+360)%360;
export function geographic(anchor,x,y){if(!anchor||!finite(x)||!finite(y))return null;return [anchor.latitude+y/R*180/Math.PI,anchor.longitude+x/(R*Math.cos(anchor.latitude*Math.PI/180))*180/Math.PI];}
export function local(anchor,lat,lon){if(!anchor)throw new Error('请先设置共享坐标原点');if(!finite(lat)||!finite(lon)||Math.abs(lat)>85||Math.abs(lon)>180)throw new Error('经纬度超出范围');return [(lon-anchor.longitude)*Math.PI/180*R*Math.cos(anchor.latitude*Math.PI/180),(lat-anchor.latitude)*Math.PI/180*R];}
export function freshStation(station,feed,mode,clock=Date.now()){return !!station&&station.fresh!==false&&finite(station.relativeAngle)&&!!feed&&clock-(station.timestamp??feed.timestamp)<15000&&!station.error;}
export function phaseStationFresh(station,feed,mode,clock=Date.now()){
  if(!station||!feed||station.fresh===false||station.error||!finite(station.phaseDeg))return false;
  const age=clock-(station.timestamp??feed.timestamp);
  return finite(age)&&age>=-2000&&age<15000&&(mode!=='external'||station.sourceVerified===true&&station.freshnessVerified===true);
}
export const phaseStateLabel=station=>station?.signalQuality?.accepted===false?'测向中／信号质量不足':station?.referenceError||station?.referenceMatched===false?'测向中／参考失效':station?.calibrationRequired?'测向中／待参考':'相位有效／角度待确认';
export function statistics(rows){const values=rows.filter(finite);if(!values.length)return {n:0,mean:null,std:null};const mean=values.reduce((a,b)=>a+b,0)/values.length;return {n:values.length,mean,std:Math.sqrt(values.reduce((a,b)=>a+(b-mean)**2,0)/values.length)};}
export function intersectionReady(feed,mode,clock,connected){
  return !!feed?.intersection&&pairReady(feed,mode,clock,connected);
}
export function pairReady(feed,mode,clock,connected){
  if(!connected||!Array.isArray(feed?.stations)||feed.stations.length<2)return false;
  const [a,b]=feed.stations;if(![a,b].every(s=>freshStation(s,feed,mode,clock)))return false;
  const ta=a.targetId||feed.targetId,tb=b.targetId||feed.targetId;if(!ta||ta!==tb)return false;
  if(a.frameKey&&b.frameKey&&a.frameKey!==b.frameKey)return false;
  if(finite(a.timestamp)&&finite(b.timestamp)&&Math.abs(a.timestamp-b.timestamp)>2000)return false;
  return true;
}
export function intersectionPoints(feed,mode,clock,connected){
  if(!pairReady(feed,mode,clock,connected))return [];
  return Array.isArray(feed.intersections)&&feed.intersections.length?feed.intersections:feed.intersection?[feed.intersection]:[];
}
export function midpointCoordinates(feed,point){
  if(!finite(point?.xM)||!finite(point?.yM))return null;
  const stations=feed?.stations||[];
  const origin=finite(feed?.midpoint?.xM)&&finite(feed?.midpoint?.yM)?feed.midpoint:stations.length>=2&&stations.slice(0,2).every(s=>finite(s.xM)&&finite(s.yM))?{xM:(stations[0].xM+stations[1].xM)/2,yM:(stations[0].yM+stations[1].yM)/2}:null;
  return origin?{xM:point.xM-origin.xM,yM:point.yM-origin.yM}:null;
}
export function bearingsForStation(station,mode='front'){
  if(!finite(station?.bearing))return [];
  if(mode!=='full')return [{bearingDeg:station.bearing,branch:'front'}];
  if(station.bearingCandidates?.length)return station.bearingCandidates;
  if(!finite(station.relativeAngle)||!finite(station.headingDeg))return [{bearingDeg:station.bearing,branch:'provided'}];
  const front=normalized(station.headingDeg+station.relativeAngle),back=normalized(station.headingDeg+180-station.relativeAngle);
  return Math.abs(normalized(front-back+180)-180)<1e-8?[{bearingDeg:front,branch:'front'}]:[{bearingDeg:front,branch:'front'},{bearingDeg:back,branch:'back'}];
}
export function relativePlacement(a,b,reference='a-forward'){
  if(!a||!b||![a.xM,a.yM,b.xM,b.yM].every(finite))return null;
  if(reference==='a-forward'&&!finite(a.headingDeg))return null;
  const dx=b.xM-a.xM,dy=b.yM-a.yM;
  return {distanceM:Math.hypot(dx,dy),angleDeg:normalized(Math.atan2(dx,dy)*180/Math.PI-(reference==='a-forward'?a.headingDeg:0))};
}
export function relativePosition(a,distanceM,angleDeg,reference='a-forward'){
  if(!a||![a.xM,a.yM,distanceM,angleDeg].every(finite)||distanceM<.05||distanceM>100000)throw new Error('请填写有效A站位置和0.05至100000米距离');
  if(!['a-forward','north'].includes(reference))throw new Error('参考方向无效');
  if(reference==='a-forward'&&!finite(a.headingDeg))throw new Error('请先设置A站正前方朝向，或使用北向角度');
  const rad=(angleDeg+(reference==='a-forward'?a.headingDeg:0))*Math.PI/180;
  return {xM:a.xM+distanceM*Math.sin(rad),yM:a.yM+distanceM*Math.cos(rad)};
}
export const esc=v=>String(v??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const fmt=(v,d=1)=>finite(v)?v.toFixed(d):'—';
export const time=v=>finite(v)?new Date(v).toLocaleTimeString('zh-CN',{hour12:false}):'—';
export function validateRecording(value){
  if(value?.schema!=='airspace.observations'||value.version!==1||!Array.isArray(value.samples)||!value.samples.length||value.samples.length>6000)throw new Error('需要版本1的平台观测记录，最多6000条');
  const samples=structuredClone(value.samples);
  for(const s of samples){if(!['rid','doa'].includes(s.type)||!s.data||!finite(s.data.timestamp)||Math.abs(s.data.timestamp)>8e15||typeof s.data.source!=='string'||s.data.source.length>500||s.data.demo!==false)throw new Error('记录格式或时间戳无效');
    if(s.type==='rid'&&(typeof s.data.id!=='string'||!s.data.id||s.data.id.length>256))throw new Error('RID记录缺少有效ID');
    if(s.type==='doa'&&(!Array.isArray(s.data.stations)||s.data.stations.length>16))throw new Error('DOA站点记录无效');
    if(s.type==='doa')for(const st of s.data.stations)if(st.relativeAngle!=null&&(!finite(st.relativeAngle)||Math.abs(st.relativeAngle)>90))throw new Error('记录相对角超出前半平面');
    s.data.demo=false;s.data.replay=true;
  }
  samples.sort((a,b)=>a.data.timestamp-b.data.timestamp);return {schema:value.schema,version:1,samples};
}
export function download(name,value){const blob=new Blob([JSON.stringify(value,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export async function readJSON(file){if(!file||file.size>8*1024*1024)throw new Error('请选择不超过8 MiB的JSON文件');return JSON.parse(await file.text());}
export async function jsonFetch(url,options={}){const response=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(7000),...options});if(!response.ok){let message=`接口失败 HTTP ${response.status}`;if(response.status===409)message='配置已被其他窗口修改，请重新载入后再保存';throw new Error(message);}return response.json();}
