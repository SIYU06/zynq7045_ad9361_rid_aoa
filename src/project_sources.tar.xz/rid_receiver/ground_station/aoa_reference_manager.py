"""Known-position reference library; boards provide source-verified phase results."""
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import threading
import time
import uuid
from datetime import datetime, timezone

sys.path.insert(0,str(Path(__file__).resolve().parent.parent))

from station_config import LOCK, atomic, document, revision, validate_patch
from reference_calibration import C, STATUS, validate_reference,load_reference,validate_geometry
from board_doa import default_context, context_hash, validate_observation,context_from_setup
from wifi_channels import CHANNELS, channel_frequency


def number(value, name, low, high):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError('%s需在%s至%s之间' % (name, low, high))
    return float(value)


def wrap(value):
    return (value + 180) % 360 - 180


def settings(value, config):
    if not isinstance(value, dict):
        raise ValueError('基准参数需为对象')
    channel = value.get('channel', 6)
    frequency = channel_frequency(channel)
    result = dict(channel=channel, frequencyMhz=frequency,
        name=str(value.get('name', '')).strip()[:80],
        baselineM=number(value.get('baselineM', 2.8), '两站间距/m', .05, 1000),
        forwardM=number(value.get('forwardM', 3), '参考源前向距离/m', .1, 10000),
        lateralM=number(value.get('lateralM', 0), '参考源右向偏移/m', -10000, 10000),
        headingDeg=number(value.get('headingDeg', 0), '共同正前方朝向/°', -3600, 3600) % 360,
        aSide=value.get('aSide', 'right'),
        maxSpreadDeg=number(value.get('maxSpreadDeg', 5), '最大相位离散/°', .1, 30),
        reuseAcrossRestarts=value.get('reuseAcrossRestarts', True))
    if result['aSide'] not in ('right', 'left') or type(result['reuseAcrossRestarts']) is not bool:
        raise ValueError('站点左右顺序或复用选项无效')
    for key, default, low, high in (('sampleCount', 20, 10, 100), ('timeoutSeconds', 90, 15, 180)):
        val=value.get(key, default)
        if type(val) is not int or not low <= val <= high:
            raise ValueError('%s需为%s至%s的整数' % (key, low, high))
        result[key]=val
    mac=value.get('referenceMac', '')
    if not isinstance(mac,str):raise ValueError('参考源MAC需为文本')
    mac=mac.strip().lower()
    if mac and (not re.fullmatch(r'(?:[0-9a-f]{2}:){5}[0-9a-f]{2}', mac)
                or int(mac[:2], 16) & 1 or mac=='00:00:00:00:00:00'):
        raise ValueError('参考源MAC需为完整的单播MAC')
    result['referenceMac']=mac
    stations={s['id']:s for s in config.get('stations', [])}
    if not all(s in stations for s in ('A', 'B')):
        raise ValueError('需先配置A、B两站')
    for station in ('A', 'B'):
        key='bearingSign'+station
        sign=value.get(key, 1)
        if type(sign) is not int or sign not in (-1, 1):
            raise ValueError('角度方向符号仅支持+1或-1')
        result[key]=sign
        result['spacing'+station+'M']=number(stations[station].get('antennaSpacingM'), station+'站天线中心距/m', .001, 1)
    if not result['name']:
        result['name']='信道%s · %s米站距 / 前向%s米' % (channel, result['baselineM'], result['forwardM'])
    return result


def geometry(params, config):
    stations={s['id']:s for s in config['stations']}
    mid={axis:sum(number(stations[s].get(axis), s+'站位置', -100000, 100000) for s in ('A', 'B'))/2 for axis in ('xM', 'yM')}
    angle=math.radians(params['headingDeg'])
    right=(math.cos(angle), -math.sin(angle));forward=(math.sin(angle), math.cos(angle))
    source={axis:mid[axis]+params['lateralM']*right[i]+params['forwardM']*forward[i] for i,axis in enumerate(('xM','yM'))}
    result={};warnings=[]
    for station in ('A','B'):
        side=(1 if station=='A' else -1)*(1 if params['aSide']=='right' else -1)
        setup=dict(stations[station],headingDeg=params['headingDeg'],antennaSpacingM=params['spacing'+station+'M'])
        for i,axis in enumerate(('xM','yM')):
            setup[axis]=mid[axis]+side*params['baselineM']/2*right[i]
        known=wrap(math.degrees(math.atan2(source['xM']-setup['xM'],source['yM']-setup['yM']))-params['headingDeg'])
        if abs(known)>80:
            raise ValueError(station+'站参考角超过±80°，请增加前向距离或减小横向偏移')
        if setup['antennaSpacingM']>=C/(params['frequencyMhz']*1e6)/2:
            warnings.append(station+'站天线间距达到半波长，当前频率可能出现多个角度解；单点基准无法消除空间模糊')
        expected=360*params['frequencyMhz']*1e6/C*setup['antennaSpacingM']*math.sin(math.radians(known)/params['bearingSign'+station])
        result[station]=dict(setup=setup,knownAngleDeg=known,expectedPhaseDeg=expected)
    return dict(midpoint=mid,source=source,stations=result,warnings=warnings)


def phase_statistics(values):
    if not values:
        raise ValueError('没有有效相位样本')
    vector=sum(complex(math.cos(math.radians(v)),math.sin(math.radians(v))) for v in values)/len(values)
    mean=math.degrees(math.atan2(vector.imag,vector.real))
    spread=math.degrees(math.sqrt(max(0,-2*math.log(max(abs(vector),1e-15)))))
    return dict(meanDeg=mean,spreadDeg=spread,resultantLength=abs(vector),samples=len(values))


def build_reference(station, params, layout, samples, metadata, session):
    if len(samples)<params['sampleCount']:
        raise ValueError(station+'站有效样本不足')
    values=[r['observation']['rawPhaseDeg'] for r in samples]
    stats=phase_statistics(values)
    halves=[phase_statistics(values[:len(values)//2]),phase_statistics(values[len(values)//2:])]
    drift=abs(wrap(halves[0]['meanDeg']-halves[1]['meanDeg']))
    stats['halfDriftDeg']=drift
    if stats['spreadDeg']>params['maxSpreadDeg'] or drift>params['maxSpreadDeg']:
        raise ValueError('%s站相位不稳定：离散%.2f°，前后半组漂移%.2f°，上限%.2f°' % (station,stats['spreadDeg'],drift,params['maxSpreadDeg']))
    if max(r['monotonic'] for r in samples)-min(r['monotonic'] for r in samples)<2:
        raise ValueError(station+'站样本时间跨度不足2秒，请重试')
    item=layout['stations'][station];setup=item['setup'];capture=copy.deepcopy(metadata)
    ref=dict(status=STATUS,station_id=station,phase_estimator='ofdm_ltf_unit_bins_v1',
        phase_bias_deg=wrap(stats['meanDeg']-item['expectedPhaseDeg']),bearing_sign=params['bearingSign'+station],
        known_angle_deg=item['knownAngleDeg'],reference_mac=params['referenceMac'],reference_id=params['name'],
        capture_session_id=session,capture_metadata=capture,fixed_gain_profile=copy.deepcopy(capture.get('fixed_gain_profile')),
        station_geometry={k:setup[k] for k in ('antennaSpacingM','xM','yM','headingDeg')},
        accepted_for_production_bearing=False,independent_nonzero_angles_validated=False,
        repeatability_check_passed=None,stationarity_check_passed=True,training_statistics=stats,
        evidence=[{k:r[k] for k in ('index','tsf','sha256','monotonic')} for r in samples])
    if params['reuseAcrossRestarts']:
        ref.update(reuse_policy='operator_fixed_outdoor_reference',operator_authorized_reuse=True,
            fixed_reference_geometry=dict(baseline_m=params['baselineM'],source_forward_from_midpoint_m=params['forwardM'],
                source_right_from_midpoint_m=params['lateralM'],A_side=params['aSide'],operator_assumed=True))
    validate_reference(ref,setup,dict(sessionId=session),metadata)
    return ref


class AOAReferenceManager:
    def __init__(self,pipeline,scanner,doa,root):
        self.pipeline=pipeline;self.scanner=scanner;self.doa=doa;self.root=Path(root)
        self.path=doa.path.with_name('aoa_reference_profiles.json')
        self.runtime_path=doa.path.with_name('aoa_reference_runtime.json')
        self.recovery_path=doa.path.with_name('aoa_reference_operation.json')
        self.lock=threading.RLock();self.operation=threading.Lock();self.cancel=threading.Event()
        self.job=dict(state='idle',message='选择信道并填写参考源位置后，可预览、保存参数或采集基准')
        self.pipeline.reference_manager=self
        # Actual calibration paths are authoritative. A stale library selection
        # must never replace or invalidate an explicitly restored default.
        if not self.recovery_path.exists() and self.using_default():
            lib=self.library()
            if lib.get('activeId') is not None:
                lib['activeId']=None;atomic(self.path,lib)
        if self.recovery_path.exists():
            self.job=dict(state='recovery_required',message='上次基准操作未完成恢复，请先恢复原测向状态')
            self.pipeline.reference_capture=True
        elif self.runtime_path.exists() and not self.using_default():
            for setup in self.doa.config().get('stations',[]):
                ref,digest=load_reference(setup,self.root)
                saved=self.runtime().get('stations',{}).get(setup['id'],{})
                if ref and saved.get('referenceHash')==digest and saved.get('valid') is False:
                    self.job=dict(state='needs_verification',message='当前旧基准尚未通过当前会话原位核验；旧文件保留，暂不输出套用旧偏置的角度')
                    break

    def library(self):
        if not self.path.exists():return dict(version=1,profiles=[],activeId=None)
        if self.path.stat().st_size>16*1024*1024:raise ValueError('基准库文件过大')
        return json.loads(self.path.read_text(encoding='utf8'))

    def using_default(self):
        stations=self.doa.config().get('stations',[])
        return len(stations)==2 and {s['id'] for s in stations}=={'A','B'} and all(
            (self.root/s.get('calibration','')).resolve()==(self.path.parent/('aoa_calibration_'+s['id']+'.json')).resolve()
            for s in stations)

    def default_profile(self):
        """Describe the original files without importing or rewriting them."""
        config=self.doa.config();refs={}
        for setup in config['stations']:
            ref,_=load_reference(dict(setup,calibration=(self.path.parent/('aoa_calibration_'+setup['id']+'.json')).relative_to(self.root).as_posix()),self.root)
            if not ref:raise ValueError('默认基准文件缺失')
            refs[setup['id']]=ref
        if set(refs)!={'A','B'}:raise ValueError('默认基准需要A/B两站')
        a=refs['A'];fixed=a.get('fixed_reference_geometry',{})
        channels={next((c for c in CHANNELS if abs(channel_frequency(c)-ref.get('capture_metadata',{}).get('rf_hz',0)/1e6)<.01),None) for ref in refs.values()}
        if len(channels)!=1 or None in channels:raise ValueError('默认基准两站频率不一致或不支持')
        params=settings(dict(name='默认基准',channel=channels.pop(),baselineM=fixed.get('baseline_m',2.8),
            forwardM=fixed.get('source_forward_from_midpoint_m',3),lateralM=fixed.get('source_right_from_midpoint_m',0),
            aSide=fixed.get('A_side','right'),headingDeg=a['station_geometry']['headingDeg'],referenceMac=a['reference_mac'],
            bearingSignA=refs['A']['bearing_sign'],bearingSignB=refs['B']['bearing_sign']),config)
        for s in ('A','B'):params['spacing'+s+'M']=refs[s]['station_geometry']['antennaSpacingM']
        layout=geometry(params,config)
        for s,ref in refs.items():
            setup=layout['stations'][s]['setup'];setup.update(ref['station_geometry'])
            layout['stations'][s].update(knownAngleDeg=ref['known_angle_deg'],
                expectedPhaseDeg=360*params['frequencyMhz']*1e6/C*setup['antennaSpacingM']*math.sin(math.radians(ref['known_angle_deg'])/ref['bearing_sign']))
        return dict(id=None,name='默认基准',settings=params,geometry=layout,references=refs)

    def preview(self,value):
        config=self.doa.config();params=settings(value,config)
        return dict(settings=params,geometry=geometry(params,config))

    @staticmethod
    def reference_hash(reference):
        return hashlib.sha256(json.dumps(reference,sort_keys=True).encode()).hexdigest()

    def runtime(self):
        return json.loads(self.runtime_path.read_text(encoding='utf8')) if self.runtime_path.exists() else dict(version=1,stations={})

    def set_runtime(self,station,reference,session,valid,reason,**extra):
        with self.lock:
            state=self.runtime();record=dict(referenceHash=self.reference_hash(reference),sessionId=session,valid=valid,reason=reason,**extra)
            if state['stations'].get(station)!=record:
                state['stations'][station]=record;atomic(self.runtime_path,state)

    def observe_receiver(self,station,current):
        """File identity is independent of phase validity after RF-session changes."""
        setup=next(s for s in self.doa.config()['stations'] if s['id']==station)
        reference,digest=load_reference(setup,self.root)
        if not reference:return
        if self.using_default():return
        lib=self.library();profile=next((p for p in lib['profiles'] if p['id']==lib.get('activeId')),None)
        if not profile or not profile.get('references'):return
        saved=profile['references'].get(station)
        expected=profile.get('referenceHashes',{}).get(station)
        if saved is None or self.reference_hash(saved)!=digest or expected and expected!=digest:
            self.set_runtime(station,reference,current['sessionId'],False,'当前活动文件与选中基准内容不一致')
            return
        state=self.runtime().get('stations',{}).get(station,{})
        if state.get('referenceHash')==digest and state.get('sessionId')==current['sessionId']:
            return
        same=reference.get('capture_session_id')==current['sessionId']
        self.set_runtime(station,reference,current['sessionId'],same,
            '原采集会话' if same else '射频会话已变化；同频率、同增益不能证明原相位偏置仍适用')

    def begin_operation(self,kind,reference_mac=''):
        """Persist recovery information before the first hardware-changing request."""
        if self.recovery_path.exists():raise ValueError('前一基准操作尚未恢复，请先恢复原测向状态')
        if not self.scanner.operation.acquire(timeout=25):raise ValueError('等待已有切频结束超时')
        try:
            previous=dict(kind=kind,scan=copy.deepcopy(self.scanner.config),currentChannel=self.scanner.snapshot().get('currentChannel'),tasks={},fallbackMac=reference_mac,
                configuration=self.doa.config(),activeId=self.library().get('activeId'))
        finally:self.scanner.operation.release()
        observed_channels=set()
        for station,url in self.pipeline.url_by_station.items():
            status=self.pipeline.request(url+'/api/doa/status')
            frequency=status.get('metadata',{}).get('rf_hz',0)/1e6
            channel=next((c for c in CHANNELS if abs(channel_frequency(c)-frequency)<.01),None)
            if channel is None:raise ValueError(station+'站当前频率不在支持范围，无法建立安全恢复点')
            observed_channels.add(channel)
            previous['tasks'][station]=copy.deepcopy(status.get('task'))
        if len(observed_channels)!=1:raise ValueError('两站当前频率不一致，请先完成同步切频再采集基准')
        actual=next(iter(observed_channels))
        if previous['currentChannel'] is not None and actual!=previous['currentChannel']:raise ValueError('实际频率与扫描状态不同，请等待切频确认')
        previous['currentChannel']=actual
        atomic(self.recovery_path,previous)
        return previous

    def synchronize_contexts(self,channel,tasks,fallback_mac):
        for station,url in self.pipeline.url_by_station.items():
            current=self.pipeline.request(url+'/api/doa/status')
            self.observe_receiver(station,current)
            setup=next(s for s in self.doa.config()['stations'] if s['id']==station)
            context=context_from_setup(setup,self.root);digest=context_hash(context)
            task=tasks.get(station) or {}
            mac=task.get('mac') or (context.get('reference') or {}).get('reference_mac') or fallback_mac
            if not mac:raise ValueError(station+'站缺少恢复任务MAC；请检查原任务')
            ack=self.pipeline.request(url+'/api/iq/target',dict(mac=mac,frequencyMhz=channel_frequency(channel),leaseSeconds=1,directionContext=context))
            if ack.get('accepted') is not True or ack.get('contextHash')!=digest:
                raise ValueError(station+'站未确认恢复后的参考配置')

    def restore_operation(self,previous):
        """Restore actual RF and both reference contexts, not only scan JSON."""
        if previous.get('kind')=='activate':
            with LOCK:
                current=self.doa.config()
                if revision(current)!=revision(previous['configuration']):
                    if revision(current)!=previous.get('appliedRevision'):raise ValueError('布站在操作外发生变化，禁止盲目回滚')
                    atomic(self.doa.path,previous['configuration'])
                with self.lock:
                    lib=self.library()
                    if lib.get('activeId') not in (previous.get('activeId'),previous.get('appliedId')):raise ValueError('活动基准在操作外发生变化，禁止盲目回滚')
                    if lib.get('activeId')!=previous.get('activeId'):
                        lib['activeId']=previous.get('activeId');atomic(self.path,lib)
        channel=previous.get('currentChannel') or previous['scan']['channel']
        self.tune(channel)
        self.synchronize_contexts(channel,previous.get('tasks',{}),previous.get('fallbackMac'))
        # Restore scan mode only after the physical frequency and contexts agree.
        if previous['scan']['mode']!='fixed':self.scanner.configure(previous['scan'])
        if self.recovery_path.exists():self.recovery_path.unlink()

    def clear_measurements(self):
        self.pipeline.active=None;self.pipeline.angles.clear();self.pipeline.last_results.clear();self.pipeline.board_contexts.clear()
        getattr(self.pipeline,'cursors',{}).clear();self.pipeline.doa.set_diagnostic_target(None)

    def verify_samples(self,profile,samples,statuses):
        results={};passed=True
        for station in ('A','B'):
            ref=profile['references'][station];rows=samples[station]
            if len(rows)<self.job['sampleCount']:raise ValueError(station+'站核验样本不足')
            values=[r['observation']['rawPhaseDeg'] for r in rows];stats=phase_statistics(values)
            if max(r['monotonic'] for r in rows)-min(r['monotonic'] for r in rows)<2:raise ValueError(station+'站核验时间跨度不足')
            expected=wrap(ref['phase_bias_deg']+profile['geometry']['stations'][station]['expectedPhaseDeg'])
            delta=wrap(stats['meanDeg']-expected);limit=profile['settings']['maxSpreadDeg']
            valid=stats['spreadDeg']<=limit and abs(delta)<=limit
            results[station]=dict(**stats,savedMeanDeg=expected,phaseDifferenceDeg=delta,passed=valid)
            passed=passed and valid
        for station,result in results.items():
            self.set_runtime(station,profile['references'][station],statuses[station]['sessionId'],passed,
                '原位核验通过，旧基准内容未改变' if passed else '原位相位与旧基准不符；保持原始相位，禁止输出套用旧偏置的角度',verification=result)
        return passed,results

    def snapshot(self):
        with self.lock:
            lib=self.library();job=copy.deepcopy(self.job)
        profiles=[{k:v for k,v in p.items() if k!='references'} for p in lib['profiles']]
        sources=self.pipeline.snapshot().get('sources',[])
        default=self.using_default()
        active_id=None if default else lib.get('activeId')
        current=[];state=self.runtime();active=next((p for p in lib['profiles'] if p['id']==active_id),None);matches=[]
        for setup in self.doa.config().get('stations',[]):
            try:
                from direction_reference import load_reference
                ref,_=load_reference(setup,self.root)
                digest=self.reference_hash(ref) if ref else None
                approved=state.get('stations',{}).get(setup['id'],{})
                saved=active.get('references',{}).get(setup['id']) if active else None
                matches.append(bool(saved and self.reference_hash(saved)==digest))
                current.append(dict(station=setup['id'],frequencyMhz=ref.get('capture_metadata',{}).get('rf_hz',0)/1e6 if ref else None,name=ref.get('reference_id') if ref else None,
                    referenceHash=digest,sourcePath=setup.get('calibration'),phaseBiasDeg=ref.get('phase_bias_deg') if ref else None,
                    verification=approved if not default and approved.get('referenceHash')==digest else None))
            except (ValueError,OSError,KeyError):current.append(dict(station=setup['id'],name='参考读取失败'))
        last_verification={r['station']:r['verification']['verification'] for r in current if r.get('verification') and r['verification'].get('verification')}
        active_settings=active.get('settings') if active else None
        if default:
            try:active_settings=self.default_profile()['settings']
            except (ValueError,OSError,KeyError,TypeError):pass
        return dict(schema='airspace.aoa-reference',version=1,profiles=profiles,activeId=active_id,activeMode='default' if default else 'profile' if active else 'external',activeSettings=active_settings,job=job,lastVerification=last_verification,
            activeProfileName=active.get('name') if active else None,activeProfileCreatedAt=active.get('createdAt') if active else None,
            activeMatchesFiles=all(matches) if active and len(matches)==2 else None,recoveryRequired=self.recovery_path.exists() and job.get('state')=='recovery_required',
            channels=[dict(channel=c,frequencyMhz=channel_frequency(c),band='2.4' if c<=13 else '5') for c in sorted(CHANNELS)],
            sources=[dict(mac=s['mac'],ssid=s.get('ssid'),frequencyMhz=s['frequencyMhz'],fresh=s.get('fresh'),doaSupported=s.get('doaSupported')) for s in sources],
            currentReferences=current,scan=self.scanner.snapshot(),configuration=document(self.doa.path))

    def save_profile(self,params,layout,references=None):
        with self.lock:
            lib=self.library()
            if len(lib['profiles'])>=100:raise ValueError('基准库已满，请删除不用的配置')
            profile=dict(id=uuid.uuid4().hex,name=params['name'],createdAt=datetime.now(timezone.utc).isoformat(),
                settings=copy.deepcopy(params),geometry=copy.deepcopy(layout),references=references,
                status='captured' if references else 'draft',
                statistics={s:r['training_statistics'] for s,r in references.items()} if references else {},
                referenceHashes={s:self.reference_hash(r) for s,r in references.items()} if references else {})
            lib['profiles'].append(profile);atomic(self.path,lib)
            return profile

    def action(self,value):
        if not isinstance(value,dict):raise ValueError('请求需为对象')
        action=value.get('action')
        if action=='preview':return self.preview(value.get('settings',{}))
        if action=='cancel':self.cancel.set();return self.snapshot()
        if not self.operation.acquire(False):raise ValueError('基准任务正在执行，请完成或取消后重试')
        handed_off=False
        try:
            if action=='recover':
                if not self.recovery_path.exists():return self.snapshot()
                self.pipeline.reference_capture=True
                self.restore_operation(json.loads(self.recovery_path.read_text(encoding='utf8')))
                self.clear_measurements();self.pipeline.reference_capture=False
                self.job=dict(state='restored',message='原信道与两站参考配置已恢复；请查看当前基准核验状态')
                return self.snapshot()
            if self.recovery_path.exists():raise ValueError('上次操作恢复未完成，请先点击恢复原测向')
            if action=='restoreDefault':return self.activate(self.default_profile(),use_default=True)
            if action=='verify':
                with self.lock:
                    lib=self.library();profile=next((p for p in lib['profiles'] if p['id']==lib.get('activeId')),None)
                if not profile or profile.get('status')!='captured':raise ValueError('当前没有可核验的已采集基准')
                if value.get('physicalConfirmed') is not True:raise ValueError('请先将参考源放回当前基准原位并确认')
                supplied=settings(value.get('settings',{}),self.doa.config());saved=profile['settings']
                for key in ('channel','baselineM','forwardM','lateralM','headingDeg','aSide','referenceMac'):
                    if supplied[key]!=saved[key]:raise ValueError('请先载入当前基准参数，按原位置摆放后再核验')
                for station in ('A','B'):
                    setup=next(s for s in self.doa.config()['stations'] if s['id']==station)
                    validate_geometry(profile['references'][station],setup)
                    actual,digest=load_reference(setup,self.root)
                    if digest!=self.reference_hash(profile['references'][station]):raise ValueError('当前活动文件与保存的基准不一致')
                self.cancel.clear();self.job=dict(state='tuning',message='正在原位核验旧基准；不会修改保存的相位偏置',progress={s:0 for s in ('A','B')},sampleCount=supplied['sampleCount'])
                self.pipeline.reference_capture=True
                thread=threading.Thread(target=self.capture,args=(dict(settings=supplied,geometry=profile['geometry']),'verify',profile),daemon=True)
                thread.start();handed_off=True;return self.snapshot()
            if action in ('saveDraft','capture'):
                preview=self.preview(value.get('settings',{}))
                if action=='saveDraft':
                    self.save_profile(preview['settings'],preview['geometry']);return self.snapshot()
                if value.get('physicalConfirmed') is not True:raise ValueError('请先确认参考源位置、站间距、天线间距与输入一致')
                if not preview['settings']['referenceMac']:raise ValueError('请选择或输入参考源MAC')
                self.cancel.clear()
                self.job=dict(state='tuning',message='正在固定信道并等待两站确认',progress={s:0 for s in ('A','B')},sampleCount=preview['settings']['sampleCount'])
                self.pipeline.reference_capture=True
                thread=threading.Thread(target=self.capture,args=(preview,),daemon=True)
                thread.start();handed_off=True
                return self.snapshot()
            with self.lock:
                lib=self.library();profile=next((p for p in lib['profiles'] if p['id']==value.get('profileId')),None)
                if profile is None:raise ValueError('未找到所选基准')
            if action=='activate':return self.activate(profile)
            if action=='delete':
                if lib.get('activeId')==profile['id']:raise ValueError('当前应用的基准不能删除，请先应用另一份基准')
                with self.lock:
                    lib['profiles']=[p for p in lib['profiles'] if p['id']!=profile['id']];atomic(self.path,lib)
                return self.snapshot()
            raise ValueError('未知基准操作')
        finally:
            if not handed_off:self.operation.release()

    def tune(self,channel):
        if not self.scanner.operation.acquire(timeout=25):raise ValueError('切频忙，请稍后重试')
        self.scanner.operation.release()
        self.scanner.configure(dict(mode='fixed',channel=channel,dwellSeconds=self.scanner.config['dwellSeconds']))
        self.scanner.tick()
        scan=self.scanner.snapshot()
        if scan.get('state')!='receiving' or scan.get('currentChannel')!=channel or not all(scan.get('stations',{}).get(s,{}).get('accepted') is True for s in ('A','B')):
            raise ValueError('两站未同时确认所选信道：'+str(scan.get('partialErrors') or scan.get('error') or '等待设备连接'))

    def capture(self,preview,mode='capture',profile=None):
        params=preview['settings'];layout=preview['geometry'];previous=None
        initial_revision=document(self.doa.path)['revision']
        samples={s:[] for s in ('A','B')};statuses={};contexts={};cursors={};seen={s:set() for s in ('A','B')}
        try:
            # Wait for any pre-existing normal IQ request; the flag prevents new ones.
            with self.pipeline.iq_operation:pass
            self.pipeline.active=None;self.pipeline.angles.clear();self.pipeline.last_results.clear()
            self.pipeline.doa.set_diagnostic_target(None)
            previous=self.begin_operation(mode,params['referenceMac'])
            self.tune(params['channel'])
            for station in ('A','B'):
                if station not in self.pipeline.url_by_station:raise ValueError(station+'站测向接口未配置')
                context=default_context(station);context['setup']={k:layout['stations'][station]['setup'][k] for k in context['setup']}
                contexts[station]=context
                current=self.pipeline.request(self.pipeline.url_by_station[station]+'/api/doa/observations?after=0')
                self.check_status(current,station,params,layout)
                statuses[station]=current;cursors[station]=max((r['index'] for r in current.get('observations',[])),default=0)
            with self.lock:self.job.update(state='capturing',message='原位核验旧基准；不修改旧偏置' if mode=='verify' else '采集两站真实相位；保持参考源与天线静止')
            deadline=time.monotonic()+params['timeoutSeconds'];renew={s:0 for s in ('A','B')}
            while time.monotonic()<deadline and not all(len(samples[s])>=params['sampleCount'] for s in samples):
                if self.cancel.is_set() or self.pipeline.stop.is_set():raise ValueError('基准采集已取消，未保存新基准')
                if document(self.doa.path)['revision']!=initial_revision:raise ValueError('采集中布站配置已改变，请按新布站重新采集')
                for station in ('A','B'):
                    url=self.pipeline.url_by_station[station];digest=context_hash(contexts[station])
                    if time.monotonic()>=renew[station]:
                        ack=self.pipeline.request(url+'/api/iq/target',dict(mac=params['referenceMac'],frequencyMhz=params['frequencyMhz'],leaseSeconds=15,directionContext=contexts[station]))
                        if ack.get('accepted') is not True or ack.get('contextHash')!=digest:raise ValueError(station+'站未确认基准采集配置')
                        renew[station]=time.monotonic()+6
                    current=self.pipeline.request(url+'/api/doa/observations?after='+str(cursors[station]))
                    self.check_status(current,station,params,layout)
                    if current['sessionId']!=statuses[station]['sessionId'] or current['metadata']!=statuses[station]['metadata']:
                        raise ValueError(station+'站采集中会话或射频配置发生变化')
                    for row in current.get('observations',[]):
                        cursors[station]=max(cursors[station],row['index'])
                        if len(samples[station])>=params['sampleCount']:continue
                        try:
                            obs=validate_observation(row,current,station,dict(mac=params['referenceMac'],frequencyMhz=params['frequencyMhz']),digest)
                            if (obs.get('signalQuality') or {}).get('accepted') is False:
                                raise ValueError(obs.get('angleRejection') or '目标LTF质量不足，不能用于基准')
                            age=current['generatedMonotonic']-row['monotonic']
                            if not 0<=age<=5:raise ValueError('观测已过期')
                            identity=(row['sessionId'],row['tsf'],row['sha256'])
                            if identity in seen[station]:continue
                            if samples[station] and row['monotonic']-samples[station][-1]['monotonic']<.25:continue
                            seen[station].add(identity);samples[station].append(copy.deepcopy(row))
                        except (ValueError,KeyError,TypeError) as exc:
                            with self.lock:self.job.setdefault('rejections',{})[station]=str(exc)
                    with self.lock:self.job['progress'][station]=len(samples[station])
                self.cancel.wait(.2)
            if self.cancel.is_set() or self.pipeline.stop.is_set():raise ValueError('基准采集已取消，未保存新基准')
            if document(self.doa.path)['revision']!=initial_revision:raise ValueError('采集中布站配置已改变，请按新布站重新采集')
            if mode=='verify':
                passed,results=self.verify_samples(profile,samples,statuses)
                with self.lock:self.job.update(state='verified' if passed else 'verification_failed',message='旧基准原位核验通过；旧偏置未改变' if passed else '旧基准原位核验失败：当前相位已变化，禁止沿用旧偏置；原文件完整保留',verification=results,profileId=profile['id'])
            else:
                references={s:build_reference(s,params,layout,samples[s],statuses[s]['metadata'],statuses[s]['sessionId']) for s in ('A','B')}
                profile=self.save_profile(params,layout,references)
                with self.lock:self.job.update(state='completed',message='新基准已另存为独立记录，未替换当前基准',profileId=profile['id'],statistics=profile['statistics'])
        except Exception as exc:
            with self.lock:self.job.update(state='cancelled' if self.cancel.is_set() else 'failed',message=str(exc))
        finally:
            try:
                if previous is not None:
                    outcome=self.job['state']
                    with self.lock:self.job['state']='restoring'
                    try:
                        self.restore_operation(previous)
                        with self.lock:self.job.update(state=outcome,restored=True)
                    except Exception as exc:
                        with self.lock:self.job.update(state='recovery_required',restoreError='原测向恢复未确认：'+str(exc),message='为防止误用基准，已暂停普通测向，请恢复原测向')
                self.clear_measurements()
            finally:
                self.pipeline.reference_capture=self.recovery_path.exists();self.operation.release()

    def check_status(self,current,station,params,layout):
        if current.get('schema')!='airspace.board-doa.v1' or current.get('station')!=station or current.get('processing',{}).get('location')!='board':
            raise ValueError(station+'站未提供板端相位接口')
        if current.get('state') in ('stopped','starting'):raise ValueError(station+'站采集服务尚未就绪')
        meta=current.get('metadata',{})
        if abs(meta.get('rf_hz',0)/1e6-params['frequencyMhz'])>.001:raise ValueError(station+'站实际频率与所选信道不符')
        if meta.get('iq_sample_rate_hz')!=20000000:raise ValueError(station+'站采样率不是已验证的20 MS/s')
        if abs(meta.get('spacing_m',0)-layout['stations'][station]['setup']['antennaSpacingM'])>1e-6:
            raise ValueError(station+'站板端阵距元数据与布站设置不符，请先同步设备阵距')
        gains=meta.get('fixed_gain_profile',{})
        if gains.get('active_mode')!='manual' or gains.get('session_id')!=current.get('sessionId') or len(gains.get('active_gains',[]))!=2:
            raise ValueError(station+'站缺少当前会话的双路固定增益信息')

    def activate(self,profile,use_default=False):
        if not use_default and not re.fullmatch('[0-9a-f]{32}',profile.get('id','')):raise ValueError('基准编号无效')
        refs=profile.get('references')
        if not refs or set(refs)!={'A','B'}:raise ValueError('该配置仅保存了参数，请先采集两站基准')
        params=profile['settings'];previous=None
        self.pipeline.reference_capture=True
        try:
            with self.pipeline.iq_operation:pass
            self.clear_measurements()
            previous=self.begin_operation('activate',params['referenceMac'])
            self.tune(params['channel'])
            with LOCK:
                original=self.doa.config();patch=dict(stations=[{k:item['setup'][k] for k in ('id','xM','yM','headingDeg','antennaSpacingM')} for item in profile['geometry']['stations'].values()])
                updated=validate_patch(original,patch)
                for station in ('A','B'):
                    expected=profile.get('referenceHashes',{}).get(station)
                    if expected and expected!=self.reference_hash(refs[station]):raise ValueError('保存的基准内容校验失败，禁止应用')
                    setup=next(s for s in updated['stations'] if s['id']==station)
                    current=self.pipeline.request(self.pipeline.url_by_station[station]+'/api/doa/status')
                    self.check_status(current,station,params,profile['geometry'])
                    validate_reference(refs[station],setup,dict(sessionId=current['sessionId']),current['metadata'])
                for station in ('A','B'):
                    path=self.path.parent/(('aoa_calibration_'+station+'.json') if use_default else ('aoa_profile_'+profile['id']+'_'+station+'.json'))
                    if path.exists():
                        if json.loads(path.read_text(encoding='utf8'))!=refs[station]:raise ValueError('已保存的基准文件与库记录不符，禁止覆盖旧文件')
                    elif use_default:raise ValueError('默认基准文件缺失，禁止生成替代文件')
                    else:atomic(path,refs[station])
                    next(s for s in updated['stations'] if s['id']==station)['calibration']=path.relative_to(self.root).as_posix()
                previous.update(appliedRevision=revision(updated),appliedId=profile['id']);atomic(self.recovery_path,previous)
                if revision(updated)!=revision(original):
                    atomic(self.doa.path.with_suffix('.previous.json'),original);atomic(self.doa.path,updated)
                with self.lock:
                    lib=self.library()
                    if lib.get('activeId')!=profile['id']:
                        lib['activeId']=profile['id'];atomic(self.path,lib)
            self.synchronize_contexts(params['channel'],{},params['referenceMac'])
            self.recovery_path.unlink()
            approved=self.runtime()['stations'];valid=all(approved.get(s,{}).get('valid') is True for s in ('A','B'))
            message='已恢复默认基准并同步两站，沿用原固定复用设置' if use_default else '已选中该基准并同步两站；当前会话原位核验已通过' if valid else '已选中该基准，但当前射频会话尚未核验；请载入当前参数后原位核验'
            with self.lock:self.job=dict(state='applied',message=message,profileId=profile['id'])
            return self.snapshot()
        except Exception:
            if previous is not None:
                try:self.restore_operation(previous)
                except Exception as exc:
                    with self.lock:self.job=dict(state='recovery_required',message='应用失败且原测向恢复未确认',restoreError=str(exc))
            raise
        finally:
            self.clear_measurements();self.pipeline.reference_capture=self.recovery_path.exists()
