"""Compatibility imports for the shared board/PC reference validation contract."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"zynq7045_ad9361_rid_aoa/linux_doa"))
from direction_reference import (C,STATUS,finite,load_reference,validate_geometry,validate_reference,
    apply_reference,apply_reference_data,reject_reference,verify_observation_reference)
