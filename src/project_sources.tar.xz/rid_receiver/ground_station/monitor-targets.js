import {state,hasPosition} from './data.js';
import {config} from './config.js';
import {finite,geographic,intersectionPoints} from './workspace-core.js';
import {compatibleDOAScene,trackMatchesFeed,recentTrackPoints} from './doa-tracks.js';

export const frequencyBand=mhz=>!finite(mhz)?'频段未知':mhz>=2400&&mhz<2500?'2.4 GHz':mhz>=4900&&mhz<5925?'5 GHz':mhz>=5925?'更高频段':`${mhz} MHz`;
const macOf=value=>value?.sourceMac?.toLowerCase()||value?.mac?.toLowerCase();
const matches=(a,b)=>!!macOf(a)&&macOf(a)===macOf(b)&&(!finite(a.frequencyMhz)||!finite(b.frequencyMhz)||a.frequencyMhz===b.frequencyMhz);
const ageFresh=(stamp,now)=>finite(stamp)&&now-stamp>=-2000&&now-stamp<15000;

function mergeTargetObservations(rows,pipeline){
  const groups=new Map(),frequency=pipeline?.coverage?.channelScan?.frequencyMhz,active=pipeline?.activeSource?.key;
  for(const row of rows){
    const mac=macOf(row),ssid=row.source?.ssid;
    // Only a known, identical SSID and MAC join observations across frequencies.
    const identity=mac&&typeof ssid==='string'&&ssid.length?JSON.stringify([mac,ssid]):row.key;
    if(!groups.has(identity))groups.set(identity,[]);
    groups.get(identity).push(row);
  }
  const rank=row=>[row.positionFresh===true,row.fresh===true,!!row.target,!!active&&row.source?.key===active,finite(frequency)&&row.frequencyMhz===frequency,finite(row.timestamp)?row.timestamp:-Infinity];
  const compare=(a,b)=>{const ar=rank(a),br=rank(b);for(let i=0;i<ar.length;i++){if(ar[i]!==br[i])return Number(br[i])-Number(ar[i]);}return 0;};
  return [...groups.values()].map(members=>{
    const chosen=[...members].sort(compare)[0],mac=macOf(chosen),ssid=chosen.source?.ssid;
    const named=mac&&typeof ssid==='string'&&ssid.length;
    // The display identity survives switching frequency. AoA, coordinates and
    // tracks stay together on the chosen observation; never mix station phases.
    const id=!chosen.target&&named?`${mac}#ssid:${encodeURIComponent(ssid)}`:chosen.id;
    return {...chosen,id,key:!chosen.target&&named?'rf:'+id:chosen.key,
      observedFrequenciesMhz:[...new Set(members.map(r=>r.frequencyMhz).filter(finite))].sort((a,b)=>a-b),
      observations:members.map(r=>({key:r.key,sourceKey:r.source?.key,frequencyMhz:r.frequencyMhz,timestamp:r.timestamp,fresh:r.fresh,features:r.source?.features,doaSupported:r.source?.doaSupported}))};
  });
}

export function monitorTargets({pipeline=null,now=Date.now()}={}){
  const live=state.mode==='external',sources=live?pipeline?.sources||[]:[],rows=[],used=new Set();
  const feeds=new Map(state.doaTargets);
  if(state.doa?.targetId)feeds.set(state.doa.targetId,state.doa);
  const validFeeds=[...feeds.values()].filter(feed=>compatibleDOAScene(feed,state.doa));
  const feedFrequency=f=>{const value=Number(f.targetId?.split('@').at(-1));return finite(value)?value:f.stations.find(s=>finite(s.frequencyMhz))?.frequencyMhz;};
  const aoaFor=(key,mac,frequency)=>{
    const exact=validFeeds.find(f=>f.targetId===key);if(exact)return exact;
    const matching=validFeeds.filter(f=>mac&&f.stations.some(s=>macOf(s)===mac)&&(!finite(frequency)||feedFrequency(f)===frequency));
    return matching.length===1?matching[0]:null;
  };
  function direction(feed){
    if(!feed)return {feed:null,points:[],tracks:[],fresh:false};
    const stamp=Math.max(...feed.stations.map(s=>s.timestamp??feed.timestamp));
    const verified=!live||feed.stations.length>=2&&feed.stations.every(s=>s.sourceVerified&&s.freshnessVerified&&s.frameKey)&&new Set(feed.stations.map(s=>s.frameKey)).size===1;
    const fresh=ageFresh(stamp,now)&&feed.stations.some(s=>s.fresh!==false&&!s.error);
    const points=verified&&now-stamp<config.aoaTrackRetentionMs?intersectionPoints(feed,state.mode,now,fresh).map(p=>{
      if(hasPosition(p))return p;const coord=geographic(feed.anchor,p.xM,p.yM);return coord?{...p,latitude:coord[0],longitude:coord[1]}:p;
    }):[];
    const tracks=[...state.doaTracks.values()].filter(t=>t.targetId===feed.targetId&&trackMatchesFeed(t,feed,state.mode)&&(feed.directionMode!=='front'||t.branch==='front-front')).map(t=>({...t,points:recentTrackPoints(t.points,now,config.aoaTrackRetentionMs)})).filter(t=>t.points.length);
    return {feed,points,tracks,fresh,stamp};
  }
  for(const target of state.targets.values()){
    const source=sources.find(s=>matches(target,s));if(source)used.add(source.key);
    const direct=hasPosition(target)&&ageFresh(target.positionTimestamp??target.timestamp,now)&&(!live||state.ridConnected);
    const d=direction(aoaFor(source?.key||target.id,macOf(target),target.frequencyMhz));
    // Keep a past RID position visibly historical when a later ID-only packet arrives.
    const history=recentTrackPoints(target.history,now,config.ridTrackRetentionMs),last=history.at(-1);
    const position=hasPosition(target)&&now-(target.positionTimestamp??target.timestamp)<config.ridTrackRetentionMs?target:hasPosition(last)?last:null;
    const scan=pipeline?.coverage?.channelScan,scanAway=scan&&finite(scan.frequencyMhz)&&finite(target.frequencyMhz)&&Math.abs(scan.frequencyMhz-target.frequencyMhz)>.1;
    const waitingReason=scanAway?'轮扫已切到其他频点，等待再次收到该目标并取得同源角度':!ageFresh(target.timestamp,now)?'该目标广播已过期；等待新鲜观测，不能用旧身份生成位置':null;
    rows.push({key:'rid:'+(target.trackId||target.id),id:target.trackId||target.id,title:target.id,mac:target.sourceMac,source,target,waitingReason,method:direct?'rid':source?.positioning?.method==='aoa'||d.feed||!hasPosition(target)?'aoa':'rid',
      frequencyMhz:target.frequencyMhz??source?.frequencyMhz,timestamp:target.timestamp,fresh:direct||d.fresh,
      position,positionFresh:direct,ridHistory:history,...d});
    rows.at(-1).fresh=direct||d.fresh;
    if(d.feed)used.add(d.feed.targetId);
  }
  for(const source of sources){
    if(used.has(source.key)||!['rid','video_candidate','ssid_candidate'].includes(source.recognition?.kind))continue;
    const d=direction(aoaFor(source.key,macOf(source),source.frequencyMhz));used.add(source.key);
    rows.push({key:'rf:'+source.key,id:source.key,title:source.recognition.identities?.[0]||source.ssid||source.mac,mac:source.mac,source,target:null,method:'aoa',frequencyMhz:source.frequencyMhz,timestamp:d.stamp??(pipeline.timestamp-(source.ageSeconds||0)*1000),ridHistory:[],position:null,positionFresh:false,...d,fresh:source.fresh===true&&(!finite(pipeline.timestamp)||ageFresh(pipeline.timestamp,now))});
  }
  for(const feed of validFeeds){
    if(used.has(feed.targetId)||rows.some(r=>r.feed?.targetId===feed.targetId))continue;
    const d=direction(feed),s=feed.stations.find(s=>s.sourceMac),mac=s?.sourceMac;
    // A source already represented by RID must not gain a second aircraft icon.
    if(rows.some(r=>mac&&macOf(r.target)===mac.toLowerCase()&&(!finite(r.frequencyMhz)||r.frequencyMhz===feedFrequency(feed))))continue;
    rows.push({key:'rf:'+feed.targetId,id:feed.targetId,title:mac||feed.targetId,mac,source:null,target:null,method:'aoa',frequencyMhz:feedFrequency(feed)??null,timestamp:d.stamp,ridHistory:[],position:null,positionFresh:false,...d});
  }
  return mergeTargetObservations(rows,pipeline);
}

export function aircraftMarkup(row,svg){
  return `<span class="plane-core${row.method==='aoa'?' aoa-aircraft':''}" style="transform:rotate(${row.method==='rid'&&finite(row.target?.heading)?row.target.heading:0}deg)">${svg}</span>`;
}
