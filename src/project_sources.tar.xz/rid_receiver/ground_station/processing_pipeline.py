"""Evidence-led capture -> recognition -> identity -> source-associated AoA.

Scores are rule weights, never calibrated drone probabilities. A non-RID
video candidate stays suspected, and uncalibrated AoA stays diagnostic.
"""
import base64
import copy
from collections import deque
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import threading
import time
from urllib.parse import urlsplit
from urllib.request import build_opener,ProxyHandler,Request
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'zynq7045_ad9361_rid_aoa/linux_doa'))
from capture_io import monitor_frame
from reference_analysis import radiotap_tsf_us,analyze_reference_phase
from doa_bridge import phase_bearing_candidates
from reference_calibration import apply_reference,verify_observation_reference
from board_doa import SCHEMA,context_from_setup,context_hash,validate_observation,verify_observation_context

from signal_recognition import source_key,positioning_route,signal_features,classify_source

from source_doa import analyze_window as analyze_source_window


def analyze_window(raw,row,metadata,spacing):
    """Offline/legacy audit wrapper; live transport consumes board observations."""
    return analyze_source_window(raw,row,metadata,spacing,phase_analyzer=analyze_reference_phase,
        frame_decoder=monitor_frame,tsf_reader=radiotap_tsf_us,angle_solver=phase_bearing_candidates)

class ProcessingPipeline:
    def __init__(self,signals,doa,rid=None):
        self.signals=signals;self.doa=doa;self.rid=rid;self.lock=threading.Lock();self.stop=threading.Event()
        self.opener=build_opener(ProxyHandler({}));self.sources=[];self.events=deque(maxlen=100)
        self.active=None;self.manual=None;self.last_rotation=0;self.index=0;self.last_states={};self.cursors={};self.sessions={}
        self.resources={};self.iq_status={};self.errors={};self.rejected={};self.angles={};self.last_results={};self.last_task=None
        self.board_contexts={};self.scanner=None
        self.iq_operation=threading.RLock();self.reference_capture=False;self.reference_manager=None
        self.url_by_station={s['id']:s['url'].rstrip('/') for s in doa.config().get('stations',[]) if s.get('url')}
    def request(self,url,body=None,raw=False):
        data=json.dumps(body).encode() if body is not None else None
        request=Request(url,data=data,headers={'Content-Type':'application/json'} if data else {})
        with self.opener.open(request,timeout=2) as response:value=response.read(1024*1024+1)
        if len(value)>1024*1024:raise ValueError('oversized pipeline response')
        return value if raw else json.loads(value)
    def event(self,value):
        with self.lock:self.events.append(value)
    def choose(self,key):
        if self.reference_capture:raise ValueError('正在采集AOA基准，请完成或取消后再切换测向目标')
        with self.lock:
            if key is None:self.manual=None;return
            if not any(s['key']==key and s['recognition']['eligible'] and s['fresh'] and s.get('doaSupported',True) and s.get('positioning',{}).get('method')!='rid' for s in self.sources):raise ValueError('该信源已有RID位置、暂不支持同源IQ测向，或缺少有效识别依据')
            if self.scanner:
                source=next(s for s in self.sources if s['key']==key)
                from wifi_channels import CHANNELS,channel_frequency
                channel=next((c for c in CHANNELS if abs(channel_frequency(c)-source['frequencyMhz'])<.01),None)
                if channel is None:raise ValueError('目标频率不在当前接收信道范围')
                self.scanner.configure(dict(mode='fixed',channel=channel,dwellSeconds=self.scanner.config['dwellSeconds']))
            self.manual=key;self.last_rotation=0
    def classify(self):
        feed=self.signals.snapshot();groups={};now=time.time()*1000
        rid_feed=self.rid.snapshot() if self.rid else {}
        rid_targets=rid_feed.get('targets',[]) if rid_feed.get('connected') and rid_feed.get('mode')=='live' else []
        connected={s['id'] for s in feed.get('stations',[]) if s.get('connected') and s.get('mode')=='live'}
        for source in feed.get('sources',[]):
            if source.get('historical') or source.get('station') not in connected:continue
            frequency=source.get('frequency_mhz');mac=source.get('mac')
            if not frequency or not mac:continue
            key=source_key(mac,frequency);groups.setdefault(key,[]).append(source)
        rows=[]
        for key,sources in groups.items():
            source=sources[0];packets=[p for p in feed.get('packets',[]) if p.get('fcs_valid') is True and not p.get('historical') and p.get('age_seconds',1e9)<10 and p.get('source_mac')==source['mac'] and p.get('frequency_mhz')==source['frequency_mhz']]
            recognition=classify_source(sources,packets);age=min(s.get('age_seconds',1e9) for s in sources)
            positioning=positioning_route(recognition)
            for target in rid_targets:
                if target.get('sourceMac')!=source['mac'] or target.get('frequencyMhz')!=source['frequency_mhz'] or now-target.get('timestamp',0)>=15000:continue
                lat,lon=target.get('latitude'),target.get('longitude')
                if not all(type(v) in (int,float) and math.isfinite(v) for v in (lat,lon)) or abs(lat)>90 or abs(lon)>180:continue
                # The RID bridge preserves the Location age independently of newer ID packets.
                if now-(target.get('positionTimestamp') or 0)>=15000:continue
                positioning=dict(method='rid',label='RID广播位置直显',position=dict(latitude=lat,longitude=lon),reason='RID桥接已获得新鲜广播位置，无需AOA排队')
                break
            # DSSS identity is usable, but an OFDM LTF/TSF association cannot
            # measure its angle. Keep it visible without scheduling false IQ.
            dsss_only=bool(packets) and all(p.get('phy_type')=='dsss_long_1m' for p in packets)
            if not packets:
                types={name for s in sources for name in s.get('phy_types',{})}
                dsss_only=types=={'dsss_long_1m'}
            item=dict(key=key,mac=source['mac'],frequencyMhz=source['frequency_mhz'],ssid=next((s['ssid'] for s in sources if s.get('ssid')),None),
                doaSupported=not dsss_only,positioning=positioning,features=signal_features(sources,packets),
                receiverStations=sorted({s['station'] for s in sources if s.get('age_seconds',1e9)<10}),
                fresh=age<10,ageSeconds=age,frames=sum(s.get('frames',0) for s in sources),recognition=recognition,
                stages=dict(capture='observed' if age<10 else 'stale',features=recognition['kind'],
                    identity='parsed' if recognition['identities'] else 'pending' if recognition['kind']=='rid' else 'skipped_no_rid' if recognition.get('identitySkipped') else 'not_applicable',
                    direction='rid_position' if positioning['method']=='rid' else 'unsupported_phy' if dsss_only and recognition['eligible'] else 'queued' if recognition['eligible'] and age<10 else 'not_eligible'))
            previous=self.last_states.get(key)
            if previous!=recognition['kind']:
                self.event(dict(timestamp=now,sourceKey=key,kind=recognition['kind'],label=recognition['label']));self.last_states[key]=recognition['kind']
            if key in self.last_results and not dsss_only and positioning['method']!='rid':
                result=self.last_results[key]
                valid_cache=True
                for station,observation in result.get('stations',{}).items():
                    if observation.get('processingLocation')=='board':
                        try:
                            setup=next(s for s in self.doa.config().get('stations',[]) if s['id']==station)
                            verify_observation_context(observation,setup,Path(__file__).resolve().parent)
                        except (ValueError,KeyError,OSError,TypeError,StopIteration):
                            valid_cache=False;self.angles.pop(station,None)
                    if observation.get('calibrationStatus')!='provisional_reference':continue
                    try:
                        setup=next(s for s in self.doa.config().get('stations',[]) if s['id']==station)
                        verify_observation_reference(observation,setup,Path(__file__).resolve().parent)
                    except (ValueError,KeyError,OSError,TypeError,StopIteration):
                        valid_cache=False;self.angles.pop(station,None)
                if valid_cache:
                    item['direction']=copy.deepcopy(result)
                    item['stages']['direction']='diagnostic' if now-result['timestamp']<15000 else 'stale'
                else:
                    self.last_results.pop(key,None)
            rows.append(item)
        rows.sort(key=lambda s:(s['fresh'],s['recognition']['eligible'],s['recognition']['kind']=='rid',-s['ageSeconds']),reverse=True)
        with self.lock:self.sources=rows[:512]
        return rows
    def schedule(self,rows):
        scan=self.scanner.snapshot() if self.scanner else None
        current_frequency=scan.get('frequencyMhz') if scan and scan['state']=='receiving' else None
        candidates=[s for s in rows if (not scan or current_frequency is not None and abs(s['frequencyMhz']-current_frequency)<.01) and s['fresh'] and s['recognition']['eligible'] and s.get('doaSupported',True) and s.get('positioning',{}).get('method')!='rid'][:16];now=time.monotonic()
        wanted=next((s for s in candidates if s['key']==self.manual),None)
        if self.manual and not wanted:self.manual=None
        current=next((s for s in candidates if s['key']==self.active),None)
        if wanted:current=wanted
        elif not current or now-self.last_rotation>=5:
            if candidates:current=candidates[self.index%len(candidates)];self.index+=1
            self.last_rotation=now
        key=current['key'] if current else None
        if key!=self.active:
            self.active=key;self.angles={};self.doa.set_diagnostic_target(key)
            self.event(dict(timestamp=time.time()*1000,sourceKey=key,kind='task',label='切换同源IQ测向任务' if key else '等待可测目标'))
        return current
    def poll_iq(self,station,url,target):
        current=self.request(url+'/api/doa/observations?after='+str(self.cursors.get(station,0)))
        self.iq_status[station]={k:v for k,v in current.items() if k!='observations'}
        session=current['sessionId']
        if self.sessions.get(station)!=session:
            self.sessions[station]=session;self.cursors[station]=0
            self.angles.pop(station,None)
            with self.lock:self.last_results.clear()
            self.doa.invalidate_diagnostic_station(station,'IQ会话已改变，等待当前会话的新鲜窗口')
            current=self.request(url+'/api/doa/observations?after=0')
        if abs(current.get('metadata',{}).get('rf_hz',0)/1e6-target['frequencyMhz'])>.01:
            self.angles.pop(station,None);return
        if current.get('state')=='stopped':raise ValueError(current.get('error') or 'IQ采集服务已结束')
        if current.get('schema')!=SCHEMA or current.get('station')!=station or current.get('processing',{}).get('location')!='board':
            raise ValueError('需要板端DOA计算接口；不自动退回PC下载原始IQ')
        setup=next(s for s in self.doa.config()['stations'] if s['id']==station)
        if self.reference_manager:self.reference_manager.observe_receiver(station,current)
        context=context_from_setup(setup,Path(__file__).resolve().parent);digest=context_hash(context)
        if self.board_contexts.get(station)!=digest:
            self.board_contexts[station]=digest;self.angles.pop(station,None)
            with self.lock:self.last_results.clear()
            self.doa.invalidate_diagnostic_station(station,'站点配置已同步，等待板端当前配置的新观测')
        task=current.get('task') or {}
        if task.get('mac')!=target['mac'] or task.get('contextHash')!=digest or task.get('expires',0)-current['generatedMonotonic']<6:
            acknowledgement=self.request(url+'/api/iq/target',dict(mac=target['mac'],frequencyMhz=target['frequencyMhz'],leaseSeconds=15,directionContext=context))
            if acknowledgement.get('accepted') is not True or acknowledgement.get('contextHash')!=digest:
                raise ValueError('板端未确认当前测向配置')
        for row in current.get('observations',[]):
            self.cursors[station]=max(self.cursors.get(station,0),row['index'])
            age=current['generatedMonotonic']-row['monotonic']
            if row['sourceMac']!=target['mac'] or abs(row['frequencyMhz']-target['frequencyMhz'])>.01 or not math.isfinite(age) or not 0<=age<=5:continue
            try:
                observation=validate_observation(row,current,station,target,digest)
                verify_observation_context(observation,setup,Path(__file__).resolve().parent)
                if observation.get('calibrationStatus')=='provisional_reference':
                    verify_observation_reference(observation,setup,Path(__file__).resolve().parent)
                observation.update(targetId=target['key'],frequencyMhz=target['frequencyMhz'],sourceClass=target['recognition']['kind'],broadcastIdentities=target['recognition']['identities'],timestamp=time.time()*1000-age*1000)
                self.doa.add_diagnostic_observation(station,observation,age)
                if observation.get('angleRejection'):self.rejected[station]=observation['angleRejection']
                else:self.rejected.pop(station,None)
                self.angles[station]=dict(angleDeg=observation['relativeAngle'],phaseDeg=observation['phaseDeg'],rawPhaseDeg=observation.get('rawPhaseDeg'),phaseBiasAppliedDeg=observation.get('phaseBiasAppliedDeg',0),calibrationStatus=observation['calibrationStatus'],referenceSessionId=observation.get('referenceSessionId'),referenceHash=observation.get('referenceHash'),referenceStationId=observation.get('referenceStationId'),referenceMatched=observation.get('referenceMatched'),referencePolicy=observation.get('referencePolicy'),referenceCaptureSessionId=observation.get('referenceCaptureSessionId'),referenceReusedAcrossSessions=observation.get('referenceReusedAcrossSessions'),sessionId=observation['sessionId'],productionAccepted=False,frameKey=observation['frameKey'],timestamp=observation['timestamp'],processingLocation='board',directionContextHash=digest)
                self.angles[station].update(signalQuality=copy.deepcopy(observation.get('signalQuality')),
                    calibrationRequired=observation.get('calibrationRequired'),angleRejection=observation.get('angleRejection'))
                both_referenced=len(self.angles)==2 and all(o.get('calibrationStatus')=='provisional_reference' for o in self.angles.values())
                with self.lock:self.last_results[target['key']]=dict(timestamp=observation['timestamp'],stations=copy.deepcopy(self.angles),calibrationStatus='provisional_reference' if both_referenced else 'uncalibrated',geometryVerified=False)
            except (ValueError,KeyError,IndexError) as exc:
                self.rejected[station]=str(exc)
        self.errors.pop(station,None)
    def run(self):
        resource_tick=0
        while not self.stop.is_set():
            try:
                if self.scanner and not self.reference_capture and self.scanner.tick():
                    self.angles.clear();self.last_results.clear();self.active=None
                    self.doa.set_diagnostic_target(None)
                    for station in self.url_by_station:self.doa.invalidate_diagnostic_station(station,'切换接收信道，等待当前频率的新观测')
                rows=self.classify()
                with self.iq_operation:
                    if not self.reference_capture:
                        target=self.schedule(rows)
                        for station,url in self.url_by_station.items():
                            if target:
                                try:self.poll_iq(station,url,target)
                                except Exception as exc:self.errors[station]=str(exc);self.doa.set_diagnostic_error(station,str(exc))
                            else:
                                try:
                                    current=self.request(url+'/api/iq/status')
                                    self.iq_status[station]=current;self.errors.pop(station,None)
                                except Exception as exc:self.errors[station]=str(exc)
                if time.monotonic()-resource_tick>2:
                    for station,url in self.signals.urls.items():
                        try:self.resources[station]=dict(self.request(url+'/api/resources'),receivedMonotonic=time.monotonic())
                        except Exception as exc:self.resources[station]=dict(available=False,error=str(exc),receivedMonotonic=time.monotonic())
                    resource_tick=time.monotonic()
            except Exception as exc:self.errors['pipeline']=str(exc)
            self.stop.wait(.5)
    def snapshot(self):
        with self.lock:rows=copy.deepcopy(self.sources);events=list(self.events)
        active=next((s for s in rows if s['key']==self.active),None)
        counts={kind:sum(s['fresh'] and s['recognition']['kind']==kind for s in rows) for kind in ('rid','rid_candidate','video_candidate','ssid_candidate','wifi')}
        frequencies={station:round(value.get('metadata',{}).get('rf_hz',0)/1e6,3) for station,value in list(self.iq_status.items()) if value.get('metadata',{}).get('rf_hz')}
        common_frequency=next(iter(frequencies.values())) if frequencies and len(set(frequencies.values()))==1 else None
        reference_states={station:dict(calibrationStatus=value.get('calibrationStatus','uncalibrated'),phaseBiasAppliedDeg=value.get('phaseBiasAppliedDeg',0),referenceSessionId=value.get('referenceSessionId')) for station,value in list(self.angles.items())}
        has_reference=any(value['calibrationStatus']=='provisional_reference' for value in reference_states.values())
        return dict(schema='airspace.pipeline',version=1,mode='live',timestamp=time.time()*1000,
            referenceCaptureActive=self.reference_capture,
            stages=['检测采集','特征识别','身份解析','测向定位'],sources=rows,counts=counts,
            activeSource=active,selection='manual' if self.manual else 'auto',events=events,
            direction=dict(mode='provisional_reference_diagnostic' if has_reference else 'uncalibrated_diagnostic',processingLocation='board',rawIQTransport=False,geometryVerified=False,phaseBiasAppliedDeg=None if has_reference else 0,stationReferences=reference_states,productionAccepted=False,errors=dict(self.errors),rejections=dict(self.rejected)),
            coverage=dict(scanMode='channel_scan' if self.scanner and self.scanner.config['mode']!='fixed' else 'fixed_channel',channelScan=self.scanner.snapshot() if self.scanner else None,frequencyMhz=common_frequency,stationFrequenciesMhz=frequencies,bandwidthMhz=20,decodedPHY='OFDM / HT20'+(' / DSSS 1 Mbps 长前导' if any((s.get('phyCapabilities') or {}).get('dsss',{}).get('captureActive') for s in (self.signals.status().get('stations',[]) if hasattr(self.signals,'status') else [])) else ''),ble=False,allSpectrum=False,
                description='逐信道被动检测2.4/5 GHz可解码Wi-Fi信号；轮扫有接收间隙，不含BLE及5.8 GHz'),
            iq=dict(self.iq_status),resources=self.resource_snapshot(),
            receiverSelection=self.signals.selection.snapshot() if getattr(self.signals,'selection',None) else None)
    def resource_snapshot(self):
        stations=[];now=time.monotonic()
        for station,value in list(self.resources.items()):
            item=dict(value,id=station,ageSeconds=max(0,now-value.get('receivedMonotonic',now)))
            if item['ageSeconds']>8:item['available']=False
            item.pop('receivedMonotonic',None);stations.append(item)
        path=Path(__file__).parent/'resource_build.json'
        build=json.loads(path.read_text(encoding='utf-8')) if path.exists() else None
        return dict(stations=stations,fpga=build)
