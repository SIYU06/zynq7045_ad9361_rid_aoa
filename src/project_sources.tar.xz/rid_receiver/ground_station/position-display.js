import {finite,local} from './workspace-core.js';

// The map still uses WGS84 internally; the presentation exposes metres only.
export function localFrame(layout){
  const stations=layout?.stations||[],anchor=layout?.anchor;
  if(!anchor||![anchor.latitude,anchor.longitude].every(finite)||stations.length<2||!stations.slice(0,2).every(s=>[s.xM,s.yM].every(finite)))return null;
  return {anchor,origin:{xM:(stations[0].xM+stations[1].xM)/2,yM:(stations[0].yM+stations[1].yM)/2}};
}
export function localPoint(point,frame){
  if(!point||!frame)return null;
  let x=point.xM,y=point.yM;
  if(![x,y].every(finite)){
    try{[x,y]=local(frame.anchor,point.latitude,point.longitude);}catch{return null;}
  }
  return {xM:x-frame.origin.xM,yM:y-frame.origin.yM};
}
export function localPointLabel(point,frame){
  const value=localPoint(point,frame);
  return value?`东 X ${value.xM.toFixed(2)} m · 北 Y ${value.yM.toFixed(2)} m`:'等待局部坐标参考';
}
