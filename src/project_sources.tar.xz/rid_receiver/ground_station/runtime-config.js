// Static-server fallback. serve.py replaces this response with the public key.
globalThis.GROUND_STATION_CONFIG = {maptilerKey: ''};
