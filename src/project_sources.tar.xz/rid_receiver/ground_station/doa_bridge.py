"""Read actual paired RF IQ over Ethernet, associate frames, render provisional AoA."""
import base64
import copy
from collections import deque
import hashlib
import json
import math
from pathlib import Path
import sys
import threading
import time
from urllib.request import build_opener,ProxyHandler

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'zynq7045_ad9361_rid_aoa/linux_doa'))
sys.path.insert(0,str(ROOT.parent))
from single_station import analyze,wrap,C
from reference_analysis import radiotap_tsf_us,require_matching_profile,analyze_reference_phase
from capture_io import monitor_frame
from decoder import extract_frame,decode_payload
from doa_geometry import geographic,intersect,bearing_solutions,intersect_candidates,midpoint_origin,relative_to_midpoint
from station_config import update as update_config,document as config_document
from reference_calibration import verify_observation_reference
from board_doa import verify_observation_context


from direction_math import phase_bearing_candidates


def verified_iq(raw,row,references,calibration,metadata):
    if calibration.get('status')=='requires_reference':
        raise ValueError(calibration.get('reason','阵列几何已更新，等待重新标定'))
    require_matching_profile(metadata,calibration)
    if len(raw)!=32776 or hashlib.sha256(raw).hexdigest()!=row['sha256']: raise ValueError('IQ长度或哈希错误')
    tsf=int.from_bytes(raw[:8],'little')
    if tsf!=row['tsf'] or tsf<=row['minimum_iq_tsf_exclusive']: raise ValueError('IQ不满足阶段时间界限')
    if row['session_id']!=calibration['fixed_gain_profile']['session_id']: raise ValueError('标定会话已改变')
    matches=[]
    expected=bytes.fromhex(calibration['reference_mac'].replace(':',''))
    for reference in references:
        if abs(tsf-reference['tsf']-53)>1: continue
        packet=base64.b64decode(reference['packet_b64'],validate=True)
        if radiotap_tsf_us(packet)!=reference['tsf']: continue
        frame,info=monitor_frame(packet,127,openwifi_fcs=True)
        if len(frame)<24 or frame[10:16]!=expected or info['fcs_valid'] is not True: continue
        ids=[m.get('uas_id') for event in extract_frame(frame) for m in decode_payload(event['payload']) if m['type']==0]
        if calibration['reference_id'] in ids: matches.append((reference,frame))
    if len(matches)!=1: raise ValueError('等待唯一MAC/RID/FCS/TSF参考帧')
    estimator=calibration.get('phase_estimator','burst_phase_v1')
    result=analyze_reference_phase(raw,metadata['rf_hz'],metadata['spacing_m'],estimator)
    if result['whole_window']['clipped_fraction'] or len(result['observations'])!=1: raise ValueError('IQ削顶或突发数量不确定')
    observation=result['observations'][0]
    if observation['status']!='UNCALIBRATED': raise ValueError('当前窗口质量不适合测向')
    phase=wrap(math.radians(observation['phase_deg']-calibration['phase_bias_deg']))
    candidates=phase_bearing_candidates(phase,metadata['rf_hz'],metadata['spacing_m'])
    if not candidates: raise ValueError('相位超出当前阵列可反演范围')
    if len(candidates)!=1: raise ValueError('当前间距存在多个角度解，等待消歧或缩小间距')
    return dict(relativeAngle=calibration.get('bearing_sign',1)*candidates[0],
        phaseDeg=observation['phase_deg'],phaseEstimator=estimator,coherence=result['whole_window']['coherence'],
        sourceMac=calibration['reference_mac'],targetId=calibration['reference_id'],
        sessionId=row['session_id'],tsf=tsf,freshnessVerified=True,sourceVerified=True,
        frameKey=hashlib.sha256(matches[0][1]).hexdigest(),
        quality='实测／临时标定／精度待优化',productionAccepted=False)


class DOABridge:
    def __init__(self,config_path=None):
        self.path=Path(config_path) if config_path else ROOT/'runtime/doa_config.json'
        self.lock=threading.Lock(); self.stop=threading.Event(); self.observations={}; self.errors={}; self.history={}
        self.opener=build_opener(ProxyHandler({}))
        self.diagnostic_mode=False;self.diagnostic_target=None

    def set_diagnostic_target(self,target):
        with self.lock:
            self.diagnostic_mode=True
            if target!=self.diagnostic_target:
                self.observations.clear();self.history.clear();self.errors.clear()
            self.diagnostic_target=target

    def set_diagnostic_error(self,station,error):
        with self.lock:self.errors[station]=error

    def invalidate_diagnostic_station(self,station,error):
        """A restarted receiver cannot reuse even a still-fresh old frame pair."""
        with self.lock:
            self.observations.pop(station,None)
            self.history.pop(station,None)
            self.errors[station]=error

    def add_diagnostic_observation(self,station,observation,age):
        if observation.get('calibrationStatus') not in ('uncalibrated','provisional_reference') or not observation.get('sourceVerified'):
            raise ValueError('diagnostic observations require explicit calibration and identity status')
        if observation.get('processingLocation')=='board':
            setup=next((s for s in self.config().get('stations',[]) if s['id']==station),None)
            if not setup:raise ValueError('板端观测站点未配置')
            verify_observation_context(observation,setup,ROOT)
        if observation.get('calibrationStatus')=='provisional_reference':
            setup=next((s for s in self.config().get('stations',[]) if s['id']==station),None)
            if not setup:raise ValueError('临时参考站点未配置')
            verify_observation_reference(observation,setup,ROOT)
        with self.lock:
            if observation['targetId']!=self.diagnostic_target:return
            value=dict(observation,key=(observation['sessionId'],observation['tsf']),
                received=time.monotonic(),initialAge=age,boardAge=age,streamAlive=True)
            self.observations[station]=value
            self.history.setdefault(station,deque(maxlen=64)).append(dict(value))
            self.errors.pop(station,None)

    def config(self):
        if not self.path.exists(): return dict(anchor=None,stations=[])
        return json.loads(self.path.read_text(encoding='utf-8'))

    def configure(self,patch):
        configuration=update_config(self.path,patch)
        value=self.snapshot();value['configuration']=configuration
        return value

    def get(self,url,limit=1024*1024):
        with self.opener.open(url,timeout=2) as response: data=response.read(limit+1)
        if len(data)>limit: raise ValueError('观测资源过大')
        return data

    def load_reference(self,station):
        calibration=json.loads((ROOT/station['calibration']).read_text(encoding='utf-8'))
        if calibration.get('status')=='requires_reference':
            spacing=station.get('antennaSpacingM',calibration.get('expected_spacing_m'))
            raise ValueError('阵列几何已更新，等待 %.1f cm 新标定'%(spacing*100) if spacing else '阵列几何已更新，等待重新标定')
        spacing=station.get('antennaSpacingM')
        if spacing is not None:
            recorded=calibration.get('capture_metadata',{}).get('spacing_m')
            if recorded is None or abs(recorded-spacing)>1e-6:
                raise ValueError('天线中心距与标定不一致，等待 %.1f cm 新标定'%(spacing*100))
        return calibration

    def poll_station(self,station):
        calibration=self.load_reference(station)
        calhash=hashlib.sha256(json.dumps(calibration,sort_keys=True).encode()).hexdigest()
        url=station['url'].rstrip('/')
        row=json.loads(self.get(url+'/latest.json'))
        status=json.loads(self.get(url+'/status.json'))
        key=(row['session_id'],row['tsf'])
        with self.lock: old=self.observations.get(station['id'])
        if old and old['key']==key and old.get('calibrationHash')==calhash:
            with self.lock:
                old['boardAge']=max(old['boardAge'],status['generated_monotonic_s']-row['monotonic_s'])
                old['streamAlive']=status['state'] not in ('complete','aborted')
            return
        path=row['raw_path']
        if '..' in path or path.startswith('/') or '\\' in path: raise ValueError('无效IQ路径')
        raw=self.get(url+'/'+path,32776)
        metadata=json.loads(self.get(url+'/'+row['stage']+'/metadata.json'))
        references=json.loads(self.get(url+'/reference_packets.json'))
        observation=verified_iq(raw,row,references,calibration,metadata)
        observation['calibrationHash']=calhash
        observation['antennaSpacingM']=metadata['spacing_m']
        age=max(0,status['generated_monotonic_s']-row['monotonic_s'])
        now=time.monotonic()
        with self.lock:
            history=self.history.setdefault(station['id'],deque(maxlen=8))
            if old and (old['sessionId']!=observation['sessionId'] or old.get('calibrationHash')!=observation['calibrationHash']): history.clear()
            self.observations[station['id']]=dict(observation,key=key,received=now,
                initialAge=age,boardAge=age,timestamp=time.time()*1000-age*1000,
                streamAlive=status['state'] not in ('complete','aborted'))
            history.append(dict(self.observations[station['id']]))
            self.errors.pop(station['id'],None)

    def run(self):
        workers={}
        def worker(identifier):
            while not self.stop.is_set():
                try:
                    if self.diagnostic_mode:
                        self.stop.wait(.5);continue
                    station=next((s for s in self.config().get('stations',[]) if s['id']==identifier),None)
                    if station and station.get('url'): self.poll_station(station)
                except Exception as exc:
                    with self.lock: self.errors[identifier]=str(exc)
                self.stop.wait(.5)
        while not self.stop.is_set():
            try:
                for station in self.config().get('stations',[]):
                    if station['id'] not in workers:
                        thread=threading.Thread(target=worker,args=(station['id'],),daemon=True)
                        workers[station['id']]=thread; thread.start()
            except Exception as exc:
                with self.lock: self.errors['config']=str(exc)
            self.stop.wait(1)
        for thread in workers.values(): thread.join(3)

    def snapshot(self):
        config=self.config(); now=time.monotonic()
        with self.lock:
            observations=copy.deepcopy(self.observations); errors=dict(self.errors)
            histories={key:list(copy.deepcopy(value)) for key,value in self.history.items()}
        ids=[s['id'] for s in config.get('stations',[]) if s.get('url')]
        if len(ids)>=2 and all(observations.get(i,{}).get('streamAlive') and i not in errors for i in ids[:2]):
            pairs=[]
            for first in histories.get(ids[0],[]):
                for second in histories.get(ids[1],[]):
                    if first.get('frameKey') and first.get('frameKey')==second.get('frameKey') and all(o.get('framePairingEligible') is not False and max(o['boardAge'],o['initialAge']+now-o['received'])<=config.get('maxAgeSeconds',3) for o in (first,second)):
                        pairs.append((min(first['timestamp'],second['timestamp']),first,second))
            if pairs:
                _,first,second=max(pairs,key=lambda row:row[0])
                observations[ids[0]]=first; observations[ids[1]]=second
        stations=[]
        for setup in config.get('stations',[]):
            obs=observations.get(setup['id']); x=setup.get('xM'); y=setup.get('yM')
            reference_problem=None
            if obs and obs.get('processingLocation')=='board':
                try:verify_observation_context(obs,setup,ROOT)
                except (ValueError,KeyError,OSError,TypeError) as exc:reference_problem=str(exc)
            if obs and obs.get('calibrationStatus')=='provisional_reference':
                try:verify_observation_reference(obs,setup,ROOT)
                except (ValueError,KeyError,OSError,TypeError) as exc:reference_problem=str(exc)
            if setup.get('calibration') and not self.diagnostic_mode:
                try:
                    reference=self.load_reference(setup)
                    if obs and obs.get('calibrationHash')!=hashlib.sha256(json.dumps(reference,sort_keys=True).encode()).hexdigest():
                        reference_problem='标定已更新，等待当前会话重新计算角度'
                except (ValueError,KeyError,OSError) as exc:reference_problem=str(exc)
            if reference_problem:obs=None
            lat,lon=geographic(config.get('anchor'),x,y) if x is not None and y is not None else (None,None)
            item=dict(id=setup['id'],name=setup.get('name',setup['id']),latitude=lat,longitude=lon,
                xM=x,yM=y,headingDeg=setup.get('headingDeg'),rayLengthM=setup.get('rayLengthM',10),
                relativeAngle=None,bearing=None,fresh=False,error=reference_problem or errors.get(setup['id']),
                antennaSpacingM=setup.get('antennaSpacingM'),calibrationRequired=bool(reference_problem),
                quality=reference_problem or ('等待同源IQ／未校准诊断' if self.diagnostic_mode else '等待真实观测' if setup.get('url') else '设备尚未接入'),
                orientationSource=setup.get('orientationSource','未设置'))
            if obs:
                age=max(obs['boardAge'],obs['initialAge']+now-obs['received'])
                fresh=obs['streamAlive'] and age<=config.get('maxAgeSeconds',3) and setup['id'] not in errors
                item.update({k:v for k,v in obs.items() if k not in ('key','received','initialAge','boardAge','streamAlive')})
                item.update(ageSeconds=age,fresh=fresh,bearing=(setup['headingDeg']+obs['relativeAngle'])%360 if setup.get('headingDeg') is not None and obs.get('relativeAngle') is not None else None)
            stations.append(item)
        full=config.get('directionMode','front')=='full'
        for item in stations:
            item['bearingCandidates']=bearing_solutions(item) if full and item.get('fresh') else []
        origin=midpoint_origin(stations[0],stations[1]) if len(stations)>=2 else None
        if origin:
            lat,lon=geographic(config.get('anchor'),origin['xM'],origin['yM']);origin.update(latitude=lat,longitude=lon)
        positioned=[s for s in stations if s.get('fresh') and s.get('bearing') is not None]
        point=None; reason='等待两站可反演角度；当前保留有效原始相位' if any(s.get('fresh') and s.get('relativeAngle') is None and s.get('phaseDeg') is not None for s in stations) else '等待第二台设备的真实角度'
        points=[]
        if len(positioned)>=2 and any(s.get('framePairingEligible') is False for s in positioned[:2]):
            reason='空数据帧仅用于单站相位，等待可区分的同一数据帧双站观测'
        elif len(positioned)>=2:
            if full:
                points,reason=intersect_candidates(positioned[0],positioned[1],config.get('minCrossingDeg',1),config.get('maxPairSkewMs',2000))
                if len(points)==1:point=points[0]
                elif len(points)>1:reason='存在%d个前后方向候选，尚未消歧'%len(points)
            else:
                point,reason=intersect(positioned[0],positioned[1],config.get('minCrossingDeg',5),config.get('maxPairSkewMs',2000))
                if point:points=[point]
        for candidate in points:
            lat,lon=geographic(config.get('anchor'),candidate['xM'],candidate['yM'])
            candidate.update(latitude=lat,longitude=lon,relativeToMidpoint=relative_to_midpoint(candidate,origin),
                quality='前后模糊候选／未消歧' if candidate.get('ambiguous') else '实测角度试验交汇／精度待优化',uncertaintyM=None)
            if positioned:candidate.update(targetId=positioned[0].get('targetId'),sourceMac=positioned[0].get('sourceMac'),sourceClass=positioned[0].get('sourceClass'),broadcastIdentities=positioned[0].get('broadcastIdentities',[]))
        target=next((s.get('targetId') for s in stations if s.get('targetId')),None)
        diagnostic_status='provisional_reference' if positioned and all(s.get('calibrationStatus')=='provisional_reference' for s in positioned) else 'uncalibrated'
        if self.diagnostic_mode:
            for candidate in points:candidate.update(calibrationStatus=diagnostic_status,geometryVerified=False,productionAccepted=False,quality='临时已知参考交汇／精度待独立验证／前后候选' if diagnostic_status=='provisional_reference' else '未校准诊断交汇／实际几何待确认／前后候选')
        return dict(configured=bool(config.get('stations')),connected=any(s['fresh'] and s.get('relativeAngle') is not None for s in stations),
            source='双RX同源帧测向' if self.diagnostic_mode else 'OpenWiFi双RX／参考源实测联调',scope='provisional_reference_source_conditioned_diagnostic' if self.diagnostic_mode and diagnostic_status=='provisional_reference' else 'uncalibrated_source_conditioned_diagnostic' if self.diagnostic_mode else 'bounded_reference_source_integration',demo=False,timestamp=time.time()*1000,
            targetId=target,stations=stations,intersection=point,intersections=points,intersectionReason=reason,
            directionMode='full' if full else 'front',midpoint=origin,displayCoordinateOrigin='station_midpoint',
            anchor=config.get('anchor'),precisionValidated=False,productionAccepted=False,calibrationStatus=diagnostic_status if self.diagnostic_mode else 'reference_required_or_provisional',geometryVerified=False)
