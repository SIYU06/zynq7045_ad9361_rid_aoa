$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Devices.Geolocation.Geolocator, Windows.Devices.Geolocation, ContentType=WindowsRuntime]
    $positionType = [Windows.Devices.Geolocation.Geoposition, Windows.Devices.Geolocation, ContentType=WindowsRuntime]
    $locator = New-Object Windows.Devices.Geolocation.Geolocator
    $locator.DesiredAccuracy = [Windows.Devices.Geolocation.PositionAccuracy]::High
    $locator.DesiredAccuracyInMeters = 5
    $operation = $locator.GetGeopositionAsync([TimeSpan]::Zero, [TimeSpan]::FromSeconds(12))
    $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and
        $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    } | Select-Object -First 1
    $task = $asTask.MakeGenericMethod($positionType).Invoke($null, @($operation))
    if (-not $task.Wait(15000)) { $operation.Cancel(); throw 'System location timed out' }
    $coordinate = $task.Result.Coordinate
    $position = $coordinate.Point.Position
    [ordered]@{
        available = $true
        provider = 'windows'
        source = $coordinate.PositionSource.ToString()
        latitude = $position.Latitude
        longitude = $position.Longitude
        accuracy = $coordinate.Accuracy
        timestamp = $coordinate.Timestamp.ToUnixTimeMilliseconds()
    } | ConvertTo-Json -Compress
} catch {
    [ordered]@{available=$false; provider='windows'; error=$_.Exception.GetBaseException().Message} | ConvertTo-Json -Compress
}
