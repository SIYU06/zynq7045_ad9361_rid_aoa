import {state,changes} from './data.js';
import {jsonFetch} from './workspace-core.js';

export function receiverRoleView(value,live=true){
 const selected=value?.selectedStation;
 return {selected,canApply:live&&!!selected&&!value?.applying,
  label:!live?'回放不控制接收站':value?.applying?'接收站切换中':value?.error?'分工未确认 · '+value.error:
   value?.confirmed?`${selected}站检测与解码 · A站信源识别 · 双站测向`:'等待板端确认接收分工'};
}

export function setupReceiverControl({toast,onChanged}){
 const page=document.querySelector('[data-page="signals"]'),panel=document.createElement('section');
 panel.className='receiver-role-control';panel.setAttribute('aria-label','实机接收任务');
 panel.innerHTML='<div><strong>信源接收站</strong><span id="receiver-role-status" role="status">正在读取</span></div><div class="button-row"><label for="receiver-role-select">检测与身份解析</label><select id="receiver-role-select"><option value="B">B站</option><option value="A">A站</option></select><button id="receiver-role-apply" disabled>应用分工</button></div>';
 page.querySelector('.page-heading').after(panel);
 const select=panel.querySelector('select'),button=panel.querySelector('button'),status=panel.querySelector('[role="status"]');
 const filter=document.getElementById('signals-station');
 if(filter){filter.setAttribute('aria-label','列表站点筛选');filter.title='仅筛选列表；实机接收站由上方分工设置';filter.options[0].textContent='显示全部站点';}
 let value=null,busy=false,polling=false,dirty=false;
 function render(){
  const view=receiverRoleView(value,state.mode==='external');
  if(!dirty&&view.selected)select.value=view.selected;
  select.disabled=busy||state.mode!=='external'||!value?.selectedStation;
  button.disabled=busy||!view.canApply;button.textContent=busy?'正在切换…':'应用分工';
  status.textContent=busy?'等待两站确认任务切换':view.label;
  status.classList.toggle('receiver-role-error',!!value?.error);
 }
 async function poll(){if(polling||busy)return;polling=true;try{value=await jsonFetch('/api/receiver/config');render();}catch(e){status.textContent=e.message;}finally{polling=false;}}
 select.onchange=()=>{dirty=true;render();};
 button.onclick=async()=>{
  if(busy||state.mode!=='external'||!value)return;
  const selectedStation=select.value,revision=value.revision;busy=true;render();
  try{
   value=await jsonFetch('/api/receiver/config',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({selectedStation,revision}),signal:AbortSignal.timeout(22000)});
   dirty=false;onChanged?.();toast(value.confirmed?`${value.selectedStation}站负责信源解码，双站测向保留`:`已选择${value.selectedStation}站，其余站分工待确认`);
  }catch(e){toast(e.message);dirty=false;}
  finally{busy=false;render();await poll();}
 };
 changes.addEventListener('change',render);poll();setInterval(poll,2000);
 return {render,poll};
}
