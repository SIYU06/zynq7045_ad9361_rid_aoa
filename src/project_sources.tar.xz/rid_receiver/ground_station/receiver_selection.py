"""One full decoder, two independent IQ receivers; transactional role control."""
import copy
import json
from pathlib import Path
import threading
import time
from urllib.request import build_opener,ProxyHandler,Request
from urllib.error import HTTPError,URLError

class ReceiverConflict(ValueError):pass
class ReceiverUnavailable(RuntimeError):pass

class ReceiverSelection:
    def __init__(self,urls,path):
        self.urls={s:u.rstrip('/') for s,u in urls.items() if u};self.path=Path(path)
        self.lock=threading.RLock();self.operation=threading.Lock();self.stop=threading.Event()
        self.opener=build_opener(ProxyHandler({}));self.boards={};self.error=None;self.applying=False;self.verified=0
        value=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
        self.selected=value.get('selectedStation','B' if 'B' in self.urls else next(iter(self.urls),None))
        if self.selected is not None and self.selected not in self.urls:raise ValueError('Unknown configured receiver')
        self.revision=value.get('revision',0)
        if type(self.revision) is not int or self.revision<0:raise ValueError('Invalid receiver revision')

    def is_selected(self,station):
        with self.lock:return station==self.selected

    def accepts_session(self,station,session):
        with self.lock:
            expected=self.boards.get(station,{}).get('sessionId')
            return station==self.selected and (not expected or session==expected)

    def request(self,station,enabled=None):
        body=json.dumps(dict(enabled=enabled)).encode() if enabled is not None else None
        path='/api/receiver/control' if body is not None else '/api/receiver/status'
        request=Request(self.urls[station]+path,data=body,headers={'Content-Type':'application/json'} if body is not None else {})
        with self.opener.open(request,timeout=4) as response:data=response.read(16385)
        if len(data)>16384:raise ReceiverUnavailable('Receiver response too large')
        value=json.loads(data)
        if type(value.get('enabled')) is not bool or type(value.get('ready')) is not bool:
            raise ReceiverUnavailable('板端接收角色接口需要更新')
        return value

    def _persist(self,station,revision):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        temporary=self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps(dict(selectedStation=station,revision=revision),indent=2)+'\n',encoding='utf-8')
        temporary.replace(self.path)

    def apply(self,station,revision=None):
        if station not in self.urls:raise ValueError('只能选择已配置的A/B接收站')
        if not self.operation.acquire(blocking=False):raise ReceiverConflict('接收站正在切换，请稍后重试')
        old=self.selected;changed=[]
        try:
            with self.lock:
                if revision is not None and (type(revision) is not int or revision!=self.revision):raise ReceiverConflict('接收配置已更新，请重新载入')
                self.applying=True
            # Enable/acknowledge the new decoder before stopping the old one.
            order=[station]+[s for s in self.urls if s!=station]
            values={};warnings=[]
            for identifier in order:
                changed.append(identifier)
                try:value=self.request(identifier,enabled=identifier==station)
                except (URLError,TimeoutError,OSError) as exc:
                    if identifier==station or isinstance(exc,HTTPError):raise
                    warnings.append('站'+identifier+'离线／未确认关闭完整解码，恢复连接后重试')
                    values[identifier]=dict(enabled=None,ready=False,error=str(exc));continue
                if not value['ready'] or value['enabled']!=(identifier==station):raise ReceiverUnavailable('站'+identifier+'未确认接收角色')
                values[identifier]=value
            with self.lock:
                revision_next=self.revision+(station!=old)
                self._persist(station,revision_next)
                self.selected=station;self.revision=revision_next;self.boards=values
                self.error='；'.join(warnings) or None;self.verified=time.monotonic() if not warnings else 0;self.applying=False
            return self.snapshot()
        except ReceiverConflict:raise
        except Exception as exc:
            # A partial network failure must not silently commit a UI-only switch.
            rollback=[]
            for identifier in reversed(changed):
                try:self.request(identifier,enabled=identifier==old)
                except Exception as failure:rollback.append(identifier+': '+str(failure))
            with self.lock:
                self.error=str(exc)+('；恢复未确认：'+'; '.join(rollback) if rollback else '')
                self.verified=0
            raise ReceiverUnavailable(self.error) from exc
        finally:
            with self.lock:self.applying=False
            self.operation.release()

    def refresh(self):
        with self.lock:selected=self.selected;revision=self.revision
        if selected is None:return
        values={}
        for identifier in [selected]+[s for s in self.urls if s!=selected]:
            try:values[identifier]=self.request(identifier)
            except (URLError,TimeoutError,OSError) as exc:
                if identifier==selected or isinstance(exc,HTTPError):raise
                values[identifier]=dict(ready=False,enabled=None,error=str(exc))
        if any(not v['ready'] or v['enabled']!=(s==selected) for s,v in values.items()):
            self.apply(selected,revision);return
        with self.lock:
            if self.selected!=selected or self.revision!=revision:return
            self.boards=values;self.error=None;self.verified=time.monotonic()
        if not self.path.exists():self._persist(selected,self.revision)

    def run(self):
        while not self.stop.is_set():
            try:self.refresh()
            except ReceiverConflict:pass
            except Exception as exc:
                with self.lock:self.error=str(exc);self.verified=0
            self.stop.wait(5)

    def snapshot(self):
        with self.lock:
            age=time.monotonic()-self.verified if self.verified else None
            return dict(selectedStation=self.selected,revision=self.revision,applying=self.applying,
                confirmed=age is not None and age<12 and not self.error,ageSeconds=age,error=self.error,
                stations=[dict(id=s,selected=s==self.selected,
                    task='检测／解码＋双RX测向' if s==self.selected else '双RX测向待命',
                    actual=copy.deepcopy(self.boards.get(s))) for s in self.urls],
                directionStations=list(self.urls),scope='single decoder; both stations retain local IQ/frame association')
