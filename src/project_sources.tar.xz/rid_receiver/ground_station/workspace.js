import {config} from './config.js';
import {state,changes,notify,reset,ingestRID,ingestDOA,setConnection,hasPosition,log,pruneTracks} from './data.js';
import {setupMapControls} from './map-controls.js?v=tile-state-20261103';
import {setupStationEditor} from './station-editor.js';
import {setupDirection} from './direction-view.js';
import {setupRecords} from './records-view.js';
import {startTransport} from './transport.js';
import {setupSignals} from './signals-view.js';
import {setupHome} from './home-experience.js?v=20261102a';
import {setupPipeline,directionStatus} from './pipeline-view.js';
import {setupReceiverControl} from './receiver-control.js';
import {setupChannelScan} from './channel-scan.js';
import {setupAOAReference} from './aoa-reference.js?v=dispatch-feedback-20261103';
import {setupMonitorData} from './monitor-data.js';
import {trackSegments} from './doa-tracks.js';
import {monitorTargets,aircraftMarkup} from './monitor-targets.js';
import {localFrame,localPoint,localPointLabel} from './position-display.js';
import {droneSVG,fixedSVG} from './map-symbols.js';
import {esc,fmt,time,finite,geographic,freshStation,phaseStationFresh,phaseStateLabel,jsonFetch,intersectionReady,intersectionPoints,midpointCoordinates,bearingsForStation} from './workspace-core.js';
const $=id=>document.getElementById(id),text=(id,value)=>$(id).textContent=value??'—';
const modes={external:'真实接入',replay:'历史回放'};
let page='home',nextPage=null,configuration=null,selected=null,map=null,markers=null,doaLayers=null,records=null,mapControls=null;
let drawerPinned=false,drawerTab='targets',drawerTimer=null,toastTimer=null,renderPending=false,listKey='',eventsKey='',serviceOK=false;
function toast(message){text('toast',message);$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,4500);}
const clock=()=>state.replayClock??Date.now();
const old=t=>!t||clock()-t.timestamp>config.staleAfterMs;
let cursorPoint=null;
const displayLayout=()=>state.mode==='external'?configuration:state.doa;
const displayFrame=()=>localFrame(displayLayout());
function updateCoordinates(){text('map-coordinates',cursorPoint?localPointLabel(cursorPoint,displayFrame()):'东 X — m · 北 Y — m');}
function drawer(tab='targets',pin=false){clearTimeout(drawerTimer);drawerTab=tab;drawerPinned=pin;$('map-drawer').hidden=false;
  for(const name of ['targets','details','computer'])$('drawer-'+name).hidden=name!==tab;
  text('drawer-title',tab==='details'?'观测详情':tab==='computer'?'电脑位置':'观测目标');$('drawer-back').hidden=tab!=='details';$('drawer-pin').setAttribute('aria-pressed',String(pin));$('targets-open').setAttribute('aria-expanded',String(tab!=='computer'));$('computer-open').setAttribute('aria-expanded',String(tab==='computer'));
}
function closeDrawer(){clearTimeout(drawerTimer);$('map-drawer').hidden=true;drawerPinned=false;for(const id of ['targets-open','computer-open'])$(id).setAttribute('aria-expanded','false');}
function delayedClose(){clearTimeout(drawerTimer);if(!drawerPinned)drawerTimer=setTimeout(closeDrawer,500);}
for(const [id,tab] of [['targets-open','targets'],['computer-open','computer']]){$(id).onclick=()=>drawer(tab,true);$(id).onpointerenter=event=>{if(event.pointerType==='mouse'&&!drawerPinned)drawer(tab,false);};$(id).onpointerleave=delayedClose;}
$('map-drawer').onpointerenter=()=>clearTimeout(drawerTimer);$('map-drawer').onpointerleave=delayedClose;
$('drawer-pin').onclick=()=>{drawerPinned=!drawerPinned;$('drawer-pin').setAttribute('aria-pressed',String(drawerPinned));};$('drawer-close').onclick=closeDrawer;$('drawer-back').onclick=()=>drawer('targets',true);
function mode(value){records?.stop();selected=null;reset(value);$('input-mode').value=value;listKey='';schedule();}
function route(requested,force=false){const dest=['home','monitor','signals','direction','stations','records'].includes(requested)?requested:'home';
  if(page==='stations'&&dest!==page&&editor.dirty()&&!force){nextPage=dest;$('leave-dialog').showModal();history.replaceState(null,'','#/stations');return;}
  page=dest;for(const el of document.querySelectorAll('[data-page]'))el.hidden=el.dataset.page!==page;
  for(const link of document.querySelectorAll('[data-route]')){link.classList.toggle('active',link.dataset.route===page);if(link.dataset.route===page)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');}
  if(location.hash!==`#/${page}`)history.replaceState(null,'',`#/${page}`);document.title=`${({home:'首页',monitor:'态势地面站',signals:'信源检测',direction:'测向工作台',stations:'设备与布站',records:'记录与诊断'})[page]} · 空域知微`;
  document.body.classList.toggle('is-home',page==='home');signals.activate(page==='signals');home.activate(page==='home');
  if(page!=='monitor')closeDrawer();mapControls?.activate(page==='monitor');requestAnimationFrame(()=>{map?.invalidateSize();editor.resize(page==='stations');schedule();});
}
window.addEventListener('hashchange',()=>route(location.hash.slice(2)));
for(const button of document.querySelectorAll('[data-leave]'))button.onclick=async()=>{const action=button.dataset.leave;if(action==='save'&&!await editor.save())return;if(action==='discard')editor.cancel();$('leave-dialog').close();if(action!=='stay'){location.hash=`#/${nextPage}`;route(nextPage,true);}};
$('input-mode').onchange=event=>mode(event.target.value);
document.addEventListener('keydown',event=>{if(event.key==='Escape'){closeDrawer();editor.cancelPick();}if(event.ctrlKey&&event.key==='Enter'&&page==='stations'){event.preventDefault();editor.save();}});
if(globalThis.L){map=L.map('map',{zoomControl:false,maxZoom:config.maxZoom,minZoom:2,worldCopyJump:true}).setView(config.center,config.zoom);L.control.scale({imperial:false,maxWidth:110,position:'bottomright'}).addTo(map);markers=L.layerGroup().addTo(map);doaLayers=L.layerGroup().addTo(map);
  map.on('mousemove',e=>{cursorPoint={latitude:e.latlng.lat,longitude:e.latlng.lng};updateCoordinates();});
  mapControls=setupMapControls(map,{active:location.hash==='#/monitor',formatPosition:point=>localPointLabel({latitude:point[0],longitude:point[1]},displayFrame())});
}else{$('tile-notice').hidden=false;text('tile-notice','本地地图资源缺失，请检查vendor目录。');}
function stationPoint(s){return hasPosition(s)?[s.latitude,s.longitude]:geographic(configuration?.anchor,s.xM,s.yM);}
function fit(){
  if(!map)return;const points=monitorTargets({pipeline:processing.snapshot(),now:clock()}).flatMap(t=>[...(hasPosition(t.position)?[[t.position.latitude,t.position.longitude]]:[]),...t.points.filter(hasPosition).map(p=>[p.latitude,p.longitude])]);
  const feed=state.doa,stations=state.mode==='external'?(configuration?.stations||[]):feed?.stations||[],intersections=intersectionPoints(feed,state.mode,clock(),state.doaConnected);
  for(const s of stations){const p=stationPoint(s);if(p)points.push(p);}
  for(const point of intersections)if(hasPosition(point))points.push([point.latitude,point.longitude]);
  if(feed?.directionMode==='full'&&state.doaConnected)for(const s of feed.stations){
    if(!freshStation(s,feed,state.mode,clock()))continue;const p=stationPoint(s);if(!p)continue;
    const setup=stations.find(item=>item.id===s.id)||s,len=Math.max(setup.rayLengthM??50,...intersections.filter(point=>finite(point.xM)&&finite(point.yM)).map(point=>Math.hypot(point.xM-s.xM,point.yM-s.yM)*1.05));
    for(const candidate of bearingsForStation(s,'full')){const r=candidate.bearingDeg*Math.PI/180;points.push(geographic({latitude:p[0],longitude:p[1]},Math.sin(r)*len,Math.cos(r)*len));}}
  if(points.length)map.fitBounds(points,{maxZoom:22,padding:[65,80]});else toast('暂无可适配的位置');
}
function selectTarget(id,rf=false){selected=(rf?'rf:':'')+id;drawer('details',true);const row=monitorTargets({pipeline:processing.snapshot(),now:clock()}).find(r=>r.id===id||r.mac===id),p=rf?row?.points.find(hasPosition):row?.position;if(hasPosition(p))map?.setView([p.latitude,p.longitude],Math.max(map.getZoom(),17));schedule();}
function list(){const query=$('search').value.trim().toLowerCase(),filter=$('target-filter').value;
  const key=JSON.stringify([state.epoch,selected,query,filter,[...state.targets.values()].map(t=>[t.id,t.timestamp,t.positionStatus,old(t)]),state.candidates,processing.snapshot()?.timestamp,state.doa?.timestamp]);if(key===listKey)return;listKey=key;
  const rows=monitorTargets({pipeline:processing.snapshot(),now:clock()}).map(row=>({...row.target,id:row.id,displayId:row.title,sourceMac:row.mac,rf:!row.target,timestamp:row.timestamp,frequencyMhz:row.frequencyMhz,classification:row.source?.recognition?.label||'AOA测向候选',positionStatus:row.positionFresh?'RID广播位置':row.points.length?'AOA交汇候选':'等待有效位置'})).concat(state.candidates.map(t=>({...t,id:t.mac,rf:true})));
  $('target-list').replaceChildren();for(const t of rows){const stale=old(t)||t.historical;if(query&&!`${t.id} ${t.sourceMac||''} ${t.source||''} ${t.classification||''}`.toLowerCase().includes(query))continue;if(filter==='rid'&&t.rf||filter==='rf'&&!t.rf||filter==='stale'&&!stale)continue;
    const button=document.createElement('button');button.className='target-item'+(stale?' stale':'')+(selected===(t.rf?'rf:':'')+t.id?' selected':'');button.setAttribute('aria-pressed',String(selected===(t.rf?'rf:':'')+t.id));button.innerHTML=`${t.rf?'':`<span class="mini-aircraft">${t.type?.includes('固定翼')?fixedSVG:droneSVG}</span>`}<span class="target-copy"><strong>${esc(t.displayId||t.id)}</strong><small>${esc(t.rf?t.classification||'Wi-Fi候选':t.type||'RID身份 · 类型未知')}</small><small>${t.rf?`${esc(t.frequencyMhz)} MHz · ${esc(t.positionStatus||'无独立位置')}`:`${esc(t.positionStatus||'位置待提供')}`}</small></span><em>${state.mode==='replay'?'历史':stale?'过期':t.rf?'待归因':'RID'}</em>`;
    button.onclick=()=>selectTarget(t.id,t.rf);$('target-list').append(button);}
  if(!$('target-list').children.length)$('target-list').innerHTML='<p class="empty">暂无匹配观测</p>';text('target-count',rows.length);
}
function details(){let html='';if(selected?.startsWith('rf:')){const current=monitorTargets({pipeline:processing.snapshot(),now:clock()}).find(row=>row.key===selected||row.mac===selected.slice(3));
    if(current)html=`<span class="badge">疑似无人机 · ${current.points.length?'AOA交汇候选':current.source?directionStatus(current.source):'等待AOA'}</span><h3>${esc(current.title)}</h3><dl>${[['空口MAC',current.mac],['频率',`${current.frequencyMhz??'—'} MHz`],['定位方式','双站AOA'],['识别依据',current.source?.recognition?.evidence?.join('；')||'同源测向观测'],['观测时间',time(current.timestamp)]].map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl><p class="muted">无RID不等于黑飞；黄色图标表示测向估计或候选，精度与前后方向需核验。</p>`;
    const t=state.candidates.find(t=>t.mac===selected.slice(3));if(!current&&t)html=`<span class="badge">历史实验 · 非实时</span><h3>${esc(t.mac)}</h3><p>${esc(t.classification)}</p><dl>${[['接收MAC',t.receiver],['频率',`${t.frequencyMhz} MHz`],['公开UDP头',t.network],['记录时间',time(t.timestamp)],['来源',t.source]].map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl><p class="muted">未取得机型、RID或DOA，不根据MAC生成地图坐标。</p>`;
  }else{const t=state.targets.get(selected);if(t)html=`<span class="badge">${state.mode==='replay'?'历史回放':old(t)?'观测过期':'RID广播 · 身份未认证'}</span><h3>${esc(t.id)}</h3><p class="muted">${esc(t.type)} · ${esc(t.status)}</p><div class="detail-grid">${[['几何高度/m',fmt(t.altitude)],['速度/m·s⁻¹',fmt(t.speed)],['RID航向/°',fmt(t.heading)],['接收参数',`${fmt(t.frequencyMhz,0)} MHz`]].map(([k,v])=>`<div><span>${k}</span><strong>${v}</strong></div>`).join('')}</div><dl>${[['局部东X / m',fmt(localPoint(t,displayFrame())?.xM,2)],['局部北Y / m',fmt(localPoint(t,displayFrame())?.yM,2)],['空口MAC',t.sourceMac],['观测时间',time(t.timestamp)],['来源',t.source]].map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl><p class="muted">${esc(t.positionStatus||'RID位置独立于测向定位。')}</p>`;}
  $('drawer-details').innerHTML=html||'<p class="empty">请选择一个观测目标</p>';
  const receiverTarget=selected&&!selected.startsWith('rf:')?state.targets.get(selected):null;
  if(receiverTarget?.receiverStations?.length){const row=document.createElement('div'),label=document.createElement('dt'),value=document.createElement('dd');label.textContent='接收站';value.textContent=receiverTarget.receiverStations.join(' / ');row.append(label,value);$('drawer-details').querySelector('dl')?.append(row);}
}
function mapRender(){if(!map||page!=='monitor')return;markers.clearLayers();doaLayers.clearLayers();let positioned=0;
  const targets=monitorTargets({pipeline:processing.snapshot(),now:clock()});
  for(const row of targets){const t=row.target,stale=!row.positionFresh;
    if(hasPosition(row.position)&&(row.method==='rid'||!row.points.length)){
      positioned++;const p=[row.position.latitude,row.position.longitude];
      L.marker(p,{opacity:stale?.4:1,icon:L.divIcon({className:'plane-marker',html:aircraftMarkup({...row,method:'rid'},t?.type?.includes('固定翼')?fixedSVG:droneSVG),iconSize:[38,38],iconAnchor:[19,19]})}).addTo(markers).on('click',()=>selectTarget(row.id)).bindTooltip(`${esc(row.title)} · ${stale?'RID最后有效位置／历史':'RID广播位置'}`);}
    for(const segment of trackSegments({points:row.ridHistory}))L.polyline(segment,{color:'#36816f',weight:2,opacity:stale?.25:.7}).addTo(markers);}
  const feed=state.doa,active=state.doaConnected&&(state.mode==='replay'||!old(feed)),stations=state.mode==='external'?(configuration?.stations||[]):feed?.stations||[];
  const intersections=intersectionPoints(feed,state.mode,clock(),state.doaConnected);
  for(const row of targets.filter(t=>t.method==='aoa')){
    for(const track of row.tracks)for(const segment of trackSegments(track))L.polyline(segment,{color:'#f2c453',weight:2.5,opacity:row.points.length?.75:.25,dashArray:'5 4'}).bindTooltip(`${esc(row.title)} · AOA交汇候选轨迹${row.points.length?'':'／历史'}`).addTo(doaLayers);
    for(const point of row.points){if(!hasPosition(point))continue;const relative=midpointCoordinates(row.feed,point);
      L.marker([point.latitude,point.longitude],{opacity:point.ambiguous?.7:1,icon:L.divIcon({className:'plane-marker aoa-marker',html:aircraftMarkup(row,droneSVG),iconSize:[38,38],iconAnchor:[19,19]})}).bindTooltip(`${esc(row.title)} · ${point.ambiguous?'AOA候选／前后未消歧':'AOA交汇估计'}${relative?` · 中点 (${fmt(relative.xM,2)}, ${fmt(relative.yM,2)}) m`:''}`).on('click',()=>selectTarget(row.id,!row.target)).addTo(doaLayers);positioned++;}
  }
  for(const setup of stations){const p=stationPoint(setup);if(!p)continue;const s=feed?.stations.find(s=>s.id===setup.id),color=setup.id==='B'?'#d6a463':'#75afc0';L.marker(p,{icon:L.divIcon({className:'station-marker',html:`<span class="station-pin ${setup.id==='B'?'b':''}">${esc(setup.id)}</span>`,iconSize:[28,28],iconAnchor:[14,14]})}).bindTooltip(`站 ${esc(setup.id)} · ${esc(setup.orientationSource||'朝向待核验')}`).addTo(doaLayers);
    if(active&&freshStation(s,feed,state.mode,clock())&&finite(s.bearing)){
      const len=Math.max(setup.rayLengthM??s.rayLengthM??50,...intersections.filter(point=>finite(point.xM)&&finite(point.yM)&&finite(s.xM)&&finite(s.yM)).map(point=>Math.hypot(point.xM-s.xM,point.yM-s.yM)*1.05));
      for(const candidate of bearingsForStation(s,feed.directionMode)){const r=candidate.bearingDeg*Math.PI/180,point=geographic({latitude:p[0],longitude:p[1]},Math.sin(r)*len,Math.cos(r)*len);L.polyline([p,point],{color,weight:1.6,dashArray:candidate.branch==='back'?'2 6':'5 5',opacity:.75}).bindTooltip(`站 ${s.id} · ${candidate.branch==='back'?'后向候选':'前向方向'}`).addTo(doaLayers);}}}
  if(stations.length>=2&&stations.slice(0,2).every(s=>finite(s.xM)&&finite(s.yM))){const origin=geographic(state.mode==='external'?configuration?.anchor:feed?.anchor,(stations[0].xM+stations[1].xM)/2,(stations[0].yM+stations[1].yM)/2);if(origin)L.circleMarker(origin,{radius:3,color:'#b6c9ce',fillOpacity:1,weight:1}).bindTooltip('O · 两站中点，交汇坐标原点').addTo(doaLayers);}
  $('map-empty').hidden=positioned>0;
}
function events(){const query=$('event-search').value.toLowerCase(),kind=$('event-kind').value,key=JSON.stringify([state.events,query,kind]);if(key===eventsKey)return;eventsKey=key;const rows=state.events.filter(e=>(kind==='all'||e.kind===kind)&&`${time(e.time)} ${e.kind} ${e.message} ${e.source}`.toLowerCase().includes(query));$('events').replaceChildren();for(const row of rows){const tr=document.createElement('tr');for(const value of [time(row.time),row.kind,row.message,row.source]){const td=document.createElement('td');td.textContent=value;tr.append(td);}$('events').append(tr);}text('event-count',rows.length);$('events-empty').hidden=rows.length>0;}
function status(){const freshTargets=[...state.targets.values()].filter(t=>!old(t)&&state.ridConnected),stations=state.doa?.stations||[],freshStations=stations.filter(s=>state.doaConnected&&freshStation(s,state.doa,state.mode,clock())),phaseStations=stations.filter(s=>phaseStationFresh(s,state.doa,state.mode,clock()));
  text('home-mode',modes[state.mode]);text('home-stations',['A','B'].map(id=>{const receiver=state.mode==='external'?state.receivers.find(s=>s.id===id):null,phase=phaseStations.find(s=>s.id===id);return `${id} ${freshStations.some(s=>s.id===id)?'测向中':phase?phaseStateLabel(phase):receiver?.standbyReady?'测向待命':receiver?.receiving?'收帧中':receiver?.connected?'在线':'待连接'}`;}).join(' / '));text('home-observations',`${freshTargets.length}个RID · ${new Set([...phaseStations,...freshStations].map(s=>s.id)).size}站计算 · ${freshStations.length}站有角度`);text('home-last',time(state.lastUpdate));text('clock',time(Date.now()));text('mode-note',`${modes[state.mode]}${state.mode==='replay'?' · 保留原始时间':''}`);
  text('rid-status',`RID ${state.mode==='replay'?'历史':state.ridConnected?'接口可达':'未连接'} / ${freshTargets.length}有效`);text('doa-status',`测向 ${state.mode==='replay'?'历史':freshStations.length?(state.doa?.calibrationStatus==='uncalibrated'?'未校准诊断':'有新观测'):phaseStations.length?phaseStateLabel(phaseStations[0]):'等待观测'}`);
  text('home-state',state.mode==='replay'?'正在查看历史记录':freshTargets.length||freshStations.length||phaseStations.length?'正在接收观测':'等待外部观测');text('home-description',state.mode==='external'?'硬件未连接时仍可配置站点与查看记录，真实数据接入后自动更新。':'历史时间与来源保留，回放不代表设备当前在线。');
  const c=configuration,a=c?.stations.find(s=>s.id==='A'),b=c?.stations.find(s=>s.id==='B');text('home-geometry',a&&b?`已配置A/B站 · 基线 ${fmt(Math.hypot(a.xM-b.xM,a.yM-b.yM),3)} m · 朝向以配置来源为准`:'站点配置待载入');
  text('service-status',serviceOK?'本机服务正常':'本机服务检查中');$('service-light').classList.toggle('active',serviceOK);
  if($('connection-raw').parentElement.open)text('connection-raw',JSON.stringify({mode:state.mode,receivers:state.receivers,rid:state.ridFeed,doa:state.doaFeed},null,2));
}
function render(){renderPending=false;pruneTracks(clock());list();if(drawerTab==='details'&&!$('map-drawer').hidden)details();if(page==='monitor'){mapRender();monitorData.render(clock());updateCoordinates();mapControls?.refreshPosition();}if(page==='records')events();if(page==='signals')signals.render();direction.render();status();}
function schedule(){if(!renderPending){renderPending=true;requestAnimationFrame(render);}}
const editor=setupStationEditor({toast,onSaved:value=>{configuration=value;state.doaTargets.clear();state.doaTracks.clear();schedule();}}),direction=setupDirection();
records=setupRecords({setMode:mode,toast,onEvidence:()=>{selected=null;}});
const signals=setupSignals({setMode:mode,toast}),home=setupHome();
const processing=setupPipeline({toast});
const monitorData=setupMonitorData({readPipeline:()=>processing.snapshot(),readSelected:()=>selected,readLayout:displayLayout});
setupReceiverControl({toast,onChanged:()=>mode('external')});
setupChannelScan({toast});
setupAOAReference({toast,onApplied:()=>editor.load(),hasDraft:()=>editor.dirty()});
const signalNav=document.createElement('a');signalNav.href='#/signals';signalNav.dataset.route='signals';signalNav.textContent='信源检测';document.querySelector('[data-route="monitor"]').after(signalNav);
document.querySelector('.map-legend .rid').innerHTML=droneSVG;
document.querySelector('.map-legend .intersection').innerHTML=droneSVG;
$('map-focus').onclick=()=>{const focused=document.body.classList.toggle('map-focus');text('map-focus',focused?'退出专注':'专注地图');closeDrawer();map?.invalidateSize();};
for(const id of ['search','target-filter','event-search','event-kind'])$(id).addEventListener(id.includes('search')?'input':'change',schedule);$('clear-events').onclick=()=>{state.events=[];notify();};
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else{document.body.classList.toggle('map-focus');toast('当前环境不支持浏览器全屏，已切换专注布局');}}catch(e){toast(`未能进入全屏：${e.message}`);}};
document.addEventListener('fullscreenchange',()=>{text('fullscreen',document.fullscreenElement?'⛶ 退出全屏':'⛶ 全屏');requestAnimationFrame(()=>{map?.invalidateSize();editor.resize();});});
new ResizeObserver(()=>map?.invalidateSize()).observe($('map'));changes.addEventListener('change',schedule);setInterval(schedule,1000);
window.GroundStation=Object.freeze({ingestRID,ingestDOA,setConnection,getMapCenter:()=>map?{latitude:map.getCenter().lat,longitude:map.getCenter().lng}:null});
async function health(){try{const value=await jsonFetch('/api/health');serviceOK=value.available===true;}catch{serviceOK=false;}finally{schedule();setTimeout(health,5000);}}
reset('external');route(location.hash.slice(2));startTransport();health();
