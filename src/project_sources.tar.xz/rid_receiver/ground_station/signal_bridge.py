"""Read-only multi-station frame feed and bounded local PCAP import."""
import copy
import json
from pathlib import Path
import tempfile
import threading
import time
from urllib.request import build_opener,ProxyHandler
from urllib.parse import urlsplit
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from capture_io import read_capture,monitor_frame
from signal_inspector import SignalStore

def parse_capture(data,openwifi=False):
    if not data or len(data)>8*1024*1024:raise ValueError('抓包文件需为1字节至8 MiB')
    store=SignalStore();count=0
    with tempfile.TemporaryDirectory(prefix='airspace_pcap_') as folder:
        path=Path(folder)/'capture.pcap';path.write_bytes(data)
        for timestamp,link,packet in read_capture(path):
            count+=1
            if count>50000:raise ValueError('文件超过50000帧，请截取后导入')
            try:
                frame,meta=monitor_frame(packet,link,openwifi_fcs=openwifi);store.frame(timestamp,frame,meta)
            except (ValueError,IndexError):continue
    value=store.snapshot()
    for packet in value['packets']:packet.update(station='文件',session_id='archive',historical=True,observed_at=packet['capture_time']*1000)
    for source in value['sources']:source.update(station='文件',historical=True)
    value.update(schema='airspace.signals',version=1,mode='archive',connected=False,stations=[],label='导入抓包 · 历史',file_frames=count)
    return value

class SignalBridge:
    def __init__(self,urls=None,selection=None):
        self.urls=urls or {};self.stop=threading.Event();self.lock=threading.Lock();self.values={};self.errors={}
        self.selection=selection
        self.opener=build_opener(ProxyHandler({}))
    def run_station(self,station,url):
        failures=0
        while not self.stop.is_set():
            if self.selection and not self.selection.is_selected(station):
                with self.lock:self.values.pop(station,None);self.errors.pop(station,None)
                self.stop.wait(.5);continue
            try:
                with self.opener.open(url.rstrip('/')+'/api/signals',timeout=2) as response:data=response.read(4*1024*1024+1)
                if len(data)>4*1024*1024:raise ValueError('信源接口响应过大')
                value=json.loads(data)
                if not isinstance(value.get('packets'),list) or not isinstance(value.get('sources'),list):raise ValueError('板端尚未提供信源接口')
                if len(value['packets'])>1000 or len(value['sources'])>512:raise ValueError('板端缓冲区超出约定')
                with self.lock:self.values[station]=(value,time.time()*1000,time.monotonic());self.errors.pop(station,None)
                failures=0
            except Exception as exc:
                with self.lock:self.errors[station]=str(exc)
                failures=min(failures+1,4)
            self.stop.wait(min(2**failures,15))
    def run(self):
        threads=[threading.Thread(target=self.run_station,args=(station,url),daemon=True) for station,url in self.urls.items() if url]
        for thread in threads:thread.start()
        self.stop.wait()
        for thread in threads:thread.join(3)
    def status(self):
        now=time.monotonic();stations=[]
        roles=self.selection.snapshot() if self.selection else None
        actual={s['id']:s.get('actual') or {} for s in (roles or {}).get('stations',[])}
        with self.lock:
            for station,url in self.urls.items():
                selected=not self.selection or self.selection.is_selected(station)
                item=self.values.get(station) if selected else None
                if item and self.selection and not self.selection.accepts_session(station,item[0].get('session_id')):item=None
                connected=bool(item and station not in self.errors and now-item[2]<5)
                value=item[0] if item else {}
                packets=value.get('packets',[])
                age=max(0,value['monotonic']-packets[-1]['received_monotonic'])+now-item[2] if packets else None
                stations.append(dict(id=station,configured=bool(url),connected=connected,selected=selected,
                    standbyReady=bool(not selected and roles and roles['confirmed'] and actual.get(station,{}).get('ready') and actual[station].get('enabled') is False),
                    receiving=bool(connected and value.get('mode')=='live' and age is not None and age<5),
                    mode=value.get('mode'),sessionId=value.get('session_id'),phyCapabilities=value.get('phyCapabilities'),
                    total=value.get('total',0),badFcs=value.get('bad_fcs',0),lastFrameAgeSeconds=age,
                    error=self.errors.get(station) if selected else None))
        return dict(stations=stations,timestamp=time.time()*1000,receiverSelection=self.selection.snapshot() if self.selection else None)
    def snapshot(self):
        with self.lock:values=copy.deepcopy(self.values);errors=dict(self.errors)
        now=time.monotonic();packets=[];sources=[];stations=[]
        for station,url in self.urls.items():
            if self.selection and not self.selection.is_selected(station):
                stations.append(dict(id=station,connected=False,error=None,configured=bool(url),mode='standby',selected=False));continue
            item=values.get(station)
            if item and self.selection and not self.selection.accepts_session(station,item[0].get('session_id')):item=None
            connected=bool(item and station not in errors and now-item[2]<5)
            stations.append(dict(id=station,connected=connected,error=errors.get(station),configured=bool(url),mode=item[0].get('mode') if item else None,phyCapabilities=item[0].get('phyCapabilities') if item else None))
            if not item:continue
            value,received,received_mono=item;historical=value.get('mode')=='replay';board_now=value['monotonic']
            for row in value['packets']:
                row.update(station=station,session_id=value.get('session_id'),historical=historical,
                           observed_at=received-max(0,board_now-row['received_monotonic'])*1000,
                           age_seconds=max(0,board_now-row['received_monotonic'])+now-received_mono)
                packets.append(row)
            for row in value['sources']:
                row.update(station=station,historical=historical,age_seconds=max(0,board_now-row['last_monotonic'])+now-received_mono,
                           last_observed_at=received-max(0,board_now-row['last_monotonic'])*1000)
                sources.append(row)
        packets=sorted(packets,key=lambda r:r['observed_at'])[-800:]
        return dict(schema='airspace.signals',version=1,mode='live',connected=any(s['connected'] for s in stations),stations=stations,
                    packets=packets,sources=sources,total=sum(item[0].get('total',0) for s,item in values.items() if not self.selection or self.selection.accepts_session(s,item[0].get('session_id'))),
                    bad_fcs=sum(item[0].get('bad_fcs',0) for s,item in values.items() if not self.selection or self.selection.accepts_session(s,item[0].get('session_id'))),timestamp=time.time()*1000,
                    receiverSelection=self.selection.snapshot() if self.selection else None)

def station_urls(config,primary=None):
    urls={}
    for station in config.get('stations',[]):
        value=urlsplit(station.get('url',''))
        if value.scheme in ('http','https') and value.hostname:
            urls[station['id']]='%s://%s:18771'%(value.scheme,value.hostname)
    if primary:urls['A']=primary
    return urls
