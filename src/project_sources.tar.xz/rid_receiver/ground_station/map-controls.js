import {config} from './config.js';

const $ = id => document.getElementById(id);
const MAX_LAT = 85.0511288;
const VIEW_KEY = 'aeroscope.map.view.v2';
const COMPUTER_KEY = 'aeroscope.computer.position.v1';
const providerAttribution = '&copy; <a href="https://www.maptiler.com/copyright/" target="_blank" rel="noopener">MapTiler</a> &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>';
// Some providers return a warning PNG with HTTP 200. Reject missing credentials
// before creating their layer; tileerror cannot detect such images.
export function tileAccessAllowed(url){
  if(!/\b(?:[\w.-]+\.)?basemaps\.cartocdn\.com\b/i.test(url))return true;
  return /[?&]key=(?!YOUR_KEY(?:&|$)|undefined(?:&|$)|null(?:&|$))[^&{}\s]+/i.test(url);
}

function validPoint(point) {
  return Array.isArray(point) && Number.isFinite(point[0]) && Number.isFinite(point[1])
    && Math.abs(point[0]) <= MAX_LAT && Math.abs(point[1]) <= 180;
}

function readSavedView() {
  try {
    const value = JSON.parse(localStorage.getItem(VIEW_KEY));
    return validPoint(value?.center) && Number.isFinite(value.zoom) ? value : null;
  } catch { return null; }
}

function readSavedComputer() {
  try {
    const value = JSON.parse(localStorage.getItem(COMPUTER_KEY));
    return value?.source === 'manual' && validPoint(value.point) ? value : null;
  } catch { return null; }
}

function formatPoint(point) {
  return `${point[0].toFixed(6)}, ${point[1].toFixed(6)}`;
}

function coordinateQuery(value) {
  const match = value.trim().match(/^(-?\d+(?:\.\d+)?)\s*[,，\s]\s*(-?\d+(?:\.\d+)?)$/);
  if (!match) return null;
  const point = [Number(match[1]), Number(match[2])];
  return validPoint(point) ? point : false;
}

export function setupMapControls(map, {onNavigate,formatPosition=formatPoint,active=true} = {}) {
  const notice = $('tile-notice');
  const status = $('location-status');
  const results = $('search-results');
  const pickButton = $('pick-location');
  const mapArea = document.querySelector('.map-area');
  let activeLayers = [];
  let selectedLocation = null;
  let computerLocation = null;
  let computerSource = null;
  let locationRequest = 0;
  let computerMarker = null;
  let accuracyCircle = null;
  let picking = false;
  let userInteracted = false;
  let lastSearchAt = 0;
  let tileErrors = 0;
  let layerEpoch=0;
  let tileTimer=null;
  let visible=active,desiredLayer=$('basemap').value;

  const saved = readSavedView();
  if (saved) map.setView(saved.center, Math.max(2, Math.min(config.maxZoom, saved.zoom)));

  function setStatus(message) { status.textContent = message; }
  function markNavigation() { userInteracted = true; onNavigate?.(); }
  function clearResults() { results.replaceChildren(); results.hidden = true; }

  function selectLocation(point, move = true) {
    if (!validPoint(point)) return;
    selectedLocation = point;
    if (move) map.setView(point, Math.max(map.getZoom(), 14));
  }

  function publicLayers(name) {
    return (config.layers[name] || []).filter(item=>tileAccessAllowed(item.url)).map(item => L.tileLayer(item.url, {
      ...item.options,...config.tileOptions,crossOrigin:true
    }));
  }

  function mapTilerLayer(name) {
    const mapId = config.maptilerMaps[name];
    if (!config.maptilerKey || !mapId) return null;
    return L.tileLayer(`https://api.maptiler.com/maps/${mapId}/{z}/{x}/{y}.png?key=${encodeURIComponent(config.maptilerKey)}`, {
      maxNativeZoom: 20, maxZoom: config.maxZoom, tileSize: 256, crossOrigin: true,...config.tileOptions,
      attribution: providerAttribution
    });
  }

  function changeLayer(name) {
    desiredLayer=name;
    const epoch=++layerEpoch;
    clearTimeout(tileTimer);
    for (const layer of activeLayers) map.removeLayer(layer);
    activeLayers = [];
    tileErrors = 0;
    notice.hidden = true;
    if(!visible)return;
    mapArea.classList.toggle('grid', name === 'grid');
    if (name === 'grid') {
      map.attributionControl.setPrefix('<a href="https://leafletjs.com/" target="_blank" rel="noopener">Leaflet</a>');
      return;
    }
    const mapTiler = mapTilerLayer(name);
    activeLayers = mapTiler ? [mapTiler] : publicLayers(name);
    let fallback=false;
    let lightFallback=name==='light',baseLoaded=false;
    const satellite=name==='satellite'||name==='hybrid';
    if(satellite){notice.textContent='卫星影像加载中…';notice.hidden=false;}
    if(!activeLayers.length&&name==='dark'){fallback=true;activeLayers=publicLayers('darkFallback');}
    function armTimeout(){
      clearTimeout(tileTimer);baseLoaded=false;
      tileTimer=setTimeout(()=>{if(epoch!==layerEpoch||baseLoaded)return;if(!lightFallback)useLight();else showUnavailable();},10000);
      tileTimer?.unref?.();
    }
    function showUnavailable(){notice.textContent='底图网络暂未恢复，可选择离线网格；目标数据继续更新。';notice.hidden=false;}
    function useLight(){
      clearTimeout(tileTimer);lightFallback=true;fallback=true;tileErrors=0;
      for(const old of activeLayers)map.removeLayer(old);
      activeLayers=publicLayers('light');$('basemap').value='light';desiredLayer='light';wire(activeLayers);armTimeout();
      notice.textContent=satellite?'卫星影像暂不可达，已切换浅色底图。':'已切换浅色底图，目标数据继续更新。';notice.hidden=false;
    }
    function wire(layers){for (const layer of layers) {
      const current=()=>epoch===layerEpoch&&activeLayers.includes(layer);
      layer.on('loading',()=>{if(current()&&layer===activeLayers[0])armTimeout();});
      layer.on('tileload',()=>{
        if(!current()||layer!==activeLayers[0])return;
        baseLoaded=true;clearTimeout(tileTimer);
        tileErrors=0;
        notice.hidden=true;
      });
      layer.on('tileerror', () => {
        if(!current()||layer!==activeLayers[0])return;
        tileErrors += 1;
        if (tileErrors === 3) {
          if(satellite||lightFallback){if(!lightFallback)useLight();else showUnavailable();return;}
          if(!fallback&&(name==='dark'||mapTiler)){
            fallback=true;tileErrors=0;for(const old of activeLayers)map.removeLayer(old);
            activeLayers=publicLayers(name==='dark'?'darkFallback':name);wire(activeLayers);
            notice.textContent='已切换备用底图';notice.hidden=false;return;
          }
          useLight();
        }
      });
      layer.addTo(map);
    }}
    wire(activeLayers);
    armTimeout();
  }

  function setComputerPosition(point, {source, accuracy = null, move = true, restored = false}) {
    if (!validPoint(point)) {
      setStatus('定位结果超出 Web 地图支持范围，请搜索地点或手动选点。');
      return;
    }
    computerLocation = [...point];
    computerSource = source;
    const manual = source === 'manual';
    if (manual) locationRequest += 1; // A pending browser callback must not replace a manual point.
    const systemLabels = {Satellite: 'Windows 卫星定位', WiFi: 'Windows Wi-Fi 定位',
      Cellular: 'Windows 基站定位', IPAddress: 'Windows IP 定位',
      Default: 'Windows 默认位置', Unknown: 'Windows 定位（来源未知）', Obfuscated: 'Windows 模糊定位'};
    const sourceLabel = source.startsWith('windows:') ? systemLabels[source.slice(8)] || systemLabels.Unknown : '浏览器定位';
    const detail = manual ? '手动设置 · 精度未测量'
      : Number.isFinite(accuracy) ? `${sourceLabel} · 估计误差约 ${Math.round(accuracy)} m` : `${sourceLabel} · 精度未知`;
    if (!computerMarker) {
      computerMarker = L.marker(point, {zIndexOffset: 800, draggable: true, autoPan: true, icon: L.divIcon({
        className: 'computer-marker', html: '<span></span>', iconSize: [16, 16], iconAnchor: [8, 8]
      })}).addTo(map).bindTooltip(`电脑位置 · ${detail}`);
      computerMarker.on('dragstart', () => {
        locationRequest += 1; // Lock out automatic results before the drag ends.
        markNavigation();
        setStatus('拖动电脑标记到实际位置，松开后保存。');
      });
      computerMarker.on('dragend', () => {
        const point = computerMarker.getLatLng();
        const value = [point.lat, point.lng];
        if (!validPoint(value)) {
          computerMarker.setLatLng(computerLocation);
          setStatus('位置超出地图支持范围，已保留原电脑位置。');
          return;
        }
        picking = false; pickButton.setAttribute('aria-pressed', 'false');
        map.getContainer().style.cursor = '';
        setComputerPosition(value, {source: 'manual', move: false});
      });
    } else computerMarker.setLatLng(point).setTooltipContent(`电脑位置 · ${detail}`);
    if (accuracyCircle) {map.removeLayer(accuracyCircle); accuracyCircle = null;}
    if (!manual && Number.isFinite(accuracy) && accuracy >= 0) {
      accuracyCircle = L.circle(point, {radius: accuracy, color: '#8eb3f0', weight: 1,
        opacity: .65, fillColor: '#8eb3f0', fillOpacity: .05, interactive: false}).addTo(map);
    }
    $('computer-location').textContent = formatPosition(point);
    $('computer-location-source').textContent = detail;
    selectLocation(point, move);
    let saved = true;
    try {
      if (manual) localStorage.setItem(COMPUTER_KEY, JSON.stringify({point: [...point], source: 'manual'}));
      else localStorage.removeItem(COMPUTER_KEY);
    } catch {saved = false;}
    setStatus(manual
      ? `${restored ? '已恢复保存的' : '已设置'}电脑位置，使用蓝色电脑标记；${saved ? '刷新后保留。' : '浏览器未允许保存，刷新后需重设。'}`
      : `${detail}；可拖动蓝色电脑标记或用“地图选点”修正。`);
  }

  async function locate(auto = false) {
    if (auto && computerSource === 'manual') return;
    if (!auto) markNavigation();
    const request = ++locationRequest;
    setStatus('正在读取 Windows 与浏览器位置，比较可用来源的估计误差…');
    let best = null;
    function accept(value) {
      if (request !== locationRequest) return;
      if (!validPoint(value.point) || !Number.isFinite(value.accuracy) || value.accuracy < 0
          || !Number.isFinite(value.timestamp) || Math.abs(Date.now() - value.timestamp) > 120000) {
        throw new Error('位置无效或已过期');
      }
      if (best && (value.accuracy > best.accuracy || (value.accuracy === best.accuracy
          && (best.source.startsWith('windows:') || !value.source.startsWith('windows:'))))) return;
      best = value;
      setComputerPosition(value.point, {source: value.source, accuracy: value.accuracy, move: !auto || !userInteracted});
    }
    const windowsPosition = fetch('/api/computer-location', {method: 'POST', cache: 'no-store'})
      .then(response => {if (!response.ok) throw new Error('系统定位接口不可用'); return response.json();})
      .then(value => {
        if (!value.available) throw new Error(value.error || '系统位置不可用');
        return {point: [value.latitude, value.longitude], accuracy: value.accuracy,
          timestamp: value.timestamp, source: `windows:${value.source}`};
      });
    const browserPosition = new Promise((resolve, reject) => {
      if (!navigator.geolocation) {reject(new Error('浏览器定位不可用')); return;}
      navigator.geolocation.getCurrentPosition(position => resolve({
        point: [position.coords.latitude, position.coords.longitude], accuracy: position.coords.accuracy,
        timestamp: position.timestamp, source: 'browser'}), reject,
      {enableHighAccuracy: true, timeout: 9000, maximumAge: 0});
    });
    await Promise.allSettled([windowsPosition.then(accept), browserPosition.then(accept)]);
    if (request === locationRequest && !best) {
      setStatus(`暂时无法取得有效自动位置；${computerLocation ? '保留当前电脑位置。' : '可使用“手动设置”或输入坐标。'}`);
    }
  }

  function renderSearchResults(items) {
    results.replaceChildren();
    if (!items.length) {
      const empty = document.createElement('p');
      empty.textContent = '没有找到匹配地点；可直接输入“纬度, 经度”。';
      results.append(empty);
    }
    for (const item of items) {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'search-result';
      const title = document.createElement('strong'); title.textContent = item.title;
      const detail = document.createElement('small'); detail.textContent = item.detail || formatPosition(item.point);
      button.append(title, detail);
      button.onclick = () => {
        markNavigation(); setComputerPosition(item.point, {source: 'manual'}); clearResults();
      };
      results.append(button);
    }
    results.hidden = false;
  }

  async function searchPlaces(query) {
    const now = Date.now();
    if (now - lastSearchAt < 1000) {
      setStatus('地点搜索请求间隔至少 1 秒，请稍后再试。');
      return;
    }
    lastSearchAt = now;
    setStatus('正在搜索地点…');
    const endpoint = config.maptilerKey
      ? `https://api.maptiler.com/geocoding/${encodeURIComponent(query)}.json?key=${encodeURIComponent(config.maptilerKey)}&language=zh&limit=5`
      : `${config.geocodingUrl}?format=jsonv2&limit=5&accept-language=zh-CN&q=${encodeURIComponent(query)}`;
    try {
      const response = await fetch(endpoint, {headers: {'Accept': 'application/json'}});
      if (!response.ok) throw new Error(String(response.status));
      const body = await response.json();
      const items = config.maptilerKey
        ? (body.features || []).map(feature => ({point: [feature.center[1], feature.center[0]],
          title: feature.text || feature.place_name, detail: feature.place_name}))
        : body.map(feature => ({point: [Number(feature.lat), Number(feature.lon)],
          title: feature.name || feature.display_name.split(',')[0], detail: feature.display_name}));
      renderSearchResults(items.filter(item => validPoint(item.point)));
      setStatus(items.length ? '请选择一个搜索结果。' : '未找到地点，可输入坐标或在地图上选点。');
    } catch {
      setStatus('地点搜索服务暂不可用。可直接输入“纬度, 经度”或在地图上选点。');
      renderSearchResults([]);
    }
  }

  function resetView() {
    markNavigation(); clearResults();
    const point = computerLocation || selectedLocation;
    if (point) map.setView(point, Math.max(map.getZoom(), 14));
    else map.setView(config.center, config.zoom);
    setStatus(point ? '已回到当前地图位置。' : '已回到全国初始视角。');
  }

  function closeView() {
    markNavigation(); clearResults();
    const center = map.getCenter();
    const point = computerLocation || selectedLocation || [center.lat, center.lng];
    // For the 100px Leaflet scale, select a zoom where its maximum span is 5..10m.
    // The metric scale then rounds to a 5m label; coordinates are unchanged.
    const metersPerPixelAtZero = 2 * Math.PI * 6378137 * Math.cos(point[0] * Math.PI / 180) / 256;
    const zoom = Math.max(2, Math.min(config.maxZoom, Math.floor(Math.log2(metersPerPixelAtZero * 100 / 5))));
    map.setView(point, zoom);
    setStatus('已进入约5米比例尺近景；定位误差仍以位置来源标注为准。');
  }

  $('basemap').onchange = event => changeLayer(event.target.value);
  $('locate-me').onclick = () => locate(false);
  if ($('reset-view')) $('reset-view').onclick = resetView;
  if ($('close-view')) $('close-view').onclick = closeView;
  pickButton.onclick = () => {
    picking = !picking; pickButton.setAttribute('aria-pressed', String(picking));
    if (picking) { locationRequest += 1; markNavigation(); }
    map.getContainer().style.cursor = picking ? 'crosshair' : '';
    setStatus(picking ? '请在地图上单击电脑实际所在位置，将直接更新蓝色电脑标记。' : '已退出电脑位置设置。');
  };
  $('map-search-form').onsubmit = event => {
    event.preventDefault();
    const query = $('place-query').value.trim();
    if (!query) return;
    markNavigation();
    const point = coordinateQuery(query);
    if (point === false) {
      setStatus(`坐标超出范围：纬度需在 ±${MAX_LAT.toFixed(2)}°、经度在 ±180° 内。`);
    } else if (point) {
      clearResults(); setComputerPosition(point, {source: 'manual'});
    } else searchPlaces(query);
  };
  map.on('click', event => {
    if (!picking) return;
    markNavigation(); setComputerPosition([event.latlng.lat, event.latlng.lng], {source: 'manual', move: false});
    picking = false; pickButton.setAttribute('aria-pressed', 'false'); map.getContainer().style.cursor = '';
  });
  map.on('dragstart zoomstart', () => { userInteracted = true; });
  map.on('moveend', () => {
    try { localStorage.setItem(VIEW_KEY, JSON.stringify({center: [map.getCenter().lat, map.getCenter().lng], zoom: map.getZoom()})); } catch {}
  });
  document.addEventListener('pointerdown', event => {
    if (!results.hidden && !event.target.closest('.map-search-wrap')) clearResults();
  });

  changeLayer($('basemap').value);
  const savedComputer = readSavedComputer();
  if (savedComputer) setComputerPosition(savedComputer.point, {source: 'manual', move: !saved, restored: true});
  else locate(true);
  if (new URLSearchParams(globalThis.location?.search || '').get('view') === '5m') closeView();
  return {changeLayer,activate:value=>{if(visible!==value){visible=value;changeLayer(desiredLayer);}},resetView,refreshPosition:()=>{if(computerLocation)$('computer-location').textContent=formatPosition(computerLocation);}, getSelectedLocation: () => selectedLocation && [...selectedLocation]};
}
