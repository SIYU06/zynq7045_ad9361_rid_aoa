import {state} from './data.js';
import {fmt,esc,finite,time,freshStation,phaseStationFresh,phaseStateLabel,statistics,intersectionReady,intersectionPoints,midpointCoordinates,bearingsForStation,normalized} from './workspace-core.js';
const $=id=>document.getElementById(id),text=(id,v)=>$(id).textContent=v;
export function setupDirection(){
  let epoch=-1,history={A:[],B:[]},seen={},paused=false,frozen=null,target=null;
  function capture(){if(epoch!==state.epoch){epoch=state.epoch;history={A:[],B:[]};seen={};paused=false;frozen=null;text('direction-pause','暂停显示');}
    if(target!==(state.doa?.targetId||null)){target=state.doa?.targetId||null;history={A:[],B:[]};seen={};}
    for(const s of state.doa?.stations||[]){if(!history[s.id]||!freshStation(s,state.doa,state.mode,state.replayClock??Date.now())||!state.doaConnected)continue;
      const key=s.sessionId||s.frameKey||s.tsf?`${s.sessionId}:${s.frameKey}:${s.tsf}`:`${s.timestamp}:${s.relativeAngle}`;
      if(seen[s.id]===key)continue;seen[s.id]=key;history[s.id].push({time:s.timestamp??state.doa.timestamp,angle:s.relativeAngle});history[s.id]=history[s.id].slice(-1800);}
  }
  function dial(angle,full){let svg='<circle cx="220" cy="180" r="145" fill="none" stroke="#afc6c4" stroke-width="1.5"/>';
    for(let a=0;a<360;a+=30){const r=a*Math.PI/180;svg+=`<path d="M${220+Math.sin(r)*145} ${180-Math.cos(r)*145}L${220+Math.sin(r)*135} ${180-Math.cos(r)*135}" stroke="#839b8f"/><text x="${220+Math.sin(r)*117}" y="${184-Math.cos(r)*117}" text-anchor="middle">${a}°</text>`;}
    if(finite(angle)){const angles=[normalized(angle)];if(full&&Math.abs(normalized(180-angle)-angles[0])>1e-8)angles.push(normalized(180-angle));
      for(const [i,a] of angles.entries()){const r=a*Math.PI/180;svg+=`<path d="M220 180L${220+Math.sin(r)*130} ${180-Math.cos(r)*130}" stroke="${i?'#b57a30':'#277e91'}" stroke-width="2.5" ${i?'stroke-dasharray="5 4"':''}/>`;}
      svg+='<circle cx="220" cy="180" r="4" fill="#277e91"/>';}
    $('angle-dial').innerHTML=svg;
  }
  function trend(rows,now){const windowMs=Number($('trend-window').value)*1000,visible=rows.filter(r=>r.time>=now-windowMs&&r.time<=now),W=720,H=240;
    let svg='';for(let a=-90;a<=90;a+=30){const y=20+(90-a)/180*180;svg+=`<path d="M42 ${y}H705" stroke="#e7ece6"/><text x="28" y="${y+4}" text-anchor="end">${a}</text>`;}
    const points=visible.map(r=>`${42+(r.time-(now-windowMs))/windowMs*663},${20+(90-r.angle)/180*180}`).join(' ');
    if(visible.length)svg+=`<polyline points="${points}" fill="none" stroke="#277e91" stroke-width="1.8"/>`;else svg+='<text x="370" y="114" text-anchor="middle">暂无可用角度样本</text>';
    svg+=`<text x="42" y="230">${time(now-windowMs)}</text><text x="705" y="230" text-anchor="end">${time(now)}</text>`;$('angle-trend').innerHTML=svg;
    const stats=statistics(visible.map(r=>r.angle));$('angle-stats').innerHTML=[['有效样本',stats.n],['均值',`${fmt(stats.mean,2)}°`],['标准差',`${fmt(stats.std,2)}°`]].map(([k,v])=>`<div><span>${k}</span><b>${v}</b></div>`).join('');
  }
  function localDiagram(feed,source){const stations=(feed?.stations||[]).filter(s=>finite(s.xM)&&finite(s.yM)),point=feed?.intersection;
    if(!stations.length){$('local-geometry').innerHTML='<text x="350" y="200" text-anchor="middle">等待局部站点几何；可先到“设备与布站”设置</text>';return;}
    const points=intersectionPoints(feed,source?.mode,source?.clock,source?.connected);
    const origin=feed?.midpoint||{xM:stations.length>=2?(stations[0].xM+stations[1].xM)/2:stations[0].xM,yM:stations.length>=2?(stations[0].yM+stations[1].yM)/2:stations[0].yM};
    const positions=[[0,0],...stations.map(s=>[s.xM-origin.xM,s.yM-origin.yM]),...points.filter(p=>finite(p.xM)&&finite(p.yM)).map(p=>[p.xM-origin.xM,p.yM-origin.yM])];
    const minX=Math.min(...positions.map(p=>p[0])),maxX=Math.max(...positions.map(p=>p[0])),minY=Math.min(...positions.map(p=>p[1])),maxY=Math.max(...positions.map(p=>p[1]));
    const span=Math.max(maxX-minX,maxY-minY,1)*1.6,centerX=(minX+maxX)/2,centerY=(minY+maxY)/2,scale=320/span;
    const xy=(x,y)=>[350+(x-origin.xM-centerX)*scale,210-(y-origin.yM-centerY)*scale];let svg='';
    for(let i=0;i<=6;i++){const x=60+i*96.6,y=40+i*56.6;svg+=`<path d="M${x} 40V380M60 ${y}H640" stroke="#edf0eb"/>`;}
    svg+=`<text x="62" y="405">图宽约 ${fmt(580/scale,2)} m · O为两站中点</text><text x="625" y="28">北 y ↑</text><text x="608" y="405">东 x →</text><defs><clipPath id="local-plot-clip"><rect x="45" y="30" width="610" height="350"/></clipPath></defs><g clip-path="url(#local-plot-clip)">`;
    for(const s of stations){const [x,y]=xy(s.xM,s.yM),color=s.id==='B'?'#b57a30':'#277e91';
      if(source?.connected&&finite(s.bearing)&&freshStation(s,feed,source.mode,source.clock)){const len=Math.max(span*.7,...points.filter(p=>finite(p.xM)&&finite(p.yM)).map(p=>Math.hypot(p.xM-s.xM,p.yM-s.yM)*1.05));for(const candidate of bearingsForStation(s,feed.directionMode)){const r=candidate.bearingDeg*Math.PI/180,[ex,ey]=xy(s.xM+Math.sin(r)*len,s.yM+Math.cos(r)*len);svg+=`<path d="M${x} ${y}L${ex} ${ey}" stroke="${color}" stroke-width="2" stroke-dasharray="${candidate.branch==='back'?'2 6':'5 4'}"/>`;}}
      svg+=`<rect x="${x-7}" y="${y-7}" width="14" height="14" rx="2" fill="${color}"/><text x="${x+12}" y="${y+5}">站 ${esc(s.id)}</text>`;}
    for(const point of points){if(!finite(point.xM)||!finite(point.yM))continue;const [x,y]=xy(point.xM,point.yM);svg+=`<circle cx="${x}" cy="${y}" r="7" stroke="#b57a30" fill="#e0eee4" fill-opacity=".4" stroke-width="2" ${point.ambiguous?'stroke-dasharray="3 3"':''}/>`;}
    const [ox,oy]=xy(origin.xM,origin.yM);svg+=`<path d="M${ox-5} ${oy}H${ox+5}M${ox} ${oy-5}V${oy+5}" stroke="#586f78"/><text x="${ox+7}" y="${oy+16}">O (0,0)</text></g>`;
    $('local-geometry').innerHTML=svg;
  }
  function render(){capture();const source=paused?frozen:{feed:state.doa,clock:state.replayClock??Date.now(),history:structuredClone(history),mode:state.mode,connected:state.doaConnected};
    const feed=source?.feed,clock=source?.clock??Date.now(),mode=source?.mode??state.mode,id=$('direction-station').value,s=feed?.stations.find(s=>s.id===id),active=source?.connected&&freshStation(s,feed,mode,clock);
    text('direction-source',`${paused?'显示已暂停 · ':''}${feed?`${feed.source} · ${time(feed.timestamp)} · ${mode==='replay'?'历史回放':'真实接入'}`:'暂无测向观测 · 不从RID航向推算来向'}`);
    text('angle-station',`接收站 ${id}`);text('angle-quality',paused?'显示已暂停':active&&s?.calibrationStatus==='uncalibrated'?'未校准诊断角':phaseStationFresh(s,feed,mode,clock)&&!finite(s?.relativeAngle)?phaseStateLabel(s):s?.calibrationRequired?'等待重新标定':active?'有效观测':s?.error?'质量/连接异常':s?.relativeAngle!=null?'观测已过期':'等待数据');$('angle-quality').classList.toggle('active',!!active&&!paused);
    text('angle-value',active?`${s.relativeAngle>=0?'+':''}${fmt(s.relativeAngle,1)}`:'—');dial(active?s.relativeAngle:null,feed?.directionMode==='full');trend(source?.history?.[id]||[],clock);
    const fields=[['天线中心距',finite(s?.antennaSpacingM)?`${fmt(s.antennaSpacingM*100,1)} cm`:'未提供'],['相干性',fmt(s?.coherence,3)],['原始相位差',`${fmt(s?.phaseDeg,2)}°`],['电平差',`${fmt(s?.gainDifferenceDb,2)} dB`],['削顶比例',fmt(s?.clippedFraction,4)],['标定会话',s?.sessionId?s.sessionId.slice(0,10):'未提供'],['质量',s?.quality||s?.error||'未提供']];
    const q=s?.signalQuality;
    if(q){
      fields.push(['LTF信噪比估计 RX1 / RX2',q.snrProxyDb?.map(v=>`${fmt(v,1)} dB`).join(' / ')||'未提供'],
        ['可靠子载波',`${q.reliableSubcarriers} / ${q.totalSubcarriers}`],
        ['子载波相位集中度',fmt(q.subcarrierConcentration,3)],
        ['两段LTF相位差',`${fmt(q.repeatPhaseDifferenceDeg,2)}°`],
        ['接收增益建议',({hold_gain:'保持当前增益',trial_increase_gain_and_revalidate:'可试增益；需重新核验基准',reduce_gain_and_revalidate:'电平接近满量程；降低增益并核验',inspect_channel_or_interference:'检查反射、通道或干扰'})[q.gainAdvice]||'未提供']);
    }
    $('quality-fields').innerHTML=fields.map(([k,v])=>`<div><span>${k}</span><b>${esc(v)}</b></div>`).join('');
    $('dual-stations').innerHTML=['A','B'].map(id=>{const v=feed?.stations.find(s=>s.id===id),ok=source?.connected&&freshStation(v,feed,mode,clock);return `<div class="dual-station"><div>站 ${id}<p>${esc(v?.error||v?.quality||(ok?'有效观测':'等待观测'))}</p></div><strong>${ok?fmt(v.relativeAngle,1)+'°':'—'}</strong></div>`;}).join('');
    const points=intersectionPoints(feed,mode,clock,source?.connected);
    text('intersection-position',points.length?points.map((p,i)=>{const relative=midpointCoordinates(feed,p);return `${p.ambiguous?'候选'+(i+1)+' ':''}${relative?`(${fmt(relative.xM,2)}, ${fmt(relative.yM,2)}) m`:finite(p.latitude)?`${fmt(p.latitude,6)}, ${fmt(p.longitude,6)}`:'—'}`;}).join('\n'):'—');text('intersection-reason',points.length?(points.some(p=>p.ambiguous)?`${points.length}个候选 · 前后未消歧`:'角度交汇结果 · 精度待核验')+(points.some(p=>p.geometryQuality==='weak')?' · 交角小，几何较弱':''):feed?.intersectionReason||'等待双站有效观测');
    const a=feed?.stations[0],b=feed?.stations[1];$('association-fields').innerHTML=[['同一目标',a?.targetId&&b?.targetId?(a.targetId===b.targetId?'是':'否'):'未提供'],['同一空口帧',a?.frameKey&&b?.frameKey?(a.frameKey===b.frameKey?'是':'否'):'未提供'],['两站时间差',finite(a?.timestamp)&&finite(b?.timestamp)?`${fmt(Math.abs(a.timestamp-b.timestamp),0)} ms`:'未提供']].map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('');
    localDiagram(feed,source);if($('direction-raw').parentElement.open)$('direction-raw').textContent=JSON.stringify(feed,null,2)||'暂无观测';
  }
  $('direction-pause').onclick=()=>{paused=!paused;frozen=paused?{feed:structuredClone(state.doa),clock:state.replayClock??Date.now(),history:structuredClone(history),mode:state.mode,connected:state.doaConnected}:null;text('direction-pause',paused?'恢复实时显示':'暂停显示');render();};
  const view=()=>{const dual=$('direction-view').value==='dual';$('dual-workspace').hidden=!dual;$('single-workspace').hidden=dual;$('direction-station').hidden=dual;render();};
  $('direction-view').onchange=view;$('direction-station').onchange=render;$('trend-window').onchange=render;$('direction-raw').parentElement.ontoggle=render;
  return {render,clear:()=>{epoch=-1;}};
}
