import {state,reset,ingestRID,ingestDOA,notify} from './data.js';
import {fmt,esc,time,download,readJSON,validateRecording,jsonFetch} from './workspace-core.js';
const $=id=>document.getElementById(id);
export function setupRecords({setMode,toast,onEvidence}){
  let recording=null,cursor=0,index=0,timer=null,lastTick=0;
  function stop(){if(timer)clearInterval(timer);timer=null;$('replay-play').textContent='播放';}
  function progress(){if(!recording)return;const start=recording.samples[0].data.timestamp,end=recording.samples.at(-1).data.timestamp;$('replay-position').value=end===start?0:(cursor-start)/(end-start)*1000;$('replay-time').textContent=`${time(cursor)} / ${time(end)}`;}
  function apply(until){state.replayClock=until;while(index<recording.samples.length&&recording.samples[index].data.timestamp<=until){const s=recording.samples[index++];(s.type==='rid'?ingestRID:ingestDOA)(s.data);}progress();notify();}
  function seek(until){stop();reset('replay');$('input-mode').value='replay';cursor=until;index=0;apply(cursor);}
  function evidence(value,name){
    if(!Array.isArray(value.rows)||value.rows.length>1000||typeof value.transmitter_mac!=='string'||!/^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i.test(value.transmitter_mac))throw new Error('实验汇总格式无效');
    for(const row of value.rows)if(!['A','B'].includes(row.station)||!Number.isFinite(row.candidate_frames)||row.candidate_frames<0)throw new Error('实验汇总计数无效');
    setMode('replay');recording=null;stop();$('replay-play').disabled=true;$('replay-position').disabled=true;
    $('record-title').textContent=name;$('record-info').textContent='已验证实验汇总 · 没有逐时刻样本，不提供时间播放；不代表实时观测';$('replay-time').textContent='静态实验摘要';
    const timestamp=Date.parse(value.updated_local);state.replayClock=Number.isFinite(timestamp)?timestamp:Date.now();
    state.candidates=[{mac:value.transmitter_mac,receiver:value.receiver_mac,frequencyMhz:value.frequency_mhz,channel:value.channel,timestamp:state.replayClock,
      source:'历史实验汇总',historical:true,classification:'当次电源对照支持的无人机相关链路',network:value.exposed_udp_link}];
    $('record-evidence').hidden=false;$('record-evidence').innerHTML=`<h2>无人机Wi-Fi电源对照 · 历史证据</h2><p class="muted">${esc(value.transmitter_mac)} → ${esc(value.receiver_mac)} · ${esc(value.frequency_mhz)} MHz<br>${esc(value.exposed_udp_link)}</p><div class="table-scroll"><table><thead><tr><th>阶段</th><th>站点</th><th>驻留/秒</th><th>候选有效帧</th><th>UDP帧</th></tr></thead><tbody>${value.rows.map(r=>`<tr><td>${esc(r.run)}</td><td>${esc(r.station)}</td><td>${fmt(r.dwell_s,3)}</td><td>${esc(r.candidate_frames)}</td><td>${esc(r.candidate_udp_frames)}</td></tr>`).join('')}</tbody></table></div><p class="muted">仅对应此次开关机实验。未取得机型、RID或当前测向结果。</p>`;
    onEvidence(value);notify();toast('历史图传实验已载入，可在目标列表查看链路');
  }
  function load(value,name){stop();if(value?.transmitter_mac&&value?.rows){evidence(value,name);return;}
    const validated=validateRecording(value);recording=validated;setMode('replay');$('record-evidence').hidden=true;
    $('record-title').textContent=name;$('record-info').textContent=`历史观测 · ${recording.samples.length}条 · 保留原始时间 · 非实时`;
    $('replay-play').disabled=false;$('replay-position').disabled=false;seek(recording.samples[0].data.timestamp);toast('观测记录已载入');
  }
  $('record-import').onchange=async event=>{try{const file=event.target.files[0];load(await readJSON(file),file.name);}catch(e){toast(e.message);}finally{event.target.value='';}};
  $('load-example').onclick=async()=>{try{load(await jsonFetch('records/wifi_power_off_20261102.json'),'2026-11-02 无人机图传电源对照');location.hash='#/records';}catch(e){toast(e.message);}};
  const doaExample=document.createElement('button');doaExample.id='load-doa-example';doaExample.className='text-link';doaExample.textContent='回放35帧真实双站测向记录 →';$('load-example').after(doaExample);
  doaExample.onclick=async()=>{try{load(await jsonFetch('records/dual_center_20261102.json'),'2026-11-02 双站同帧验证 · 历史临时标定');location.hash='#/direction';}catch(e){toast(e.message);}};
  const videoExample=document.createElement('button');videoExample.id='load-video-doa-example';videoExample.className='text-link';videoExample.textContent='回看非RID图传测向记录 →';doaExample.after(videoExample);
  videoExample.onclick=async()=>{try{load(await jsonFetch('records/nonrid_video_20261102.json'),'2026-11-02 非RID图传测向 · 历史未校准');location.hash='#/direction';}catch(e){toast(e.message);}};
  $('record-export').onclick=()=>{const samples=state.mode==='replay'?recording?.samples:state.samples;if(!samples?.length){toast('暂无逐时刻观测可导出；静态实验摘要可直接使用原JSON文件');return;}download('空域知微-观测记录.json',{schema:'airspace.observations',version:1,samples});};
  $('event-export').onclick=()=>download('空域知微-会话事件.json',{schema:'airspace.events',version:1,events:state.events});
  $('replay-play').onclick=()=>{if(!recording)return;if(state.mode!=='replay')setMode('replay');if(timer){stop();return;}
    const end=recording.samples.at(-1).data.timestamp;if(cursor>=end)seek(recording.samples[0].data.timestamp);lastTick=performance.now();$('replay-play').textContent='暂停';
    timer=setInterval(()=>{if(state.mode!=='replay'){stop();return;}const now=performance.now();cursor=Math.min(end,cursor+(now-lastTick)*Number($('replay-speed').value));lastTick=now;apply(cursor);if(cursor>=end)stop();},100);
  };
  $('replay-position').oninput=()=>{if(!recording)return;const start=recording.samples[0].data.timestamp,end=recording.samples.at(-1).data.timestamp;seek(start+(end-start)*Number($('replay-position').value)/1000);};
  return {stop,load};
}
