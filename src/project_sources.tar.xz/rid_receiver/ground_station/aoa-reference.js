import {state,changes} from './data.js';
import {esc,fmt} from './workspace-core.js';

export const referenceChannels=(channels,band)=>channels.filter(c=>c.band===band);
export const referenceSelectionId=(profiles,selected,active)=>profiles.some(p=>p.id===selected)?selected:profiles.some(p=>p.id===active)?active:profiles[0]?.id||'';
export function verificationMarkup(results){
  if(!results)return '';
  return `<table class="reference-stats"><thead><tr><th>原位核验</th><th>当前相位</th><th>与旧基准差值</th><th>离散</th><th>结果</th></tr></thead><tbody>${Object.entries(results).map(([s,v])=>`<tr><td>${esc(s)}</td><td>${fmt(v.meanDeg,2)}°</td><td>${fmt(v.phaseDifferenceDeg,2)}°</td><td>${fmt(v.spreadDeg,2)}°</td><td>${v.passed?'通过':'不符'}</td></tr>`).join('')}</tbody></table>`;
}
export function referenceDiagram(p){
  const lateral=Number(p.lateralM)||0,forward=Math.max(.1,Number(p.forwardM)||3),half=Math.max(.025,Number(p.baselineM)/2||1.4);
  const scale=Math.min(135/forward,165/Math.max(half,Math.abs(lateral),.5)),mid=210,base=190,tx=mid+lateral*scale,ty=base-forward*scale;
  const ax=mid+(p.aSide==='left'?-half:half)*scale,bx=mid+(p.aSide==='left'?half:-half)*scale;
  return `<svg viewBox="0 0 420 230" role="img" aria-label="基准布置示意：两站中点正前方为参考方向，右向偏移为正"><path d="M${mid} 205V30" stroke="#b8cbc1" stroke-dasharray="4 5"/><path d="M${ax} ${base}L${tx} ${ty}L${bx} ${base}Z" fill="#e7f0eb" stroke="#8da99c"/><circle cx="${tx}" cy="${ty}" r="6" fill="#b88624"/><text x="${tx}" y="${ty-14}" text-anchor="middle">参考源</text><circle cx="${ax}" cy="${base}" r="6" fill="#347c69"/><circle cx="${bx}" cy="${base}" r="6" fill="#347c69"/><text x="${ax}" y="${base+23}" text-anchor="middle">站 A</text><text x="${bx}" y="${base+23}" text-anchor="middle">站 B</text><text x="18" y="22">前向 ↑　右向 →</text></svg>`;
}
export function referenceStatistics(stats){
  if(!stats||!Object.keys(stats).length)return '';
  return `<table class="reference-stats"><thead><tr><th>站点</th><th>样本</th><th>平均相位</th><th>相位离散</th><th>半组漂移</th></tr></thead><tbody>${Object.entries(stats).map(([s,v])=>`<tr><td>${esc(s)}</td><td>${esc(v.samples)}</td><td>${fmt(v.meanDeg,2)}°</td><td>${fmt(v.spreadDeg,2)}°</td><td>${fmt(v.halfDriftDeg,2)}°</td></tr>`).join('')}</tbody></table>`;
}
export async function referenceRequest(body){
  const response=await fetch('/api/aoa-reference',{cache:'no-store',signal:AbortSignal.timeout(['activate','restoreDefault','recover'].includes(body?.action)?60000:10000),
    ...(body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});
  const value=await response.json();if(!response.ok)throw new Error(value.error||`基准接口失败 HTTP ${response.status}`);return value;
}

export function setupAOAReference({toast,onApplied,hasDraft=()=>false}){
  const sheet=document.createElement('link');sheet.rel='stylesheet';sheet.href=new URL('./aoa-reference.css',import.meta.url).href;document.head.append(sheet);
  const page=document.querySelector('[data-page="stations"]'),panel=document.createElement('article');
  panel.className='aoa-reference-panel';panel.setAttribute('aria-label','AOA基准调试与复用');
  panel.innerHTML=`<div class="section-heading"><div><h2>AOA基准调试与复用</h2><p class="muted">旧基准独立保留。切频后先原位核验，不把稳定相位直接当成正确角度。</p></div><span id="reference-current" class="muted">正在读取当前基准…</span></div><p id="reference-current-detail" class="reference-job" role="status"></p>
  <div class="reference-workspace"><section class="reference-form"><h3>1　设置参考场景</h3><div class="field-grid">
  <label>频段<select id="reference-band"><option value="2.4">2.4 GHz</option><option value="5">5 GHz</option></select></label><label>信道<select id="reference-channel" aria-label="基准信道"></select></label>
  <label class="reference-wide">基准名称<input id="reference-name" maxlength="80" placeholder="例如：信道1 · 户外三米基准"></label>
  <label>两站中心间距 / m<input id="reference-baselineM" type="number" min="0.05" max="1000" step="0.01" value="2.8"></label><label>参考源前向距离 / m<input id="reference-forwardM" type="number" min="0.1" max="10000" step="0.01" value="3"></label>
  <label>参考源右向偏移 / m<input id="reference-lateralM" type="number" min="-10000" max="10000" step="0.01" value="0"></label><label>共同正前方朝向 / °<input id="reference-headingDeg" type="number" min="-3600" max="3600" step="0.1" value="0"></label>
  <label>两站左右顺序<select id="reference-aSide"><option value="right">面向正前方：A右 / B左</option><option value="left">面向正前方：A左 / B右</option></select></label>
  <label>已观测参考源<select id="reference-source"><option value="">手动输入MAC</option></select></label>
  <label class="reference-wide">参考源空口MAC<input id="reference-referenceMac" placeholder="90:e5:b1:ce:27:08" maxlength="17" spellcheck="false" autocomplete="off"></label></div>
  <p id="reference-spacing" class="muted"></p><p class="muted">前向距离从两站中点量起，右向为正、左向为负。参考源与阵列按同一水平面布置。5 GHz当前仅提供设备支持的信道，不含5.8 GHz。</p>
  <details><summary>采样与复用选项</summary><div class="field-grid"><label>每站有效样本<input id="reference-sampleCount" type="number" min="10" max="100" step="1" value="20"></label><label>采集超时 / 秒<input id="reference-timeoutSeconds" type="number" min="15" max="180" step="1" value="90"></label><label>最大相位离散 / °<input id="reference-maxSpreadDeg" type="number" min="0.1" max="30" step="0.1" value="5"></label>
  <label>A站角度方向<select id="reference-bearingSignA"><option value="1">+1 · 默认</option><option value="-1">−1 · 反向</option></select></label><label>B站角度方向<select id="reference-bearingSignB"><option value="1">+1 · 默认</option><option value="-1">−1 · 反向</option></select></label></div>
  <label class="reference-check"><input id="reference-reuse" type="checkbox" checked>允许保留跨会话复用；会话变化后先原位核验，核验不改写旧偏置</label></details>
  <div class="button-row"><button id="reference-preview">预览理论角度</button><button id="reference-save">保存参数草稿</button></div>
  <label class="reference-check"><input id="reference-confirm" type="checkbox">我已按输入摆好两站、天线和参考源，并确认参考源MAC</label>
  <div class="button-row"><button id="reference-capture" class="primary">采集并另存新基准</button><button id="reference-cancel" disabled>取消采集</button></div><p class="muted">采集成功只新增独立记录，不自动切换当前基准。失败或取消也会恢复实际信道与两站参考配置；若射频会话变化，旧基准需先原位核验。</p></section>
  <section class="reference-results"><h3>2　预览与采集结果</h3><div id="reference-diagram" class="reference-diagram"></div><div id="reference-preview-result" class="reference-preview-result" aria-live="polite">点击预览，核对两站理论角度。</div>
  <div id="reference-job" class="reference-job" role="status">正在读取…</div><div id="reference-statistics" class="table-scroll"></div><div id="reference-verification" class="table-scroll"></div>
  <h3>3　保存的基准与下发</h3><label>选择配置<select id="reference-profiles" aria-label="保存的AOA基准"></select></label><p id="reference-profile-info" class="muted"></p>
  <div class="button-row"><button id="reference-apply" class="primary">下发所选基准到两站</button><button id="reference-default">下发默认基准到两站</button></div>
  <p id="reference-action-result" class="reference-job" role="status" aria-live="polite">下发使用下拉框选中的基准。点击后会显示两站确认结果。</p>
  <details><summary>将参数填回左侧表单 / 管理记录</summary><div class="button-row"><button id="reference-load">将所选参数填回表单</button><button id="reference-load-active">将当前参数填回表单</button><button id="reference-delete">删除所选</button></div><p class="muted">填回表单供查看、调整或重新采集；需要让两站使用基准，请点击上方的下发按钮。</p></details>
  <div class="button-row"><button id="reference-verify">原位核验当前基准</button><button id="reference-recover" hidden>恢复原测向</button></div>
  <p class="muted">上方显示实际正在选用的基准。新采集记录切频或重启后需原位核验，核验不会修改旧偏置。默认基准保留此前指定的固定复用设置，沿用历史偏置不代表当前会话核验通过。</p></section></div>`;
  page.querySelector('.station-workspace').after(panel);
  const $=id=>panel.querySelector('#reference-'+id),numeric=['baselineM','forwardM','lateralM','headingDeg','sampleCount','timeoutSeconds','maxSpreadDeg','bearingSignA','bearingSignB'];
  let data=null,initial=true,busy=false,polling=false,localError='',pendingMessage='',localResult='';
  const currentProfile=()=>data?.profiles.find(p=>p.id===$('profiles').value);
  function read(){return Object.fromEntries([...numeric.map(k=>[k,$(k).value.trim()===''?NaN:Number($(k).value)]),['channel',Number($('channel').value)],['name',$('name').value],['referenceMac',$('referenceMac').value.trim()],['aSide',$('aSide').value],['reuseAcrossRestarts',$('reuse').checked]]);}
  function channels(chosen){$('channel').innerHTML=referenceChannels(data?.channels||[],$('band').value).map(c=>`<option value="${c.channel}">信道 ${c.channel} / ${c.frequencyMhz} MHz</option>`).join('');if(chosen)$('channel').value=String(chosen);}
  function draw(){$('diagram').innerHTML=referenceDiagram(read());}
  function fill(p){for(const k of [...numeric,'name','referenceMac','aSide'])if(p[k]!==undefined)$(k).value=String(p[k]);$('band').value=p.channel<=13?'2.4':'5';channels(p.channel);$('reuse').checked=p.reuseAcrossRestarts!==false;$('confirm').checked=false;draw();$('preview-result').textContent='参数已载入，请预览并确认实物布置。';}
  function render(){
    if(!data){for(const button of panel.querySelectorAll('button'))button.disabled=true;return;}const job=data.job,running=['tuning','capturing','restoring'].includes(job.state),live=state.mode==='external',recovery=data.recoveryRequired===true;
    $('current').textContent=data.activeMode==='default'?'当前选用：默认基准':data.activeProfileName?`当前选用：${data.activeProfileName} · ${new Date(data.activeProfileCreatedAt).toLocaleString('zh-CN')}`:'当前参考来自原有配置文件';
    $('current-detail').textContent=data.currentReferences.map(r=>`${r.station}站 ${r.frequencyMhz?fmt(r.frequencyMhz,0)+' MHz':'无参考'} · 偏置 ${fmt(r.phaseBiasDeg,2)}° · ${data.activeMode==='default'?'默认固定复用':r.verification?.valid===true?'当前会话已核验':r.verification?'需原位核验':'历史参考／未核验'}`).join('；')+(data.activeMatchesFiles===false?'；活动文件与保存记录不一致，禁止覆盖旧文件':data.activeMatchesFiles===true?'；文件与保存记录一致':'');
    const a=data.configuration.config.stations.find(s=>s.id==='A'),b=data.configuration.config.stations.find(s=>s.id==='B');
    $('spacing').textContent=`沿用设备天线中心距：A ${fmt((a?.antennaSpacingM||.06)*100,2)} cm / B ${fmt((b?.antennaSpacingM||.06)*100,2)} cm。修改天线间距请使用上方布站设置，并同步板端阵距。`;
    $('job').textContent=localError||pendingMessage||job.message+(job.progress?' · '+Object.entries(job.progress).map(([s,n])=>`${s} ${n}/${job.sampleCount}`).join('　'):'')+(job.restoreError?'；'+job.restoreError:'');
    $('job').classList.toggle('is-error',!!localError||['failed','verification_failed','recovery_required'].includes(job.state));
    const chosen=$('profiles').value;
    $('profiles').innerHTML=data.profiles.length?data.profiles.map(p=>`<option value="${p.id}">${esc(p.name)} · 信道${p.settings.channel} · ${esc(new Date(p.createdAt).toLocaleString('zh-CN'))} · ${p.status==='draft'?'草稿':'已采集'}${data.activeId===p.id?' · 当前选用':''}</option>`).join(''):'<option value="">尚无保存的配置</option>';
    $('profiles').value=referenceSelectionId(data.profiles,chosen,data.activeId);
    const profile=currentProfile();
    const unavailable=!live?'请先切换到真实接入模式。':running?'基准任务正在执行，请等待完成。':recovery?'请先恢复原测向。':!profile?'请先选择一份已采集基准。':profile.status!=='captured'?'所选记录是参数草稿，需先采集基准才能下发。':'';
    $('action-result').textContent=localError||pendingMessage||localResult||unavailable||'下发使用下拉框选中的基准。点击后会显示两站确认结果。';
    $('action-result').classList.toggle('is-error',!!localError);
    $('apply').title=unavailable||'将所选记录分别下发到A/B两站，并等待两站确认';
    $('profile-info').textContent=profile?`信道 ${profile.settings.channel} · 站距 ${profile.settings.baselineM} m · 前向 ${profile.settings.forwardM} m · 右移 ${profile.settings.lateralM} m · ${new Date(profile.createdAt).toLocaleString('zh-CN')}`:'可先保存参数草稿，再按实物布置采集。';
    $('statistics').innerHTML=referenceStatistics(job.state==='completed'?job.statistics:profile?.statistics);
    $('verification').innerHTML=verificationMarkup(job.verification||data.lastVerification);
    for(const id of ['preview','save','load','delete'])$(id).disabled=busy||running||recovery||(['load','delete'].includes(id)&&!profile);
    $('capture').disabled=busy||running||recovery||!live||!$('confirm').checked;
    $('apply').disabled=busy||running||recovery||!live||profile?.status!=='captured';$('cancel').disabled=!['tuning','capturing'].includes(job.state)||busy;
    $('default').disabled=busy||running||recovery||!live;
    $('load-active').disabled=busy||running||!data.activeSettings;
    $('verify').disabled=busy||running||recovery||!live||!data.activeId||!$('confirm').checked||data.activeMatchesFiles===false;
    $('recover').hidden=!recovery;$('recover').disabled=busy||running||!live;
    for(const input of panel.querySelectorAll('.reference-form input,.reference-form select'))input.disabled=busy||running;
  }
  async function poll(){if(polling||busy)return;polling=true;try{data=await referenceRequest();
    if(initial){const cfg=data.configuration.config,a=cfg.stations.find(s=>s.id==='A'),b=cfg.stations.find(s=>s.id==='B');
      fill(data.activeSettings||{channel:data.scan.currentChannel||data.scan.channel||6,baselineM:data.configuration.baselineM||2.8,headingDeg:a?.headingDeg||0});
      initial=false;}
    const selected=$('source').value;$('source').innerHTML='<option value="">手动输入MAC</option>'+data.sources.filter(s=>s.fresh&&s.doaSupported).map(s=>`<option value="${esc(s.mac)}">${esc(s.ssid||s.mac)} · ${s.frequencyMhz} MHz</option>`).join('');$('source').value=selected;
    render();}catch(e){$('job').textContent=e.message;}finally{polling=false;}}
  async function action(action,extra={}){if(busy)return;busy=true;localError='';localResult='';pendingMessage=['activate','restoreDefault'].includes(action)?'正在下发基准，等待A/B两站确认…':action==='preview'?'正在计算理论角度…':'正在处理基准配置…';render();try{const reply=await referenceRequest({action,...extra});
    if(action==='preview'){const p=reply.geometry;$('preview-result').innerHTML=['A','B'].map(s=>`<div><b>站 ${s}</b><span>理论角 ${fmt(p.stations[s].knownAngleDeg,2)}°</span><small>理论相位 ${fmt(p.stations[s].expectedPhaseDeg,2)}°</small></div>`).join('')+p.warnings.map(w=>`<p class="reference-warning">${esc(w)}</p>`).join('');draw();}
    else{data=reply;if(['activate','restoreDefault','recover'].includes(action)){localResult=(['activate','restoreDefault'].includes(action)?'A/B两站均已确认接收。':'')+reply.job.message;await onApplied?.();toast(localResult);}else if(action==='saveDraft')toast('基准参数已保存，未改变当前参考');else if(action==='capture')toast('新基准采集已启动；不会自动替换旧基准');else if(action==='verify')toast('已启动旧基准原位核验，不修改保存数据');render();}
  }catch(e){localError=e.message;toast(e.message);}finally{busy=false;pendingMessage='';render();}}
  $('band').onchange=()=>{channels();draw();};
  $('source').onchange=()=>{if($('source').value)$('referenceMac').value=$('source').value;};
  for(const input of panel.querySelectorAll('.reference-form input,.reference-form select'))input.addEventListener('change',()=>{if(input.id!=='reference-confirm')$('confirm').checked=false;draw();if(data)render();});
  $('preview').onclick=()=>action('preview',{settings:read()});$('save').onclick=()=>action('saveDraft',{settings:read()});
  $('capture').onclick=()=>action('capture',{settings:read(),physicalConfirmed:$('confirm').checked});$('cancel').onclick=()=>action('cancel');
  function loadParameters(params,label,hint){fill(params);localError='';localResult=`已将“${label}”的参数填回左侧表单。${hint}`;toast(localResult);render();}
  $('load').onclick=()=>{const profile=currentProfile();if(profile)loadParameters(profile.settings,profile.name,profile.status==='draft'?'该记录为草稿，需先采集基准。':'下发这份记录请点击“下发所选基准到两站”。');};
  $('load-active').onclick=()=>{if(data.activeSettings)loadParameters(data.activeSettings,data.activeMode==='default'?'默认基准':data.activeProfileName||'当前基准',data.activeMode==='default'?'下发默认基准请点击“下发默认基准到两站”。':'');};
  $('verify').onclick=()=>action('verify',{settings:read(),physicalConfirmed:$('confirm').checked});
  $('recover').onclick=()=>action('recover');
  function readyToDispatch(){if(!hasDraft())return true;localError='上方布站有未保存修改，请先点击“保存配置”或“取消草稿”，再下发基准。';localResult='';toast(localError);render();return false;}
  $('default').onclick=()=>{if(readyToDispatch())action('restoreDefault');};
  $('apply').onclick=()=>{if(readyToDispatch())action('activate',{profileId:$('profiles').value});};
  $('delete').onclick=()=>action('delete',{profileId:$('profiles').value});$('profiles').onchange=()=>{localResult='';localError='';render();};
  changes.addEventListener('change',render);render();poll();setInterval(()=>{if(!page.hidden||['tuning','capturing','restoring'].includes(data?.job.state))poll();},1500);
  return {poll};
}
