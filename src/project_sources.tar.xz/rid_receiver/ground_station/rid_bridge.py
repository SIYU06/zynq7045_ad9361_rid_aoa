"""Translate the board's read-only RID feed into the existing map input."""
import copy
import json
import threading
import time
from urllib.request import build_opener, ProxyHandler


def map_snapshot(snapshot, pc_received_ms):
    sampled = snapshot['monotonic']
    replay = snapshot['mode'] == 'replay'
    targets = []
    for target in snapshot.get('targets', []):
        messages = list(target.get('messages', {}).values())
        basics = [m for m in messages if m['type'] == 0 and m.get('uas_id')]
        basic = max(basics, key=lambda m: m['received_monotonic'], default={})
        location = next((m for m in messages if m['type'] == 1), {})
        system = next((m for m in messages if m['type'] == 4), {})
        age = max(0, sampled - target['last_seen_monotonic'])
        location_age = sampled - location.get('received_monotonic', -1e20)
        # Do not let fresh identity-only packets extend the life of old positions.
        fresh_location = replay or location_age <= 15
        source = '参考PCAP回放' if replay else '空口接收 / ' + snapshot.get('interface', 'sdr0')
        if fresh_location:
            position = {name: location.get(key) for name, key in
                        [('latitude', 'latitude'), ('longitude', 'longitude'), ('altitude', 'altitude_geo'),
                         ('speed', 'speed_horizontal'), ('heading', 'direction')]}
        else:
            position = dict.fromkeys(('latitude', 'longitude', 'altitude', 'speed', 'heading'))
        if not location:
            position_status = '等待Location消息'
        elif not fresh_location:
            position_status = '位置消息已过期'
        elif position['latitude'] is None or position['longitude'] is None:
            position_status = 'Location未提供有效当前位置'
        else:
            position_status = 'RID广播当前位置'
        system_fresh = replay or sampled - system.get('received_monotonic', -1e20) <= 15
        reference = dict(type=system.get('operator_location_type'),
                         latitude=system.get('operator_latitude'), longitude=system.get('operator_longitude')) if system_fresh else None
        targets.append(dict(position, id=basic.get('uas_id') or target['mac'],
                            type={1: '固定翼', 2: '多旋翼/直升机'}.get(basic.get('ua_type'), '类型未知'),
                            status={1: '地面', 2: '空中', 3: '紧急', 4: 'RID故障'}.get(location.get('status'), '状态未知'),
                            source=source, demo=False, replay=replay, timestamp=pc_received_ms - age * 1000,
                            timestampBasis='PC接收时间减板端单调时钟数据年龄',
                            sourceMac=target['mac'], rssi=target.get('rssi'), packets=target['packets'],
                            positionStatus=position_status, referencePosition=reference,
                            frequencyMhz=target.get('frequency_mhz'), rateMbps=target.get('rate_mbps'),
                            fcsValid=target.get('fcs_valid'), fcsMethod=target.get('fcs_method'), captureTime=target.get('capture_time'),
                            positionTimestamp=pc_received_ms - location_age * 1000 if location else None,
                            observationId='%s:%s:%s:%s' % (snapshot['session_id'], target['mac'], target['last_seen_monotonic'], fresh_location)))
    return dict(targets=targets, mode=snapshot['mode'], source=snapshot.get('source'),
                status=snapshot['status'], frames=snapshot['frames'], packets=snapshot['packets'],
                errors=snapshot['errors'], capture=snapshot.get('capture', {}), sessionId=snapshot['session_id'])


class RIDBridge:
    def __init__(self, url=None,selection=None,station=None):
        self.url = url.rstrip('/') if url else None
        self.lock, self.stop = threading.Lock(), threading.Event()
        self.value = dict(configured=bool(url), connected=False, targets=[], status='等待RID数据源', error=None)
        self.last_poll = None
        self.selection=selection;self.station=station
        self.opener = build_opener(ProxyHandler({}))  # Direct Ethernet, independent of PC proxy settings.

    def run(self):
        while not self.stop.is_set():
            if self.selection and not self.selection.is_selected(self.station):self.stop.wait(.5);continue
            try:
                with self.opener.open(self.url + '/api/state', timeout=2) as response:
                    snapshot = json.load(response)
                value = map_snapshot(snapshot, time.time() * 1000)
                value.update(configured=True, connected=not snapshot['status'].startswith('接收失败'), error=None)
                with self.lock:
                    self.value, self.last_poll = value, time.monotonic()
            except Exception as exc:
                with self.lock:
                    self.value.update(connected=False, error=str(exc))
            self.stop.wait(1)

    def snapshot(self):
        with self.lock:
            value = copy.deepcopy(self.value)
            if self.selection and not self.selection.accepts_session(self.station,value.get('sessionId')):
                value.update(connected=False,targets=[],status='本站不负责信源解码',error=None)
            if self.last_poll is None or time.monotonic() - self.last_poll > 4:
                value['connected'] = False
            return value


class RIDFleet:
    """Use both receivers, keeping one freshest track per advertised identity/MAC."""
    def __init__(self, urls,selection=None):
        self.selection=selection
        self.bridges = {station: RIDBridge(url,selection,station) for station, url in urls.items() if url}
        self.url = next(iter(urls.values()), None)
        self.stop = threading.Event()

    def run(self):
        threads = [threading.Thread(target=bridge.run, daemon=True) for bridge in self.bridges.values()]
        for thread in threads:
            thread.start()
        self.stop.wait()
        for bridge in self.bridges.values():
            bridge.stop.set()
        for thread in threads:
            thread.join(3)

    def snapshot(self):
        feeds = {station: bridge.snapshot() for station, bridge in self.bridges.items()}
        targets, receivers = {}, {}
        for station, feed in feeds.items():
            for target in feed.get('targets', []):
                # Failed receivers must not eclipse a healthy receiver's latest observation.
                if not feed['connected']:
                    continue
                key = (target['id'], target.get('sourceMac'))
                receivers.setdefault(key, []).append(station)
                if key not in targets or target['timestamp'] > targets[key]['timestamp']:
                    targets[key] = dict(target, receiver=station)
        for key, target in targets.items():
            target['receiverStations'] = receivers[key]
        online = [feed for feed in feeds.values() if feed['connected']]
        live = any(feed.get('mode') == 'live' for feed in online)
        return dict(configured=bool(feeds), connected=bool(online), targets=list(targets.values()),
                    mode='live' if live else ('replay' if online else None),
                    status='双站被动接收中' if len(online)>1 else '单站被动接收中' if online else '等待RID数据源',
                    stations=[dict(id=s, connected=f['connected'], sessionId=f.get('sessionId'),
                                   frames=f.get('frames',0), capture=f.get('capture',{}), error=f.get('error')) for s,f in feeds.items()],
                    error=None if online else '; '.join(f.get('error') or '等待接收' for s,f in feeds.items() if not self.selection or self.selection.is_selected(s)),
                    receiverSelection=self.selection.snapshot() if self.selection else None)
