import {finite,geographic,intersectionPoints} from './workspace-core.js';

const position=p=>finite(p?.latitude)&&finite(p?.longitude)&&Math.abs(p.latitude)<=85&&Math.abs(p.longitude)<=180;
export const branchId=(point,feed)=>point.candidateId||Object.values(point.branches||{}).join('-')||(feed.directionMode==='front'?'front-front':'provided');
const geometryOf=(feed,mode)=>JSON.stringify([mode,feed.directionMode,feed.anchor,feed.stations.map(s=>[s.id,s.xM,s.yM,s.headingDeg,s.antennaSpacingM,s.sessionId,s.referenceHash,s.calibrationHash,s.phaseBiasAppliedDeg])]);
export const trackMatchesFeed=(track,feed,mode)=>!!feed?.stations&&track.geometry===geometryOf(feed,mode);

// Target rotation is allowed; a changed deployment, reference or RF session is not.
export function compatibleDOAScene(saved,current){
  if(!current?.stations)return true;
  if(saved.directionMode!==current.directionMode||JSON.stringify(saved.anchor)!==JSON.stringify(current.anchor))return false;
  return saved.stations.every(a=>{const b=current.stations.find(s=>s.id===a.id);return b&&!b.calibrationRequired&&
    ['xM','yM','headingDeg','antennaSpacingM'].every(k=>a[k]===b[k])&&
    ['sessionId','referenceHash','calibrationHash'].every(k=>!b[k]||a[k]===b[k]);});
}

export function updateDOATracks(store,feed,{mode='external',connected=false,now=Date.now(),maxPoints=120,maxTracks=64}={}){
  const points=intersectionPoints(feed,mode,now,connected);
  if(!points.length)return;
  const stations=feed.stations;
  if(mode==='external'&&stations.some(s=>!s.sourceVerified||!s.freshnessVerified))return;
  const target=feed.targetId||stations[0]?.targetId;
  if(!target)return;
  const stamp=Math.max(...stations.map(s=>s.timestamp??feed.timestamp));
  const geometry=geometryOf(feed,mode);
  const observation=JSON.stringify(stations.map(s=>[s.frameKey,s.tsf??s.timestamp]));
  for(const point of points){
    if(point.targetId&&point.targetId!==target)continue;
    const branch=branchId(point,feed),key=JSON.stringify([target,branch]);
    let track=store.get(key);
    if(!track||track.geometry!==geometry){
      track={targetId:target,sourceMac:point.sourceMac||stations[0]?.sourceMac||null,branch,geometry,points:[],lastObservation:null,lastTimestamp:0};
      store.set(key,track);
    }
    if(stamp<track.lastTimestamp||observation===track.lastObservation)continue;
    const p=position(point)?[point.latitude,point.longitude]:geographic(feed.anchor,point.xM,point.yM);
    if(!p||!position({latitude:p[0],longitude:p[1]}))continue;
    const last=track.points.at(-1),gap=stamp-track.lastTimestamp>15000;
    if(!last||gap||last.latitude!==p[0]||last.longitude!==p[1]){
      track.points.push({latitude:p[0],longitude:p[1],xM:point.xM,yM:point.yM,timestamp:stamp,breakBefore:!!last&&gap});
      track.points=track.points.slice(-maxPoints);
    }
    track.lastObservation=observation;track.lastTimestamp=stamp;
  }
  if(store.size>maxTracks){
    const oldest=[...store.entries()].sort((a,b)=>a[1].lastTimestamp-b[1].lastTimestamp);
    for(const [key] of oldest.slice(0,store.size-maxTracks))store.delete(key);
  }
}

export function recentTrackPoints(points,now,retentionMs){
  return points.filter(p=>finite(p.timestamp)&&p.timestamp<=now+2000&&now-p.timestamp<retentionMs);
}
export function trackSegments(track,{now=null,retentionMs=Infinity}={}){
  const segments=[];let current=[];
  for(const point of now===null?track.points:recentTrackPoints(track.points,now,retentionMs)){
    if(point.breakBefore&&current.length){segments.push(current);current=[];}
    current.push([point.latitude,point.longitude]);
  }
  if(current.length)segments.push(current);
  return segments.filter(points=>points.length>=2);
}
