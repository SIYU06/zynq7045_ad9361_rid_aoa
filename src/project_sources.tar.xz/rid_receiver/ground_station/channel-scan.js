import {state,changes} from './data.js';
import {jsonFetch} from './workspace-core.js';
export function scanLabel(value){
 if(!value)return '等待扫描状态';
 const mode=value.mode==='fixed'?'固定信道':value.mode==='combined'?'2.4 / 5 GHz轮扫':value.mode+' GHz轮扫';
 return `${mode} · ${value.state==='tuning'?'切频中':value.currentChannel?`信道 ${value.currentChannel} / ${value.frequencyMhz} MHz`:'等待接收'}${value.error?' · '+value.error:''}${Object.keys(value.partialErrors||{}).length?' · 部分测向站未确认':''}`;
}
export function setupChannelScan({toast}){
 const page=document.querySelector('[data-page="signals"]'),panel=document.createElement('section');
 panel.className='receiver-role-control';panel.setAttribute('aria-label','接收频段与信道');
 panel.innerHTML='<div><strong>接收频段与信道</strong><span role="status">正在读取</span><small>逐信道被动接收；离开某信道期间会有接收间隙。选择AOA目标后固定到该信道。</small></div><div class="button-row"><select aria-label="扫描频段"><option value="combined">2.4 + 5 GHz轮扫</option><option value="2.4">2.4 GHz轮扫</option><option value="5">5 GHz轮扫</option><option value="fixed">固定信道</option></select><select aria-label="固定信道"></select><button disabled>应用接收范围</button></div>';
 page.querySelector('.page-heading').after(panel);
 const [mode,channel]=panel.querySelectorAll('select'),button=panel.querySelector('button'),status=panel.querySelector('[role="status"]');
 let value=null,dirty=false,busy=false;
 function render(){
  const live=state.mode==='external';
  if(value&&!dirty){mode.value=value.mode;channel.innerHTML=(value.supportedChannels||[]).map(c=>`<option value="${c}">信道 ${c} / ${c<=13?2407+5*c:5000+5*c} MHz</option>`).join('');channel.value=String(value.channel);}
  status.textContent=live?scanLabel(value):'历史记录保留原始频率';
  mode.disabled=busy||!live;channel.disabled=busy||!live||mode.value!=='fixed';button.disabled=busy||!live||!value;
 }
 mode.onchange=()=>{dirty=true;render();};channel.onchange=()=>{dirty=true;};
 async function poll(){try{value=await jsonFetch('/api/channel-scan');render();}catch(e){status.textContent=e.message;}}
 button.onclick=async()=>{if(busy||state.mode!=='external'||!value)return;busy=true;render();try{value=await jsonFetch('/api/channel-scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:mode.value,channel:Number(channel.value||6),dwellSeconds:value?.dwellSeconds||3})});dirty=false;toast('接收范围已保存，等待板端切频确认');}catch(e){toast(e.message);}finally{busy=false;render();}};
 changes.addEventListener('change',render);setInterval(poll,1500);poll();return {render};
}
