"""Validated, versioned station geometry. Never alters RF calibration files."""
import copy
import hashlib
import json
import math
from pathlib import Path
import threading
from doa_geometry import geographic, R

LOCK = threading.RLock()

class ConfigConflict(ValueError):
    pass

def revision(config):
    return hashlib.sha256(json.dumps(config,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:20]

def numeric(value,name,minimum,maximum,nullable=False):
    if value is None and nullable:return None
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not minimum<=value<=maximum:
        raise ValueError(name+'需为范围内的有效数字')
    return value

def local(anchor,latitude,longitude):
    if not anchor:raise ValueError('请先设置共享坐标原点')
    lat=numeric(latitude,'纬度',-85,85);lon=numeric(longitude,'经度',-180,180)
    return (math.radians(lon-anchor['longitude'])*R*math.cos(math.radians(anchor['latitude'])),
            math.radians(lat-anchor['latitude'])*R)

def read(path):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else dict(anchor=None,stations=[])

def document(path):
    with LOCK:
        config=read(path)
        points=[s for s in config.get('stations',[]) if s.get('xM') is not None and s.get('yM') is not None]
        baseline=math.hypot(points[0]['xM']-points[1]['xM'],points[0]['yM']-points[1]['yM']) if len(points)>=2 else None
        return dict(schema='airspace.stations',version=1,revision=revision(config),config=config,
                    baselineM=baseline,canUndo=path.with_suffix('.previous.json').exists())

def atomic(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    temporary.replace(path)

def validate_patch(config,patch):
    if not isinstance(patch,dict) or not isinstance(patch.get('stations',[]),list):raise ValueError('站点配置格式错误')
    result=copy.deepcopy(config)
    if 'directionMode' in patch:
        if patch['directionMode'] not in ('front','full'):raise ValueError('方位显示模式无效')
        result['directionMode']=patch['directionMode']
    if 'minCrossingDeg' in patch:result['minCrossingDeg']=numeric(patch['minCrossingDeg'],'最小交角',.1,30)
    if 'anchor' in patch:
        value=patch['anchor']
        if value is None:raise ValueError('坐标原点不能为空')
        if not isinstance(value,dict):raise ValueError('坐标原点需为经纬度对象')
        latitude=numeric(value.get('latitude'),'纬度',-85,85);longitude=numeric(value.get('longitude'),'经度',-180,180)
        if not result.get('anchor') or any(result['anchor'].get(k)!=v for k,v in [('latitude',latitude),('longitude',longitude)]):
            result['anchor']=dict(latitude=latitude,longitude=longitude,source='用户设置的共享坐标原点')
    ids=set()
    for change in patch.get('stations',[]):
        if not isinstance(change,dict) or change.get('id') in ids:raise ValueError('站点ID重复或格式错误')
        ids.add(change.get('id'))
        target=next((s for s in result.get('stations',[]) if s['id']==change.get('id')),None)
        if target is None:raise ValueError('未知测向站')
        previous_heading=target.get('headingDeg')
        if 'latitude' in change or 'longitude' in change:
            x,y=local(result.get('anchor'),change.get('latitude'),change.get('longitude'))
            if any(k in change and (not isinstance(change[k],(int,float)) or abs(change[k]-v)>.002) for k,v in [('xM',x),('yM',y)]):
                raise ValueError('经纬度与局部坐标不一致')
            target.update(xM=numeric(x,'东向位置',-100000,100000),yM=numeric(y,'北向位置',-100000,100000))
        for key in ('xM','yM','headingDeg','rayLengthM','antennaSpacingM'):
            if key not in change:continue
            value=change[key]
            if key in ('xM','yM'):value=numeric(value,key,-100000,100000,True)
            elif key=='headingDeg':
                value=numeric(value,key,-3600,3600,True)
                if value is not None:value%=360
            elif key=='antennaSpacingM':value=numeric(value,key,.001,1)
            else:value=numeric(value,key,1,100000)
            target[key]=value
        if 'headingDeg' in change and target.get('headingDeg')!=previous_heading:target['orientationSource']='用户设置；实际北向是否测量需现场核验'
        if target.get('xM') is not None and target.get('yM') is not None and result.get('anchor'):
            lat,lon=geographic(result['anchor'],target['xM'],target['yM'])
            numeric(lat,'换算纬度',-85,85);numeric(lon,'换算经度',-180,180)
    # Resolve relative B placement after all A changes, regardless of patch order.
    for change in patch.get('stations',[]):
        if 'relativeToA' not in change:continue
        if change['id']!='B' or not isinstance(change['relativeToA'],dict):raise ValueError('相对A站布站仅用于B站')
        value=change['relativeToA'];a=next((s for s in result['stations'] if s['id']=='A'),None)
        if not a or a.get('xM') is None or a.get('yM') is None:raise ValueError('请先设置A站位置')
        distance=numeric(value.get('distanceM'),'距A站距离',.05,100000)
        angle=numeric(value.get('angleDeg'),'相对角度',-3600,3600)
        frame=value.get('reference','a-forward')
        if frame not in ('a-forward','north'):raise ValueError('相对角参考方向无效')
        if frame=='a-forward':
            if a.get('headingDeg') is None:raise ValueError('请先设置A站正前方朝向或使用北向角度')
            angle+=a['headingDeg']
        rad=math.radians(angle)
        x=a['xM']+distance*math.sin(rad);y=a['yM']+distance*math.cos(rad)
        for k,v in [('xM',x),('yM',y)]:
            if k in change and (not isinstance(change[k],(int,float)) or abs(change[k]-v)>.002):raise ValueError('相对布站与局部坐标不一致')
        if 'latitude' in change or 'longitude' in change:
            gx,gy=local(result.get('anchor'),change.get('latitude'),change.get('longitude'))
            if math.hypot(gx-x,gy-y)>.002:raise ValueError('相对布站与经纬度不一致')
        b=next(s for s in result['stations'] if s['id']=='B')
        b.update(xM=numeric(x,'B东向位置',-100000,100000),yM=numeric(y,'B北向位置',-100000,100000))
        if result.get('anchor'):
            lat,lon=geographic(result['anchor'],x,y);numeric(lat,'纬度',-85,85);numeric(lon,'经度',-180,180)
    return result

def update(path,patch):
    with LOCK:
        current=read(path)
        if not isinstance(patch,dict):raise ValueError('配置需为对象')
        if 'expectedRevision' in patch and patch['expectedRevision']!=revision(current):
            raise ConfigConflict('配置已被其他窗口修改，请重新载入后再保存')
        if patch.get('action')=='undo':
            previous=path.with_suffix('.previous.json')
            if not previous.exists():raise ValueError('没有可撤销的配置')
            old=read(previous)
            # Restore only geometry; retain transport and calibration settings.
            base=copy.deepcopy(current);base['anchor']=old.get('anchor')
            patch=dict(stations=[{k:s.get(k) for k in ('id','xM','yM','headingDeg','rayLengthM','antennaSpacingM') if k in s} for s in old['stations']])
            result=validate_patch(base,patch)
            for key in ('directionMode','minCrossingDeg'):
                if key in old:result[key]=old[key]
                else:result.pop(key,None)
            for s in result['stations']:
                previous_station=next((p for p in old['stations'] if p['id']==s['id']),{})
                if 'orientationSource' in previous_station:s['orientationSource']=previous_station['orientationSource']
                else:s.pop('orientationSource',None)
        else:result=validate_patch(current,patch)
        if revision(result)!=revision(current):
            atomic(path.with_suffix('.previous.json'),current)
            atomic(path,result)
        return document(path)
