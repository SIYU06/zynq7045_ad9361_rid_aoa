import {state,hasPosition} from './data.js';
import {esc,fmt,time,finite,midpointCoordinates,phaseStationFresh,phaseStateLabel} from './workspace-core.js';
import {monitorTargets,frequencyBand} from './monitor-targets.js';
import {localFrame,localPoint,localPointLabel} from './position-display.js';

const field=(name,value)=>`<div><dt>${esc(name)}</dt><dd>${esc(value??'—')}</dd></div>`;
const fields=rows=>`<dl class="monitor-fields">${rows.map(([k,v])=>field(k,v)).join('')}</dl>`;
const unit=(value,suffix,digits=1)=>finite(value)?`${fmt(value,digits)}${suffix}`:'—';
const modes={external:'实时接入',replay:'历史回放'};
function targetCard(row,selected,reference){
  const {target,source,feed,points,tracks}=row,rid=row.method==='rid',position=row.position;
  const count=rid?row.ridHistory.length:tracks.reduce((n,t)=>n+t.points.length,0);
  const selectedRow=selected===row.id||selected===row.key||selected===`rf:${row.mac}`;
  const sourcePhase=source?.fresh&&source?.stages?.direction==='diagnostic'&&Date.now()-(source.direction?.timestamp??0)<15000?
    Object.values(source.direction?.stations||{}).find(s=>finite(s.phaseDeg)&&finite(s.timestamp)&&Date.now()-s.timestamp<15000):null;
  const phase=(feed?.stations||[]).find(s=>phaseStationFresh(s,feed,state.mode,state.replayClock??Date.now()))||sourcePhase;
  const referenceProblem=phase?.referenceError||phase?.angleRejection||(phase?.referenceMatched===false?'参考与当前接收状态不匹配':null);
  const status=state.mode==='replay'?'历史回放':rid?(row.positionFresh?'广播位置有效':row.fresh?'RID位置待更新':'历史位置'):
    points.length?'交汇候选':source?.doaSupported===false?'当前PHY不支持测向':phase?phaseStateLabel(phase):row.fresh?'等待同源交汇':'观测已过期';
  const label=rid?'RID广播无人机':target||source?.recognition?.kind==='rid'?'RID缺位置 · AOA测向':'疑似无人机 · AOA测向';
  const pointCards=points.map(point=>{const p=localPoint(point,reference)||midpointCoordinates(feed,point);return `<div class="monitor-point"><b>${point.ambiguous?'AOA交汇候选 · 前后未消歧':'AOA交汇估计'}</b><strong>${p?`(${fmt(p.xM,2)}, ${fmt(p.yM,2)})`:'—'}<small>m</small></strong><span>相对两站中点 · 东X / 北Y</span></div>`;}).join('');
  return `<article class="monitor-target-card ${rid?'is-rid':'is-aoa'}${selectedRow?' is-selected':''}" data-target-key="${esc(row.key)}">
    <header><h3>${label}</h3><span class="monitor-tag ${row.fresh?'is-live':''}">${esc(status)}</span></header>
    <strong class="monitor-target-id">${esc(row.title)}</strong><span class="monitor-target-type">${esc(target?.type||source?.recognition?.label||'同源帧测向目标')}</span>
    ${fields([['定位方式',rid?'RID广播经纬度直显':'双站AOA交汇'],['身份状态',target?'RID广播声明／未认证':source?.recognition?.identityStatus||'未收到RID身份／归属待核验'],['空口MAC',row.mac],...(source?.ssid?[['SSID',source.ssid]]:[]),['频率',unit(row.frequencyMhz,' MHz',0)],...(row.observations?.length>1?[['合并观测',`${row.observations.length} 条记录`],['接收频点记录',row.observedFrequenciesMhz.map(f=>fmt(f,0)).join(' / ')+' MHz']]:[]),['频段',frequencyBand(row.frequencyMhz)],...(source?.features?[['调制/PHY',source.features.phy.join(' / ')],['协议',source.features.protocols.join(' / ')]]:[]),['观测时间',time(row.timestamp)]])}
    <div class="monitor-card-block"><h4>${rid?'RID广播位置':'AOA定位'}</h4>${rid?
      `${position?`<div class="monitor-location">${esc(localPointLabel(position,reference))}</div>`:'<p class="monitor-waiting">等待RID有效位置</p>'}${fields([['位置状态',row.positionFresh?'当前广播位置':position?'最后有效位置／历史':'尚无有效位置'],['位置时间',time(target?.positionTimestamp??row.ridHistory.at(-1)?.timestamp)],['几何高度',unit(target?.altitude,' m')],['速度',unit(target?.speed,' m/s')],['航向',unit(target?.heading,'°')]])}`:
      pointCards||`<p class="monitor-waiting">${esc(row.waitingReason|| (source?.doaSupported===false?'已识别信源；当前DSSS仅能解析身份，尚无对应测向算法':phase&&referenceProblem?`测向计算已启动；${referenceProblem}。当前尚无有效定位角度。`:feed?.intersectionReason||source?.positioning?.reason||'等待两站新鲜、同源同帧的测向结果'))}</p>`}
      ${!rid?'<p class="monitor-origin">黄色无人机表示AOA估计／候选位置，精度与前后方向仍待验证。</p>':''}
    </div><div class="monitor-card-block"><h4>${rid?'最近2分钟':'最近10秒'}轨迹</h4>${fields([['轨迹来源',rid?'RID广播位置':'AOA同源交汇'],['保留位置',`${count} 个`]])}<p class="monitor-origin">${count>1?(rid||points.length?'轨迹随时间逐步清除；中断处断开连线':'保留短时轨迹，等待新的有效交汇'):count?'已记录首个位置，等待位置变化':'等待连续有效位置'}</p></div>
    ${fields([...(finite(target?.rssi)?[['信号强度',unit(target.rssi,' dBm')]]:[]),...(finite(target?.rateMbps)?[['接收速率',unit(target.rateMbps,' Mbps')]]:[])])}
  </article>`;
}
export function monitorMarkup({feed,selected,now=Date.now(),layout=state.doa}){
  const rows=monitorTargets({pipeline:feed,now}),rid=rows.filter(r=>r.method==='rid'),aoa=rows.filter(r=>r.method==='aoa');
  const reference=localFrame(layout);
  return `<header class="monitor-data-heading"><h2>全部目标 <small>${rows.length}</small></h2><span class="monitor-tag">${esc(modes[state.mode])}</span></header>
    <div class="monitor-counters"><div><strong>${rid.length}</strong><span>RID目标</span></div><div><strong>${aoa.length}</strong><span>AOA目标/候选</span></div><div><strong>${rows.filter(r=>r.positionFresh||r.points.length).length}</strong><span>有效位置</span></div></div>
    <p class="monitor-origin monitor-list-note">向下滚动查看全部目标 · <span class="rid-text">绿色RID</span><span class="legend-divider">/</span><span class="aoa-text">黄色AOA</span></p>
    <div class="monitor-target-cards">${rows.map(row=>targetCard(row,selected,reference)).join('')||'<p class="monitor-waiting">等待RID广播或具有识别依据的疑似无人机信源。A/B测向站保持显示。</p>'}</div>`;
}
export function setupMonitorData({readPipeline,readSelected,readLayout=()=>state.doa}){
  const element=document.getElementById('monitor-data');let last='';
  return {render(now){const html=monitorMarkup({feed:readPipeline(),selected:readSelected(),now,layout:readLayout()});if(html===last)return;last=html;
    const top=element.scrollTop;element.innerHTML=html;element.scrollTop=top;
  }};
}
