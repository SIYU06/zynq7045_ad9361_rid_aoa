import {esc,fmt,finite,fieldNumber,normalized,geographic,local,jsonFetch,download,readJSON,relativePlacement,relativePosition} from './workspace-core.js';
import {log,notify} from './data.js';
import {config} from './config.js';
const $=id=>document.getElementById(id);
export function setupStationEditor({toast,onSaved}){
  let saved=null,draft=null,revision=null,dirty=false,unlocked=false,picking=false,invalid=false;
  let map=null,layer=null,showMap=false,applyBasemap=null;
  if(globalThis.L){map=L.map('station-map',{maxZoom:22,zoomControl:true}).setView([34,108],5);
    const select=document.createElement('select');select.id='station-basemap';select.className='station-basemap';select.setAttribute('aria-label','布站底图');select.innerHTML='<option value="satellite">卫星影像</option><option value="hybrid">卫星混合</option><option value="light">浅色底图</option><option value="grid">离线网格</option>';document.querySelector('.station-map-wrap').append(select);
    let tiles=[],epoch=0;
    const changeLayer=name=>{const token=++epoch;for(const tile of tiles)map.removeLayer(tile);tiles=[];let notified=false;
      if(showMap)for(const item of config.layers[name]||[]){const tile=L.tileLayer(item.url,{...item.options,...config.tileOptions});tile.on('tileerror',()=>{if(token!==epoch||notified||!tiles.includes(tile))return;notified=true;$('station-status').textContent='底图暂不可用，可切换图层；站点编辑仍可使用。';});tile.addTo(map);tiles.push(tile);}
      try{localStorage.setItem('airspace.station.basemap.v1',name);}catch{}
    };
    let savedLayer='satellite';try{const value=localStorage.getItem('airspace.station.basemap.v1');if(['satellite','hybrid','light','grid'].includes(value))savedLayer=value;}catch{}
    select.value=savedLayer;select.onchange=()=>changeLayer(select.value);applyBasemap=visible=>{if(showMap!==visible){showMap=visible;changeLayer(select.value);}};layer=L.layerGroup().addTo(map);
  }
  const station=()=>draft?.stations.find(s=>s.id===$('station-choice').value);
  function mark(){dirty=true;$('station-dirty').textContent='有未保存修改';$('station-dirty').classList.add('dirty');$('station-save').disabled=false;}
  function status(message){$('station-status').textContent=message;}
  function fill(){const s=station();if(!s)return;
    for(const [id,key] of [['station-heading','headingDeg'],['station-ray','rayLengthM']])$(id).value=s[key]??'';
    $('station-connection').textContent=`站 ${s.id} · ${s.url||'未配置数据接口'} · 连接状态见实时工作区`;
    $('station-orientation').textContent=s.orientationSource||'朝向未实测；北0°、东90°，顺时针。';
    $('anchor-lat').value=draft.anchor?.latitude??'';$('anchor-lon').value=draft.anchor?.longitude??'';
    $('station-antenna-spacing').value=finite(s.antennaSpacingM)?(s.antennaSpacingM*100).toFixed(2):'';
    $('station-relative-panel').hidden=s.id!=='B';
    const a=draft.stations.find(s=>s.id==='A'),placement=relativePlacement(a,draft.stations.find(s=>s.id==='B'),$('station-relative-frame').value);
    $('station-relative-distance').value=placement?placement.distanceM.toFixed(3):'';
    $('station-relative-angle').value=placement?placement.angleDeg.toFixed(2):'';
    $('station-coverage').value=draft.directionMode||'front';$('station-min-crossing').value=draft.minCrossingDeg??5;
    invalid=false;draw();
  }
  function setPosition(point){try{const [x,y]=local(draft.anchor,point.lat,point.lng);if(Math.abs(x)>100000||Math.abs(y)>100000)throw new Error('位置超出局部100 km范围，请先设置合适坐标原点');Object.assign(station(),{xM:x,yM:y});mark();fill();status('位置已预览；请保存配置。');}catch(e){status(e.message);}}
  function draw(){if(!draft)return;
    const a=draft.stations.find(s=>s.id==='A'),b=draft.stations.find(s=>s.id==='B');
    $('station-baseline').textContent=`站间基线 ${a&&b&&[a.xM,a.yM,b.xM,b.yM].every(finite)?fmt(Math.hypot(a.xM-b.xM,a.yM-b.yM),3):'—'} m`;
    $('station-spacing').textContent=`天线中心距 A ${finite(a?.antennaSpacingM)?fmt(a.antennaSpacingM*100,1):'—'} cm / B ${finite(b?.antennaSpacingM)?fmt(b.antennaSpacingM*100,1):'—'} cm`;
    if(!layer)return;layer.clearLayers();
    const points=[];
    for(const s of draft.stations){const p=geographic(draft.anchor,s.xM,s.yM);if(!p)continue;points.push(p);
      const editable=unlocked&&s.id===$('station-choice').value;
      const marker=L.marker(p,{draggable:editable,icon:L.divIcon({className:'station-marker',html:`<span class="station-pin ${s.id==='B'?'b':''}">${esc(s.id)}</span>`,iconSize:[28,28],iconAnchor:[14,14]})}).addTo(layer);
      marker.bindTooltip(`站 ${esc(s.id)} · ${fmt(s.xM,2)}, ${fmt(s.yM,2)} m`);
      marker.on('click',()=>{$('station-choice').value=s.id;fill();});
      marker.on('dragend',()=>setPosition(marker.getLatLng()));
      if(finite(s.headingDeg)){
        const rad=s.headingDeg*Math.PI/180,len=Math.max(1,Math.min(15,map.getZoom()>19?2:8));
        const end=geographic(draft.anchor,s.xM+Math.sin(rad)*len,s.yM+Math.cos(rad)*len);
        L.polyline([p,end],{color:s.id==='B'?'#b57a30':'#277e91',weight:2,interactive:false}).addTo(layer);
        if(editable){const handle=L.marker(end,{draggable:true,icon:L.divIcon({className:'station-heading-handle',html:'↗',iconSize:[22,22],iconAnchor:[11,11]})}).addTo(layer);handle.bindTooltip('拖动调整正前方朝向');handle.on('dragend',()=>{const ll=handle.getLatLng(),[x,y]=local(draft.anchor,ll.lat,ll.lng);s.headingDeg=normalized(Math.atan2(x-s.xM,y-s.yM)*180/Math.PI);s.orientationSource='用户拖动设置；实际北向待核验';mark();fill();});}
      }
    }
    if(points.length===2)L.polyline(points,{color:'#9aa99f',weight:1,dashArray:'4 5',interactive:false}).addTo(layer);
  }
  function fit(){const pts=draft?.stations.map(s=>geographic(draft.anchor,s.xM,s.yM)).filter(Boolean)||[];map?.invalidateSize();if(pts.length)map.fitBounds(pts,{maxZoom:22,padding:[70,90]});}
  async function load(){try{const doc=await jsonFetch('/api/doa/config');saved=structuredClone(doc.config);draft=structuredClone(saved);revision=doc.revision;dirty=false;invalid=false;$('station-dirty').textContent='配置已载入';$('station-dirty').classList.remove('dirty');$('station-save').disabled=false;$('station-undo').disabled=!doc.canUndo;
    const id=$('station-choice').value;if(!draft.stations.some(s=>s.id===id))$('station-choice').value=draft.stations[0]?.id||'A';fill();onSaved(structuredClone(saved));fit();return true;
    }catch(e){status(e.message);toast(e.message);return false;}}
  function readFields(){const s=station();if(!s)throw new Error('尚未载入站点配置');
    const heading=fieldNumber($('station-heading').value,true),ray=fieldNumber($('station-ray').value);
    if(ray<1||ray>100000)throw new Error('射线长度需为1至100000米');
    const spacing=fieldNumber($('station-antenna-spacing').value)/100;
    if(spacing<.001||spacing>1)throw new Error('天线中心距需为0.1至100厘米');
    Object.assign(s,{headingDeg:heading===null?null:normalized(heading),rayLengthM:ray,antennaSpacingM:spacing});invalid=false;
  }
  async function save(){try{if(invalid)throw new Error('请修正标记的站点输入');readFields();$('station-save').disabled=true;
    const payload={expectedRevision:revision,directionMode:draft.directionMode||'front',minCrossingDeg:draft.minCrossingDeg??5,stations:draft.stations.map(s=>({id:s.id,xM:s.xM,yM:s.yM,headingDeg:s.headingDeg,rayLengthM:s.rayLengthM??50,antennaSpacingM:s.antennaSpacingM}))};if(draft.anchor)payload.anchor=draft.anchor;
    await jsonFetch('/api/doa/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    log('布站配置','已保存站点几何；未修改RF标定','本机配置');await load();status('配置已保存。更改实物阵列后仍需核验标定。');toast('A/B站配置已保存');notify();return true;
    }catch(e){status(e.message);toast(e.message);$('station-save').disabled=false;return false;}}
  $('station-choice').onchange=()=>{fill();status('已切换站点，所有草稿仍保留。');};
  function applyRelative(){try{const a=draft.stations.find(s=>s.id==='A'),b=draft.stations.find(s=>s.id==='B');
    Object.assign(b,relativePosition(a,fieldNumber($('station-relative-distance').value),fieldNumber($('station-relative-angle').value),$('station-relative-frame').value));mark();fill();status('B站相对位置已预览，保存配置后生效；B站自身朝向保持原设置。');
    }catch(e){invalid=true;status(e.message);}}
  $('station-relative-distance').onchange=applyRelative;$('station-relative-angle').onchange=applyRelative;
  $('station-relative-frame').onchange=fill;
  $('station-coverage').onchange=()=>{draft.directionMode=$('station-coverage').value;mark();};
  $('station-min-crossing').onchange=()=>{try{const value=fieldNumber($('station-min-crossing').value);if(value<.1||value>30)throw new Error('最小交角需为0.1至30度');draft.minCrossingDeg=value;invalid=false;mark();}catch(e){invalid=true;status(e.message);}};
  for(const id of ['station-heading','station-ray','station-antenna-spacing'])$(id).addEventListener('change',()=>{mark();try{readFields();fill();status('草稿已更新，尚未保存。');}catch(e){invalid=true;status(e.message);}});
  $('station-save').onclick=save;$('station-reload').onclick=()=>{if(dirty){toast('有未保存修改，请先保存或取消草稿');return;}load();};
  $('station-cancel').onclick=()=>{if(saved){draft=structuredClone(saved);dirty=false;invalid=false;fill();$('station-dirty').textContent='草稿已取消';$('station-dirty').classList.remove('dirty');status('已恢复最近保存的配置。');}};
  $('station-unlock').onclick=()=>{unlocked=!unlocked;picking=false;$('station-unlock').textContent=unlocked?'锁定地图编辑':'解锁地图编辑';$('station-unlock').setAttribute('aria-pressed',String(unlocked));$('station-pick').setAttribute('aria-pressed','false');draw();status(unlocked?'当前选中站点可拖动；朝向手柄可旋转。':'地图已锁定。');};
  $('station-pick').onclick=()=>{if(!unlocked){toast('请先解锁地图编辑');return;}picking=!picking;$('station-pick').setAttribute('aria-pressed',String(picking));status(picking?'请在布站地图上点击当前站点位置。':'已取消选点。');};
  map?.on('click',event=>{if(!picking)return;setPosition(event.latlng);picking=false;$('station-pick').setAttribute('aria-pressed','false');});
  $('station-fit').onclick=fit;
  $('anchor-apply').onclick=()=>{try{const latitude=fieldNumber($('anchor-lat').value),longitude=fieldNumber($('anchor-lon').value);if(Math.abs(latitude)>85||Math.abs(longitude)>180)throw new Error('原点经纬度超出范围');draft.anchor={latitude,longitude,source:'用户手动设置'};mark();fill();fit();status('共享原点草稿已改变，整个布局会移动；保存后生效。');}catch(e){status(e.message);}};
  $('station-undo').onclick=async()=>{if(dirty){toast('请先保存或取消当前草稿');return;}try{await jsonFetch('/api/doa/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'undo',expectedRevision:revision})});await load();log('布站配置','已恢复上一次保存的站点几何','本机配置');notify();}catch(e){toast(e.message);}};
  $('station-export').onclick=()=>{if(!saved){toast('配置尚未载入');return;}download('空域知微-站点配置.json',{schema:'airspace.stations',version:1,config:saved});};
  $('station-import').onchange=async event=>{try{const doc=await readJSON(event.target.files[0]);if(doc.schema!=='airspace.stations'||doc.version!==1||!Array.isArray(doc.config?.stations))throw new Error('站点文件格式错误');
    const changes=doc.config.stations;if(new Set(changes.map(s=>s.id)).size!==changes.length)throw new Error('站点ID重复');const copy=structuredClone(draft);
    for(const change of changes){const s=copy.stations.find(s=>s.id===change.id);if(!s)throw new Error('文件包含未知站点');for(const k of ['xM','yM','headingDeg','rayLengthM','antennaSpacingM'])if(k in change){if(change[k]!==null&&!finite(change[k]))throw new Error('站点字段不是有效数字');s[k]=change[k];}}
    if('directionMode' in doc.config){if(!['front','full'].includes(doc.config.directionMode))throw new Error('方位模式无效');copy.directionMode=doc.config.directionMode;}
    if('minCrossingDeg' in doc.config){if(!finite(doc.config.minCrossingDeg)||doc.config.minCrossingDeg<.1||doc.config.minCrossingDeg>30)throw new Error('最小交角无效');copy.minCrossingDeg=doc.config.minCrossingDeg;}
    if(doc.config.anchor){const {latitude,longitude}=doc.config.anchor;if(!finite(latitude)||!finite(longitude)||Math.abs(latitude)>85||Math.abs(longitude)>180)throw new Error('原点无效');copy.anchor={latitude,longitude};}draft=copy;mark();fill();fit();status('文件已作为草稿载入，请核对后保存；接口和RF标定未被导入覆盖。');
    }catch(e){toast(e.message);}finally{event.target.value='';}};
  window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
  load();return {save,load,fit,resize:visible=>{if(typeof visible==='boolean')applyBasemap?.(visible);map?.invalidateSize();},dirty:()=>dirty,cancel:()=>$('station-cancel').click(),cancelPick:()=>{picking=false;$('station-pick').setAttribute('aria-pressed','false');},config:()=>saved};
}
