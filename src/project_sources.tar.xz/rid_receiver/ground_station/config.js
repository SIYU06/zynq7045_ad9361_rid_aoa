// Public browser configuration only. MAPTILER_API_KEY is injected by serve.py.
const osm = '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>';
const esri = '<details class="map-credit"><summary title="Esri World Imagery · Esri, Maxar, Earthstar Geographics, GIS User Community" aria-label="展开地图来源">Esri</summary><span class="map-credit-details"><a href="https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer" target="_blank" rel="noopener">Esri World Imagery</a> · Esri, Maxar, Earthstar Geographics, GIS User Community</span></details>';
const MAX_ZOOM = 22;
export const config = {
  center: [35, 105], zoom: 4,
  maxZoom: MAX_ZOOM,
  staleAfterMs: 15000, maxHistory: 600, ridTrackRetentionMs: 2*60*1000, aoaTrackRetentionMs: 10*1000,
  tileOptions: {updateWhenIdle:true,updateWhenZooming:false,keepBuffer:1},
  maptilerKey: globalThis.GROUND_STATION_CONFIG?.maptilerKey || '',
  maptilerMaps: {dark: 'dataviz-dark', satellite: 'satellite', hybrid: 'hybrid'},
  geocodingUrl: 'https://nominatim.openstreetmap.org/search',
  layers: {
    dark: [{url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      options: {className:'basemap-osm-dark',maxNativeZoom:19,maxZoom:MAX_ZOOM,attribution:osm}}],
    darkFallback:[{url:'https://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
      options:{className:'basemap-osm-dark',maxNativeZoom:19,maxZoom:MAX_ZOOM,attribution:'Tiles &copy; Esri, HERE, Garmin, OpenStreetMap'}}],
    light:[{url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      options:{maxNativeZoom:19,maxZoom:MAX_ZOOM,attribution:osm}}],
    satellite: [{url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      options: {maxNativeZoom: 19, maxZoom: MAX_ZOOM, attribution: esri}}],
    hybrid: [{url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      options: {maxNativeZoom: 19, maxZoom: MAX_ZOOM, attribution: esri}},
    {url: 'https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
      options: {maxNativeZoom: 19, maxZoom: MAX_ZOOM, attribution: 'Labels &copy; Esri, HERE, Garmin, FAO, NOAA, USGS'}}]
  }
};
