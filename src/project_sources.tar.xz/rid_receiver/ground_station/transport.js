import {state,ingestRID,ingestDOA,setConnection,notify} from './data.js';
import {jsonFetch} from './workspace-core.js';
export function startTransport(){
  let epoch=-1,seen=new Map(),failures=0,stopped=false;
  async function poll(){
    const token=state.epoch;
    try{
      if(state.mode!=='external')return;
      if(epoch!==token){seen.clear();epoch=token;}
      const results=await Promise.allSettled([jsonFetch('/api/rid'),jsonFetch('/api/doa'),jsonFetch('/api/receivers')]);
      if(state.mode!=='external'||state.epoch!==token)return;
      for(let i=0;i<2;i++){
        const result=results[i],name=i===0?'rid':'doa';
        if(result.status==='rejected'){state[name+'Feed']={connected:false,error:result.reason.message};setConnection({[name]:false});continue;}
        const feed=result.value;state[name+'Feed']=feed;
        if(i===0){for(const target of feed.targets||[]){const identity=target.id+'@'+(target.sourceMac||'').toLowerCase(),observation=target.observationId??JSON.stringify([target.timestamp,target.positionTimestamp,target.latitude,target.longitude]);if(seen.get(identity)===observation)continue;ingestRID(target);seen.set(identity,observation);if(seen.size>1000)seen.delete(seen.keys().next().value);}}
        else ingestDOA(feed);
        setConnection({[name]:Boolean(feed.connected),source:'OpenWiFi以太网'});
      }
      state.receivers=results[2].status==='fulfilled'?(results[2].value.stations||[]):[];
      failures=results.every(r=>r.status==='rejected')?Math.min(failures+1,4):0;notify();
    }catch(error){failures=Math.min(failures+1,4);if(state.epoch===token&&state.mode==='external')setConnection({rid:false,doa:false,source:'数据格式或接入失败'});
    }finally{if(!stopped)setTimeout(poll,state.mode==='external'?Math.min(1000*2**failures,15000):1000);}
  }
  poll();return ()=>{stopped=true;};
}
