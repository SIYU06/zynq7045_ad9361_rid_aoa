"""Read Windows location once, including its actual provider and uncertainty."""
import json
import math
from pathlib import Path
import subprocess
import sys


def read_windows_location():
    if sys.platform != 'win32':
        return dict(available=False, provider='windows', error='当前系统不支持 Windows 定位')
    try:
        result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive',
            '-ExecutionPolicy', 'Bypass', '-File', str(Path(__file__).with_name('windows_location.ps1'))],
            capture_output=True, encoding='utf-8-sig', errors='replace', timeout=18,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        value = json.loads(result.stdout.strip())
        if value.get('available') is not True:
            return dict(available=False, provider='windows', error=str(value.get('error', '系统定位暂不可用')))
        values = [value.get(k) for k in ('latitude', 'longitude', 'accuracy', 'timestamp')]
        if (any(type(v) not in (int, float) or not math.isfinite(v) for v in values)
                or abs(values[0]) > 90 or abs(values[1]) > 180 or values[2] < 0):
            raise ValueError('系统返回的位置数据无效')
        return dict(available=True, provider='windows', source=value.get('source', 'Unknown'),
                    latitude=values[0], longitude=values[1], accuracy=values[2], timestamp=values[3])
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return dict(available=False, provider='windows', error=str(exc))
