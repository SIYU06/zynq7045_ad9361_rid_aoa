"""PC coordination/scheduling and AoA; signal recognition is provided by A Linux."""
import copy
import hashlib
import json
import threading
import time
from urllib.parse import urlsplit
from urllib.request import Request
from urllib.error import HTTPError,URLError
from processing_pipeline import ProcessingPipeline
from reference_calibration import verify_observation_reference
from board_doa import verify_observation_context
from pathlib import Path

SCHEMA='airspace.board-recognition.v1'

def recognition_urls(stations):
    result={}
    for station,url in stations.items():
        parsed=urlsplit(url);result[station]='%s://%s:18789'%(parsed.scheme,parsed.hostname)
    return result

class BoardRecognitionPipeline(ProcessingPipeline):
    def __init__(self,signals,doa,rid=None):
        super().__init__(signals,doa,rid)
        self.recognition_urls=recognition_urls(self.url_by_station);self.recognition={};self.recognition_received=None
        self.last_relay_signature=None;self.relay_receipt=None;self.board_event_keys={}
    def request(self,url,body=None,raw=False):
        data=json.dumps(body,allow_nan=False).encode() if body is not None else None
        request=Request(url,data=data,headers={'Content-Type':'application/json'} if data else {})
        with self.opener.open(request,timeout=2) as response:value=response.read(4*1024*1024+1)
        if len(value)>4*1024*1024:raise ValueError('Oversized board response')
        return value if raw else json.loads(value)
    def read_recognition(self):
        # The PC does not inspect frames or evaluate recognition rules.
        if 'B' in self.recognition_urls:
            try:
                producer=self.request(self.recognition_urls['B']+'/api/recognition/status')
                if producer.get('schema')!=SCHEMA or producer.get('station')!='B' or producer.get('errors'):raise ValueError('B decoded-feed service unavailable')
                bundle=producer.get('relayBundle')
                if bundle and bundle.get('signature')!=self.last_relay_signature:
                    digest=hashlib.sha256(json.dumps(bundle,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')).hexdigest()
                    ack=self.request(self.recognition_urls['A']+'/api/recognition/feed',bundle)
                    if ack.get('accepted') is not True or ack.get('digest')!=digest:raise ValueError('Decoded-feed relay not acknowledged unchanged')
                    self.last_relay_signature=bundle['signature'];self.relay_receipt=dict(source='B',destination='A',digest=digest,acknowledged=True)
                self.errors.pop('recognition-feed',None)
            except Exception as exc:self.errors['recognition-feed']=str(exc)
        value=self.request(self.recognition_urls['A']+'/api/recognition/status')
        if value.get('schema')!=SCHEMA or value.get('station')!='A' or value.get('processingLocation')!='board':raise ValueError('A station recognition service is required; no PC recognition fallback')
        if value.get('errors'):raise ValueError('A recognition: '+str(value['errors']))
        self.recognition=value;self.recognition_received=time.time()*1000
        self.errors.pop('recognition',None);self.errors.pop('pipeline',None)
        return value
    def classify(self):
        try:current=self.read_recognition()
        except Exception as exc:
            self.errors['recognition']=str(exc);self.recognition={};self.recognition_received=None
            with self.lock:self.sources=[];self.active=None;self.angles.clear()
            self.doa.set_diagnostic_target(None)
            raise
        rows=copy.deepcopy(current.get('sources',[]))
        if not current.get('inputAvailable'):rows=[]
        for item in rows:
            key=item['key'];dsss_only=not item.get('doaSupported',True);positioning=item.get('positioning',{})
            now=time.time()*1000
            if key in self.last_results and not dsss_only and positioning['method']!='rid':
                result=self.last_results[key]
                valid_cache=True
                for station,observation in result.get('stations',{}).items():
                    if observation.get('processingLocation')=='board':
                        try:
                            setup=next(s for s in self.doa.config().get('stations',[]) if s['id']==station)
                            verify_observation_context(observation,setup,Path(__file__).resolve().parent)
                        except (ValueError,KeyError,OSError,TypeError,StopIteration):
                            valid_cache=False;self.angles.pop(station,None)
                    if observation.get('calibrationStatus')!='provisional_reference':continue
                    try:
                        setup=next(s for s in self.doa.config().get('stations',[]) if s['id']==station)
                        verify_observation_reference(observation,setup,Path(__file__).resolve().parent)
                    except (ValueError,KeyError,OSError,TypeError,StopIteration):
                        valid_cache=False;self.angles.pop(station,None)
                if valid_cache:
                    item['direction']=copy.deepcopy(result)
                    item['stages']['direction']='diagnostic' if now-result['timestamp']<15000 else 'stale'
                else:
                    self.last_results.pop(key,None)
        for event in current.get('events',[]):
            identity=(current['sessionId'],event['monotonic'],event.get('sourceKey'),event['kind'])
            if identity not in self.board_event_keys:
                self.event(dict(event,timestamp=time.time()*1000-max(0,current['generatedMonotonic']-event['monotonic'])*1000,processingLocation='board',recognitionStation='A'))
                self.board_event_keys[identity]=None
        while len(self.board_event_keys)>512:self.board_event_keys.pop(next(iter(self.board_event_keys)))
        with self.lock:self.sources=rows
        return rows
    def snapshot(self):
        value=super().snapshot()
        value.update(recognition=dict(location='board',station='A',state=self.recognition.get('state','unavailable'),sourceStation=self.recognition.get('sourceStation'),counters=self.recognition.get('counters',{}),relay=self.relay_receipt),
                     control=dict(schedulerLocation='pc',scanCoordinatorLocation='pc',recognitionLocation='board',recognitionStation='A',pcFrameRecognition=False,rawIQTransport=False))
        return value
    def import_capture(self,data,openwifi=False):
        request=Request(self.recognition_urls['A']+'/api/recognition/import?fcs='+('device' if openwifi else 'standard'),data=data,headers={'Content-Type':'application/octet-stream'})
        try:
            with self.opener.open(request,timeout=30) as response:value=response.read(4*1024*1024+1)
        except HTTPError as exc:
            detail=exc.read(4096).decode('utf8',errors='replace')
            raise ValueError('Board capture import failed: '+detail) from exc
        except (URLError,OSError) as exc:raise ValueError('A capture import service unavailable: '+str(exc)) from exc
        if len(value)>4*1024*1024:raise ValueError('Oversized imported capture result')
        return json.loads(value)
    def rid_snapshot(self):
        current=self.recognition;value=copy.deepcopy(current.get('rid'))
        connected=bool(value and current.get('inputAvailable') and self.recognition_received and time.time()*1000-self.recognition_received<5000)
        if not value:return dict(configured=True,connected=False,targets=[],mode='live',stations=[],status='等待A站识别结果',receiverSelection=self.signals.selection.snapshot() if self.signals.selection else None)
        base=self.recognition_received
        for target in value['targets']:
            target['timestamp']=base+target['timestamp']
            if target.get('positionTimestamp') is not None:target['positionTimestamp']=base+target['positionTimestamp']
        value.update(configured=True,connected=connected,stations=[dict(id=current.get('sourceStation'),connected=connected,sessionId=value.get('sessionId'))],receiverSelection=self.signals.selection.snapshot() if self.signals.selection else None)
        if not connected:value['targets']=[]
        return value

class BoardRIDView:
    def __init__(self,pipeline):self.pipeline=pipeline;self.url=pipeline.recognition_urls.get('A');self.stop=threading.Event()
    def run(self):self.stop.wait()
    def snapshot(self):return self.pipeline.rid_snapshot()
