@echo off
cd /d "%~dp0"
if not defined OPENWIFI_RID_URL set "OPENWIFI_RID_URL=http://169.254.92.202:18771"
echo Airspace ground station: http://127.0.0.1:18770/#/home
echo Open this URL in a browser. Press Ctrl+C to stop.
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 serve.py
) else if exist "D:\Python38-32\python.exe" (
  "D:\Python38-32\python.exe" serve.py
) else (
  python serve.py
)
pause
