"""Local metre geometry for forward-bearing intersections."""
import math

R=6378137.0


def geographic(anchor,x,y):
    if not anchor or anchor.get('latitude') is None or anchor.get('longitude') is None: return None,None
    lat=float(anchor['latitude']); lon=float(anchor['longitude'])
    return lat+math.degrees(y/R),lon+math.degrees(x/(R*math.cos(math.radians(lat))))


def intersect(a,b,min_crossing_deg=5,max_time_diff_ms=2000):
    if a.get('targetId')!=b.get('targetId') or not a.get('targetId'): return None,'两站目标尚未可靠关联'
    if a.get('frameKey') and b.get('frameKey') and a['frameKey']!=b['frameKey']: return None,'等待同一空口帧的双站观测'
    if not a.get('fresh') or not b.get('fresh'): return None,'等待两站新观测'
    if abs(a['timestamp']-b['timestamp'])>max_time_diff_ms: return None,'两站观测时间差过大'
    if a.get('bearing') is None or b.get('bearing') is None: return None,'等待站点朝向'
    if a.get('xM') is None or a.get('yM') is None or b.get('xM') is None or b.get('yM') is None: return None,'等待站间几何配置'
    angle1=math.radians(a['bearing']); angle2=math.radians(b['bearing'])
    u=(math.sin(angle1),math.cos(angle1)); v=(math.sin(angle2),math.cos(angle2))
    cross=u[0]*v[1]-u[1]*v[0]
    if abs(cross)<math.sin(math.radians(min_crossing_deg)): return None,'两条方位线接近平行'
    dx=b['xM']-a['xM']; dy=b['yM']-a['yM']
    if math.hypot(dx,dy)<.05: return None,'两站基线未建立'
    t=(dx*v[1]-dy*v[0])/cross; s=(dx*u[1]-dy*u[0])/cross
    if t<0 or s<0: return None,'交点位于测向站背后'
    return dict(xM=a['xM']+t*u[0],yM=a['yM']+t*u[1],rangeAM=t,rangeBM=s,
                crossingAngleDeg=math.degrees(math.asin(min(1,abs(cross))))),None


def bearing_solutions(station):
    """A horizontal two-element array measures sin(theta), not a unique 360-degree bearing."""
    angle=station.get('relativeAngle');heading=station.get('headingDeg')
    if angle is None or heading is None:
        return [dict(bearingDeg=station['bearing'],branch='provided')] if station.get('bearing') is not None else []
    values=[dict(bearingDeg=(heading+angle)%360,branch='front'),
            dict(bearingDeg=(heading+180-angle)%360,branch='back')]
    if abs((values[0]['bearingDeg']-values[1]['bearingDeg']+180)%360-180)<1e-8:return values[:1]
    return values


def midpoint_origin(a,b):
    if any(s.get(k) is None for s in (a,b) for k in ('xM','yM')):return None
    return dict(xM=(a['xM']+b['xM'])/2,yM=(a['yM']+b['yM'])/2)


def relative_to_midpoint(point,origin):
    return dict(xM=point['xM']-origin['xM'],yM=point['yM']-origin['yM']) if origin else None


def intersect_candidates(a,b,min_crossing_deg=1,max_time_diff_ms=2000):
    points=[];reason='等待候选方位线交汇'
    for first in bearing_solutions(a):
        for second in bearing_solutions(b):
            point,error=intersect(dict(a,bearing=first['bearingDeg']),dict(b,bearing=second['bearingDeg']),min_crossing_deg,max_time_diff_ms)
            if not point:reason=error;continue
            if any(math.hypot(point['xM']-p['xM'],point['yM']-p['yM'])<.001 for p in points):continue
            point.update(candidateId=first['branch']+'-'+second['branch'],
                         branches={a.get('id','A'):first['branch'],b.get('id','B'):second['branch']},
                         geometryQuality='weak' if point['crossingAngleDeg']<5 else 'normal')
            points.append(point)
    for point in points:point.update(ambiguous=len(points)>1,resolved=len(points)==1)
    return points,None if points else reason
